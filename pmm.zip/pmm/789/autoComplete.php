<?php
include"../interno/input_banco.php";

	
	
ini_set('default_charset','UTF-8'); // Para o charset das páginas e
mysql_set_charset('utf8'); // para a conexão com o MySQL
error_reporting(0);
$q = strtolower($_GET["q"]);
if (!$q) return;

		$query_noticias = "select DISTINCT cbo from cbo where cbo LIKE '%$q'";	
		$rs_noticias    = mysql_query($query_noticias); 		
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$id= $campo_noticias['id']; 
		$cbo= $campo_noticias['cbo']; 
		$codigocbo= $campo_noticias['codigocbo']; 
	
	echo "$codigocbo $cbo\n";
}
?>