<?php
$host="localhost"; // SERVIDOR E PORTA UTILIZADA   
$db_name="semtre"; // BASE DE DADOS 
$username="root"; // USUÁRIO DO MYSQL
$password="web"; // SENHA DO MYSQL



	$con = mysql_connect($host,$username,$password)   or die(mysql_error());
	mysql_select_db($db_name, $con)  or die(mysql_error());

	
	
ini_set('default_charset','UTF-8'); // Para o charset das páginas e
mysql_set_charset('utf8'); // para a conexão com o MySQL

$q = strtolower($_GET["q"]);
if (!$q) return;

$sql = "select DISTINCT cbo from cbo where cbo LIKE '%$q'";
$rsd = mysql_query($sql);
while($rs = mysql_fetch_array($rsd)) {
	$cname = $rs['cbo'];
	
	echo "<option>$cname</option>\n";
}
?>