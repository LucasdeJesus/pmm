
<html>
<?include'topo.php';?>

<body>
	<?include"topo_logo.php";
	
	?>


	<?
	$diahoje = date("d");
	$meshoje = date("m");
	if($meshoje =="01"){$meshoje="0";}
	$anohoje = date("Y");
	?>
	<!--------------------valida cpf--------------->										
<script language="JavaScript">
function validar_cpf(){
var cpf_busca = document.cadastro.cpf_busca.value;
var datanascimento = document.cadastro.datanascimento.value;
var nome = document.cadastro.nome.value;
var telcel = document.cadastro.telcel.value;

	
	var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
	if(!filtro.test(cpf_busca)){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	
	
	
	if(datanascimento=="" || datanascimento < 6){
	window.alert("Favor Informe Data Nascimento.");
	return false;
	}
	
	if(nome=="" || nome < 8){
	window.alert("Favor Informe Nome.");
	return false;
	}
	
	
	if(telcel=="" || telcel < 8){
	window.alert("Favor Informe Celular.");
	return false;
	}
	

	cpf_busca = remove(cpf_busca, ".");
	cpf_busca = remove(cpf_busca, "-");

	if(cpf_busca.length != 11 || cpf_busca == "00000000000" || cpf_busca == "11111111111" ||
	cpf_busca == "22222222222" || cpf_busca == "33333333333" || cpf_busca == "44444444444" ||
	cpf_busca == "55555555555" || cpf_busca == "66666666666" || cpf_busca == "77777777777" ||
	cpf_busca == "88888888888" || cpf_busca == "99999999999"){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}

	soma = 0;
	for(i = 0; i < 9; i++)
	soma += parseInt(cpf_busca.charAt(i)) * (10 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(9))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	soma = 0;
	for(i = 0; i < 10; i ++)
	soma += parseInt(cpf_busca.charAt(i)) * (11 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(10))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	return true;
  
}

	function remove(str, sub) {
	i = str.indexOf(sub);
	r = "";
	if (i == -1) return str;
	r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
	return r;
	}
	
</script>
  

	
		
		
		
				<table>	
				<tr>	
				<td>	
				
				<?$tipoatendimento = $_GET['tipo'];?>
				<form  class="form" method="post" action="agendamentoescolhedia.php"  id="cadastro" name='cadastro' >	
				<h3>Atendimento Agendado - Emissão de Carteira de Trabalho e Previdência Social - CTPS </h3>
				
				<div>
						<p><b>Emissão de Carteira de Trabalho - DOCUMENTAÇÃO</b></p>
						<p><br><br>
						<font style="color:red;"><b>1ª Via</b></font><br><br>
						<b>1. </b>CPF - Cadastro de Pessoa Física<br>
						<b>2.</b> RG - Cédula de Identidade ou CN - Certidão de Nascimento ou CC - Certidão de Casamento ou RES - Certificado de 
							Reservista ou OAB - Carteira da OAB ou CREA - Carteira do CREA<br>
						<b>3. </b>OBS - Observação<br>
						&nbsp;	&nbsp;	&nbsp;	&nbsp;- CNH - Carteira Nacional de Habilitação não é aceita como documento de identificação para emissão da CTPS<br>
						<b>4. </b>CC - Certidão de Casamento<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Caso o solicitante seja casado.<br>
						<b>5.</b> 2 Fotos - Fotos 3x4<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Com fundo branco, com ou sem data, colorida e recente, que identifique plenamente o solicitante.<br>
						<b>6.</b> CR - Comprovante de Residência<br>
						O comprovante deve possuir o numero do CEP.<br>
						
						</p>
						
						<p><br><br>
						<font style="color:red;"><b>2ª Via</b></font><br><br>
						<b>1.</b> Todos - Todos os itens da 1ª via<br>
						<b>2.</b> CTPS - Carteira de Trabalho e Previdência Social<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;Carteira de Trabalho anterior em caso de inutilização ou continuação.<br>
						<b>3.</b> BO - Boletim de Ocorrência<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;Boletim de Ocorrência em caso de perda, roubo ou furto da CTPS.<br>
						<b>4.</b> DOC - Documento que comprove o número da Carteira de Trabalho anterior<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Carteira de Trabalho ou;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato FGTS ou;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Rescisão do Contrato de Trabalho.<br>
						<font style="color:red;"><b>5.</b> OBS - Observação<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;CNH - Carteira Nacional de Habilitação não é aceita como documento de identificação para emissão da CTPS</font>
						
						</p>
				</div>		
				
					<h3>Informe dados para Agendamento </h3>
					
				<b>Li e concordo com os termos acima Solicitação de Documentos : <input type="checkbox" value="S" name="checkbox"/></b>
				<div class="form-row">
				<div class="label">CPF: <font class='simbolo'>&#10045;</font> </div>
				<div class="input-container"><input onclick="if(!this.form.checkbox.checked){alert('Marque Li e concordo com os termos acima Solicitação de Documentos');return false}" onBlur="maiuscula(this)" onBlur="maiuscula(this)" onBlur="return validar_cpf()" name="cpf_busca" id='cpf_busca' placeholder="Insira o CPF" type="text"  class="input req-same" maxlength="14"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label">Nome <font class='simbolo'>&#10045;</font> </div>
				<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" onclick="if(!this.form.checkbox.checked){alert('Marque Li e concordo com os termos acima Solicitação de Documentos');return false}"name="nome" required  value='<?=$nome;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label">Data Nascimento <font class='simbolo'>&#10045;</font> </div>
				<?$datanascimento2 = implode('/',array_reverse(explode('-',$datanascimento)));?>
				<div class="input-container"><input onBlur="VerificaData(this.value);" name="datanascimento" id='datanascimento'required  onclick="if(!this.form.checkbox.checked){alert('Marque Li e concordo com os termos acima Solicitação de Documentos');return false}"value='<?=$datanascimento2;?>' type="text"    class="input req-same"  /></div>
				</div>
										
				
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container"   style='width:546px;'>
				Tel.: Residencial
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telres" id="telres" value="<?=$telres;?>"   class="input req-same"    tabindex="34" style="width:100px;" type="text" /> 
				&nbsp;Celular <font class='simbolo'>&#10045;</font> 
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telcel" required id="telcel" value="<?=$telcel;?>"  class="input req-same" tabindex="35" style="width:99px;" type="text" />
				
				</div>
				</div>
				
				
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container" style='width:546px;'>		
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" id="submitBtn2" value="Enviar" type="submit" class="sendBtn"  onclick='return validar_cpf()' />
				<div id="errorDiv2" class="error-div"></div>
				</div>
				</div>
				<input type='hidden' name='buscaform' value='b'>
				<input type='hidden' name='tipoatendimento' value='<?=$tipoatendimento;?>'>

										
				
				</form>
				</td>
				</tr>
			</table>	
			
		
		
		
		
			<?include"rodape_novo.php";?>
	
</body>
</html>