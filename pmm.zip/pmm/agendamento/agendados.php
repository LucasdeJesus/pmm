<?include("../seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<html lang="en" class="no-js">
<!--<![endif]-->


<!-- Mirrored from www.scoopthemes.com/templates/Oleose/Freeze/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Sep 2015 12:49:54 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<body>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.js"></script>
    <script src="glDatePicker.min.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	<?
	$diahoje = date("d");
	$meshoje = date("m");
	if($meshoje =="01"){$meshoje="0";}else{$meshoje=$meshoje-1;}
	$anohoje = date("Y");
	?>
  <script type="text/javascript">
        $(window).load(function()
{
	
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// Example #4 - Day of week offset and restricting date selections
	$('#example4d').glDatePicker(
	{
	
		
		showAlways: true,
		//selectedDate: new Date(<?=$anohoje;?>, <?=$meshoje;?>, <?=$diahoje;?>),
		//dowOffset: true,
		//selectableYears: true,
		//selectableMonths: true,
		//selectableDOW: [2,3,4,5,6],
		
		
		specialDates: [
		
				<?
				$query_estado_db = "SELECT * FROM `diaagendamento` where status='A' ";
				$rs_estado_db     = mysql_query($query_estado_db );
				while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
				$datadisponivel        = $campo_estado_db ['data'];
				$pieces = explode("-", $datadisponivel);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia
				$diasoma = $pieces[1] - 1;
				//$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				?>
				{ date: new Date(<?=$pieces[0];?>, <?=$diasoma?>, <?=$pieces[2];?>), repeatMonth: false },
				<?}?>
				
		],
	
	
    onClick: function(target, cell, date, data) {
	
        target.val(date.getFullYear() + '-' +
                    date.getMonth() + '-' +
                    date.getDate());

        if(data != null) {
            alert(data.message + '\n' + date);
        }
		
		
		var valorinput = $('#example4d').val();
		 $( "#opcaoagendamento" ).show();
		 $( "#dataselecionada" ).val(valorinput);
		//Abrir_Pagina("trabalhadores_agendado.php?dia="+valorinput+"");
		/*var txt;
		var r = confirm( "Deseja Desativar está data?");
		if (r == true) {
		   $.ajax({
				url: 'script.php?dia='+ valorinput+'&acao=excluir&quatidadedia='+quatidadedia,
				success: function(data) {
				alert(data);
				 window.setTimeout('location.reload()', 300);	
				}
				
				});
		} else {
			
		}*/
		
		
		
		
    }
	
	//alert("oi");
	});

});

		function Abrir_Pagina(URL) {
			var valorinput = $('#example4d').val();	
		  window.open(URL+"&dia="+valorinput,'','scrollbars=yes,width=500,height=500');      
		} 

    </script>
	

<table width="900px ">
	
	
	
	<tr>
	
	
	
	
	<td>
			<h3 style="width:400px;">Datas disponíveis  para agendamento </h3>
		<input type="text" id="example4d"  readonly="true" style="width:400px;"gldp-id="gldp-62714503052" class="gldp-el">
		<div gldp-el="example4d"
			 style=" height:300px; position:absolute; top:70px; left:100px;">
		</div>
		
		
	</td>
	
	<td>
			<div id='opcaoagendamento' style='display:none'>
				<h3 style="width:400px;">Escolha tipo de agendamento</h3>
				<form  class="form">	
				<p style="margin:5px"><a href="#" Onclick="Abrir_Pagina('trabalhadores_agendado.php?tipo=V');"  class="sendBtn">Vagas de Emprego</a><br></p>
				<p style="margin:5px"><a href="#" Onclick="Abrir_Pagina('trabalhadores_agendado.php?tipo=D');"  class="sendBtn">DETRAN</a><br></p>
				<p style="margin:5px"><a href="#" Onclick="Abrir_Pagina('trabalhadores_agendado.php?tipo=C');"  class="sendBtn">CTPS</a></p>
				</form>
			</div>
		
		
	</td>
	
 </tr>
</table>

</body>
</html>