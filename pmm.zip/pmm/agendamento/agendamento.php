<?include("../interno/input_banco.php"); // Inclui o arquivo com o sistema de segurança

?>
<html lang="en" class="no-js">
<!--<![endif]-->


<!-- Mirrored from www.scoopthemes.com/templates/Oleose/Freeze/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Sep 2015 12:49:54 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<body style="background-color:transparent" >


<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	

		
	<?include'../interno/topo.php';?>	
	<?
	$tipoget = $_GET['tipo'];
	$diahoje = date("d");
	$meshoje = date("m");
		if($meshoje =="01"){$meshoje="0";}else{$meshoje=$meshoje-1;}
	$anohoje = date("Y");
	
	
	if($tipoget=="D"){ $menianohj= $anohoje; }else{ $menianohj= $anohoje - 15 ;}
	?>
	
	
	
	<script type="text/javascript" src="../jquery.reveal.js"></script>
	<script type="text/javascript" src="../jquery.validate.js" ></script>
	<script src="../jquery.maskMoney.js" type="text/javascript"></script>
	<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
	
	
	
	<!--------------------valida cpf--------------->										
<script language="JavaScript">

$(document).ready(function(){									
										$("#cadastro").validate();										
										$.validator.setDefaults({
									submitHandler: function() {
										
										}
										});
					});
						

				
										
function validar_cpf(){
	
	
var cpf_busca = document.cadastro.cpf_busca.value;
var datanascimento = document.cadastro.datanascimento.value;
var nome = document.cadastro.nome.value;
var telcel = document.cadastro.telcel.value;
var email = document.cadastro.email.value;
var checkbox = document.cadastro.checkbox.value;
var d = document.cadastro;

	
	var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
	if(!filtro.test(cpf_busca)){
	//window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	<?if($tipoget=="D"){?>
	document.getElementById("msg").innerHTML = "CPF INVÁLIDO.Menor de 14 anos Informar CPF do responsavel";		
	<?}else{?>
	document.getElementById("msg").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
	<?}?>
	return false;
	}
	
	

	cpf_busca = remove(cpf_busca, ".");
	cpf_busca = remove(cpf_busca, "-");

	if(cpf_busca.length != 11 || cpf_busca == "00000000000" || cpf_busca == "11111111111" ||
	cpf_busca == "22222222222" || cpf_busca == "33333333333" || cpf_busca == "44444444444" ||
	cpf_busca == "55555555555" || cpf_busca == "66666666666" || cpf_busca == "77777777777" ||
	cpf_busca == "88888888888" || cpf_busca == "99999999999"){
	//window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	<?if($tipoget=="D"){?>
	document.getElementById("msg").innerHTML = "CPF INVÁLIDO.Menor de 14 anos Informar CPF do responsavel";		
	<?}else{?>
	document.getElementById("msg").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
	<?}?>
	return false;
	}

	soma = 0;
	for(i = 0; i < 9; i++)
	soma += parseInt(cpf_busca.charAt(i)) * (10 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(9))){
//	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
<?if($tipoget=="D"){?>
	document.getElementById("msg").innerHTML = "CPF INVÁLIDO.Menor de 14 anos Informar CPF do responsavel";		
	<?}else{?>
	document.getElementById("msg").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
	<?}?>
	return false;
	}
	soma = 0;
	for(i = 0; i < 10; i ++)
	soma += parseInt(cpf_busca.charAt(i)) * (11 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(10))){
	//window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	<?if($tipoget=="D"){?>
	document.getElementById("msg").innerHTML = "CPF INVÁLIDO.Menor de 14 anos Informar CPF do responsavel";		
	<?}else{?>
	document.getElementById("msg").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
	<?}?>
	return false;
	}
	return true;
  
}

	function remove(str, sub) {
	i = str.indexOf(sub);
	r = "";
	if (i == -1) return str;
	r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
	return r;
	}
	
</script>
  <script type="text/javascript">
        $(window).load(function()
{
		
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// Example #4 - Day of week offset and restricting date selections
	$('#example4d').glDatePicker(
	{
	
		
		showAlways: true,
		selectedDate: new Date(<?=$anohoje;?>, <?=$meshoje;?>, <?=$diahoje;?>),
		//dowOffset: true,
		//selectableYears: true,
		//selectableMonths: true,
		//selectableDOW: [2,3,4,5,6],
		
		
		selectableDates: [
		
				<?
				$query_estado_db = "SELECT * FROM `diaagendamento` where status='A' ";
				$rs_estado_db     = mysql_query($query_estado_db );
				while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
				$datadisponivel        = $campo_estado_db ['data'];
				$pieces = explode("-", $datadisponivel);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia
				$diasoma = $pieces[1] - 1;
				//$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				?>
				{ date: new Date(<?=$pieces[0];?>, <?=$diasoma?>, <?=$pieces[2];?>) },
				<?}?>
				
		],
	
	
    onClick: function(target, cell, date, data) {
	
        target.val(date.getFullYear() + '-' +
                    date.getMonth() + '-' +
                    date.getDate());

        if(data != null) {
            alert(data.message + '\n' + date);
        }
		
		
		var valorinput = $('#example4d').val();
		
		var txt;
		var r = confirm( "Deseja Desativar está data?");
		if (r == true) {
		 /*  $.ajax({
				url: 'script.php?dia='+ valorinput+'&acao=excluir&quatidadedia='+quatidadedia,
				success: function(data) {
				alert(data);
				 window.setTimeout('location.reload()', 300);	
				}
				
				});*/
		} else {
			
		}
		
		
		
		
    }
	
	//alert("oi");
	});

});


    </script>
<script type="text/javascript">		
		$(function() {
		$("#datanascimento1").datepicker({
		changeMonth: true,
		changeYear: true,
		yearRange: '1900:<?=$menianohj;?>',
		dateFormat: 'dd/mm/yy',
        dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
        dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
        dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
        monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
        monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
		});
		});

		
			$(document).ready(function(){	$("#datalimiteencaminhar").mask("99/99/9999");});			
			$(document).ready(function(){	$("#datanascimento").mask("99/99/9999");});			
			$(document).ready(function(){	$("#datanascimento1").mask("99/99/9999");});
	

	function calculaIdade(data,dataHoje) {

             x = data.split("/");
             h = dataHoje.split("/");

             if(x[0] > 31 || x[1] > 12 || x[2] > h[2]) {
                 //alert('Data de Nascimento inv&#30109;ida!');
                 return 0;
             }

             anosProvisorio = h[2] - x[2];
            
            if(h[1] < x[1]) {
                 anosProvisorio -= 1;
             }
             else if(h[1] == x[1]) {
                 if(h[0] < x[0]) {
                     anosProvisorio -= 1;
                 }
             }

            if(anosProvisorio < 14){
				document.getElementById("msgidade").innerHTML = "Não Permitido para menores de 14 anos";				
				document.getElementById("datanascimento1").value = "";				
			}else{
				
				document.getElementById("msgidade").innerHTML = "";				
			}
         }

	  </script>
	
	

		
		
		
<div id="content" name='contente' >
<div id="container">
<?include'topo.php'?>
		<div id="bg-container"   class='contener'>
					
			
			
			
				<table width='960px' align='center'>
					<tr>
					
						<td width='460'>
						<div style='height:225px;border: 3px dotted  red;margin:10px;border-radius: 5px;margin-top:10px;color:red;padding:15px;font-size:13px'>
							<h2>Comunicado Importante!</h2>
							<p >A partir do dia 21/02/17 o agendamento será liberado no horário das 6:30h. para o agendamento do dia seguinte.</b> 
							</p><br><br>
							
						</div>	
						</td>
						
						<td width='460'>
							<iframe src="https://www.google.com/maps/d/embed?mid=zUY1owRsQ2QI.kr-yOs1VzKb4" width="460" height="270"></iframe>
						</td>
					</tr>	
			</table>
			
			
				<form  class="form" method="post" action="agendamentoescolhedia.php"  id="cadastro" name='cadastro' >	
				
	<div style='background-color:#fff;padding:10px'>		
				<?if($tipoget=="C"){?>
				
				<!--------------------------------------->
				<h3>por meio do instrumento de convênio de cooperação nº 46670,002079/2013-44, do trabalho e o municipio de Macaé, firmam parceria para a emissão da carteira de Trabalho (CTPS)  </h3>
				<h3>Atendimento Agendado - Emissão de Carteira de Trabalho e Previdência Social - CTPS </h3>
				
				<div>
						<p><b>Emissão de Carteira de Trabalho - DOCUMENTAÇÃO</b></p>
						<p><br><br>
						
						<h4> Para emissão de CTPS favor observar vestuário devido à restrições para a fotografia. </h4>
						<font style="color:red;"><b>Usar vestimentos:</b></font><br><br>
							<p>Mais Fechada</p>
							<p>Mais Discreta</p>
							<p>Sem Estampas</p>
							<p>Sem Propagandas, camisa de times , uniformes escolares ou empresa </p>
							<p>Não usar veste Branca </p><br>
						
						
						
						
						<font style="color:red;"><b>1ª Via (Documentos Originais )</b></font><br><br>
						<b>1. </b>CPF - CADASTRO DE PESSOA FISICA <br>
						<b>2.</b> DOCUMENTO OFICIAL DE IDENTIFICAÇÃO CIVIL QUE CONTENHA NOME DO INTERESSADO, DATA, MUNICÍPIO E ESTADO DE NASCIMENTO, FILIAÇÃO, NOME DO DOCUMENTO COM ÓRGÃO EMISSOR E DATA DE EMISSÃO<br>
						<b>3. </b>CERTIDÃO DE NASCIMENTO OU CERTIDÃO DE CASAMENTO<br><I>OBS: CASO SEPARADO(A) JUDICIALMENTE CERTIDÃO AVERBADA</I>
						
						<br><br>
						<b>4.</b>COMPROVANTE DE RESIDÊNCIA <br>
						O comprovante deve possuir o numero do CEP.<br><I>OBS:O COMPROVANTE DEVE POSSUIR NÚMERO DO CEP</I>
						
						</p>
						
						<p><br><br>
						<font style="color:red;"><b>2ª Via</b></font><br><br>
						<b>1.</b> TODOS DOCUMENTOS NECESSÁRIO PARA 1º VIA<br>
						
						<b>1.1 </b>CPF - CADASTRO DE PESSOA FISICA <br>
						<b>1.2.</b> DOCUMENTO OFICIAL DE IDENTIFICAÇÃO CIVIL QUE CONTENHA NOME DO INTERESSADO, DATA, MUNICÍPIO E ESTADO DE NASCIMENTO, 			FILIAÇÃO, NOME DO DOCUMENTO COM ÓRGÃO EMISSOR E DATA DE EMISSÃO<br>
						<b>1.3. </b>CERTIDÃO DE NASCIMENTO OU CERTIDÃO DE CASAMENTO<br><I>OBS: CASO SEPARADO(A) JUDICIALMENTE CERTIDÃO AVERBADA</I>
						
						<br><br>
						<b>1.4.</b>COMPROVANTE DE RESIDÊNCIA <br>
						O comprovante deve possuir o numero do CEP.<br><I>OBS:O COMPROVANTE DEVE POSSUIR NÚMERO DO CEP</I>
						
						</p>
						
						<b>2.</b> Carteira de Trabalho e Previdência Social<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;Carteira de Trabalho anterior em caso de inutilização ou continuação.<br>
						<b>3.</b> BO - Boletim de Ocorrência<br>
						
							&nbsp;	&nbsp;	&nbsp;	&nbsp;Boletim de Ocorrência em caso de perda, roubo, furto ou danos da CTPS.<br>
						<B><b>4.</b> DOC - Documento que comprove o número da Carteira de Trabalho anterior<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Carteira de Trabalho ou;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- CNIS;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato Análitico;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato FGTS ou;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Rescisão do Contrato de Trabalho.<br></B>
						<font style="color:red;"><b>5.</b> OBS - Observação<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;CNH - Carteira Nacional de Habilitação não é aceita como documento de identificação para emissão da CTPS</font>
						
						</p>
				</div>		
				<?}?>
				
				
				
				<?if($tipoget=="D"){?>
				<!-- titulo conteúdo -->


						<h2 class="content-title">
						  Identificação Civil    </h2>
					 
					  



					<!-- banner -->


					<!-- conteúdo -->

					  <p>Por meio do Instrumento de convênio de cooperação nº 027/2011, O Detran eo  municipio de Macaé, firmam parceria para a emissão da carteira de Identidade(RG)<br>
					&nbsp;</p>
					<p><u><strong>DOCUMENTOS NECESSÁRIOS PARA 1º VIA </strong></u><br>
					<br>
					O requerente deverá apresentar original e cópia ou cópia autenticada dos documentos:<br>
					&nbsp;</p>
					<p><em><strong>DOCUMENTOS OBRIGATÓRIOS</strong></em></p>
					<ul>
						<li><em>Solteiros: </em>certidão de nascimento.</li>
						<li><em>Casados:</em> certidão de casamento.</li>
						<li><em>Estrangeiros naturalizados</em>: certificado de naturalização.</li>
						<li><em>Portugueses com igualdade de direitos:</em> certificado de igualdade&nbsp;de direitos e obrigações civis.</li>
					</ul>
					<br>
					<br>
					<p><em><strong>DOCUMENTOS OPCIONAIS</strong></em></p>
					<ul>
						<li>CPF</li>
						<li>PIS/PASEP</li>
						
					</ul>
					<p>&nbsp;</p>
					<p><u><strong>DOCUMENTOS NECESSÁRIOS PARA 2ª VIA </strong></u><strong><br>
					</strong><br>
					O requerente deverá apresentar original e cópia ou cópia autenticada dos documentos, a copia ficara retido no DETRAN :<br>
					&nbsp;</p>
					<p><strong><em>DOCUMENTOS OBRIGATÓRIOS</em></strong></p>
					<ul>
						<li><em>Solteiros: </em>certidão de nascimento.</li>
						<li><em>Casados: </em>certidão de casamento.</li>
						<li><em>Estrangeiros naturalizados: </em>certificado de naturalização.</li>
						<li><em>Portugueses com igualdade de direitos</em>: certificado de igualdade de direitos e obrigações civis.</li>
						<li><strong>Duda pago, isenção ou registro de ocorrência&nbsp;(não é necessário cópia)</strong></li>
					</ul>
					<br>
					<br>
					<p><strong><em>DOCUMENTOS OPCIONAIS</em></strong></p>
					<ul>
						<li>CPF</li>
						<li>PIS/PASEP</li>
						
					</ul>
					<p>&nbsp;</p>
					<p><u><strong>OBSERVAÇÕES IMPORTANTES:<br>
					<br>
					</strong></u></p>



				<p>
						
					
						<font style='color:red'><i>*MENORES DE 12 ANOS SOMENTE COM A PRESENÇA DE PAI, MÃE OU RESPONSÁVEL LEGAL MUNIDO DE IDENTIDADE ORIGINAL E CÓPIA </i></font>
				
				</p>
				
				
				<?}?>
				
				
				<?if($tipoget=="V"){?>
				<!--------------------------------------->
				<div>
				<h3>Atendimento Agendado - Candidatar-se a Vagas de Emprego</h3>
						
					<h4>O agendamento para vagas de emprego deve respeitar os seguintes requisitos:</h4>
					<br>

					<b> Apresentação de documentação original e válida:</b><br>
					&nbsp;&nbsp;&nbsp;-&nbsp; Carteira de trabalho;<br>
					&nbsp;&nbsp;&nbsp;-&nbsp;Carteira de identidade;<br>
					&nbsp;&nbsp;&nbsp;-&nbsp;CPF;<br>
					&nbsp;&nbsp;&nbsp;-&nbsp;Comprovante de Escolaridade, Diplomas e Certificados (caso possua)

					<font style="color:red;"><h4>A secretaria não garante que no momento do seu atendimento a vaga de interesse esteja disponível.</h4></font>
				</div>		
				<?}?>
				
				
	</div >			
				
				<?
				
				$nome = $_GET['nome'];
				$telres = $_GET['telres'];
				$telcel = $_GET['telcel'];
				$cpf = $_GET['cpf'];
				$email = $_GET['email'];
				$datanascimento_tra_agendamento = $_GET['datanascimento_tra_agendamento'];		

				//////// funcao mastes dia
				
				
				
								function diasemana($data) {
								$ano =  substr("$data", 0, 4);
								$mes =  substr("$data", 5, -3);
								$dia =  substr("$data", 8, 9);

								$diasemana = date("w", mktime(0,0,0,$mes,$dia,$ano) );

								switch($diasemana) {
								case"0": $diasemana = "dom";       break;
								case"1": $diasemana = "Segunda-Feira"; break;
								case"2": $diasemana = "Terça-Feira";   break;
								case"3": $diasemana = "Quarta-Feira";  break;
								case"4": $diasemana = "Quinta-Feira";  break;
								case"5": $diasemana = "Sexta-Feira";   break;
								case"6": $diasemana = "sab";        break;
								}

								//echo "$diasemana";
								if( ($diasemana=="sab") OR ($diasemana=="dom") )
								{
								//echo" nao execulta função";
								}
								else
								{

								date_default_timezone_set('America/Sao_Paulo'); 
									$hr = date("H:i");

									
										if($hr >= "06:30") {
										
										
										}
										
										if($hr >= "06:30") {
											$datadehjexatividade = date("Y/m/d");
											$quereselecionadia = "SELECT data,id FROM `diaagendamento` where status='A' and liberado=''  ORDER BY  `diaagendamento`.`data` ASC limit 1 ";
											$rs_selecionadia     = mysql_query($quereselecionadia );
											while($camo_rs_selecionadia  = mysql_fetch_array($rs_selecionadia )){
											$iddataparaliberar        = $camo_rs_selecionadia ['id'];
											$dataparaliberar        = $camo_rs_selecionadia ['data'];
												
																							
												$query2c="INSERT INTO exliberacao (`data` )VALUES ( '$datadehjexatividade')";	
												$rs2c= mysql_query($query2c);
			
												$query3ct = "update  diaagendamento set liberado='S'  where id ='$iddataparaliberar'";
												$rs3ct= mysql_query($query3ct);	
												
												
											}
										
											

										}else{

										
										}


								}

								}

								//Exemplo de uso
								$datadehjexecutarfuncao = date("Y/m/d");
								$datadehjexecutarfuncaoddd = date("Y-m-d");
								
								$quereselecionadia2 = "SELECT data,id FROM `exliberacao` where data ='$datadehjexecutarfuncaoddd' ";
								$rs_selecionadia2     = mysql_query($quereselecionadia2 );
								$consultatotal = mysql_num_rows($rs_selecionadia2);

								if($consultatotal > 0 ){}else
								
								{
									
									diasemana("$datadehjexecutarfuncao");;
								}
								
				//////// funcao mastes dia
				
				
				?>
				
				<p style="font-size:16px;margin:10px;"><b>Li e concordo com os termos acima  -<font style="color:red">(Todos documentos solicitados Originais ) </font><input type="checkbox" value="" required name="checkbox"/></b><p>
				
				<h3>Informe dados para Agendamento </h3>
					
				
				<div class="form-row">
				<div class="label">Data Nascimento <font class='simbolo'>&#10045;</font> </div>
				<?$datanascimento2 = implode('/',array_reverse(explode('-',$datanascimento)));?>
				<div class="input-container"><input <?=$bloqueinput;?> value="<?=$datanascimento_tra_agendamento;?>"  placeholder="Data Nascimento "  <?if($tipoget=="D"){}else{?>onblur="document.getElementById('idade').value = calculaIdade(this.value,'<?php echo date("d/m/Y");?>');"  onkeyup="document.getElementById('idade').value = calculaIdade(this.value,'<?php echo date("d/m/Y");?>');" <?}?>name="datanascimento" id='datanascimento1'required   maxlength="10" value='<?=$datanascimento2;?>' type="text"    class="input req-same"  /></div>
				<div id="msgidade" name='msgidade' style="color:red;font-size:10px;"></div>
				</div>
				
				
				<div class="form-row">
				<div class="label">CPF:</div>
				<div class="input-container"><input  <?=$bloqueinput;?> value="<?=$cpf;?>"   <?if($tipoget=="D"){}else{?>onBlur="return validar_cpf();" required <?}?>   name="cpf_busca" id='cpf_busca' placeholder="Insira o CPF" type="text"  class="input req-same" maxlength="14"  /></div>
				<div id="msg" name='msg' style="color:red;font-size:10px;"></div>
				</div>
				
				
				
				
				<div class="form-row">
				<div class="label">Nome <font class='simbolo'>&#10045;</font> </div>
				<div class="input-container"><input <?=$bloqueinput;?> value="<?=$nome;?>"  placeholder="Insira seu Nome "onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="nome" required  value='<?=$nome;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label">E-mail <font class='simbolo'>&#10045;</font> </div>
				<div class="input-container"><input <?=$bloqueinput;?> value="<?=$email;?>" placeholder="Insira seu  E-mail "  onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="email" required  value='<?=$email;?>'type="mail" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="150"  /></div>
				</div>
				
				
										
				
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container"   style='width:546px;'>
				Tel.: Residencial
				<input onBlur="maiuscula(this)" value="<?=$telres;?>" onBlur="maiuscula(this)"  placeholder="Tel.: Residencial"  name="telres" id="telres" value="<?=$telres;?>"   class="input req-same"    tabindex="34" style="width:100px;" type="text" /> 
				&nbsp;Celular <font class='simbolo'>&#10045;</font> 
				<input onBlur="maiuscula(this)" value="<?=$telcel;?>"onBlur="maiuscula(this)"  placeholder="Tel.: Celular"  name="telcel" required id="telcel" value="<?=$telcel;?>"  class="input req-same" tabindex="35" style="width:99px;" type="text" />
				
				</div>
				</div>
				
				
				
				
					<img src="http://cetepmacae.rj.gov.br/v2.0/captcha.php?l=150&a=50&tf=20&ql=5"><br>
					
				<div class="form-row">
				<div class="label">Informe conteudo da imagem acima <font class='simbolo'>&#10045;</font></div>
				<div class="input-container">
				<input type="text" name="palavra" placeholder="Informe conteudo da imagem acima"  required  class="input req-same"/>
				<?$msg = $_GET["msg"]; echo"<h2 style='color:red'>$msg</h2>";?>
				</div>
				
				</div>
				
				
				
				
			
				<input type='hidden' name='buscaform' value='b'>
				<input type='hidden' name='tipo' value='<?=$tipoget;?>'>

					<div class="form-row">
				<div class="label"></div>
				<div class="input-container" style='width:546px;'>		
				<input  id="submitBtn26" value="Enviar" type="submit" class="sendBtn"  <?if($tipoget=="D"){}else{?>onBlur="return validar_cpf();"  <?}?> />
				<div id="errorDiv2" class="error-div"></div>
				</div>
				</div>						
				
				</form>
			
</div>			
</div>


</body>
</html>