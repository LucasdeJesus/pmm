<?include("../interno/input_banco.php"); // Inclui o arquivo com o sistema de segurança

?>
<html lang="en" class="no-js">
<!--<![endif]-->


<!-- Mirrored from www.scoopthemes.com/templates/Oleose/Freeze/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Sep 2015 12:49:54 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<body onload='contatempoja();'>


<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
       <script src="glDatePicker.js"></script>
    <script src="glDatePicker.min.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	

		
	
	<?
	$diahoje = date("d");
	$tipo=(string)addslashes($_POST['tipo']);
	
	if($tipo=="V"){ $sqltipo="and emprego='S'";}
	if($tipo=="D"){ $sqltipo="and detran='S'";}
	if($tipo=="C"){ $sqltipo="and ctps='S'";}
	
	$cpf_busca=(string)addslashes($_POST['cpf_busca']);
	$meshoje = date("m");
	$meshojeatual = date("m");
	if($meshoje =="01"){$meshoje="0";}else{$meshoje=$meshoje-1;}
	$anohoje = date("Y");
	$dataatualhoje= $anohoje."-".$meshojeatual."-".$diahoje;
	?>
	<!--------------------valida cpf--------------->										
<script language="JavaScript">
function validar_cpf(){
var cpf_busca = document.cadastro.cpf_busca.value;
var datanascimento = document.cadastro.datanascimento.value;
var nome = document.cadastro.nome.value;
var telcel = document.cadastro.telcel.value;

	var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
	if(!filtro.test(cpf_busca)){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	
	
	
	if(datanascimento=="" || datanascimento < 6){
	window.alert("Favor Informe Data Nascimento.");
	return false;
	}
	
	if(nome=="" || nome < 8){
	window.alert("Favor Informe Nome.");
	return false;
	}
	
	if(telcel=="" || telcel < 8){
	window.alert("Favor Informe Celular.");
	return false;
	}
	

	cpf_busca = remove(cpf_busca, ".");
	cpf_busca = remove(cpf_busca, "-");

	if(cpf_busca.length != 11 || cpf_busca == "00000000000" || cpf_busca == "11111111111" ||
	cpf_busca == "22222222222" || cpf_busca == "33333333333" || cpf_busca == "44444444444" ||
	cpf_busca == "55555555555" || cpf_busca == "66666666666" || cpf_busca == "77777777777" ||
	cpf_busca == "88888888888" || cpf_busca == "99999999999"){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}

	soma = 0;
	for(i = 0; i < 9; i++)
	soma += parseInt(cpf_busca.charAt(i)) * (10 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(9))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	soma = 0;
	for(i = 0; i < 10; i ++)
	soma += parseInt(cpf_busca.charAt(i)) * (11 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(10))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	return true;
  
}

	function remove(str, sub) {
	i = str.indexOf(sub);
	r = "";
	if (i == -1) return str;
	r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
	return r;
	}
	
</script>
  <script type="text/javascript">
  
  
  var contador = 50;
function contatempoja() {
document.getElementById('tempocontagem').innerHTML=contador;
	if(contador == 0) {
		location.href="agendamento.php?tipo=<?=$tipo;?>";
		
	}
	if (contador != 0){
		contador = contador-1;
		setTimeout("contatempoja()", 1000);
	}
		
}


        $(window).load(function()
{
		
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// Example #4 - Day of week offset and restricting date selections
	$('#example4d').glDatePicker(
	{
	
		
		showAlways: true,
		//selectedDate: new Date(<?=$anohoje;?>, <?=$meshoje;?>, <?=$diahoje;?>),
		//dowOffset: true,
		//selectableYears: true,
		//selectableMonths: true,
		//selectableDOW: [2,3,4,5,6],
		
		selectableDates: [
		
				<?
				
				$query_estado_db = "SELECT data FROM `diaagendamento` where status='A' ".$sqltipo." and liberado ='S' ";
				$rs_estado_db     = mysql_query($query_estado_db );
				while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
				$datadisponivel        = $campo_estado_db ['data'];
				$pieces = explode("-", $datadisponivel);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia
				$diasoma = $pieces[1] - 1;
				//$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				
					
					?>
						<?if(strtotime($datadisponivel) >= strtotime($dataatualhoje)){?>
					{ date: new Date(<?=$pieces[0];?>, <?=$diasoma?>, <?=$pieces[2];?>) 
					},
					
				<?}}?>
				
		],
	
	
    onClick: function(target, cell, date, data) {
	
        target.val(date.getFullYear() + '-' +
                    date.getMonth() + '-' +
                    date.getDate());

        if(data != null) {
            alert(data.message + '\n' + date);
        }
		var valorinput = $('#example4d').val();
		mostrahorario(valorinput);			
		contatempoja();
		alert("Sua seção vai espirar em 50 segundos");
		
    }
	
	//alert("oi");
	});
	
	
	
		

});

function salvaragendamento(id) {
	
		var valorinput = $('#example4d').val();
		var cpf_busca = $('#cpf_busca').val();
		var nome = $('#nome').val();
		var datanascimento = $('#datanascimento').val();
		var telres = $('#telres').val();
		var telcel = $('#telcel').val();
		var tipo = $('#tipo').val();
		var email = $('#email').val();
		$("#horariosdisponivel").hide();
		$("#divmostracarregando").show();
		
		
		
		 var isChecked  = jQuery("input[name=horario]:checked").val();
   
   
	
					console.log(isChecked);
                var booleanVlaueIsChecked = false;
                if (!isChecked) {
                    booleanVlaueIsChecked = true;
                    alert('Selecione algum Horário para atendimento');
                    return false;
                }else{
		//alert(isChecked);		
		
		   $.ajax({
				url: 'script.php?dia='+ valorinput+'&acao=agendar&cpf_busca='+cpf_busca+'&email='+email+'&nome='+nome+'&datanascimento='+datanascimento+'&telres='+telres+'&telcel='+telcel+'&horario='+isChecked+'&tipo='+tipo,
				success: function(data) {
				
				// 0 echo"Existe um agendamento ativo para $cpf_busca , favor Cancelar para gerar um novo Agendamento  ";
				// 1 echo"Não foi possível cadastrar, tente novamente.";
				// 2 echo"Agendamento Salvo!";
				
				
					  if($.trim(data)  == 0){
								
								window.location.href="listaagendamento.php?id="+cpf_busca+"&msg=Existe um agendamento ativo para CPF:"+cpf_busca+" , favor Cancelar para gerar um novo Agendamento !";
								
								//Abrir_Pagina("imprimeagendamento.php?id="+cpf_busca+"");
							}else{
							
								 if($.trim(data)  == 1){
								 
									alert("Não foi possível cadastrar, tente novamente.");
									
									}else{
										 if($.trim(data)  == 2){
										 
										/// alert("Agendamento Salvo!");
										 
										 window.location.assign("listaagendamento.php?id="+cpf_busca+"&salvo=sim&msg=Agendamento Salvo!");
										 }
									}
								
								}

				//alert(data);
				 //window.setTimeout('location.reload()', 300);	
				}
				
				});
			
		
		}
		
			function Abrir_Pagina(URL) {
			  window.open(URL,'','width=500,height=500');      
			} 
		
	} 	
	
	
	
	
	function cancelaagendamento(id) {
	//alert("oi");
			$.ajax({
				url: 'script.php?id='+id+'&acao=cancelaagendamento',
				success: function(data) {				
				
				
					if($.trim(data)  == 2){
						//$("#naoagendamentoexiste" ).show("slow");
					$("#agendamentoexiste" ).hide("hide");
					//alert("Agendamento Cancelado!");
					document.getElementById("agendamentocancelado").innerHTML = "Agendamento Cancelado!";
					}
				}
				
				});
	}




function mostrahorariotes(){

var data = document.getElementById("example4d").value;

if(window.XMLHttpRequest) {
req = new XMLHttpRequest();
}
else if(window.ActiveXObject) {
req = new ActiveXObject("Microsoft.XMLHTTP");
}

// Arquivo PHP juntamente com o valor digitado no campo (método GET)

var url = "lista_horario.php?tipo=<?=$tipo;?>&data="+data;

// Chamada do método open para processar a requisição
req.open("Get", url, true); 
req.setRequestHeader("Cache-Control","no-cache,no-store");
req.setRequestHeader("Pragma", "no-cache");

// Quando o objeto recebe o retorno, chamamos a seguinte função;
req.onreadystatechange = function() {

// Exibe a mensagem "Buscando Noticias..." enquanto carrega
if(req.readyState == 1) {
document.getElementById('horariosdisponivel').innerHTML = 'Carregando...';
}

// Verifica se o Ajax realizou todas as operações corretamente
if(req.readyState == 4 && req.status == 200) {

// Resposta retornada pelo busca.php
var resposta = req.responseText;

// Abaixo colocamos a(s) resposta(s) na div resultado
document.getElementById('horariosdisponivel').innerHTML = resposta;
}
}
req.send(null);
req.setRequestHeader("Cache-Control", "no-cache");
req.setRequestHeader("Pragma", "no-cache"); 

///////////////////////////

window.onload=function(){
setTimeout('mostrahorario()',100); // aqui o tempo entre uma atualização e outra
}
/////////////////////////


}	
    </script>

	


<script type="text/javascript">


function mostrahorario(){
var data = document.getElementById("example4d").value;
var xmlHttp;
try{    
xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
}
catch (e){
try{
xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
}
catch (e){
try{
xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
}
catch (e){
alert("No AJAX!?");
return false;
}
}
}
var url = "lista_horario.php?tipo=<?=$tipo;?>&data="+data;
xmlHttp.onreadystatechange=function(){
if(xmlHttp.readyState==4){
document.getElementById('horariosdisponivel').innerHTML=xmlHttp.responseText;
setTimeout('mostrahorario()',900);
}
}
xmlHttp.open("GET",url,true); // aqui configuramos o arquivo
xmlHttp.send(null);
}

window.onload=function(){
setTimeout('mostrahorario()',90000); // aqui o tempo entre uma atualização e outra
}

</script>

		
		
<div id="content" name='contente' >
<div id="container">
<?include'topo.php';


$DateOfRequest = date("s");
$DateOfRequestm = date("i");
$horacpf= date("H");
$Diacpf= date("d");
if(($cpf_busca=="")or($cpf_busca=="000.000.000-00"))
{$cpf_busca="0".$Diacpf.".0".$horacpf.".0".$DateOfRequestm."-".$DateOfRequest;};

if($cpf_busca==""){
	?>
	<script language= "JavaScript">
		window.history.go(1);
		</script>
		<?
		exit;
}


if($tipo==""){
	?>
	<script language= "JavaScript">
		window.history.go(1);
		</script>
		<?
		exit;
}

?>
		<div id="bg-container"   class='contener'>
					
			
				<form  class="form" method="post" action=""  id="cadastro" name='cadastro' >	
				
				<?if($tipo=="C"){?>
				<h2>Atendimento Agendado - Emissão de Carteira de Trabalho e Previdência Social - CTPS </h2>
				<?}?>
				
				<?if($tipo=="V"){?>
				<h2>Atendimento Agendado - Vagas </h2>
				<?}?>
				
				<?if($tipo=="D"){?>
				<h2>Atendimento Agendado - Emissão Carteira de Identidade</h2>
				<?}?>
				
				
				
				
				<div class="form-row"  <?if($tipo=="D"){?>style="display:none"<?}else{?><?}?>>
				<div class="label">CPF:</div>
				<div class="input-container"><input onBlur="maiuscula(this)" style='border:0px;'value="<?=$cpf_busca;?>"onBlur="maiuscula(this)" readonly="true" onBlur="return validar_cpf()" name="cpf_busca" id='cpf_busca' placeholder="Insira o CPF" type="text"  class="input req-same" maxlength="14"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label">Nome <font class='simbolo'></font> </div>
				<div class="input-container"><input onBlur="maiuscula(this)" placeholder="Insira o Nome"style='border:0px;'onBlur="maiuscula(this)"readonly="true" name="nome" id="nome"    value='<?=$nome;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label">E-mail <font class='simbolo'>&#10045;</font> </div>
				<div class="input-container"><input   onBlur="maiuscula(this)" placeholder="Insira o Email" onBlur="maiuscula(this)" name="email" id="email"  readonly="true" value='<?=$email;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="150"  /></div>
				</div>
				
				
				<div class="form-row">
				<div class="label">Data Nascimento <font class='simbolo'></font> </div>
				<?$datanascimento2 = implode('/',array_reverse(explode('-',$datanascimento)));?>
				<div class="input-container"><input onBlur="VerificaData(this.value);" placeholder="Insira Data Nascimento "style='border:0px;'readonly="true"name="datanascimento" id='datanascimento'  value='<?=$datanascimento2;?>' type="text"    class="input req-same"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container"   style='width:546px;'>
				Tel.: Residencial
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telres" placeholder="Tel.: Residencial" readonly="true" id="telres" value="<?=$telres;?>" maxlength="15"  class="input req-same"    tabindex="34" style="width:100px;border:0px;" type="text" /> 
				&nbsp;Celular <font class='simbolo'></font> 
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telcel" placeholder="Tel.: Celular" readonly="true" id="telcel" value="<?=$telcel;?>" maxlength="15" class="input req-same" tabindex="35" style="width:99px;border:0px;" type="text" />
				<input type='hidden' name='tipo' id='tipo'value='<?=$tipo;?>'>
				</div>
				</div>
				

				<h2>Meus ultimos agendamentos</h2>					
				
			
			<table style='width:800px' class="sortable">
			<tr>
				
				<td class='td1' >ID</td>
				<td class='td1' >Atendimento </td>
				<td class='td1' >Data </td>
				<td class='td1' >Horário Previsto </td>
				<td class='td1'>CPF. </td>
				<td class='td1'>Status </td>
				<td class='td1'>Acão </td>
			</tr>

<?
				
				$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where  cpf='$cpf_busca' ORDER BY `id` DESC limit 3";
				//echo$cpf_buscaagenda; 
				$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
				while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
				$idp  = $campo_noticias_hcpj['id'];
				$cpf_buscap =$campo_noticias_hcpj['cpf'];
				$nomep = $campo_noticias_hcpj['nome'];
				$datanascimentop = $campo_noticias_hcpj['datanascimento'];
				$telcelp = $campo_noticias_hcpj['celular'];
				$telres = $campo_noticias_hcpj['telefone'];					
				$datap = $campo_noticias_hcpj['data'];					
				$horariop = $campo_noticias_hcpj['horario'];					
				$tipo = $campo_noticias_hcpj['tipo'];		
				$status = $campo_noticias_hcpj['status'];		
						


				switch ($tipo) {
				case "C" :
					$tipoatendimento = "Atendimento CTPS";
					break;
				case "D":
					$tipoatendimento =  "Atendimento Identidade";
					break;
				case "V":
					$tipoatendimento =  "Atendimento Vagas ";
					break;
				}	

				switch ($status) {
				case "A" :
				$status_n = "Ativo";
				break;
				case "C":
				$status_n =  "Cancelado";
				break;
				}					

					
				

				$data = date("d-m-Y", strtotime($datap));
			?>	
			
			<tr class='tr_tb' >		
				<td class='td2' > <?=$idp;?> </td>
				<td class='td2' > <?=$tipoatendimento;?> </td>
				<td class='td2' > <?=$data;?> </td>
				<td class='td2' > <?=$horariop;?> </td>
				<td class='td2' > <?=$cpf_buscap;?> </td>
				<td class='td2' > <?=$status_n;?> </td>
				
				
			</tr>
			<?}?>
			</table>
			
				
				
				
				
				
		
			
			
			
			<?
			
				$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where status='A' and cpf='$cpf_busca' ORDER BY `id` DESC limit 1";				
				$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
				$total_agendamentocpf = mysql_num_rows($rs_noticias_hcpj);											
				while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
				$idp  = $campo_noticias_hcpj['id'];
				$cpf_buscap =$campo_noticias_hcpj['cpf'];
				$nomep = $campo_noticias_hcpj['nome'];
				$datanascimentop = $campo_noticias_hcpj['datanascimento'];
				$telcelp = $campo_noticias_hcpj['celular'];
				$telres = $campo_noticias_hcpj['telefone'];					
				$datap = $campo_noticias_hcpj['data'];					
				$horariop = $campo_noticias_hcpj['horario'];					
								
				}
				
				
			?>	

			<h3 style="color:red;font-size:16px;">	
			 <b>A partir do dia 21/02/17 o agendamento será liberado no horário das 6:30h. para o atendimento do dia seguinte.</b><br>
			
			
		
			</h3>
			<h3 style="font-size:25px;">Sua seção vai espirar em  <span id="tempocontagem" name="tempocontagem"></span> segundos.</h3>
			<table >
				<tr>
			
								
				<td >
			
						
						<form  class="form" method="post" action=""  id="naoagendamentoexiste" name="naoagendamentoexiste" >	
						<table>
							<tr>
								<td width="300px">
									<h2>1- Selecione  um dia Disponível  </h2>
									<div>
										<div><img src="dianao.jpg" width="25px"/> = Aguardando liberação</div>
										<div><img src="diaok.jpg" width="25px" /> = Agendamento Liberado  </div>
									
									</div>
									
									<input type="text" id="example4d"   readonly="true" style="width:250px;"gldp-id="gldp-62714503052" class="gldp-el">
									<div gldp-el="example4d"	 style=" height:250px; position:absolute; top:70px; left:100px; ">
									</div>
									
									
									
								</td>
								
								<td >
								
									<h2>2- Selecione  Horário </h2>
								<div style="font-size:14px; width:250px;display:none" id="divmostracarregando" name="divmostracarregando">
								<h3> Aguarde, enviado sua solicitação de agendamento....<br> Carregando pagina de aviso</h3>
								</div>
								<div style="font-size:14px; width:250px;" id="horariosdisponivel" name="horariosdisponivel">
									
								</div>	
								</td>
								
							</tr>
						</table>
						</form>
						
			
			
					</td>
					
					<td width="350px">
			<div id="agendamentocancelado" name='agendamentocancelado' ></div>
			<form  class="form" method="post" action=""  id="agendamentoexiste" name="agendamentoexiste"  >				
			
			<?if($total_agendamentocpf > 0){?>
			<?if(strtotime($datap) >= strtotime($dataatualhoje)){?>
			<h2>Para realizar um novo agendamento devera cancelar o existente </h2>
			<table style='width:300px' class="sortable">
			<tr>
				
				<td class='td1' >ID</td>
				<td class='td1' >Data </td>
				<td class='td1' >Horário </td>
				<td class='td1'>CPF. </td>
			</tr>
				
			<tr class='tr_tb' >		
				<td class='td2' > <?=$idp;?> </td>
				<td class='td2' > <?=$datap;?> </td>
				<td class='td2' > <?=$horariop;?> </td>
				<td class='td2' > <?=$cpf_buscap;?> </td>
			</tr>
			
			</table>
			<a  href="#"  class="sendBtn" onclick="cancelaagendamento(<?=$idp;?>);"> Cancelar</a>	
			
			<?}}?>
			</form>
		
			
			
			</td>
					
				</tr>
			</table>
			
			
</div>			</form>

</div>


</body>
</html>