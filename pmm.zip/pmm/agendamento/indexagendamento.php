<?include("../interno/input_banco.php"); // Inclui o arquivo com o sistema de segurança
ini_set('default_charset','UTF-8'); // Para o charset das páginas e
?>
<html>
<body>


<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
       <script src="glDatePicker.js"></script>
    <script src="glDatePicker.min.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	

		
	
	<?
	$diahoje = date("d");
	$tipo=(string)addslashes($_POST['tipo']);
	$meshoje = date("m");
	$meshojeatual = date("m");
	if($meshoje =="01"){$meshoje="0";}else{$meshoje=$meshoje-1;}
	$anohoje = date("Y");
	$dataatualhoje= $anohoje."-".$meshojeatual."-".$diahoje;
	?>
	<!--------------------valida cpf--------------->										
<script language="JavaScript">
function validar_cpf(){
var cpf_busca = document.cadastro.cpf_busca.value;
var datanascimento = document.cadastro.datanascimento.value;
var nome = document.cadastro.nome.value;
var telcel = document.cadastro.telcel.value;

	var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
	if(!filtro.test(cpf_busca)){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	
	
	
	if(datanascimento=="" || datanascimento < 6){
	window.alert("Favor Informe Data Nascimento.");
	return false;
	}
	
	if(nome=="" || nome < 8){
	window.alert("Favor Informe Nome.");
	return false;
	}
	
	if(telcel=="" || telcel < 8){
	window.alert("Favor Informe Celular.");
	return false;
	}
	

	cpf_busca = remove(cpf_busca, ".");
	cpf_busca = remove(cpf_busca, "-");

	if(cpf_busca.length != 11 || cpf_busca == "00000000000" || cpf_busca == "11111111111" ||
	cpf_busca == "22222222222" || cpf_busca == "33333333333" || cpf_busca == "44444444444" ||
	cpf_busca == "55555555555" || cpf_busca == "66666666666" || cpf_busca == "77777777777" ||
	cpf_busca == "88888888888" || cpf_busca == "99999999999"){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}

	soma = 0;
	for(i = 0; i < 9; i++)
	soma += parseInt(cpf_busca.charAt(i)) * (10 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(9))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	soma = 0;
	for(i = 0; i < 10; i ++)
	soma += parseInt(cpf_busca.charAt(i)) * (11 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(10))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	return true;
  
}

	function remove(str, sub) {
	i = str.indexOf(sub);
	r = "";
	if (i == -1) return str;
	r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
	return r;
	}
	
</script>
  <script type="text/javascript">
        $(window).load(function()
{
		
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// Example #4 - Day of week offset and restricting date selections
	$('#example4d').glDatePicker(
	{
	
		
		showAlways: true,
		//selectedDate: new Date(<?=$anohoje;?>, <?=$meshoje;?>, <?=$diahoje;?>),
		//dowOffset: true,
		//selectableYears: true,
		//selectableMonths: true,
		//selectableDOW: [2,3,4,5,6],
		
		selectableDates: [
		
				<?
				
				$query_estado_db = "SELECT data FROM `diaagendamento` where status='A'  ";
				$rs_estado_db     = mysql_query($query_estado_db );
				while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
				$datadisponivel        = $campo_estado_db ['data'];
				$pieces = explode("-", $datadisponivel);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia
				$diasoma = $pieces[1] - 1;
				//$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				
					
					?>
						<?if(strtotime($datadisponivel) >= strtotime($dataatualhoje)){?>
					{ date: new Date(<?=$pieces[0];?>, <?=$diasoma?>, <?=$pieces[2];?>) 
					},
					
				<?}}?>
				
		],
	
	
    onClick: function(target, cell, date, data) {
	
        target.val(date.getFullYear() + '-' +
                    date.getMonth() + '-' +
                    date.getDate());

        if(data != null) {
            alert(data.message + '\n' + date);
        }
		var valorinput = $('#example4d').val();
		mostrahorario(valorinput);			
		
		
    }
	
	//alert("oi");
	});
	
	
	
		

});

function salvaragendamento(id) {
	
		var valorinput = $('#example4d').val();
		var cpf_busca = $('#cpf_busca').val();
		var nome = $('#nome').val();
		var datanascimento = $('#datanascimento').val();
		var telres = $('#telres').val();
		var telcel = $('#telcel').val();
		var tipo = $('#tipo').val();
		
		
		
		 var isChecked  = jQuery("input[name=horario]:checked").val();
   
   
	
					console.log(isChecked);
                var booleanVlaueIsChecked = false;
                if (!isChecked) {
                    booleanVlaueIsChecked = true;
                    alert('Selecione algum Horário para atendimento');
                    return false;
                }else{
		//alert(isChecked);		
		var txt;
		var r = confirm( "Confirmar Agendamento para  "+isChecked+" ?" );
		if (r == true) {
		   $.ajax({
				url: 'script.php?dia='+ valorinput+'&acao=agendar&cpf_busca='+cpf_busca+'&nome='+nome+'&datanascimento='+datanascimento+'&telres='+telres+'&telcel='+telcel+'&horario='+isChecked+'&tipo='+tipo,
				success: function(data) {
				
				// 0 echo"Existe um agendamento ativo para $cpf_busca , favor Cancelar para gerar um novo Agendamento  ";
				// 1 echo"Não foi possível cadastrar, tente novamente.";
				// 2 echo"Agendamento Salvo!";
				
				
					  if($.trim(data)  == 0){
								alert("Existe um agendamento ativo para CPF:"+cpf_busca+" , favor Cancelar para gerar um novo Agendamento ");
								window.location.href="listaagendamento.php?id="+cpf_busca+"";
								
								//Abrir_Pagina("imprimeagendamento.php?id="+cpf_busca+"");
							}else{
							
								 if($.trim(data)  == 1){
								 
									alert("Não foi possível cadastrar, tente novamente.");
									
									}else{
										 if($.trim(data)  == 2){
										 
										 alert("Agendamento Salvo!");
										 Abrir_Pagina("imprimeagendamento.php?id="+cpf_busca+"");
										 window.location.assign("listaagendamento.php?id="+cpf_busca+"");
										 }
									}
								
								}

				//alert(data);
				 //window.setTimeout('location.reload()', 300);	
				}
				
				});
			} else {
				
			}
		
		}
		
			function Abrir_Pagina(URL) {
			  window.open(URL,'','width=500,height=500');      
			} 
		
	} 	
	
	
	
	
	function cancelaagendamento(id) {
	//alert("oi");
			$.ajax({
				url: 'script.php?id='+id+'&acao=cancelaagendamento',
				success: function(data) {				
				
				
					if($.trim(data)  == 2){
						//$("#naoagendamentoexiste" ).show("slow");
					$("#agendamentoexiste" ).hide("hide");
					alert("Agendamento Cancelado!");
					}
				}
				
				});
	}




function mostrahorario(){

var data = document.getElementById("example4d").value;

if(window.XMLHttpRequest) {
req = new XMLHttpRequest();
}
else if(window.ActiveXObject) {
req = new ActiveXObject("Microsoft.XMLHTTP");
}

// Arquivo PHP juntamente com o valor digitado no campo (método GET)

var url = "lista_horario.php?tipo=<?=$tipo;?>&data="+data;

// Chamada do método open para processar a requisição
req.open("Get", url, true); 
req.setRequestHeader("Cache-Control","no-cache,no-store");
req.setRequestHeader("Pragma", "no-cache");

// Quando o objeto recebe o retorno, chamamos a seguinte função;
req.onreadystatechange = function() {

// Exibe a mensagem "Buscando Noticias..." enquanto carrega
if(req.readyState == 1) {
document.getElementById('horariosdisponivel').innerHTML = 'Carregando...';
}

// Verifica se o Ajax realizou todas as operações corretamente
if(req.readyState == 4 && req.status == 200) {

// Resposta retornada pelo busca.php
var resposta = req.responseText;

// Abaixo colocamos a(s) resposta(s) na div resultado
document.getElementById('horariosdisponivel').innerHTML = resposta;
}
}
req.send(null);
req.setRequestHeader("Cache-Control", "no-cache");
req.setRequestHeader("Pragma", "no-cache"); 

///////////////////////////

window.onload=function(){
setTimeout('mostrahorario()',100); // aqui o tempo entre uma atualização e outra
}
/////////////////////////


}	
    </script>

		
		
<div id="content" name='contente' >
<div id="container">
<?include'topo.php';

?>
		<div id="bg-container"   class='contener'>
					
			<form  class="form" method="post" action=""  id="cadastro" name='cadastro' >	
			<a href="agendamento.php?tipo=C" ><h4>Agendamento para emissão de Carteira de Trabalho</h4></a>
			<form>
			
		</div>			

</div>


</body>
</html>