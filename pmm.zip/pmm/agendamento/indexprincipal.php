<?include("../seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<html>
<body>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	
	<?
	$diahoje = date("d");
	$meshoje = date("m");
	if($meshoje =="01"){$meshoje="0";}
	$anohoje = date("Y");
	?>
  <script type="text/javascript">
        $(window).load(function()
{
	
	// Example #4 - Day of week offset and restricting date selections
	$('#example4').glDatePicker(
	{
		showAlways: true,
		selectedDate: new Date(<?=$anohoje;?>, <?=$meshoje;?>, <?=$diahoje;?>),
		dowOffset: true,
		selectableYears: true,
		selectableMonths: true,
		selectableDOW: [2,3,4,5,6],
		
		
		specialDates: [
		<?
				$query_estado_db = "SELECT * FROM `diaagendamento` where status='A' ";
				$rs_estado_db     = mysql_query($query_estado_db );
				while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
				$datadisponivel        = $campo_estado_db ['data'];
				$pieces = explode("-", $datadisponivel);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia
				$diasoma = $pieces[1] - 1;
				//$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				?>
        {
            date: new Date(<?=$pieces[0];?>, <?=$diasoma?>,  <?=$pieces[2];?>),
            //data: { message: 'Meeting every day 8 of the month' },
            repeatMonth: false
        },
        <?}?>
    ],
	

		
				
	
	
    onClick: function(target, cell, date, data) {
        target.val(date.getFullYear() + '-' +
                    date.getMonth() + '-' +
                    date.getDate());

        if(data != null) {
            alert(data.message + '\n' + date);
        }
		
		var valorinput = $('#example4').val();
		var quatidadedia = $('#quatidadedia').val();
		//alert(valorinput);
		if(quatidadedia==""){alert("Favor Informar Quantidade por dia !");}else{		
				$.ajax({
				url: 'script.php?dia='+ valorinput+'&acao=cadastro&quatidadedia='+quatidadedia,
				success: function(data) {
				alert(data);
				 window.setTimeout('location.reload()', 300);	
				}
				
				});
		}
		
		
    }
	
	
	});
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// Example #4 - Day of week offset and restricting date selections
	$('#example4d').glDatePicker(
	{
	
		
		showAlways: true,
		selectedDate: new Date(<?=$anohoje;?>, <?=$meshoje;?>, <?=$diahoje;?>),
		dowOffset: true,
		selectableYears: true,
		selectableMonths: true,
		selectableDOW: [2,3,4,5,6],
		
		
		selectableDates: [
		
				<?
				$query_estado_db = "SELECT * FROM `diaagendamento` where status='A' ";
				$rs_estado_db     = mysql_query($query_estado_db );
				while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
				$datadisponivel        = $campo_estado_db ['data'];
				$pieces = explode("-", $datadisponivel);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia
				$diasoma = $pieces[1] - 1;
				//$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				?>
				{ date: new Date(<?=$pieces[0];?>, <?=$diasoma?>, <?=$pieces[2];?>) },
				<?}?>
				
		],
	
	
    onClick: function(target, cell, date, data) {
	
        target.val(date.getFullYear() + '-' +
                    date.getMonth() + '-' +
                    date.getDate());

        if(data != null) {
            alert(data.message + '\n' + date);
        }
		
		
		var valorinput = $('#example4d').val();
		
		var txt;
		var r = confirm( "Deseja Desativar está data?");
		if (r == true) {
		   $.ajax({
				url: 'script.php?dia='+ valorinput+'&acao=excluir&quatidadedia='+quatidadedia,
				success: function(data) {
				alert(data);
				 window.setTimeout('location.reload()', 300);	
				}
				
				});
		} else {
			
		}
		
		
		
		
    }
	
	//alert("oi");
	});

});


    </script>
	

<table width="900px ">
	<tr>
	
		<td>
			<p>
				<b>Quantidade vagas diária</b><br>
				<input type="number" id="quatidadedia" requered name='quatidadedia'style="width:400px;" value="10" class="gldp-el"/>
			</p>
		</td>
	</tr>
	
	
	<tr>
	
	<td>	
			<h3 style="width:400px;" >Datas </h3>
		<input type="text" id="example4"  readonly="true"style="width:400px;"gldp-id="gldp-6271450305" class="gldp-el">
		<div gldp-el="example4"
			 style=" height:300px; position:absolute; top:70px; left:100px;">
		</div>	
			
	</td>
	
	
	
	<td>
			<h3 style="width:400px;">Datas disponíveis  para agendamento </h3>
		<input type="text" id="example4d"  readonly="true" style="width:400px;"gldp-id="gldp-62714503052" class="gldp-el">
		<div gldp-el="example4d"
			 style=" height:300px; position:absolute; top:70px; left:100px;">
		</div>
		
		
	</td>
	
 </tr>
</table>

</body>
</html>