<?
include("../interno/input_banco.php"); // Inclui o arquivo com o sistema de segurança
$data2 = $_GET['data'];
$tipo = $_GET['tipo'];
if($data2 ==""){}
	else{
	$pieces = explode("-", $data2);
	$pieces[0]; // ano
	$pieces[1]; // mes
	$pieces[2]; // dia

	$diasoma = $pieces[1] + 1;

	$data = $pieces[0]."-".$diasoma."-".$pieces[2];
	$datapt = date("d-m-Y", strtotime($data));
	//echo $tipo;
	echo "<p style='color:red;'> Data Selecionada: <b>$datapt</b></p>";
	$hojehorario = date("Y-m-d");				
					
						switch ($tipo) {
								case "C":	
								///INICIO ATENDIMENTO c cARTEIRA
						$valorhorario=1;
									
									
						$query_horario_disponivelc = "SELECT id FROM  `agendamentoctps`  where  data='$data' and tipo='C'   ";
						$rs_noticias_horario_disponivelc    = mysql_query($query_horario_disponivelc);
						$total_horario_disponivelc = mysql_num_rows($rs_noticias_horario_disponivelc);
				
						if($total_horario_disponivelc >= 21){
						
						
								
						}else{					
				
													
														
														if($data=="2015-12-18"){
															
														$_11_45 = "13:45";
														$_12_00 = "14:00";
														$_12_15 = "14:15";														
														$_12_30 = "14:30";
														$_12_45 = "14:45";
														
														$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:15' AND  `horario` <  '13:15' order by  horario ASC";
														}
														else
														{
															
														$_11_45 = "11:45";
														$_12_00 = "12:00";
														$_12_15 = "12:15";														
														$_12_30 = "12:30";
														$_12_45 = "12:45";
														$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:00' AND  `horario` <  '13:15' order by  horario ASC";	
															
														}
														$rs_noticias_horario    = mysql_query($query_horario);
														while($campo_noticias_horario = mysql_fetch_array($rs_noticias_horario)){			
														$horario_banco  = $campo_noticias_horario['horario'];
														
															
															
																$query_horario_disponivel = "SELECT horario FROM  `agendamentoctps`  where horario='$horario_banco' and data='$data'  and tipo='C'  and `status` NOT LIKE  'C'";
																$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
																$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);	
																
															
																//echo $valorhorario;
																	if($total_horario_disponivel>=$valorhorario){ $horariosnao ="Atenção não há mais horário disponível para atendimento nesta data , favor escolha outra data!";}else{	
																		
																		
																			
																			if( ($horario_banco==$_12_45)){}else{
																			
																					
																						$hoje=date('Y-n-j');
																						$agora=date('H:i');
																	
																
																							if($hoje == $data ){
																								if($horario_banco > $agora ){
																									?>
																										<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																									<?																
																									$numeroHdisponivel=1;
																								}
																							}else{
																									?>
																										<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																									<?																
																									$numeroHdisponivel=1;
																								
																							}


																					
																					
																				
																					}
																
																	}
															}
												
												
									}			
												
												if($numeroHdisponivel>="1"){}else{
													
													echo "<div style='float:left;margin:5px;'>Atenção não há mais horário disponível para atendimento nesta  data !</DIV><h3 style='color:red;'>	
													Todos os dias a partir das 06:30 horas é liberado agendamento para o dia seguinte. 
													</h3>";
												}
											///FIM ATENDIMENTO c
											
						


					break;					
						case "V":
						
								/// inicio demais atendimento 
							
								
									if($data=="2015-01-21"){
											$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:15' AND  `horario` <  '16:15' order by  horario ASC";
									}else{
											$query_horario = "SELECT * FROM  `horarioatendimento`  where `horario` >  '08:15' AND  `horario` <  '16:15' order by horario ASC ";
										
									}	
									
								$rs_noticias_horario    = mysql_query($query_horario);
								while($campo_noticias_horario = mysql_fetch_array($rs_noticias_horario)){			
								$horario_banco  = $campo_noticias_horario['horario'];
								
										if(($horario_banco > "08:15")&&($horario_banco < "13:00")){$valorhorario=3;}else{$valorhorario=2;};
										
										$query_horario_disponivel = "SELECT horario FROM  `agendamentoctps`  where horario='$horario_banco' and data='$data' and tipo='V'  and `status` NOT LIKE  'C' ";
									
										$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
										$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);	
										
										
										//echo $valorhorario;
											if($total_horario_disponivel>=$valorhorario){$horariosnao ="Não há mais horário disponível para atendimento nesta  data , favor escolha outra data!";}else{	
												
												
																	$hoje=date('Y-n-j');
																	$agora=date('H:i');
																	
																
																if($hoje == $data ){
																	if($horario_banco > $agora ){
																		?>
																			<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																		<?																
																		$numeroHdisponivel=1;
																	}
																}else{
																		?>
																			<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																		<?																
																		$numeroHdisponivel=1;
																	
																}
																	
										
											}
									}
									if($numeroHdisponivel>="1"){}else{
													
														echo "<div style='float:left;margin:5px;'>Atenção não há mais horário disponível para atendimento nesta  data.!</DIV><h3 style='color:red;'>	
													Todos os dias a partir das 06:30 horas é liberado agendamento para o dia seguinte. 											</h3>";
												}
						break;						
						case "D":	////// fim demais atendimento	
						
						///INICIO ATENDIMENTO c cARTEIRA
						
											$valorhorario=1;
									/// se for atendimento C Carteira	
									
									
						$query_horario_disponivelc = "SELECT id FROM  `agendamentoctps`  where  data='$data' and tipo='D'   ";
						$rs_noticias_horario_disponivelc    = mysql_query($query_horario_disponivelc);
						$total_horario_disponivelc = mysql_num_rows($rs_noticias_horario_disponivelc);
				
						if($total_horario_disponivelc >= 20){
							
							
							echo "<div style='float:left;margin:5px;'>Atenção não há mais horário disponível para atendimento nesta  data.!</DIV><h3 style='color:red;'>	
													Todos os dias a partir das 06:30 horas é liberado agendamento para o dia seguinte. 
													</h3>";
						}else{
							
												if($data=="2015-12-18"){
														$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:35' AND  `horario` <  '11:45' order by  horario ASC";
												}else{
													$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:00' AND  `horario` <  '11:45' order by  horario ASC";
													
												}		
														
											$rs_noticias_horario    = mysql_query($query_horario);
											while($campo_noticias_horario = mysql_fetch_array($rs_noticias_horario)){			
											$horario_banco  = $campo_noticias_horario['horario'];
											
												
												
													$query_horario_disponivel = "SELECT horario FROM  `agendamentoctps`  where horario='$horario_banco' and data='$data'  and tipo='D'   and `status` NOT LIKE  'C'";
													$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
													$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);	
													
												
													//echo $valorhorario;
														if($total_horario_disponivel>=$valorhorario){ $horariosnao ="Atenção não há mais horário disponível para atendimento nesta data , favor escolha outra data!";}else{	
															
															
																
																if( ($horario_banco=="12:00") or ($horario_banco=="11:45") or ($horario_banco=="12:15") or ($horario_banco=="12:30") or ($horario_banco=="12:45") or ($horario_banco=="13:00")){}else{
																
																
																	$hoje=date('Y-n-j');
																	$agora=date('H:i');
																	
																
																if($hoje == $data ){
																	if($horario_banco > $agora ){
																		?>
																			<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																		<?																
																		$numeroHdisponivel=1;
																	}
																}else{
																		?>
																			<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																		<?																
																		$numeroHdisponivel=1;
																	
																}
																	
																}
													
														}
												}
												
												
												
												
												if($numeroHdisponivel>="1"){}else{
													
														echo "<div style='float:left;margin:5px;'>Atenção não há mais horário disponível para atendimento nesta  data.!</DIV><h3 style='color:red;'>	
													Todos os dias a partir da 06:30 horas é liberado agendamento para o dia seguinte. 
													</h3>";
												}
								}
											///FIM ATENDIMENTO D
						break;
					
						}	
						
				
	}
					
					?>