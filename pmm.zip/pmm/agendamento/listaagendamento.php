<?include("../interno/input_banco.php"); // Inclui o arquivo com o sistema de segurança

?>
<html lang="en" class="no-js">
<!--<![endif]-->


<!-- Mirrored from www.scoopthemes.com/templates/Oleose/Freeze/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Sep 2015 12:49:54 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->


<head>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
<SCRIPT LANGUAGE="JavaScript">   
<!-- Disable   
function disableselect(e){   
return false   
}   

function reEnable(){   
return true   
}   

//if IE4+   
document.onselectstart=new Function ("return false")   
document.oncontextmenu=new Function ("return false")   
//if NS6   
if (window.sidebar){   
document.onmousedown=disableselect   
document.onclick=reEnable   
}   
//-->   
</script>  

</head>
<body>



	

		
	
	<?
	$diahoje = date("d");
	$meshoje = date("m");
	if($meshoje =="01"){$meshoje="0";}
	$anohoje = date("Y");
	
	$cpf_buscaagenda=(string)addslashes($_GET['id']);
	?>

	<script>
	
	function Abrir_Pagina(URL) {
			  window.open(URL,'','width=500,height=500');      
			} 
			
	</script>
		
<div id="content" name='contente' >
<div id="container">
<?include'topo.php'?>
		<div id="bg-container"   class='contener'>
					
			
			<form  class="form" method="post" action=""  id="cadastro" name='cadastro' >	
			<script>
									
								function cancelaagendamento(id) {
					//alert("oi");
							$.ajax({
								url: 'script.php?id='+id+'&acao=cancelaagendamento',
								success: function(data) {				
								
								
									if($.trim(data)  == 2){
										//$("#naoagendamentoexiste" ).show("slow");
									//$("#agendamentoexiste" ).hide("hide");
									//alert("Agendamento Cancelado!");
									window.location.assign("listaagendamento.php?id=<?=$cpf_buscaagenda;?>&msg=Agendamento Cancelado!");
									}
								}
								
								});						
								
								
					}
					
					
					
				
								
								
				</script>
			
			<h2>Meus Agendamentos</h2>
			<?$msg= $_GET['msg'];?>
			<h3 style='font-size:16px'><?=$msg;?></h3>
			
			<table style='width:800px' class="sortable">
			<tr>
				<td class='td1'>Cancelar </td>
				<td class='td1' >ID</td>
				<td class='td1' >Atendimento </td>
				<td class='td1' >Data </td>
				<td class='td1' >Horário Previsto </td>
				<td class='td1'>CPF. </td>
				<td class='td1'>Imprimir </td>
			</tr>

<?
				
				$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where status='A' and cpf='$cpf_buscaagenda'  ORDER BY `id` DESC  ";
				//echo$cpf_buscaagenda; 
				$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
				while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
				$idp  = $campo_noticias_hcpj['id'];
				$cpf_buscap =$campo_noticias_hcpj['cpf'];
				$nomep = $campo_noticias_hcpj['nome'];
				$datanascimentop = $campo_noticias_hcpj['datanascimento'];
				$telcelp = $campo_noticias_hcpj['celular'];
				$telres = $campo_noticias_hcpj['telefone'];					
				$datap = $campo_noticias_hcpj['data'];					
				$horariop = $campo_noticias_hcpj['horario'];					
				$tipo = $campo_noticias_hcpj['tipo'];		


				switch ($tipo) {
				case "C" :
					$tipoatendimento = "Atendimento CTPS";
					break;
				case "D":
					$tipoatendimento =  "Atendimento DETRAN";
					break;
				case "V":
					$tipoatendimento =  "Atendimento Vagas ";
					break;
				}				
				

				$data = date("d-m-Y", strtotime($datap));
				
				$vowels = array("(", ")", ".", "-");
				$numerocelular = str_replace($vowels, "", $telcelp);
			?>	
			
			<tr class='tr_tb' >
				<td class='td2' ><a href="#" Onclick="cancelaagendamento('<?=$idp;?>');">Cancelar</a></td>			
				<td class='td2' > <?=$idp;?> </td>
				<td class='td2' > <?=$tipoatendimento;?> </td>
				<td class='td2' > <?=$data;?> </td>
				<td class='td2' > <?=$horariop;?> </td>
				<td class='td2' > <?=$cpf_buscap;?> </td>
				<td class='td2' > <a href="#" Onclick="Abrir_Pagina('imprimeagendamento.php?id=<?=$cpf_buscap;?>');">Imprimir</a></td>
				
			</tr>
			
			
			<?}?>
			
			<?$salvo = $_GET['salvo'];?>
			<?if($salvo=="sim"){?>
			
				<?if($numerocelular=="00000000000"){}else{?>
				<!--<script>
				$.ajax({
				url: 'http://app.smsconecta.com.br/SendAPI/Send.aspx?usr=cetep&pwd=cetep357&number=55<?=$numerocelular;?>&sender=SEMTRE&msg=Confirmado agendamento para <?=$tipoatendimento;?> no dia <?=$data;?> no horario <?=$horariop;?>, ID <?=$idp;?>',
				success: function(data) {				
					if($.trim(data)  > 2){
							document.getElementById("sms").innerHTML = "<h3>Enviamos uma SMS para <?=$numerocelular;?>  com detalhes do seu agendamento , favor verificar seu Celular </h3>";		

					}
				}

				});


				</script>-->
				
					<?}?>
			<?}?>
				
			</table>
			<div id='sms' name='sms'>
			</div>
			
			
			</form>
		
			
			
		
			
			
</div>			

</div>


</body>
</html>