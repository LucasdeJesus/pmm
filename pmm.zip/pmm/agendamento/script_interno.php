<?php
include("../interno/input_banco.php"); // Inclui o arquivo com o sistema de segurança


$dataget= $_GET['dia'];
$pieces = explode("-", $dataget);
$pieces[0]; // ano
$pieces[1]; // mes
$pieces[2]; // dia

$diasoma = $pieces[1] + 1;

$data = $pieces[0]."-".$diasoma."-".$pieces[2];

//echo $data;


$vaga= $_GET['quatidadedia'];
$acao= $_GET['acao'];

//echo"esse e $dia e $quatidadedia";

	switch ($acao) {
			case cadastro:
			
			$query_noticias_total_emca = "SELECT * FROM `diaagendamento` where status='A' and data='$data'";	
			$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
			$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
			
			if($total_total_emca > 0)			
			{
			echo"Data $data já está Ativa";
				
			}else{

					$query="insert INTO `diaagendamento` ( `data`, `vaga`,`status`) VALUES  ('$data','$vaga','A')";
					$rs= mysql_query($query);
					
				

							if ($rs) {

								echo"Data $data Ativa";

							} else {
									
								echo"Não foi possível cadastrar, tente novamente.";
											
							}
			}
			break;
			

			case excluir:			
				$query_noticias_total_emca = "DELETE FROM  diaagendamento where data='$data'";	
				$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 	

				if ($rs_noticias_total_emca) {

					echo"Data $data Desativada";

				} else {
						
					echo"Não foi possível Desativada, tente novamente.";
								
				}
							
			break;
			
			
			
			case agendar:
			
			
						$cpf_busca =$_GET['cpf_busca'];
						$usuarioID =$_GET['usuarioID'];
						$nome = $_GET['nome'];
						$datanascimento = $_GET['datanascimento'];
						$telcel = $_GET['telcel'];
						$telres = $_GET['telres'];
						$horario = $_GET['horario'];
						$tipo = $_GET['tipo'];
						$tipoget = $_GET['tipo'];
						$email = $_GET['email'];
						$avulso = $_GET['avulso'];
						
				$diahoje = date("d");
				$meshoje = date("m");
				$meshojeatual = date("m");	
				$anohoje = date("Y");
				$dataatualhoje= $anohoje."-".$meshojeatual."-".$diahoje;
				
				
				
			
				
			$query_noticias_total_emca = "SELECT * FROM `agendamentoctps` where status='A' and cpf='$cpf_busca' and tipo ='$tipo' and data='$data' ";	
			//$query_noticias_total_emca = "SELECT * FROM `agendamentoctps` where status='A' and cpf='$cpf_busca' and tipo ='$tipo' ";	
			$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
			$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
			
				while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_total_emca)){			
				$idp  = $campo_noticias_hcpj['id'];
				$cpf_buscap =$campo_noticias_hcpj['cpf'];
				$nomep = $campo_noticias_hcpj['nome'];
				$datanascimentop = $campo_noticias_hcpj['datanascimento'];
				$telcelp = $campo_noticias_hcpj['celular'];
				$telres = $campo_noticias_hcpj['telefone'];					
				$datap = $campo_noticias_hcpj['data'];					
				$horariop = $campo_noticias_hcpj['horario'];					
				}
				
			if($total_total_emca >=1){ echo"0"; exit;}
			
			
			
			if((strtotime($datap) >= strtotime($dataatualhoje)))			
			{
			echo"0";
				
			}else{
				
					$query_noticias_total_emcaverica = "SELECT * FROM `agendamentoctps` where  cpf='$cpf_busca' and status='A' and tipo ='$tipo' ";	
					$rs_noticias_total_emcaverifica    = mysql_query($query_noticias_total_emcaverica); 
					$total_total_emcaverifica = mysql_num_rows($rs_noticias_total_emcaverifica);
					if($total_total_emcaverifica >=1){ echo"0"; exit;}

					$query="insert INTO `agendamentoctps` ( `data`, `cpf`,`status`,`nome`,`datanascimento`,`telefone`,`celular`,`horario`,`tipo`,`email`,`avulso`,`usuarioid`) VALUES  ('$data','$cpf_busca','A','$nome','$datanascimento','$telres','$telcel','$horario','$tipo','$email','$avulso','$usuarioID')";
					$rs= mysql_query($query);
					
				

							if ($rs) {
								
								/* Medida preventiva para evitar que outros domínios sejam remetente da sua mensagem. */
													if (eregi('tempsite.ws$|locaweb.com.br$|hospedagemdesites.ws$|websiteseguro.com$', $_SERVER[HTTP_HOST])) {
													$emailsender='oportunidade.semtre@macae.rj.gov.br';
													} else {
													$emailsender = "oportunidade.semtre@macae.rj.gov.br";
													//    Na linha acima estamos forçando que o remetente seja 'webmaster@seudominio',
													// você pode alterar para que o remetente seja, por exemplo, 'contato@seudominio'.
													}

													/* Verifica qual é o sistema operacional do servidor para ajustar o cabeçalho de forma correta. Não alterar */
													if(PHP_OS == "Linux") $quebra_linha = "\n"; //Se for Linux
													elseif(PHP_OS == "WINNT") $quebra_linha = "\r\n"; // Se for Windows
													else die("Este script nao esta preparado para funcionar com o sistema operacional de seu servidor");

													// Passando os dados obtidos pelo formulário para as variáveis abaixo
													$nomeremetente     = "Secretaria Trabalho e Renda";
													$emailremetente    = "oportunidade.semtre@macae.rj.gov.br";
													$emaildestinatario = "$email";
													$comcopia          = "$email";
													$comcopiaoculta    = "";
													$assunto           = "Agendamento para Atendimento  SEMTRE CTM 2.0";



													/* Montando a mensagem a ser enviada no corpo do e-mail. */
													//$mensagemHTML = "<div style='border:1px solid #ddd;padding:10px' >Sr(a),$nome Parabens seu agendamento foi concluido para  <br>LINK:  <a href='http://sistemas.macae.rj.gov.br:84/catalogo/semtre'>http://sistemas.macae.rj.gov.br:84/catalogo/semtre</a> </div>";

										
										$data2 = date("d-m-Y", strtotime($data));
													
													
													
				if($tipoget=="C"){
				
				
				$mensagemHTML="<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>"
                        . "<html xmlns='http://www.w3.org/1999/xhtml'>" 
                        . "<head>"
                        . "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" 
                        . "<body>"
				."<h3>Atendimento Agendado - Emissão de Carteira de Trabalho e Previdência Social - CTPS </h3>"
				
				."<p> Parabens ".$nome.", seu agendamento para o dia ".$data2." as ".$horario." </p>"
				. "<div>"
						. "<p><b>Emissão de Carteira de Trabalho - DOCUMENTAÇÃO</b></p>"
						. "<p><br><br>"
						
						. "<h4> Para emissão de CTPS favor observar vestuário devido à restrições para a fotografia. </h4>"
						. "<font style='color:red;'><b>Usar vestimentos:</b></font><br><br>"
							. "<p>Mais Fechada</p>"
							. "<p>Mais Discreta</p>"
							. "<p>Sem Estampas</p>"
							. "<p>Sem Propagandas, camisa de times ou uniformes </p>"
							. "<p>Não usar veste Branca </p><br>"
						
						
						
						
						. "<font style='color:red;'><b>1ª Via</b></font><br><br>"
						. "<b>1. </b>CPF - Cadastro de Pessoa Física<br>"
						. "<b>2.</b> RG - Cédula de Identidade ou CN - Certidão de Nascimento ou CC - Certidão de Casamento ou RES - Certificado de" 
							. "Reservista ou OAB - Carteira da OAB ou CREA - Carteira do CREA<br>"
						. "<b>3. </b>OBS - Observação<br>"
						. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- CNH - Carteira Nacional de Habilitação não é aceita como documento de identificação para emissão da CTPS<br>"
						. "<b>4. </b>CC - Certidão de Casamento<br>"
							. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Caso o solicitante seja casado.<br>"
							. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Com fundo branco, com ou sem data, colorida e recente, que identifique plenamente o solicitante.<br>"
						. "<b>5.</b> CR - Comprovante de Residência<br>"
						. "O comprovante deve possuir o numero do CEP.<br>"
						
						. "</p>"
						
						. "<p><br><br>"
						. "<font style='color:red;'><b>2ª Via</b></font><br><br>"
						. "<b>1.</b> Todos - Todos os itens da 1ª via<br>"
						. "<b>2.</b> CTPS - Carteira de Trabalho e Previdência Social<br>"
							. "&nbsp;	&nbsp;	&nbsp;	&nbsp;Carteira de Trabalho anterior em caso de inutilização ou continuação.<br>"
						. "<b>3.</b> BO - Boletim de Ocorrência<br>"
							. "&nbsp;	&nbsp;	&nbsp;	&nbsp;Boletim de Ocorrência em caso de perda, roubo, furto ou danos da CTPS.<br>"
						. "<b>4.</b> DOC - Documento que comprove o número da Carteira de Trabalho anterior<br>"
							. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Carteira de Trabalho ou;<br>"
							. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato Análitico;<br>"
							. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato FGTS ou;<br>"
							. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Rescisão do Contrato de Trabalho.<br>"
						. "<font style='color:red;'><b>5.</b> OBS - Observação<br>"
							. "&nbsp;	&nbsp;	&nbsp;	&nbsp;CNH - Carteira Nacional de Habilitação não é aceita como documento de identificação para emissão da CTPS</font>"
						
						. "</p>"
				. "</div>	"
					. "</body>"
                        ."</html>";				
				}
				
				
				
				if($tipoget=="D"){
				


					$mensagemHTML="<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>"
                        . "<html xmlns='http://www.w3.org/1999/xhtml'>" 
                        . "<head>"
                        . "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" 
                        . "<body>"
					."<h2 class='content-title'>  Identificação Civil    </h2>"
					."<p> Parabens ".$nome.", seu agendamento para o dia ".$data2." as ".$horario." </p>"
					 . "<p>Graças a um convênio firmado com o DETRAN, agora é possível fazer a carteira de identidade na Secretaria Municipal de Trabalho e Renda.<br>"
					. "&nbsp;</p>"
					. "<p><u><strong>DOCUMENTOS NECESSÁRIOS PARA 1º VIA </strong></u><br>"
					. "<br>"
					. "O requerente deverá apresentar original e cópia ou cópia autenticada dos documentos:<br>"
					. "&nbsp;</p>"
					. "<p><em><strong>DOCUMENTOS OBRIGATÓRIOS</strong></em></p>"
					. "<ul>"
						. "<li><em>Solteiros: </em>certidão de nascimento.</li>"
						. "<li><em>Casados:</em> certidão de casamento.</li>"
						. "<li><em>Estrangeiros naturalizados</em>: certificado de naturalização.</li>"
						. "<li><em>Portugueses com igualdade de direitos:</em> certificado de igualdade&nbsp;de direitos e obrigações civis.</li>"
					. "</ul>"
					. "<br>"
					. "<br>"
					. "<p><em><strong>DOCUMENTOS OPCIONAIS</strong></em></p>"
					. "<ul>"
						. "<li>CPF</li>"
						. "<li>PIS/PASEP</li>"
						. "<li>1 FOTO 3X4</li>"
					. "</ul>"
					. "<p>&nbsp;</p>"
					. "<p><u><strong>DOCUMENTOS NECESSÁRIOS PARA 2ª VIA </strong></u><strong><br>"
					. "</strong><br>"
					. "O requerente deverá apresentar original e cópia ou cópia autenticada dos documentos:<br>"
					. "&nbsp;</p>"
					. "<p><strong><em>DOCUMENTOS OBRIGATÓRIOS</em></strong></p>"
					. "<ul>"
						. "<li><em>Solteiros: </em>certidão de nascimento.</li>"
						. "<li><em>Casados: </em>certidão de casamento.</li>"
						. "<li><em>Estrangeiros naturalizados: </em>certificado de naturalização.</li>"
						. "<li><em>Portugueses com igualdade de direitos</em>: certificado de igualdade de direitos e obrigações civis.</li>"
						. "<li><strong>Duda pago, isenção ou registro de ocorrência&nbsp;(não é necessário cópia)</strong></li>"
					. "</ul>"
					. "<br>"
					. "<br>"
					. "<p><strong><em>DOCUMENTOS OPCIONAIS</em></strong></p>"
					. "<ul>"
					. "	<li>CPF</li>"
					. "	<li>PIS/PASEP</li>"
					. "	<li>1 FOTO 3X4&nbsp;</li>"
					. "</ul>"
					. "<p>&nbsp;</p>"
					. "<p><u><strong>OBSERVAÇÕES IMPORTANTES:<br>"
					. "<br>"
					. "</strong></u></p>"



				. "<p>"
						
					
						. "<font style='color:red'><i>*MENORES DE 12 ANOS SOMENTE COM A PRESENÇA DE PAI, MÃE OU RESPONSÁVEL LEGAL MUNIDO DE IDENTIDADE ORIGINAL E CÓPIA </i></font>"
				
				. "</p>"
				. "</body>"
                        ."</html>";	
				
				
				}
				
				
				if($tipoget=="V"){				
				$mensagemHTML="<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>"
                        . "<html xmlns='http://www.w3.org/1999/xhtml'>" 
                        . "<head>"
                        . "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" 
                        . "<body>"
				."<div>"
				. "<h3>Atendimento Agendado - Candidatar-se a Vagas de Emprego</h3>"
						."<p> Parabens ".$nome.", seu agendamento para o dia ".$data2." as ".$horario." </p>"
					. "<h4>O agendamento para vagas de emprego deve respeitar os seguintes requisitos:</h4>"
					. "<br>"

					. "<b> Apresentação de documentação original e válida:</b><br>"
					. "&nbsp;&nbsp;&nbsp;-&nbsp; Carteira de trabalho;<br>"
					. "&nbsp;&nbsp;&nbsp;-&nbsp;Carteira de identidade;<br>"
					. "&nbsp;&nbsp;&nbsp;-&nbsp;CPF;<br>"
					. "&nbsp;&nbsp;&nbsp;-&nbsp;Comprovante de Escolaridade, Diplomas e Certificados (caso possua)"

					. "<font style='color:red;'><h4>A secretaria não garante que no momento do seu atendimento a vaga de interesse esteja disponível.</h4></font>"
				. "</div>	"
				. "</body>"
				."</html>";					
				}
													
													
													
													
													
													
													

													/* Montando o cabeçalho da mensagem */
													$headers = "MIME-Version: 1.1".$quebra_linha;
													$headers .= "Content-type: text/html; charset=utf-8".$quebra_linha;
													// Perceba que a linha acima contém "text/html", sem essa linha, a mensagem não chegará formatada.
													$headers .= "From: ".$emailsender.$quebra_linha;
													$headers .= "Return-Path: " . $emailsender . $quebra_linha;
													// Esses dois "if's" abaixo são porque o Postfix obriga que se um cabeçalho for especificado, deverá haver um valor.
													// Se não houver um valor, o item não deverá ser especificado.
													if(strlen($comcopia) > 0) $headers .= "Cc: ".$comcopia.$quebra_linha;
													if(strlen($comcopiaoculta) > 0) $headers .= "Bcc: ".$comcopiaoculta.$quebra_linha;
													$headers .= "Reply-To: ".$emailremetente.$quebra_linha;
													// Note que o e-mail do remetente será usado no campo Reply-To (Responder Para)

													/* Enviando a mensagem */
													mail($emaildestinatario, $assunto, $mensagemHTML, $headers, "-r". $emailsender);
													

								echo"2";

							} else {
									
								echo"1";
											
							}
			}
			break;
			
			
			case cancelaagendamento:
			
			$id= $_GET['id'];
			$query="update  agendamentoctps set status='C' where id='$id' ";
			$rs= mysql_query($query);
			
				if ($rs) {

						echo"2";

					} else {
							
						echo"1";
									
					}
			break;
		}

?>