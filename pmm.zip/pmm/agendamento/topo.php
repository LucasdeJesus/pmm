<?					
						$cpf_busca=(string)addslashes($_POST['cpf_busca']);
						$nome=(string)addslashes($_POST['nome']);
						$datanascimento=(string)addslashes($_POST['datanascimento']);
						$telcel=(string)addslashes($_POST['telcel']);
						$telres=(string)addslashes($_POST['telres']);
						$tipo=(string)addslashes($_POST['tipo']);
						$email=(string)addslashes($_POST['email']);
						
						
									
					?>
	<script>
	
	function Abrir_Pagina(URL) {
			  window.open(URL,'','width=500,height=500');      
			} 
			
	</script>			
<!--<div style='width:100%;border-top:3px solid #00B8AD; border-bottom:1px solid #D1D8DB;background-color:#FAFAFA;margin-top:20px;' align='center' >
		
			<table width='960px' >
				<tr>
					<td >
						<a href='../index.php'><img src='../img/logo.jpg'/></a>
					</td>
					
					<td>
						
					</td>
					
				</tr>
			</table>
		</div>-->