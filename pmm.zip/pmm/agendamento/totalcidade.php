<?include("../interno/input_banco.php"); // Inclui o arquivo com o sistema de segurança

?>
<body>

<table border=1 width="100%">
	<tr>
		<td>Estado</td>
		<td>Cidade</td>
		<td>Total</td>
	</tr>
	
	<?
		$somatotal=0;
		$query_noticiasdcemede = "SELECT cidadeid FROM `trabalhador` GROUP BY cidadeid  ";
		$rs_noticiasdcemede    = mysql_query($query_noticiasdcemede);
		while($campo_noticiasdcemede = mysql_fetch_array($rs_noticiasdcemede)){																												
		
		$cidade_id = $campo_noticiasdcemede['cidadeid'];		
		
		$query_noticiasdcemedeb = "SELECT id FROM `trabalhador` WHERE `cidadeid` = '$cidade_id' ";
		$rs_noticiasdcemedeb    = mysql_query($query_noticiasdcemedeb);
		$total = mysql_num_rows($rs_noticiasdcemedeb);
		$somatotal+="$total";
		
		
		$query_noticiasdcemede2 = "SELECT * FROM `cidade` where id='$cidade_id' ORDER BY  `cidade`.`nome` ASC ";
		$rs_noticiasdcemede2    = mysql_query($query_noticiasdcemede2);
		while($campo_noticiasdcemede2 = mysql_fetch_array($rs_noticiasdcemede2)){																												
		$cidade = $campo_noticiasdcemede2['nome'];
		$ufid = $campo_noticiasdcemede2['ufid'];
		
			$query_noticias_estado = "SELECT *  FROM  `uf` where id='$ufid'";
			$rs_noticias_estado    = mysql_query($query_noticias_estado);
			while($campo_noticias_estado = mysql_fetch_array($rs_noticias_estado)){		
			$iduf 	= $campo_noticias_estado['id']; 
			$nome_uf 	= $campo_noticias_estado['uf']; }

		
	?>
		<tr>
			<td><?=$nome_uf;?></td>
			<td><?=$cidade;?></td>
			<td><?=$total;?></td>
		</tr>
	<?}?>
	<?}?>
	
	<tr>
			<td>Total</td>
			<td><?=$somatotal;?></td>
		</tr>
	
</table>
</body>
</html>