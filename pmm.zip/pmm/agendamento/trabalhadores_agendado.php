<?include("../interno/input_banco.php"); // Inclui o arquivo com o sistema de segurança

?>
<html lang="en" class="no-js">
<!--<![endif]-->


<!-- Mirrored from www.scoopthemes.com/templates/Oleose/Freeze/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Sep 2015 12:49:54 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<body>


<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	

		
	
	<?
	$diahoje = date("d");
	$meshoje = date("m");
	if($meshoje =="01"){$meshoje="0";}
	$anohoje = date("Y");
	?>

	<script>
	
	function Abrir_Pagina(URL) {
			  window.open(URL,'','width=500,height=500');      
			} 
			
	</script>
		
<div id="content" name='contente' >
<div id="container">

		<div id="bg-container"   class='contener'>
					
			
			<form  class="form" method="post" action=""  id="cadastro" name='cadastro' >	
			
			<?
			$dataget= $_GET['dia'];
				$pieces = explode("-", $dataget);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia

				$diasoma = $pieces[1] + 1;

				$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				
			?>
			<h2>Agendamento do dia <?=$data ;?></h2>
			<table style='width:800px' class="sortable">
			<tr>
				
				<td class='td1' >ID</td>
				<td class='td1' >Nome </td>
				<td class='td1' >Data </td>
				<td class='td1' >Horário </td>
				<td class='td1'>CPF. </td>
				<td class='td1'>Acão </td>
			</tr>

<?
				
				$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where status='A' and data='$data' ";
				$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
				while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
				$idp  = $campo_noticias_hcpj['id'];
				$cpf_buscap =$campo_noticias_hcpj['cpf'];
				$nomep = $campo_noticias_hcpj['nome'];
				$datanascimentop = $campo_noticias_hcpj['datanascimento'];
				$telcelp = $campo_noticias_hcpj['celular'];
				$telres = $campo_noticias_hcpj['telefone'];					
				$datap = $campo_noticias_hcpj['data'];					
				$horariop = $campo_noticias_hcpj['horario'];					
				

				
			?>	
			
			<tr class='tr_tb' >		
				<td class='td2' > <?=$idp;?> </td>
				<td class='td2' > <?=$nomep;?> </td>
				<td class='td2' > <?=$datap;?> </td>
				<td class='td2' > <?=$horariop;?> </td>
				<td class='td2' > <?=$cpf_buscap;?> </td>
				<td class='td2' > <a href="#" Onclick="Abrir_Pagina('imprimeagendamento.php?idp=<?=$idp;?>');">Imprimir</td>
			</tr>
			<?}?>
			</table>
			
			
			
			</form>
		
			
			
		
			
			
</div>			

</div>


</body>
</html>