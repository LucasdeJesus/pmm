<?
?>

<html>
<?include'topo.php';?>

	<script>
 $(document).ready(function(){									
										$("#cadastro_empresa").validate();										
										$.validator.setDefaults({
									submitHandler: function() {
										
										}
										});
										});
</script>	
<body onload="">
			
			
			
		<?include"topo_logo.php";?>
	
	
		<div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);margin-top:50px;' align='center' >
			<table width='960px'>
					<tr>
					
					
						<td width=''>
									
							<div style='min-height:400px;'>	
						<div id="pdf_condutores">
				

							</div><!-- fim pdf_condutores -->

								<iframe src="ajudasemtre.pdf" width="100%" height="780" style="border: none;"></iframe>
							</div>
									
						</td>	

					</tr>
				</table>
				
		</div>
		
		

		<?include"rodape_novo.php";?>
		
</body>
</html>
