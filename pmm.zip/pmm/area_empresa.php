<?include("conf.php"); // Inclui o arquivo com o sistema de segurança

error_reporting(0);
?>

<html>
<?include'topo.php';?>

<body>
		
		
		<?include"topo_logo_empresa.php";?>
	
	
		<div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);margin-top:50px;' align='center' >
			<table width='960px'>
					<tr>
					
					
						<td width=''>
									
							<div style='min-height:400px;'>				
							</div>
									
						</td>	

					</tr>
				</table>
				
		</div>
		
		
		 

		<?include"rodape_novo.php";?>
		
</body>
</html>