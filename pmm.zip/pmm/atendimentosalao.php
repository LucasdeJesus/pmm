	<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	

	
	
	?>
	

					
		
					<?
						
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			
			
						$diaatual = date("d");
						$mestual = date("m");
						$anoatual = date("Y");
						
						if($get_acao==""){
						$sql2data="$anoatual-$mestual";						
						}
						else
						{
						//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
						if($post_status==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='$post_status'  ";}
						if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
						if($post_descricao==""){}else{$sqldescricao="and `descricao` LIKE '%$post_descricao%' ";}				
						if($post_escolaridade==""){}else{$sqloescolaridade="and escolaridade='$post_escolaridade' ";}
						if($post_sexo==""){}else{$sqlsexo="and sexo='$post_sexo' ";}
						if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
						if($post_id==""){}else{$sqlid="and id='$post_id' ";}
						if($empresaid==""){}else{$sqlempresaid="and empresaid='$empresaid' ";}


						$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));						;


						if($post_datainicio==""){}else{
						
						$sql2data="$post_datainicio1";
						
						}
						
						
					}
					
					$pieces = explode("-", $sql2data);
					$anogetdata=  $pieces[0]; // piece1
					$mesgetdata=  $pieces[1]; // piece1
					$totalgeralctpmm=0;
					$nomeusuarioarrei = ""; 
					echo"<div style='width:100%;' align='center'><h5>Busca referente: $anogetdata-$mesgetdata</h5></div>";
					$dataatual="$anogetdata-$mesgetdata";
					?>
						<script  type="text/javascript">	
						
				
					function salvaatendimento(atividade,dia) {
					
											
					switch(dia) {
							case 1:
								var dia1= "01";
								break;
							case 2:
								var dia1= "02";
								break;
						 case 3:
								var dia1= "03";
								break;
						 case 4:
								var dia1= "04";
								break;
						 case 5:
								var dia1= "05";
								break;
						 case 6:
								var dia1= "06";
								break;
						 case 7:
								var dia1= "07";
								break;
						 case 8:
								var dia1= "08";
								break;
						 case 9:
								var dia1= "09";
								break;
						default:		
								var dia1= dia;
						}
						   
						   
					valor_input = document.getElementById(atividade+'carteira_'+dia1).value;
					 
					// Verificando Browser
					if(window.XMLHttpRequest) {
					req = new XMLHttpRequest();
					}
					else if(window.ActiveXObject) {
					req = new ActiveXObject("Microsoft.XMLHTTP");
					}
					   
					// Arquivo PHP juntamente com o valor digitado no campo (método GET)
					var url = "script.php?atividade="+atividade+"&valorinput="+valor_input+"&data=<?=$dataatual;?>-"+dia1;
					//alert(url);
					// Chamada do método open para processar a requisição
					req.open("Get", url, true); 
					req.setRequestHeader("Cache-Control","no-cache,no-store");
					req.setRequestHeader("Pragma", "no-cache");

					// Quando o objeto recebe o retorno, chamamos a seguinte função;
					req.onreadystatechange = function() {

					// Exibe a mensagem "Buscando Noticias..." enquanto carrega
					if(req.readyState == 1) {
					document.getElementById('salvadados').innerHTML = 'Carregando aguarde...';
					}
							
					// Verifica se o Ajax realizou todas as operações corretamente
					if(req.readyState == 4 && req.status == 200) {

					// Resposta retornada pelo busca.php
					var resposta = req.responseText;

					// Abaixo colocamos a(s) resposta(s) na div resultado
					document.getElementById('salvadados').innerHTML = resposta;
					}
					}
					req.send(null);
					req.setRequestHeader("Cache-Control", "no-cache");
					req.setRequestHeader("Pragma", "no-cache"); 
					
					}
					
					</script>
					
							
							<div id="getexcel">
							
								<!-------------------carteira- de trabalho---------------------------->
								
							
								<table border="1" width="">
										
										
										<tr width=''>
															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;CTPM + DETRAN&nbsp;</b></font>
														    </td>
																
																
																<td width='40px' class="td2"><b> &nbsp;01&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;02&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;03&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;04&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;05&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;06&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;07&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;08&nbsp; </b></td>																	
																<td width='40px' class="td2"><b> &nbsp;09&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;10&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;11&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;12&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;13&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;14&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;15&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;16&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;17&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;18&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;19&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;20&nbsp; </b></td>
																<td width='40px' class="td2"><b> &nbsp;21&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;22&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;23&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;24&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;25&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;26&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;27&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;28&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;29&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;30&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;31&nbsp; </b></td>																
																<td width='40px' class="td2"><b> &nbsp;T&nbsp;</b> </td>																
														</tr>
														
														<tr width='' bgcolor="#8FB98"><!---dic  via---->
															<td  align="center" id="trCab1" onMouseOver="MouseSobreCab('1')"  onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#000" face="Tahoma" style="width:100px;padding:3px;"><b>&nbsp;Total DETRAN </b></font>
														    </td>
																
															<?php
																$totalgeral = 0;
																$arrCadict  = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
																$iCadict = 0;
																$totalfinalrg = 0;
																												
																while ($iCadict  < count($arrCadict)) {
																$Cadict  = $arrCadict [$iCadict ];
																
																
																////1
																	$totalCat =0;
																	$query_noticias_hcpj1t = "SELECT * FROM `atendimentorg` WHERE  `dia` = '$anogetdata-$mesgetdata-$Cadict'  and via='1' ";
																	$rs_noticias_hcpj1t    = mysql_query($query_noticias_hcpj1t);
																	$totaldia1t = mysql_num_rows($rs_noticias_hcpj1t);
																	
																	if($totaldia1t > 0){
																		
																		while($campo_noticias_hcpj1t = mysql_fetch_array($rs_noticias_hcpj1t)){			
																		$quantidade1t  = $campo_noticias_hcpj1t['quantidade'];
																		$totalCat+=$quantidade1t;																			
																		}																		
																	}else{$totalCat+=$quantidade1t=0;}
																////2
																	$totalCa2t =0;	
																	$query_noticias_hcpj2t = "SELECT * FROM `atendimentorg` WHERE  `dia` = '$anogetdata-$mesgetdata-$Cadict' and via='2'";
																	$rs_noticias_hcpj2t    = mysql_query($query_noticias_hcpj2t);
																	$totaldia2t = mysql_num_rows($rs_noticias_hcpj2t);
																	
																	if($totaldia2t > 0)
																	{
																		while($campo_noticias_hcpj2t = mysql_fetch_array($rs_noticias_hcpj2t)){			
																		$quantidade2t  = $campo_noticias_hcpj2t['quantidade'];
																		$totalCa2t+=$quantidade2t;																			
																		}
																	}else{$totalCa2t+=$quantidade2t=0;}
																////3
																	$totalCadict  = 0;
																	$query_noticias_hcpjdict = "SELECT * FROM `atendimentorg` WHERE  `dia` ='$anogetdata-$mesgetdata-$Cadict'  and via='3'";
																	$rs_noticias_hcpjdict     = mysql_query($query_noticias_hcpjdict );
																	$totaldiadict = mysql_num_rows($rs_noticias_hcpjdict);																	
																	if($totaldiadict > 0)
																	{
																		while($campo_noticias_hcpjdict  = mysql_fetch_array($rs_noticias_hcpjdict )){			
																		$quantidadedict   = $campo_noticias_hcpjdict ['quantidade'];
																		$totalCadict+=$quantidadedict ;
																		}
																	}else{$totalCadict+=$quantidadedict=0;}
																
																	$totalgeral= $totalCat+$totalCa2t+$totalCadict;
																	$totalfinalrg+=$totalgeral;
																 ?>
																 
																 <td width='40px' class="td2" title="" style="padding:0px;"><input type='text' id="detran_<?=$Cadict ;?>"  name="detran_<?=$Cadict ;?>" value="<?=$totalgeral;?>" style="width:25px;height:17px;background-color: transparent;border: 0px"/></td>																		
																
																  <?
																   $iCadict ++;
															}?>	
																
																
																<td width='40px' class="td2"  bgcolor="#fff" > <input id='totalgeral_detran' value="<?=$totalfinalrg;?>" style="width:25px;height:17px;background-color: transparent;border: 0px"/>  </td>	
														</tr><!---dic via---->
														
														
														
																					
																																
							<tr bgcolor="#EEDD82">
							<td  align="center"  style="width:279px"id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#00" face="Tahoma"><b>&nbsp;Total_Atendimento&nbsp;</b></font>
							</td>

							<?
								$arratgerald = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
								$iatgerald = 0;
								$totalatgerald = 0;
								while ($iatgerald < count($arratgerald)) {
								$atgerald = $arratgerald[$iatgerald];

								$query_C1agd = "SELECT * FROM `atendimento` WHERE  atividade='T' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%' ";
								$rs_C1agd    = mysql_query($query_C1agd);
								$diaC1agd = mysql_num_rows($rs_C1agd);
								if($diaC1agd==""){$diaC1agd="0";}


								//$query_C1aegd = "SELECT * FROM `encaminhamento` WHERE `datacadastro` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioid='$usuarioaid1'";
								$query_C1aegd = "SELECT * FROM `atendimento` WHERE  atividade='E' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%'  ";
								$rs_C1aegd    = mysql_query($query_C1aegd);
								$diaC1aegd = mysql_num_rows($rs_C1aegd);
								if($diaC1aegd==""){$diaC1aegd="0";}

								$query_N1agd = "SELECT * FROM `atendimento` WHERE  atividade='N' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%'  ";
								$rs_N1agd    = mysql_query($query_N1agd);
								$diaN1agd = mysql_num_rows($rs_N1agd);
								if($diaN1agd==""){$diaN1agd="0";}

								$query_C1aezgd= "SELECT * FROM `atendimento` WHERE  atividade='Z' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%' ";
								$rs_C1aezgd    = mysql_query($query_C1aezgd);
								$diaC1aezgd = mysql_num_rows($rs_C1aezgd);
								if($diaC1aezgd==""){$diaC1aezgd="0";}

								$query_C1aezagd= "SELECT * FROM `atendimento` WHERE  atividade='A' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%'  ";
								$rs_C1aezagd    = mysql_query($query_C1aezagd);
								$diaC1aezagd = mysql_num_rows($rs_C1aezagd);
								if($diaC1aezagd==""){$diaC1aezagd="0";}

								/// r11
								$cadastro_CEagd =$diaC1agd+$diaN1agd+$diaC1aegd+$diaC1aezgd+$diaC1aezagd;

								////////////////////////////////////////////////////////////----- encaminha ------------------////////////////////////////////
								$query_E1gd = "SELECT * FROM `encaminhamento` WHERE `datacadastro` LIKE '%$anogetdata-$mesgetdata-$atgerald%'  ";
								$rs_E1gd    = mysql_query($query_E1gd);
								$diaE1gd = mysql_num_rows($rs_E1gd);
								if($diaE1gd==""){$diaE1gd="0";}
								/// r11
								$diaE1gd; 

								////////////////////////////////////////////////////////////-------------cadastro----------////////////////////////////////

								$query_C1gd = "SELECT * FROM `trabalhador` WHERE   `datacadastro` LIKE '%$anogetdata-$mesgetdata-$atgerald%' ";
								$rs_C1gd    = mysql_query($query_C1gd);
								$diaC1gd = mysql_num_rows($rs_C1gd);
								if($diaC1gd==""){$diaC1gd="0";}

								$query_N1gd = "SELECT * FROM `atendimento` WHERE  atividade='N' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%'  ";
								$rs_N1gd    = mysql_query($query_N1gd);
								$diaN1gd = mysql_num_rows($rs_N1gd);
								if($diaN1gd==""){$diaN1gd="0";}
								/// r11
								$cadastro_CEgd =$diaC1gd+$diaN1gd;



								$somadiariad= $cadastro_CEgd+$cadastro_CEagd;
								$totalatgerald+=$somadiariad;
								?>	
								
								<td width='40px' class="td2"  style="padding:0px;" Title="soma cadastro <?=$cadastro_CEgd;?> / Atend.<?=$cadastro_CEagd;?> / "><input type='text' id="atendimento_<?=$atgerald ;?>"  name="atendimento_<?=$atgerald ;?>" value="<?=$somadiariad;?>" style="width:25px;height:17px;background-color: transparent;border: 0px"/></td>
								<?
								$iatgerald++;
								}?>															
							<td width='40px' class="td2"> <input id='totalgeral_atendimento' value="<?=$totalatgerald;?>" style="width:25px;height:17px;background-color: transparent;border: 0px"/></td>																
							</tr>
							
							
							
							
							
							<tr width='' bgcolor="#87CEEB"><!---1 via---->
															<td  align="center" id="trCab1" onMouseOver="MouseSobreCab('1')"  onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#000" face="Tahoma" style="width:100px;padding:3px;"><b>Total CTPM + Detran </b></font>
														    </td>
																
															<?php
															
																$arrCa = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
																$iCa = 0;
																$totalCa = 0;																
																while ($iCa < count($arrCa)) {
																   $Ca = $arrCa[$iCa];
																   
																  															
																?>
																
																<td width='40px' class="td2" title="" style="padding:0px;"><input type='text' id="soma<?=$Ca;?>"  name="soma<?=$Ca;?>" value="" style="width:25px;height:17px;background-color: transparent;border: 0px"/></td>
																<script>
																	var atendimento_<?=$Ca ;?> = document.getElementById("atendimento_<?=$Ca ;?>").value;
																	var detran_<?=$Ca ;?>= document.getElementById("detran_<?=$Ca ;?>").value;
																	var detran_atendiemnto_<?=$Ca ;?>= parseInt(atendimento_<?=$Ca ;?>) + parseInt(detran_<?=$Ca ;?>);																	
																	document.getElementById("soma<?=$Ca;?>").value=detran_atendiemnto_<?=$Ca ;?>;
																	
																</script>
																	
															<?
															$iCa++;
															}?>	
																
																
															<td width='40px' class="td2"  bgcolor="#fff" > <input id='totalgeral'  style="width:25px;height:17px;background-color: transparent;border: 0px"/> </td>	
															<script>
																	var totalgeral_detran = document.getElementById("totalgeral_detran").value;
																	var totalgeral_atendimento= document.getElementById("totalgeral_atendimento").value;
																	var dsomatudo= parseInt(totalgeral_detran) + parseInt(totalgeral_atendimento);																	
																	document.getElementById("totalgeral").value=dsomatudo;
																</script>
								</tr><!---1 via---->
															
															
								
				</table>
								
	
	</div>
	 
