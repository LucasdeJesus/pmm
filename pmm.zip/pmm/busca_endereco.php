<?include("interno/input_banco.php"); // Inclui o arquivo com o sistema de segurança



	$tipo_busca = $_GET['tipo_busca'];
	$uf = $_GET['uf'];
	$id_bairro = $_GET['cidade'];
	
switch ($tipo_busca) {
	
	case cidade:
		$query_noticiasdcemede = "SELECT * FROM `cidade` where ufid='$uf' ORDER BY  `cidade`.`nome` ASC ";
		$rs_noticiasdcemede    = mysql_query($query_noticiasdcemede);
		while($campo_noticiasdcemede = mysql_fetch_array($rs_noticiasdcemede)){																												
		$cidade = $campo_noticiasdcemede['nome'];
		$cidade_id = $campo_noticiasdcemede['id'];
		
		echo"<option value='$cidade_id'>$cidade</option>";
		}
	break;	
	
	case bairro:
		$query_noticiasdcemedeb = "SELECT * FROM `bairros` WHERE `cd_cidade` = '$id_bairro' ORDER BY `bairros`.`ds_bairro_nome` ASC ";
		$rs_noticiasdcemedeb    = mysql_query($query_noticiasdcemedeb);
		while($campo_noticiasdcemedeb = mysql_fetch_array($rs_noticiasdcemedeb)){																												
		$ds_bairro_nome = $campo_noticiasdcemedeb['ds_bairro_nome'];
		$bairro_id= $campo_noticiasdcemedeb['cd_bairro'];
		
		echo"<option value='$bairro_id'>$ds_bairro_nome</option>";
		}
	break;
	
}?>