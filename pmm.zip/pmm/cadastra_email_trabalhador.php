<?
include'interno/input_banco.php';
?>

<html>
<?include'topo.php';?>

		
<body onload="">
			
			
			
		<?include"topo_logo.php";?>
	
	
		<div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);margin-top:50px;' align='center' >
			<table width='960px'>
					<tr>
					
					
						<td width=''>
									
							<div style='min-height:400px;'>	
						

				
							<?
							$id = $_GET['id'];
							$email 	=(string)addslashes($_POST['email']); 
							
							if($email ==""){}else{
								$query="update  trabalhador set email ='$email' where id='$id' ";
								$rs= mysql_query($query);
								
								if($rs){
									$style="style='display:none'";
									echo"
										<h3>
										
										<b>$email </b>Inserido com sucesso!<br>
										
											
											1°- clique em : <a  href='#'title='Login do Trabalhado' data-reveal-id='myModal'><span>Login do Trabalhado</span></a> <br>
											2°- esquecir minha senha .<br>
											3°- Informe seu cpf.
										
										</h3>
										
									";
								}
								
								else
								{
									
									echo"<h3>Erro, tente novamente</h3>";
								}
							}
							
							$query_noticias_dados = "SELECT email,nome,id  FROM `trabalhador` where id='$id'";	
							$rs_noticias_dados    = mysql_query($query_noticias_dados);
							while($campo_noticias_dados = mysql_fetch_array($rs_noticias_dados)){			
							$email  = $campo_noticias_dados['email'];
							$nometrabalhador 	= $campo_noticias_dados['nome']; 													
							$idtrabalhador 	= $campo_noticias_dados['id']; 	
							}
							
							?>
							<div  <?=$style ;?>>
							<h2>Atualizar  email</h2>						
						
										<form  class="form" method="POST" action="?id=<?=$id;?>"  >
												
												
												
												<h3> <b><?=$nometrabalhador ;?></b>, Informe seu email para Redefinição de senha </h3>
												<div class="form-row">
												<div class="label">Email</div>
												<div class="input-container"><input name="email" id='email' required  placeholder="Email " type="email"  class="input req-same"   /></div>
												</div>

												
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn" value='enviar'  /></div>
												</div>
												
												
												
												
										
										</form>


							</div>
							
							
							
							</div>
									
						</td>	

					</tr>
				</table>
				
		</div>
		
		

		<?include"rodape_novo.php";?>
		
</body>
</html>
