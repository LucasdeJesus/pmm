function escolaridade()
{
    i = document.formPag.CodFormMax_cand.selectedIndex;
    cod = document.formPag.CodFormMax_cand.options[i].value;
	if (cod != '-1')
	  return document.formPag.CodFormMax_cand.options[i].text
	else
	  return 'indefinida'
}

function sexo ()
{
  if (document.formPagHidden.Nome_cand.value != '') {
    if (document.formPagHidden.Masc_cand.value == 'True')
      return 1;
    else
      return 0;
  } else {
    if (document.formPag.Masc_cand[0].checked)
      return 1;
    else
      return 0;
  }
}

function estadocivil(qsexo)
{
  if (document.formPagHidden.Nome_cand.value != '') {
	  cod = document.formPagHidden.CodEstadoCivil_cand.value;
  } else {
	  i = document.formPag.CodEstadoCivil_cand.selectedIndex;
	  cod = document.formPag.CodEstadoCivil_cand.options[i].value;
  }

  if (cod == "1") {
    if (qsexo == 0)
	  return "solteira";
	else if (qsexo == 1)
	  return "solteiro";
	else
	  return "solteiro(a)";
  }
  else if (cod == "2") {
    if (qsexo == 0)
	  return "casada";
	else if (qsexo == 1)
	  return "casado";
	else
	  return "casado(a)";
  }
  else if (cod == "3") {
    if (qsexo == 0)
	  return "separada";
	else if (qsexo == 1)
	  return "separado";
	else
	  return "separado(a)";
  }
  else if (cod == "4") {
    if (qsexo == 0)
	  return "divorciada";
	else if (qsexo == 1)
	  return "divorciado";
	else
	  return "divorciado(a)";
  }
  else if (cod == "5") {
    if (qsexo == 0)
	  return "vi�va";
	else if (qsexo == 1)
	  return "vi�vo";
	else
	  return "vi�vo(a)";
  }
  return "indefinido";  
}

function nacionalidade()
{
  if (document.formPagHidden.Nome_cand.value != '') {
    cod = document.formPagHidden.CodNacion_cand.value;
	if (cod = '31')
	  return 'Brasil';
	else
	  return 'indefinida';
  } else {
    i = document.formPag.CodNacion_cand.selectedIndex;
    cod = document.formPag.CodNacion_cand.options[i].value;
	if (cod != '-1')
	  return document.formPag.CodNacion_cand.options[i].text
	else
	  return 'indefinida'
  }
}

function valor(strIn)
{
  strValor = "";
  v_iMax = strIn.length;
  v_dec = 0;
  if (v_iMax > 3) {
    if (strIn.charAt(v_iMax-3) == '.' || strIn.charAt(v_iMax-3) == ',') {
	  strValor = strIn.charAt(v_iMax-3) + strIn.charAt(v_iMax-2) + strIn.charAt(v_iMax-1);
	  v_iMax = v_iMax - 3;
	}
	else
	  strValor = ",00";
  }
  for (v_i = v_iMax-1; v_i >= 0; v_i--) {
    v_car = strIn.charAt(v_i);
	if (v_car != '.' && v_car != ',') {
	  if (v_dec == 3) {
	    strValor = '.' + strValor;
		v_dec = 0;
	  }
      v_dec++;
	  strValor = v_car + strValor;
	}
  }
  return strValor;
}

function procTxt (strIn, insUL)
{
  h_haItem = false
  h_dentroUL = false
  h_liAberto = false
  txtToHtml = ""
  h_ini = 0
  if (strIn == "")
    return strIn;
  if (strIn.charAt(0) == '.') {
    h_estado = 2
    if (insUL) {
  	  txtToHtml = "<ul><li>";
	  h_dentroUL = true;
	}
	else
  	  txtToHtml = "<li>";
	h_haItem = true;
	h_ini = 1;
  }
  else
    h_estado = 0;
  for (h_i = h_ini; h_i < strIn.length; h_i++) {
    h_car = strIn.charAt(h_i);
    if (h_car != '\n') {
 	  if (h_estado == 0) {
	      if (h_car == '\r')
		    h_estado = 1;
		  else
		    txtToHtml = txtToHtml + h_car;
	  } else if (h_estado == 1) {
	      if (h_car == '.') {
		    if (insUL && !h_dentroUL) {
		      txtToHtml = txtToHtml + "<ul><li>";
			  h_dentroUL = true;
		    }
		    else
		      txtToHtml = txtToHtml + "<li>";
 	   	    h_haItem = true
		    h_estado = 2
		  }
		  else {
		    if (h_dentroUL) {
		      txtToHtml = txtToHtml + "</ul>" + "\n";
			  h_dentroUL = false;
		    }
		    else
			  txtToHtml = txtToHtml + "<br>";
			if (h_car == '\r')
			  h_estado = 1;
			else {
			  txtToHtml = txtToHtml + h_car;
		      h_estado = 0;
			}
		  }
      } else if (h_estado == 2) {
	      if (h_car == '\r') {
		    txtToHtml = txtToHtml + "</li>"
		    h_estado = 1
	  	  }
		  else
		    txtToHtml = txtToHtml + h_car;
	    }
	 }
  }
  if (h_estado == 1) {
    if (h_dentroUL)
      txtToHtml = txtToHtml + "</ul>" + "\n";
	else
      txtToHtml = txtToHtml + "\n";
  }
  else {
    if (h_estado == 2) {
      if (h_dentroUL)
        txtToHtml = txtToHtml + "</li></ul>";
	  else
        txtToHtml = txtToHtml + "</li>";
    }
  }
  return txtToHtml;
}

function procNum (strIn)
{
  var n_i;
  strProcNum = ""
  if (strIn == "")
    return strIn;
  if (strIn.charAt(n_i) == '0')
	  n_i = 1;
  else
      n_i = 0;
  for (; n_i < strIn.length; n_i++)
    strProcNum = strProcNum + strIn.charAt(n_i);
  return strProcNum;
}

function idade()
{
  if (document.formPagHidden.Nome_cand.value != '') {
    strd = procNum(document.formPagHidden.DtNasc_cand_dia.value);
    strm = procNum(document.formPagHidden.DtNasc_cand_mes.value); 
    stra = procNum(document.formPagHidden.DtNasc_cand_ano.value);
  } else {
    strd = procNum(document.formPag.DtNasc_cand_dia.value);
    strm = procNum(document.formPag.DtNasc_cand_mes.value); 
    stra = procNum(document.formPag.DtNasc_cand_ano.value);
  }
  d = parseInt(strd,10)
  m = parseInt(strm,10); 
  a = parseInt(stra,10); 
  if (isNaN(d) || isNaN(m) || isNaN(a)) {
    return "xx anos"
  }
  else {
 	if (a < 10)
	  a = a + 2000
	else
	  if (a < 100)
	    a = a + 1900
    anos = ahj - a;
	if ((mhj < m) || ((mhj == m) && (dhj < d)))
	  anos = anos - 1;
  }
  return anos + " anos";
}

function nomeDocumento(strIn)
{
  var n_i;
  if (strIn == "")
    return strIn;
  for (n_i = 0; n_i < strIn.length; n_i++) {
    if (strIn.charAt(n_i) == '-')
		return strIn.substr(n_i+2, strIn.length-n_i+1);
  }
  return strIn;
}

function prefixoTelefPais()
// por enquanto est� hardcoded apenas o prefixo do Brasil
{
  if (document.formPagHidden.Nome_cand.value != '') {
    cod = document.formPagHidden.CelCodPais_cand.value;
	if (cod == '1')
	  return '55';

  } else {
    cod = document.formPag.CelCodPais_cand.value;
	if (cod == '1')
	  return '55';
  }
}

function resumo(nrml)
{
  if (DP_DataNasc) 
	res = idade();
  else
    res = ""  
  if (DP_EstadoCivil) {
	  if (nrml)
	    res = res + ", " + estadocivil(sexo());
	  else
	    res = res + ", " + estadocivil(-1);
  }
  if (nrml && DP_Filhos) {	
    if (document.formPag.NroFilhos_cand.value != "") {
      if (document.formPag.NroFilhos_cand.value == "1")
	  	//@@+Var
	    res = res + ", 1 filho";
		//@@-Var
	  else
	  	//@@+Var
	    res = res + ", " + document.formPag.NroFilhos_cand.value + " filhos"
		//@@-Var
    }
    else {
	  if (DP_EstadoCivil)
	      if (estadocivil(1) != "solteiro")
		    //@@+Var
		    res = res + ", sem filhos"
			//@@-Var
    }
  } 
  if (DP_Nacionalidade) {
	  nacion = nacionalidade();
	  if (nacion == "Brasil") {
	    if (nrml) {
	      if (sexo() == 1)
		    //@@+Var
		    res = "Brasileiro, " + res 
			//@@-Var
	  	  else
		    //@@+Var
		    res = "Brasileira, " + res 
			//@@-Var
		}
		else
	      //@@+Var
		  res = "Brasileiro(a), " + res
	 	  //@@-Var
	  }
	  else {
	    if (document.formPagHidden.Nome_cand.value == '') {
	      //@@+Var
	      res = res + ", nacionalidade " + nacionalidade();
		  //@@-Var
		}
	  }
  }
  if (nrml) {
    if (document.formPagHidden.Nome_cand.value != '') {
		if (DP_Endereco) {
		    res = res + "<br>" + document.formPagHidden.Endereco_cand.value + " " + document.formPagHidden.Bairro_cand.value;
			if (document.formPagHidden.CodPais_cand.value == '31')
				res = res + "<br>" + document.formPagHidden.Cep_cand_1.value + "-" + document.formPagHidden.Cep_cand_2.value + " ";
			else
				res = res + "<br>" + document.formPagHidden.Cep_cand_1.value + " ";
			if (document.formPag.CodCidade_cand.value != -1 && document.formPag.CodCidade_cand.value != -2)			
				res = res + document.formPag.CodCidade_cand.options[document.formPag.CodCidade_cand.selectedIndex].text + ", ";
			if (document.formPag.CodUF_cand.value != -1 && document.formPag.CodUF_cand.value != -2)
				res = res + document.formPag.CodUF_cand.options[document.formPag.CodUF_cand.selectedIndex].text + " - ";		
			res = res + document.formPag.CodPais_cand.options[document.formPag.CodPais_cand.selectedIndex].text;	
		}					
	    if (document.formPagHidden.Tel_cand.value != "") {
	      res = res + "<br>" + document.formPagHidden.Tel_cand.value;
	    }
		if (DP_Celular) {		
			if (document.formPagHidden.Celular_cand.value != "" && !document.formPagHidden.CelularConfidencial_cand.checked ) {
 			  //@@+Var
		      res = res + "<br>" + "cel " + prefixoTelefPais() + " (" + document.formPagHidden.CelCodArea_cand.value + ") " + document.formPagHidden.Celular_cand.value;
			  //@@-Var
		    }
		}
	    if (document.formPagHidden.Email_cand.value != "") {
	      res = res + "<br>" + document.formPagHidden.Email_cand.value;
	    }
		if (DP_SitesRelPess) {
		    if (document.formPagHidden.SitePessoal_cand.value != "") {
		      res = res + "<br>" + document.formPagHidden.SitePessoal_cand.value;
	    	}
		    if (document.formPagHidden.SiteRelacionamento_cand.value != "") {
		      res = res + "<br>" + document.formPagHidden.SiteRelacionamento_cand.value;
	    	}
		}

	} else {
		if (DP_Documento) {
			if (QtdeDocCand == 1) {
				if (document.formPag.NroDoc.value != "")
					res = res + "<br>" + nomeDocumento(document.formPag.CodTipoDoc.options[document.formPag.CodTipoDoc.selectedIndex].text) + " " + document.formPag.NroDoc.value;
			}
			else {
				for (i = 0; i < QtdeDocCand; i++) {
					if (document.formPag.NroDoc[i].value != "")
						res = res + "<br>" + nomeDocumento(document.formPag.CodTipoDoc[i].options[document.formPag.CodTipoDoc[i].selectedIndex].text) + " " + document.formPag.NroDoc[i].value;
				}
			}
		}
		if (DP_Endereco) {
		    res = res + "<br>" + document.formPag.Endereco_cand.value + " " + document.formPag.Bairro_cand.value;
	//	    res = res + "<br>" + document.formPag.Cep_cand_1.value + "-" + document.formPag.Cep_cand_2.value + " " + document.formPag.Cidade_cand.value + ", " + document.formPag.UF_cand.value;
			if (document.formPag.CodPais_cand.value == '31')
				res = res + "<br>" + document.formPag.Cep_cand_1.value + "-" + document.formPag.Cep_cand_2.value + " ";
			else
				res = res + "<br>" + document.formPag.Cep_cand_1.value + " ";
			if (document.formPag.CodCidade_cand.value != -1 && document.formPag.CodCidade_cand.value != -2)			
				res = res + document.formPag.CodCidade_cand.options[document.formPag.CodCidade_cand.selectedIndex].text + ", ";
			if (document.formPag.CodUF_cand.value != -1 && document.formPag.CodUF_cand.value != -2)
				res = res + document.formPag.CodUF_cand.options[document.formPag.CodUF_cand.selectedIndex].text + " - ";		
			res = res + document.formPag.CodPais_cand.options[document.formPag.CodPais_cand.selectedIndex].text;				
		}
	    if (document.formPag.Tel_cand.value != "") {
	      res = res + "<br>" + document.formPag.Tel_cand.value;
	    }
		if (DP_Celular) {		
			if (document.formPag.Celular_cand.value != "" && !document.formPag.CelularConfidencial_cand.checked) {
			  //@@+Var
		      res = res + "<br>" + "cel " + prefixoTelefPais() + " (" + document.formPag.CelCodArea_cand.value + ") " + document.formPag.Celular_cand.value;
			  //@@-Var
		    }
		}
		if (DP_Email) {
		    if (document.formPag.Email_cand.value != "") {
		      res = res + "<br>" + document.formPag.Email_cand.value;
	    	}
		}
		if (DP_SitesRelPess) {
		    if (document.formPag.SitePessoal_cand.value != "") {
		      res = res + "<br>" + document.formPag.SitePessoal_cand.value;
	    	}
		    if (document.formPag.SiteRelacionamento_cand.value != "") {
		      res = res + "<br>" + document.formPag.SiteRelacionamento_cand.value;
	    	}
		}
	}
  } else {
//  		if (document.formPag.Cidade_cand.value != '') {
//			if (document.formPag.Cidade_cand.value == 'Rio de Janeiro') {
//			  res = res + '<br>Residente no Rio de janeiro - ' + document.formPag.UF_cand.value
//			} else {
//			  res = res + '<br>Residente em ' + document.formPag.Cidade_cand.value + ' - ' + document.formPag.UF_cand.value
//			}
//		}
		    if (DP_Endereco) {
				//@@+Var    
				res = res + '<br>Residente em '
				//@@-Var
				if (document.formPag.CodCidade_cand.value != -1 && document.formPag.CodCidade_cand.value != -2)
					res=res + document.formPag.CodCidade_cand.options[document.formPag.CodCidade_cand.selectedIndex].text;
				if (document.formPag.CodUF_cand.value != -1 && document.formPag.CodUF_cand.value != -2)
					res=res + ' - ' + document.formPag.CodUF_cand.options[document.formPag.CodUF_cand.selectedIndex].text;
				if (document.formPag.CodPais_cand.value != -1 && document.formPag.CodPais_cand.value != -2)
					res=res + ' - ' + document.formPag.CodPais_cand.options[document.formPag.CodPais_cand.selectedIndex].text;
			}

  }
  return res;
}


function idiomas() 
{
  lst = "";
  for (j = 1; j <= QtdeIdiomasCand; j++) {
    nomeidioma = "Idioma" + j
    nomenleit =  "Nleit" + j
    nomenescr = "Nescr" + j
    nomenconv = "Nconv" + j
    sep = " ";
    if (document.formPag.elements[nomeidioma].options[document.formPag.elements[nomeidioma].selectedIndex].value != '-1' && (document.formPag.elements[nomenleit].selectedIndex != 0 || document.formPag.elements[nomenescr].selectedIndex != 0 || document.formPag.elements[nomenconv].selectedIndex != 0)) {
	    if (lst != "")
		  lst = lst + "<br>";
		i = document.formPag.elements[nomeidioma].selectedIndex;
		lst = lst + "<i>" + document.formPag.elements[nomeidioma].options[i].text + "</i>:";
		i = document.formPag.elements[nomenleit].selectedIndex;
		if (i != 0) {
		  //@@+Var
		  lst = lst + sep + "leitura " + document.formPag.elements[nomenleit].options[i].text.toLowerCase();
		  //@@-Var
		  sep = ", ";
		}
		i = document.formPag.elements[nomenescr].selectedIndex;
		if (i != 0) {
		  //@@+Var
		  lst = lst + sep + "escrita " + document.formPag.elements[nomenescr].options[i].text.toLowerCase();
		  //@@-Var
		  sep = ", ";
		}
		i = document.formPag.elements[nomenconv].selectedIndex;
		if (i != 0) {
		  //@@+Var
		  lst = lst + sep + "conversa&ccedil;&atilde;o " + document.formPag.elements[nomenconv].options[i].text.toLowerCase();
		  //@@-Var
		}
	}
 }
 return lst;
}

function maior(strDt1, strDt2)
{
  dt1 = parseInt(strDt1,10); 
  dt2 = parseInt(strDt2,10); 
  if (!isNaN(dt1) && !isNaN(dt2)) {
 	if (dt1 < 10)
	  dt1 = dt1 + 2000
	else
	  if (dt1 < 100)
	    dt1 = dt1 + 1900
    if (dt2 < 10)
	  dt2 = dt2 + 2000
	else
	  if (dt2 < 100)
	    dt2 = dt2 + 1900
    return (dt1 > dt2);
  }
  else
    if (isNaN(dt1) && !isNaN(dt2))
	  return true;
	else
      if (!isNaN(dt1) && isNaN(dt2))
	    return false;
}

function formacoes() 
{
  lst = "";
  n = 0;
  for (i = 0; i < QtdeFormCand; i++) {
  	if (!BCEX) {
		if (!isBlank(document.formPag.Curso[i].value) &&
			!isBlank(document.formPag.Instituicao[i].value) &&
			document.formPag.PaisForm[i].options[document.formPag.PaisForm[i].selectedIndex].value != '-1' &&
			(document.formPag.PaisForm[i].options[document.formPag.PaisForm[i].selectedIndex].value != '31' || document.formPag.UFForm[i].options[document.formPag.UFForm[i].selectedIndex].value != '-1') &&
			document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value != '-1' &&
			document.formPag.Duracao[i].options[document.formPag.Duracao[i].selectedIndex].value != '-1' &&
			document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value != '-1' &&
			((document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value != '30' && document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value != '1') || document.formPag.CursoGradForm[i].options[document.formPag.CursoGradForm[i].selectedIndex].value != '-1') &&
			((document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value != '40' && document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value != '50' && document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value != '60' && document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value != '70' && document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value != '2') || document.formPag.CursoPGradForm[i].options[document.formPag.CursoPGradForm[i].selectedIndex].value != '-1') &&
			((document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value != '20' 
			  && document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value != '30') ||
			(document.formPag.MesConclusao[i].options[document.formPag.MesConclusao[i].selectedIndex].value != '-1' &&
			!isBlank(document.formPag.AnoConclusao[i].value))) ) {
		    Curso[i] = document.formPag.Curso[i].value;
		    Inst[i] = document.formPag.Instituicao[i].value;
//			codPais = document.formPag.PaisForm[i].options[document.formPag.PaisForm[i].selectedIndex].value;
//			if (codPais != '31' && codPais != '-1') {
//				for (j = CadIni["Pais"]; j <= CadFim["Pais"]; j++) {
//					if (codPais == CadV[j]) {
//						Inst[i] += ' (' + CadD[j] + ')'
//						break;
//					}
//				}
//			}
			j = document.formPag.Tipo[i].selectedIndex;
		    Tipo[i] = parseInt(document.formPag.Tipo[i].options[j].value,10);
			//@@+Var
			Conc[i] = 'situa��o atual indefinida';
			//@@-Var
			if (document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '10')
				//@@+Var
				Conc[i] = 'interrompido'
				//@@-Var
			else if (document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '20') {
				//@@+Var
				Conc[i] = 'cursando at� ' + CadD[CadIni["Mes"] + parseInt(document.formPag.MesConclusao[i].options[document.formPag.MesConclusao[i].selectedIndex].value,10) - 1] + '/' + document.formPag.AnoConclusao[i].value;
				//@@-Var
			} else if (document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '30') {
				//@@+Var
				Conc[i] = 'conclu�do em ' + CadD[CadIni["Mes"] + parseInt(document.formPag.MesConclusao[i].options[document.formPag.MesConclusao[i].selectedIndex].value,10) - 1] + '/' + document.formPag.AnoConclusao[i].value;
				//@@-Var
			}
			FVal[i] = true;
			n++;
		} else {
			Tipo[i] = -1;
			FVal[i] = false;
		}
	}
	else {														//BCEX
		if (!isBlank(document.formPag.Curso[i].value) ||
			!isBlank(document.formPag.Instituicao[i].value)) {
			if (!isBlank(document.formPag.Curso[i].value)) {		
			    Curso[i] = document.formPag.Curso[i].value;
			} else {
			    Curso[i] = '';
			}
			if (!isBlank(document.formPag.Instituicao[i].value)) {		
		    	Inst[i] = document.formPag.Instituicao[i].value;
			} else {
				Inst[i] = '';
			}
			if (document.formPag.PaisForm[i].value != -1)
				Inst[i] += ' (' + document.formPag.PaisForm[i].options[document.formPag.PaisForm[i].selectedIndex].text + ')';
//			codPais = document.formPag.PaisForm[i].value;
//			if (codPais != 31 && codPais != -1) {
//				for (j = CadIni["Pais"]; j <= CadFim["Pais"]; j++) {
//					if (codPais == CadV[j]) {
//						Inst[i] += ' (' + CadD[j] + ')'
//						break;
//					}
//				}
//			}
			j = document.formPag.Tipo[i].selectedIndex;
		    Tipo[i] = parseInt(document.formPag.Tipo[i].options[j].value,10);
			if (Tipo[i] == -1) Tipo[i] = 1000;			
			//@@+Var
			Conc[i] = 'situa��o atual indefinida';
			//@@-Var
			if (document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '10')
				//@@+Var
				Conc[i] = 'interrompido'
				//@@-Var
			else if (document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == 20) {
				//@@+Var
				Conc[i] = 'cursando at� ' + CadD[CadIni["Mes"] + parseInt(document.formPag.MesConclusao[i].options[document.formPag.MesConclusao[i].selectedIndex].value,10) - 1] + '/' + document.formPag.AnoConclusao[i].value;
				//@@-Var
			} else if (document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == 30) {
				//@@+Var
				Conc[i] = 'conclu�do em ' + CadD[CadIni["Mes"] + parseInt(document.formPag.MesConclusao[i].options[document.formPag.MesConclusao[i].selectedIndex].value,10) - 1] + '/' + document.formPag.AnoConclusao[i].value;
				//@@-Var
			}
			FVal[i] = true;
			n++;
		} else {
			Tipo[i] = -1;
			FVal[i] = false;
		}
	}
	
  }
  cod = CadV[CadIni["TipoForm"]];
  ultcod = -1;
  while (n > 0) {
    achou = false;
    prox = -1;
    for (i = 0; i < QtdeFormCand; i++)  {
      if (FVal[i] && Tipo[i] == cod) {
	    if (prox == -1) {
	      prox = i;
  		  achou = true;
  	    }
	    else {
	      if (maior(Conc[i],Conc[prox])) {
		    prox = i;
  		    achou = true;
  		  }
	    }
	  }
    }
	if (achou) {
	// Processa formacao
	  if (lst != "" && ultcod != cod)
	    lst = lst + "</font></li>"
	  if (ultcod != cod) {
	    formacao = document.formPag.Tipo[prox].options[document.formPag.Tipo[prox].selectedIndex].text;
		if (document.formPag.Tipo[prox].options[document.formPag.Tipo[prox].selectedIndex].value != '-1')
	    	formacao = document.formPag.Tipo[prox].options[document.formPag.Tipo[prox].selectedIndex].text;
		else
			//@@+Var
			formacao = 'Forma��o n�o classificada';
			//@@-Var
        lst = lst + '<li><font face="Verdana, Arial" size="2"><b>' + formacao + '<br></b>';
		ultcod = cod;
	  }
	  else
	    lst = lst + "<br>";
	  lst = lst + "<i>" + Curso[prox] + "</i>";
	  if (Inst[prox] != "")
	    lst = lst + ", " + Inst[prox];
	  if (Conc[prox] != "")
	    lst = lst + " (" + Conc[prox] + ")";
	  lst = lst + ".";
	  FVal[prox] = false;
	  n--;
	}
	else {
	   if (CadV[CadIni["TipoForm"]] == 1)
		  cod += 1;
	   else 
	   	  cod += 10;
	}
  }
  if (lst != "")
	lst = lst + "</font></li>"
  return lst;
}

function dd(strMes1, strAno1, strMes2, strAno2)
{
  strMes1 = procNum(strMes1);
  strAno1 = procNum(strAno1);
  strMes2 = procNum(strMes2);
  strAno2 = procNum(strAno2);
  m1 = parseInt(strMes1,10); 
  a1 = parseInt(strAno1,10); 
  m2 = parseInt(strMes2,10); 
  a2 = parseInt(strAno2,10);
  if (isNaN(a2)) {
	a2 = ahj;
	m2 = mhj;
  }

  if (isNaN(a1))
	  return "??? anos";
  else {
	  if (a1 < 10)
	    a1 = a1 + 2000
	  else
	    if (a1 < 100)
		  a1 = a1 + 1900
	  if (a2 < 10)
	    a2 = a2 + 2000
	  else
	    if (a2 < 100)
		  a2 = a2 + 1900
	  if (a1 <= a2)
	    anos = a2 - a1;
	  else
		return "??? anos";
		  
	  if (isNaN(m2)) {
	    if (anos != 0)
 	      return anos + " anos";
		else
		  return "??? meses";
	  }
	  else {
	    if (isNaN(m1)) {
	      if (anos != 0)
 	        return anos + " anos";
		  else
		    return "??? meses";
		}
		else {
		  if (m2 > m1) {
	        if (anos == 0) {
			  if (m2 - m1 == 1)
		        return "1 mes";
			  else
		        return (m2 - m1) + " meses";
			}
		    else
			  if (anos == 1) {
			    if (m2 - m1 == 1)
  	              return "1 ano e 1 mes";
				else
  	              return "1 ano e " + (m2 - m1) + " meses";
			  }
			  else {
			    if (m2 - m1 == 1)
  	              return anos + " anos e 1 mes";
				else
  	              return anos + " anos e " + (m2 - m1) + " meses";
			  }
		  }
		  else {
		    if (m2 < m1) {
	          if (anos > 1) {
			    if (anos == 2) {
				  if (12 + m2 - m1 == 1)
		            return "1 ano e 1 mes";
				  else
		            return "1 ano e " + (12 + m2 - m1) + " meses";
				}
				else {
				  if (12 + m2 - m1 == 1)
		            return (anos-1) + " anos e 1 mes";
				  else
		            return (anos-1) + " anos e " + (12 + m2 - m1) + " meses";
				}
			  }
		      else
			    if (anos == 1) {
				  if (12 + m2 - m1 == 1)
 		            return "1 mes";
				  else
 		            return (12 + m2 - m1) + " meses";
				}
				else
 	              return "??? meses";
			}
			else {
	          if (anos == 0)
		        return "Menos de 1 mes";
		      else
			    if (anos == 1)
 	              return "1 ano";
				else
 	              return anos + " anos";
			}
		  }
	    }
	  }
	}
}

function maior2(strMes1, strAno1, strMes2, strAno2)
{
  strMes1 = procNum(strMes1);
  strAno1 = procNum(strAno1);
  strMes2 = procNum(strMes2);
  strAno2 = procNum(strAno2);
  m1 = parseInt(strMes1,10); 
  a1 = parseInt(strAno1,10); 
  m2 = parseInt(strMes2,10); 
  a2 = parseInt(strAno2,10); 
  if (isNaN(a1))
    return true;
  else
    if (isNaN(a2))
	  return false;
	else {
	  if (a1 < 10)
	    a1 = a1 + 2000
	  else
	    if (a1 < 100)
		  a1 = a1 + 1900
	  if (a2 < 10)
	    a2 = a2 + 2000
	  else
	    if (a2 < 100)
		  a2 = a2 + 1900
	  if (a1 > a2)
	    return true;
	  else
	    if (a1 < a2)
		  return false;
		else {
		  if (isNaN(m2))
		    return true;
		  else
		    if (isNaN(m1))
			  return false;
			else
			  if (m1 > m2)
			    return true;
			  else
			    return false;
		}
	}
}

function historico (nrml)
{
  lst = "";
  n = 0;
  if (HP_Exps) {
	  for (i = 0; i < QtdeExpProfCand; i++) {
	  	if (!BCEX) {	  
			if (!isBlank(document.formPag.Empresa[i].value) &&
			    document.formPag.TipoEmpExp[i].selectedIndex != 0 &&
			    (document.formPag.TipoEmpExp[i].selectedIndex != 2 || !isBlank(document.formPag.NacionalidadeEmpExp[i].value)) &&
			    document.formPag.CodSegmento[i].selectedIndex != 0 &&
			    document.formPag.CodPorte[i].selectedIndex != 0 &&
			    document.formPag.MesInicio[i].options[document.formPag.MesInicio[i].selectedIndex].value != '-1' &&
			    !isBlank(document.formPag.AnoInicio[i].value) &&
			    !isBlank(document.formPag.UltimoCargo[i].value) &&
			    !isBlank(document.formPag.Descricao[i].value)
				) {
			    Empr[i] = document.formPag.Empresa[i].value;
			    //Rem[i] = document.formPag.RemoveExp[i].checked;
			    Rem[i] = false;
				if (document.formPag.TipoEmpExp[i].selectedIndex == 2)
					Multi[i] = true;
				else
					Multi[i] = false;
				j = document.formPag.CodSegmento[i].selectedIndex;
			    CodSeg[i] = parseInt(document.formPag.CodSegmento[i].options[j].value,10);
				j = document.formPag.CodPorte[i].selectedIndex;
			    CodPorte[i] = parseInt(document.formPag.CodPorte[i].options[j].value,10);
				MesIni[i] = CadD[CadIni["Mes"] + parseInt(document.formPag.MesInicio[i].options[document.formPag.MesInicio[i].selectedIndex].value,10) - 1];
				MesIni[i] = document.formPag.MesInicio[i].value
			    AnoIni[i] = document.formPag.AnoInicio[i].value;
				if (document.formPag.MesFim[i].options[document.formPag.MesFim[i].selectedIndex].value != '-1')
				    MesFim[i] = CadD[CadIni["Mes"] + parseInt(document.formPag.MesFim[i].options[document.formPag.MesFim[i].selectedIndex].value,10) - 1];
				else
					MesFim[i] = '';
				MesFim[i] = document.formPag.MesFim[i].value
			    AnoFim[i] = document.formPag.AnoFim[i].value;
			    Cargo[i] = document.formPag.UltimoCargo[i].value;
			    Descr[i] = document.formPag.Descricao[i].value;
				n++;
			} else
			  Rem[i] = true;
		}
		else {												// BCEX
			if (!isBlank(document.formPag.Empresa[i].value) ||
			    document.formPag.TipoEmpExp[i].selectedIndex != 0 ||
			    !isBlank(document.formPag.NacionalidadeEmpExp[i].value) ||
			    document.formPag.CodSegmento[i].selectedIndex != 0 ||
			    document.formPag.CodPorte[i].selectedIndex != 0 ||
			    document.formPag.MesInicio[i].options[document.formPag.MesInicio[i].selectedIndex].value != '-1' ||
			    !isBlank(document.formPag.AnoInicio[i].value) ||
			    !isBlank(document.formPag.UltimoCargo[i].value) ||
			    !isBlank(document.formPag.Descricao[i].value)
				) {
				if (!isBlank(document.formPag.Empresa[i].value))
				    Empr[i] = document.formPag.Empresa[i].value;				
				else
			    	Empr[i] = '';
			    //Rem[i] = document.formPag.RemoveExp[i].checked;
			    Rem[i] = false;
				if (document.formPag.TipoEmpExp[i].selectedIndex == 2)
					Multi[i] = true;
				else
					Multi[i] = false;
				j = document.formPag.CodSegmento[i].selectedIndex;
			    CodSeg[i] = parseInt(document.formPag.CodSegmento[i].options[j].value,10);
				j = document.formPag.CodPorte[i].selectedIndex;
			    CodPorte[i] = parseInt(document.formPag.CodPorte[i].options[j].value,10);
				if (document.formPag.MesInicio[i].options[document.formPag.MesInicio[i].selectedIndex].value != '-1')
					MesIni[i] = CadD[CadIni["Mes"] + parseInt(document.formPag.MesInicio[i].options[document.formPag.MesInicio[i].selectedIndex].value,10) - 1];
				else
					MesIni[i] = '';
				MesIni[i] = document.formPag.MesInicio[i].value
			    AnoIni[i] = document.formPag.AnoInicio[i].value;
				if (document.formPag.MesFim[i].options[document.formPag.MesFim[i].selectedIndex].value != '-1')
				    MesFim[i] = CadD[CadIni["Mes"] + parseInt(document.formPag.MesFim[i].options[document.formPag.MesFim[i].selectedIndex].value,10) - 1];
				else
					MesFim[i] = '';
				MesFim[i] = document.formPag.MesFim[i].value
			    AnoFim[i] = document.formPag.AnoFim[i].value;
				if (!isBlank(document.formPag.UltimoCargo[i].value))
				    Cargo[i] = document.formPag.UltimoCargo[i].value;
				else
					Cargo[i] = '';
				if (!isBlank(document.formPag.Descricao[i].value))					
				    Descr[i] = document.formPag.Descricao[i].value;
				else
					Descr[i] = '';
				n++;
			} else
			  Rem[i] = true;
		}
	  }
	  while (n > 0) {
	    achou = false;
	    prox = -1;
	    for (i = 0; i < QtdeExpProfCand; i++)  {
	      if (!Rem[i]) {
		    if (prox == -1) {
		      prox = i;
	  		  achou = true;
	  	    }
		    else {
		      if (maior2(MesFim[i],AnoFim[i],MesFim[prox],AnoFim[prox])) {
			    prox = i;
	  		    achou = true;
	  		  }
		    }
		  }
	    }
		if (achou) {
		  // Processa historico
		  if (Empr[prox] != "" && nrml) {
		    lst = lst + '<li><font face="Verdana, Arial" size="2"><b>' + Empr[prox] + '</b> - ';
		    if (AnoFim[prox] == "") {
			    if (MesIni[prox] != -1) {
				  //@@+Var	
			      lst = lst + 'desde ' + CadD[CadIni["Mes"] + parseInt(MesIni[prox],10) - 1].toLowerCase() + "/";
				  //@@-Var
				  if (AnoIni[prox] != "")
				  	lst = lst + AnoIni[prox];
				}
				else
				  if (AnoIni[prox] != "")
				  	//@@+Var
				    lst = lst + 'desde ' + AnoIni[prox];
					//@@-Var
		    }
		    else {
	 	        if (MesIni[prox] != -1) {
				  //@@+Var
			      lst = lst + 'de ' + CadD[CadIni["Mes"] + parseInt(MesIni[prox],10) - 1].toLowerCase() + "/";
				  //@@-Var
				  if (AnoIni[prox] != "")
				  	//@@+Var
				  	lst = lst + AnoIni[prox] + " a ";
					//@@-Var
				}
				else
					if (AnoIni[prox] != "")
					  //@@+Var	
				      lst = lst + 'de ' + AnoIni[prox] + " a ";
					  //@@-Var
			    if (MesFim[prox] != -1)
			      lst = lst + CadD[CadIni["Mes"] + parseInt(MesFim[prox],10) - 1].toLowerCase() + "/";
	 		    lst = lst + AnoFim[prox];
		    }

			if (document.formPag.CodPorte[prox].options[document.formPag.CodPorte[prox].selectedIndex].value != '-1') {
			   porte = document.formPag.CodPorte[prox].options[document.formPag.CodPorte[prox].selectedIndex].text 
			   if (document.formPag.CodPorte[prox].options[document.formPag.CodPorte[prox].selectedIndex].value < 5) {
					lst = lst + "<br><font size=1>(" + porte.toLowerCase()
					if (Multi[prox] && CodPorte[prox] <= 3) {
					    if (document.formPag.NacionalidadeEmpExp[prox].value == '')
						  //@@+Var
						  lst = lst + " - multinacional -";
						  //@@-Var
						else
						  //@@+Var
						  lst = lst + " - multinacional (" + procTxt(document.formPag.NacionalidadeEmpExp[prox].value,true) + ") -";
						  //@@-Var
					}
					if (CodSeg[prox] != 1) {
					  segto = document.formPag.CodSegmento[prox].options[document.formPag.CodSegmento[prox].selectedIndex].text
					  //@@+Var
					  lst = lst + " no segmento " + segto.toLowerCase();
					  //@@-Var
					}
					lst = lst + ")</font><b>";
				} else {
					lst = lst + "<br></b><font size=1>(" + porte.toLowerCase() + ")</font><b>";
				} 
			}
			else {				// CodPorte = -1
				if (Multi[prox]) { 
					if (document.formPag.NacionalidadeEmpExp[prox].value == '')
						//@@+Var
						lst = lst + "<br><font size=1>(empresa multinacional "
						//@@-Var
					else
						//@@+Var
						lst = lst + "<br><font size=1>(empresa multinacional (" + procTxt(document.formPag.NacionalidadeEmpExp[prox].value,true) + ") "
						//@@-Var
					if 	(CodSeg[prox] != 1 && CodSeg[prox] != -1) {
					  segto = document.formPag.CodSegmento[prox].options[document.formPag.CodSegmento[prox].selectedIndex].text
					  //@@+Var
					  lst = lst + "- no segmento " + segto.toLowerCase() + ")</font><b>";
					  //@@-Var
					}
					else
						lst = lst + ")</font><b>"
				}
				else {
					if 	(CodSeg[prox] != 1 && CodSeg[prox] != -1) {
					  segto = document.formPag.CodSegmento[prox].options[document.formPag.CodSegmento[prox].selectedIndex].text
					  //@@+Var
					  lst = lst + "<br><font size=1>(empresa no segmento " + segto.toLowerCase() + ")</font><b>";
					  //@@-Var
					}
				}
			}
		  }
		  else {

		    if (nrml) {
			    if (AnoFim[prox] == "") {
				    if (MesIni[prox] != -1) {
				      lst = lst + '<li><font face="Verdana, Arial" size="2"><b><!#>Desde<!/#> ' + CadD[CadIni["Mes"] + parseInt(MesIni[prox],10) - 1].toLowerCase() + "/";
					  if (AnoIni[prox] != "")
					  	lst = lst + AnoIni[prox];
					}
					else
					  if (AnoIni[prox] != "")
					    lst = lst + '<li><font face="Verdana, Arial" size="2"><b><!#>Desde<!/#> ' + AnoIni[prox];
					  else
					    lst = lst + '<li><font face="Verdana, Arial" size="2"><b>';					  
			    }
			    else {
		 	        if (MesIni[prox] != -1) {
				      lst = lst + '<li><font face="Verdana, Arial" size="2"><b><!#>De<!/#> ' + CadD[CadIni["Mes"] + parseInt(MesIni[prox],10) - 1].toLowerCase() + "/";
					  if (AnoIni[prox] != "")
					  	//@@+Var
					  	lst = lst + AnoIni[prox] + " a ";
						//@@-Var
					}
					else
						if (AnoIni[prox] != "")		
						  //@@+Var				  
					      lst = lst + '<li><font face="Verdana, Arial" size="2"><b>De ' + AnoIni[prox] + " a ";						  
						  //@@-Var
						else
						  //@@+Var
					      lst = lst + '<li><font face="Verdana, Arial" size="2"><b>De ? a ';						
						  //@@-Var
				    if (MesFim[prox] != -1)
				      lst = lst + CadD[CadIni["Mes"] + parseInt(MesFim[prox],10) - 1].toLowerCase() + "/";
		 		    lst = lst + AnoFim[prox];
			    }
		    }
	 	    else {
			  if ((MesIni[prox] != -1 && AnoIni[prox] != '' && MesFim[prox] != -1 && AnoFim[prox] != '') || !BCEX)
			  	lst = lst + '<li><font face="Verdana, Arial" size="2"><b>' + dd(MesIni[prox],AnoIni[prox],MesFim[prox],AnoFim[prox]);
			  else
			    //@@+Var
			  	lst = lst + '<li><font face="Verdana, Arial" size="2"><b>??? anos ou meses' ;
				//@@-Var
			}

			if (document.formPag.CodPorte[prox].value != -1) {
			   porte = document.formPag.CodPorte[prox].options[document.formPag.CodPorte[prox].selectedIndex].text 
			   if (document.formPag.CodPorte[prox].value < 5) {
					lst = lst + "</b><br><font size=1>(" + porte.toLowerCase()
					if (Multi[prox] && CodPorte[prox] <= 3) {
					    if (document.formPag.NacionalidadeEmpExp[prox].value == '')
						  //@@+Var
						  lst = lst + " - multinacional -";
						  //@@-Var
						else
						  //@@+Var
						  lst = lst + " - multinacional (" + document.formPag.NacionalidadeEmpExp[prox].value + ") -";
						  //@@-Var
					}
					if (CodSeg[prox] != 1 && CodSeg[prox] != -1) {
					  segto = document.formPag.CodSegmento[prox].options[document.formPag.CodSegmento[prox].selectedIndex].text
					  //@@+Var
					  lst = lst + " no segmento " + segto.toLowerCase()
					  //@@-Var
					}
					lst = lst + ")</font><b>";
				} else {
					lst = lst + "<br></b><font size=1>(" + porte.toLowerCase() + ")</font><b>";
				} 
			}
			else {				// CodPorte = -1
				if (Multi[prox]) { 
					if (document.formPag.NacionalidadeEmpExp[prox].value == '')
					    //@@+Var
						lst = lst + "</b><br><font size=1>(empresa multinacional "
						//@@-Var
					else
					    //@@+Var
						lst = lst + "</b><br><font size=1>(empresa multinacional (" + procTxt(document.formPag.NacionalidadeEmpExp[prox].value,true) + ") "
						//@@-Var
					if 	(CodSeg[prox] != 1 && CodSeg[prox] != -1) {
					  segto = document.formPag.CodSegmento[prox].options[document.formPag.CodPorte[prox].selectedIndex].text
					  //@@+Var
					  lst = lst + "- no segmento " + segto.toLowerCase() + ")</font><b>";
					  //@@-Var
					}
					else
						lst = lst + ")</font><b>"
				}
				else {
					if 	(CodSeg[prox] != 1 && CodSeg[prox] != -1) {
					  segto = document.formPag.CodSegmento[prox].options[document.formPag.CodSegmento[prox].selectedIndex].text
					  //@@+Var
					  lst = lst + "</b><br><font size=1>(empresa no segmento " + segto.toLowerCase() + ")</font><b>";
					  //@@-Var
					}
				}
			}

		  }
		  if (Cargo[i] != "")
		    lst = lst + "<br><i>" + Cargo[prox] + "</i>";
		  lst = lst + "<br></b>";
		  if (Descr[prox] != "") {
		    lst = lst + procTxt(Descr[prox],true) + "<br>";
		  }	
		  lst = lst + "</font></li>";
		  Rem[prox] = true;
		  n--;
		}
	  }
	  if (lst != "")
		lst = lst + "</font></li>"
  }
  return lst;
}

function showcvx()
{
  shwcv(true);
}

function showcvconfx()
{
 shwcv(false);
}

function shwcv (nrml)
{
  var appName = navigator.appName;
  if (nrml) {
    //if (cv != null && appName.indexOf("Microsoft") != 0)	
	  //cv.close();
    cv=window.open('', 'cv', 'height=460,width=640,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no');
  }	
  else {
    //if (cvconf != null && appName.indexOf("Microsoft") != 0)	
	  //cvconf.close();
    cvconf=window.open('', 'cvconf', 'height=460,width=640,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no');
  }
  html = '<html><head><title>Curr&iacute;culo</title><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>';
  html = html + '<body bgcolor="#FFFFFF"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td valign="top" width="60%" colspan="3"><p><font size="5" face="Verdana, Arial">';
  if (nrml) {
    if (document.formPagHidden.Nome_cand.value != '')
	  html = html + document.formPagHidden.Nome_cand.value;
	else
	  html = html + document.formPag.Nome_cand.value;
  } else
    //@@+Var
    html = html + "Curr&iacute;culo Confidencial";
	//@@-Var	
  html = html + '</font></p></td><td valign="top" width="40%" colspan="2" align="right"><font size="1" face="Verdana, Arial">';
  html = html + resumo(nrml);
  if (OBJ_Objetivo) {
  	html = html + '</font></td></tr><tr valign="top"><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td></tr><tr><td width="100%" colspan="5"><b><font face="Verdana, Arial" size="3"><!#>Objetivo<!/#></font></b></td></tr><tr><td width="100%" colspan="5"><blockquote><p><font face="Verdana, Arial" size="2">';
  	html = html + document.formPag.Objetivo_cand.value;
  }
  
  if (OBJ_Perfil) {
	if (document.formPag.Perfil_cand.value != "" && document.formPag.Perfil_cand.value != "-") {
  		html = html + '<tr valign="top"><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td></tr>';
		html = html + '<tr><td width="100%" colspan="5"><b><font face="Verdana, Arial" size="3"><!#>Perfil profissional<!/#></font></b></td></tr><tr><td width="100%" colspan="5"><blockquote><p><font face="Verdana, Arial" size="2">';
		html = html + procTxt(document.formPag.Perfil_cand.value,false);
		html = html + '</font></p></blockquote></td></tr>';
	  }
  }

  if (FORM_Escolaridade || FORM_Forms) {
	  html = html + '<tr><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td></tr>';
	  html = html + '<tr><td width="100%" colspan="5"><font face="Verdana, Arial" size="3"><b><!#>Forma&ccedil;&atilde;o<!/#></b></font></td></tr>';
	  html = html + '<tr><td width="100%" colspan="5"><ul>';
  }

  if (FORM_Escolaridade) {
	  html = html + '<li><font face="Verdana, Arial" size="2"><b><!#>Escolaridade<!/#></b><br>';
	  html = html + escolaridade();
	  html = html + '<br></font></li>';
  }

  if (FORM_Forms) {
	  lst = formacoes();
	  if (lst != "") {
	    html = html + lst;
	  }
  }
  if (FORM_Escolaridade || FORM_Forms)
	  html = html + '</ul></td></tr>';

  if (FORM_Idiomas) {
	  lst = idiomas();
	  if (lst != "") {
	    html = html + '<tr><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td></tr>';
	    html = html + '<tr><td width="100%" colspan="5"><font face="Verdana, Arial" size="3"><b><!#>Idiomas<!/#></b></font></td></tr>';
	    html = html + '<tr><td width="100%" colspan="5"><font face="Verdana, Arial" size="2"><ul>';
	    html = html + lst;
	    html = html + '<br></ul></font></td></tr>';
	  }
  }
  

  lst = historico(nrml);
  if (lst != "") {
	html = html + '<tr><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td></tr>';
    html = html + '<tr> <td width="100%" colspan="5"><font face="Verdana, Arial" size="3"><b><!#>Hist&oacute;rico profissional<!/#></b></font></td></tr><tr><td width="100%" colspan="5"><ul>';
    html = html + lst;
    html = html + '</ul></td></tr>';
  }

  if (HP_UltSal) {
	  if (!isBlank(document.formPag.UltSal_cand.value) && isCurrency(document.formPag.UltSal_cand.value,true) &&
	  	  (document.formPag.UltSalAtualCand[0].checked ||
		   (document.formPag.UltSalAtualCand[1].checked && document.formPag.MesUltSalCand.selectedIndex != 0 && isYear('AnoUltSalCand',-1,false)))) {
	    html = html + '<tr><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td></tr>';
	    lst = document.formPag.CodMoeUltSal_cand.options[document.formPag.CodMoeUltSal_cand.selectedIndex].text;
	    lst = lst + '&nbsp;';
	    lst = lst + valor(document.formPag.UltSal_cand.value);
		if (document.formPag.UltSalAtualCand[1].checked)
		  lst = lst + ' em ' + document.formPag.MesUltSalCand.options[document.formPag.MesUltSalCand.selectedIndex].text.toLowerCase() + '/' + document.formPag.AnoUltSalCand.value + '.';
		else
		  lst = lst + ' (atual).'
		if (document.formPag.UltBeneficios_cand.value == '') {
		    html = html + '<tr><td width="100%" colspan="5"><font face="Verdana, Arial" size="3"><b><!#>&Uacute;ltimo sal&aacute;rio<!/#>:</b></font></td></tr><tr><td width="100%" colspan="5"><blockquote><p><font face="Verdana, Arial" size="2">' + lst + '</font></p></blockquote></td></tr>';
		}
		else {
		    html = html + '<tr><td width="100%" colspan="5"><font face="Verdana, Arial" size="3"><b><!#>&Uacute;ltimo sal&aacute;rio e benef&iacute;cios<!/#></b></font></td></tr>';
		    html = html + '<tr><td width="100%" colspan="5"><font face="Verdana, Arial" size="2"><ul><li><b><!#>&Uacute;ltimo sal&aacute;rio<!/#>:</b> ' + lst + '</li>';
		    html = html + '<li><b>Benef&iacute;cios</b>';
		    html = html + '<br>' + procTxt(document.formPag.UltBeneficios_cand.value,false) + '</li></ul></font></td></tr>';
		}
	  }
  }

  bMobilMudEnd = false;
  if (OBJ_MobilMudEnd)
	  if (document.formPag.DispMudEnd_cand[0].checked)
	    bMobilMudEnd = true
  bMobilViagens = false;
  if (OBJ_MobilViagens)
	  if (document.formPag.DispViagens_cand[0].checked)
	    bMobilViagens = true
	    
  if (OBJ_SalPret || OBJ_RegInteresse || bMobilMudEnd || bMobilViagens) {
 		html = html + '<tr valign="top"><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td></tr>';
		html = html + '<tr><td width="100%" colspan="5"><font face="Verdana, Arial" size="3"><b><!#>Outros objetivos<!/#></b></font></td></tr><tr><td width="100%" colspan="5"><ul>';
  }
  if (OBJ_SalPret) {
	  if (document.formPag.ValSalPret_cand.value != "") {
	    html = html + '<li><font face="Verdana, Arial" size="2"><b><!#>Pretens&atilde;o salarial:</b> Faixa de <!/#>';
	    html = html + document.formPag.CodMoeSalPret_cand.options[document.formPag.CodMoeSalPret_cand.selectedIndex].text;
	    html = html + '&nbsp;';
	    html = html + valor(document.formPag.ValSalPret_cand.value);
	    html = html + '.<br></font></li>';
	  }
  }

  if (OBJ_RegInteresse || bMobilMudEnd || bMobilViagens)
	  html = html + '<li><font face="Verdana, Arial" size="2"><b><!#>Regi&atilde;o de trabalho<!/#></b>';
  if (OBJ_RegInteresse) {
	  i = document.formPag.Local_regCand.selectedIndex;
	  if (i == 0)
		local =	document.formPag.CodCidade_cand.options[document.formPag.CodCidade_cand.selectedIndex].text
	  else
	    local = document.formPag.Local_regCand.options[i].text;
	  html = html + '<br>';
	  if (local == "Rio de Janeiro" || local == "Rio de Janeiro/RJ")
	  	//@@+Var
	    html = html + "Prefer&ecirc;ncia pela regi&atilde;o do " + local;
		//@@-Var
	  else
	  	//@@+Var
	    html = html + "Prefer&ecirc;ncia pela regi&atilde;o de " + local;
		//@@-Var
	  i = document.formPag.Raio_regCand.selectedIndex;
	  raio = parseInt(document.formPag.Raio_regCand.options[i].value,10);
	  if (raio > 100) {
	  	//@@+Var
		html = html + ", ou cidades num raio de at&eacute; " + raio/10 + " km.";
		//@@-Var
	  }
  }
  if (OBJ_MobilMudEnd) {
	  if (document.formPag.DispMudEnd_cand[0].checked)
	  	//@@+Var
	    html = html + '<br>Aceita considerar propostas de outras regi�es.';
		//@@-Var		
  }
  if (OBJ_MobilViagens) {
	  if (document.formPag.DispViagens_cand[0].checked)
	  	//@@+Var
	    html = html + '<br>Aceita viajar pela empresa.';
		//@@-Var
	  html = html + '</font></li></ul></td></tr>';
  }
  if (bMobilMudEnd || bMobilMudEnd) {
	  html = html + '</font></li></ul></td></tr>';
  }

  if (OBJ_InfoCompl) {	  
	  if (document.formPag.InfoCompl_cand.value != "") {
		  html = html + '<tr><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td></tr>';
		  html = html + '<tr><td width="100%" colspan="5"><font face="Verdana, Arial" size="3"><b>Informa&ccedil;&otilde;es complementares</b></font></td></tr><tr><td width="100%" colspan="5"><blockquote><p><font face="Verdana, Arial" size="2">';
		  html = html + procTxt(document.formPag.InfoCompl_cand.value,false);
		  html = html + '</font></p></blockquote></td></tr>';
	  }
  }

  if (DP_NecEsp) {
	  html = html + '<tr><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td></tr>';
	  if (document.formPag.NecEspPortador.selectedIndex == 1 &&
	      (document.formPag.NecEspAuditiva.checked || document.formPag.NecEspFala.checked || 
		   document.formPag.NecEspFisica.checked || document.formPag.NecEspMental.checked || document.formPag.NecEspVisual.checked)) {
		  html = html + '<tr><td width="100%" colspan="5"><font face="Verdana, Arial" size="3"><b><!#>Defici&ecirc;ncias<!/#></b></font></td></tr><tr><td width="100%" colspan="5"><ul><font face="Verdana, Arial" size="2">';
		  if (document.formPag.NecEspAuditiva.checked) {
		    html = html + '<li><font face="Verdana, Arial" size="2"><b><!#>Auditiva:<!/#> </b>';
			if (document.formPag.NecEspAuditivaTipo.selectedIndex > 0) {
	   		 	html = html + document.formPag.NecEspAuditivaTipo.options[document.formPag.NecEspAuditivaTipo.selectedIndex].text;
				if (document.formPag.NecEspAuditivaUniBi.selectedIndex > 0)
					html = html + ', ' + document.formPag.NecEspAuditivaUniBi.options[document.formPag.NecEspAuditivaUniBi.selectedIndex].text;
			}
			else
				if (document.formPag.NecEspAuditivaUniBi.selectedIndex > 0)
					html = html + document.formPag.NecEspAuditivaUniBi.options[document.formPag.NecEspAuditivaUniBi.selectedIndex].text;
		    html = html + '</font></li>';
		  }
		  if (document.formPag.NecEspFala.checked) {
		    html = html + '<li><font face="Verdana, Arial" size="2"><b><!#>Fala:<!/#> </b>';
			if (document.formPag.NecEspFalaTipo.selectedIndex > 0)
	   		 	html = html + document.formPag.NecEspFalaTipo.options[document.formPag.NecEspFalaTipo.selectedIndex].text;
		    html = html + '</font></li>';
		  }
		  if (document.formPag.NecEspFisica.checked) {
		    html = html + '<li><font face="Verdana, Arial" size="2"><b><!#>F�sica:<!/#> </b>';
			if (document.formPag.NecEspFisicaTipo.selectedIndex > 0) {
	   		 	html = html + document.formPag.NecEspFisicaTipo.options[document.formPag.NecEspFisicaTipo.selectedIndex].text;
				if (document.formPag.NecEspFisicaInfSup.selectedIndex > 0)
					html = html + ', ' + document.formPag.NecEspFisicaInfSup.options[document.formPag.NecEspFisicaInfSup.selectedIndex].text;
			}
			else
				if (document.formPag.NecEspFisicaInfSup.selectedIndex > 0)
					html = html + document.formPag.NecEspFisicaInfSup.options[document.formPag.NecEspFisicaInfSup.selectedIndex].text;
		    html = html + '</font></li>';
		  }
		  if (document.formPag.NecEspMental.checked) {
		    html = html + '<li><font face="Verdana, Arial" size="2"><b><!#>Mental: </b>Limita��es associadas �s seguintes �reas de habilidades adaptativas: <!/#>';
			if (document.formPag.NecEspComunic.checked) html = html + 'comunica��o, ';
			if (document.formPag.NecEspCuidadoPess.checked) html = html + 'cuidado pessoal, ';
			if (document.formPag.NecEspHabSocial.checked) html = html + 'habilidade social, ';			
			if (document.formPag.NecEspRecursosCom.checked) html = html + 'utiliza��o de recursos da comunidade, ';			
			if (document.formPag.NecEspSaudeSeg.checked) html = html + 'sa�de e seguran�a, ';			
			if (document.formPag.NecEspHabAcad.checked) html = html + 'habilidade acad�mica, ';			
			if (document.formPag.NecEspLazer.checked) html = html + 'lazer, ';			
			if (document.formPag.NecEspTrabalho.checked) html = html + 'trabalho, ';	
			html = html.substring(0, html.length-2);
		    html = html + '</font></li>';
		  }
		  if (document.formPag.NecEspVisual.checked) {
		    html = html + '<li><font face="Verdana, Arial" size="2"><b><!#>Visual:<!/#> </b>';
			if (document.formPag.NecEspVisualTipo.selectedIndex > 0) {
	   		 	html = html + document.formPag.NecEspVisualTipo.options[document.formPag.NecEspVisualTipo.selectedIndex].text;
				if (document.formPag.NecEspVisualUniBi.selectedIndex > 0)
					html = html + ', ' + document.formPag.NecEspVisualUniBi.options[document.formPag.NecEspVisualUniBi.selectedIndex].text;
			}
			else
				if (document.formPag.NecEspVisualUniBi.selectedIndex > 0)
					html = html + document.formPag.NecEspVisualUniBi.options[document.formPag.NecEspVisualUniBi.selectedIndex].text;
		    html = html + '</font></li>';
		  }
		  if (document.formPag.NecEspObs.value != '') {
		    html = html + '<li><font face="Verdana, Arial" size="2"><b><!#>Observa��es:<!/#></b><br>' + procTxt(document.formPag.NecEspObs.value,false) + '</font></li>';
		  }
		  html = html + '</font></ul></td></tr></tr><tr><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td><td width="20%">&nbsp;</td></tr>';
	  }
  }
  
  html = html + Rodape;
  if (nrml) {
    cv.document.close();
    cv.document.open();
    cv.document.write(html);
    cv.focus();
  }
  else {
    cvconf.document.close();
    cvconf.document.open();
    cvconf.document.write(html);
    cvconf.focus();
  }
  return false;
}
