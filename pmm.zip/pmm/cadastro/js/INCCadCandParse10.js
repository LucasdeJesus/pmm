var BCEX = false;
var bCampoObrigNaoPreenchido = false;

function showcv()
{
  if (PagLoaded)
    shwcv(true);
  else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}

function showcvconf()
{
  if (PagLoaded)
    shwcv(false);
  else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}

function popup(pag)
{
  if (PagLoaded) {
	x=window.open(pag, 'x', 'top=0,left=0,height=600,width=800,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no')
	x.resizeTo(window.screen.width,window.screen.height);
	x.focus();
  }
  else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}

function popupt(pag)
{
  dt=new Date();
  x=window.open(pag+'&t='+dt.getMinutes()+dt.getSeconds(), 'x', 'height=460,width=640,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no'); 
  x.focus();
}

function popupProgPrivacidadeCom()
{
  dt=new Date();
  if (PagLoaded) {
	pag = 'ProgPrivacidadeComPP.asp?pp=t'
    if (document.formPag.TipoCurCom_cand[0].checked)
      pag = pag + '&tcc=1'
    if (document.formPag.TipoCurCom_cand[1].checked)
      pag = pag + '&tcc=2'
    if (document.formPag.TipoCurCom_cand[2].checked)
      pag = pag + '&tcc=3'
    if (document.formPag.TipoCur_cand[0].checked)
      pag = pag + '&tc=1'
    if (document.formPag.TipoCur_cand[1].checked)
      pag = pag + '&tc=2'
    if (document.formPag.TipoCur_cand[2].checked)
      pag = pag + '&tc=3'
    if (document.formPag.MalaDireta_cand[0].checked)
      pag = pag + '&md=t'
    else
      pag = pag + '&md=f'
    if (document.formPag.MalaDiretaSite_cand[0].checked)
      pag = pag + '&mds=t'
    else
      pag = pag + '&mds=f'
	pag = pag + '&t=' + dt.getMinutes() + dt.getSeconds()
	x=window.open(pag, 'x', 'top=0,left=0,height=600,width=800,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no')
	x.resizeTo(window.screen.width,window.screen.height);
  }
  else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}

function popupProgPrivacidade()
{
  dt=new Date();
  if (PagLoaded) {
	pag = 'ProgPrivacidadePP.asp?pp=t'
    if (document.formPag.TipoCur_cand[0].checked)
      pag = pag + '&tc=1'
    if (document.formPag.TipoCur_cand[1].checked)
      pag = pag + '&tc=2'
    if (document.formPag.TipoCur_cand[2].checked)
      pag = pag + '&tc=3'
    if (document.formPag.MalaDireta_cand[0].checked)
      pag = pag + '&md=t'
    else
      pag = pag + '&md=f'
    if (document.formPag.MalaDiretaSite_cand[0].checked)
      pag = pag + '&mds=t'
    else
      pag = pag + '&mds=f'
	pag = pag + '&t=' + dt.getMinutes() + dt.getSeconds()
	x=window.open(pag, 'x', 'top=0,left=0,height=600,width=800,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no')
	x.resizeTo(window.screen.width,window.screen.height);
  }
  else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}

function popupProgPrivacidadeCom2()
{
  dt=new Date();
  if (PagLoaded) {
	pag = 'ProgPrivacidadeComPP.asp?pp=t'
    if (document.formPag.TipoCurCom_cand[0].checked)
      pag = pag + '&tcc=1'
    if (document.formPag.TipoCurCom_cand[1].checked)
      pag = pag + '&tcc=2'
    if (document.formPag.TipoCurCom_cand[2].checked)
      pag = pag + '&tcc=3'
    if (document.formPag.TipoCur_cand[0].checked)
      pag = pag + '&tc=1'
    if (document.formPag.TipoCur_cand[1].checked)
      pag = pag + '&tc=2'
    if (document.formPag.TipoCur_cand[2].checked)
      pag = pag + '&tc=3'
    if (document.formPag.PrivRecomendacao_cand[0].checked)
      pag = pag + '&pr=1'
    if (document.formPag.PrivRecomendacao_cand[1].checked)
      pag = pag + '&pr=3'
    if (document.formPag.MalaDireta_cand[0].checked)
      pag = pag + '&md=t'
    else
      pag = pag + '&md=f'
    if (document.formPag.MalaDiretaSite_cand[0].checked)
      pag = pag + '&mds=t'
    else
      pag = pag + '&mds=f'
	pag = pag + '&t=' + dt.getMinutes() + dt.getSeconds()
	x=window.open(pag, 'x', 'top=0,left=0,height=600,width=800,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no')
	x.resizeTo(window.screen.width,window.screen.height);
  }
  else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}

function popupProgPrivacidade2()
{
  dt=new Date();
  if (PagLoaded) {
	pag = 'ProgPrivacidadePP.asp?pp=t'
    if (document.formPag.TipoCur_cand[0].checked)
      pag = pag + '&tc=1'
    if (document.formPag.TipoCur_cand[1].checked)
      pag = pag + '&tc=2'
    if (document.formPag.TipoCur_cand[2].checked)
      pag = pag + '&tc=3'
    if (document.formPag.PrivRecomendacao_cand[0].checked)
      pag = pag + '&pr=1'
    if (document.formPag.PrivRecomendacao_cand[1].checked)
      pag = pag + '&pr=3'
    if (document.formPag.MalaDireta_cand[0].checked)
      pag = pag + '&md=t'
    else
      pag = pag + '&md=f'
    if (document.formPag.MalaDiretaSite_cand[0].checked)
      pag = pag + '&mds=t'
    else
      pag = pag + '&mds=f'
	pag = pag + '&t=' + dt.getMinutes() + dt.getSeconds()
	x=window.open(pag, 'x', 'top=0,left=0,height=600,width=800,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no')
	x.resizeTo(window.screen.width,window.screen.height);
  }
  else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}

function cidadeRefMapa()
{
  if (PagLoaded) {
    dt=new Date();
	x=window.open('CadCandRegiao2-Go.asp?t=' + dt.getMinutes() + dt.getSeconds(), 'x', 'top=0,left=0,height=600,width=800,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no')
	x.resizeTo(window.screen.width,window.screen.height);
  }
  else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}

function MM_swapImgRestore() { //v2.0
  if (document.MM_swapImgData != null)
    for (var i=0; i<(document.MM_swapImgData.length-1); i+=2)
      document.MM_swapImgData[i].src = document.MM_swapImgData[i+1];
}

function MM_preloadImages() { //v2.0
  if (document.images) {
    var imgFiles = MM_preloadImages.arguments;
    if (document.preloadArray==null) document.preloadArray = new Array();
    var i = document.preloadArray.length;
    with (document) for (var j=0; j<imgFiles.length; j++) if (imgFiles[j].charAt(0)!="#"){
      preloadArray[i] = new Image;
      preloadArray[i++].src = imgFiles[j];
  } }
}

function MM_swapImage() { //v2.0
  var i,j=0,objStr,obj,swapArray=new Array,oldArray=document.MM_swapImgData;
  for (i=0; i < (MM_swapImage.arguments.length-2); i+=3) {
    objStr = MM_swapImage.arguments[(navigator.appName == 'Netscape')?i:i+1];
    if ((objStr.indexOf('document.layers[')==0 && document.layers==null) ||
        (objStr.indexOf('document.all[')   ==0 && document.all   ==null))
      objStr = 'document'+objStr.substring(objStr.lastIndexOf('.'),objStr.length);
    obj = eval(objStr);
    if (obj != null) {
      swapArray[j++] = obj;
      swapArray[j++] = (oldArray==null || oldArray[j-1]!=obj)?obj.src:oldArray[j];
      obj.src = MM_swapImage.arguments[i+2];
  } }
  document.MM_swapImgData = swapArray; //used for restore
}

function AvisoSubst(action) {
  msg = 'Esta ficha j� foi preenchida anteriormente e a empresa n�o permite o acesso �s informa��es fornecidas. Voc� pode, contudo, optar por substituir a ficha anterior preenchendo-a novamente. Voc� deseja substituir esta ficha?';
  if (confirm(msg)) {
    submitFormSav(action)
  }
  else {
    return false;
  }
}

function LimpaForm() {
  if (confirm('Todos os campos preenchidos ser�o apagados. Confirma a opera��o?'))
    clearForm();
}

function RemExp(idx) {
  if (! PagLoaded)
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
  else {
	  if (document.formPag.Empresa[idx-1].value == '' &&
	  	  document.formPag.UltimoCargo[idx-1].value == '' &&
		  document.formPag.AnoInicio[idx-1].value == '' &&
		  document.formPag.AnoFim[idx-1].value == '' &&
		  document.formPag.Descricao[idx-1].value == '' &&
		  document.formPag.MesInicio[idx-1].options[document.formPag.MesInicio[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.MesFim[idx-1].options[document.formPag.MesFim[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.TipoEmpExp[idx-1].options[document.formPag.TipoEmpExp[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.CodSegmento[idx-1].options[document.formPag.CodSegmento[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.CodPorte[idx-1].options[document.formPag.CodPorte[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.CodHierarquiaExp1[idx-1].options[document.formPag.CodHierarquiaExp1[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.CodSetorExp1[idx-1].options[document.formPag.CodSetorExp1[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.AnoIniExp1[idx-1].value == '' &&
		  document.formPag.AnoFimExp1[idx-1].value == '' &&
		  document.formPag.CodHierarquiaExp2[idx-1].options[document.formPag.CodHierarquiaExp2[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.CodSetorExp2[idx-1].options[document.formPag.CodSetorExp2[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.AnoIniExp2[idx-1].value == '' &&
		  document.formPag.AnoFimExp2[idx-1].value == '' &&
		  document.formPag.CodHierarquiaExp3[idx-1].options[document.formPag.CodHierarquiaExp3[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.CodSetorExp3[idx-1].options[document.formPag.CodSetorExp3[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.AnoIniExp3[idx-1].value == '' &&
		  document.formPag.AnoFimExp3[idx-1].value == '') {
		alert('Esta experi�ncia j� est� vazia.')
		document.formPag.MesInicio[idx-1].options[0].text = ' ';
		document.formPag.MesFim[idx-1].options[0].text = ' ';
		document.formPag.TipoEmpExp[idx-1].options[0].text = ' ';
		document.formPag.CodSegmento[idx-1].options[0].text = ' ';
		document.formPag.CodPorte[idx-1].options[0].text = ' ';
		if (document.formPag.CodHierarquiaExp1[idx-1].length <= 3)
		  document.formPag.CodHierarquiaExp1[idx-1].selectedIndex = 0;
		else
		  document.formPag.CodHierarquiaExp1[idx-1].selectedIndex = 1;
		if (document.formPag.CodSetorExp1[idx-1].length <= 3)
		  document.formPag.CodSetorExp1[idx-1].selectedIndex = 0;
		else
		  document.formPag.CodSetorExp1[idx-1].selectedIndex = 1;
		if (document.formPag.CodHierarquiaExp2[idx-1].length <= 3)
		  document.formPag.CodHierarquiaExp2[idx-1].selectedIndex = 0;
		else
		  document.formPag.CodHierarquiaExp2[idx-1].selectedIndex = 1;
		if (document.formPag.CodSetorExp2[idx-1].length <= 3)
		  document.formPag.CodSetorExp2[idx-1].selectedIndex = 0;
		else
		  document.formPag.CodSetorExp2[idx-1].selectedIndex = 1;
		if (document.formPag.CodHierarquiaExp3[idx-1].length <= 3)
		  document.formPag.CodHierarquiaExp3[idx-1].selectedIndex = 0;
		else
		  document.formPag.CodHierarquiaExp3[idx-1].selectedIndex = 1;
		if (document.formPag.CodSetorExp3[idx-1].length <= 3)
		  document.formPag.CodSetorExp3[idx-1].selectedIndex = 0;
		else
		  document.formPag.CodSetorExp3[idx-1].selectedIndex = 1;
	  }	else {
		  if (confirm('Confirma remo��o desta experi�ncia?')) {
	    	document.formPag.Empresa[idx-1].value = '';
		    document.formPag.UltimoCargo[idx-1].value = '';
		    document.formPag.AnoInicio[idx-1].value = '';
		    document.formPag.AnoFim[idx-1].value = '';
		    document.formPag.Descricao[idx-1].value = '';
		    document.formPag.MesInicio[idx-1].selectedIndex = 0;
			//document.formPag.MesInicio[idx-1].options[0].text = ' ';
		    document.formPag.MesFim[idx-1].selectedIndex = 0;
			//document.formPag.MesFim[idx-1].options[0].text = ' ';
		    document.formPag.TipoEmpExp[idx-1].selectedIndex = 0;
			document.formPag.TipoEmpExp[idx-1].options[0].text = ' ';
		    document.formPag.CodSegmento[idx-1].selectedIndex = 0;
			document.formPag.CodSegmento[idx-1].options[0].text = ' ';
		    document.formPag.CodPorte[idx-1].selectedIndex = 0;
			document.formPag.CodPorte[idx-1].options[0].text = ' ';
			if (document.formPag.CodHierarquiaExp1[idx-1].length <= 3)
			  document.formPag.CodHierarquiaExp1[idx-1].selectedIndex = 0;
			else
			  document.formPag.CodHierarquiaExp1[idx-1].selectedIndex = 1;
			if (document.formPag.CodSetorExp1[idx-1].length <= 3)
			  document.formPag.CodSetorExp1[idx-1].selectedIndex = 0;
			else
			  document.formPag.CodSetorExp1[idx-1].selectedIndex = 1;
			document.formPag.AnoIniExp1[idx-1].value = '';
			document.formPag.AnoFimExp1[idx-1].value = '';
	
			if (document.formPag.CodHierarquiaExp2[idx-1].length <= 3)
			  document.formPag.CodHierarquiaExp2[idx-1].selectedIndex = 0;
			else
			  document.formPag.CodHierarquiaExp2[idx-1].selectedIndex = 1;
			if (document.formPag.CodSetorExp2[idx-1].length <= 3)
			  document.formPag.CodSetorExp2[idx-1].selectedIndex = 0;
			else
			  document.formPag.CodSetorExp2[idx-1].selectedIndex = 1;
			document.formPag.AnoIniExp2[idx-1].value = '';
			document.formPag.AnoFimExp2[idx-1].value = '';

			if (document.formPag.CodHierarquiaExp3[idx-1].length <= 3)
			  document.formPag.CodHierarquiaExp3[idx-1].selectedIndex = 0;
			else
			  document.formPag.CodHierarquiaExp3[idx-1].selectedIndex = 1;
			if (document.formPag.CodSetorExp3[idx-1].length <= 3)
			  document.formPag.CodSetorExp3[idx-1].selectedIndex = 0;
			else
			  document.formPag.CodSetorExp3[idx-1].selectedIndex = 1;
			document.formPag.AnoIniExp3[idx-1].value = '';
			document.formPag.AnoFimExp3[idx-1].value = '';

//			checkExpVisibility (idx);
	    	document.formPag.elements['NacionalidadeEmpExp'][idx-1].value = '';
		  }
	  }
  }
}

function checkExpVisibility (idx) {
  if (HP_Exps) {
	  id = 'NacionalidadeEmpExp' + idx;
	  if (document.formPag.TipoEmpExp[idx-1].selectedIndex <= 1) {
	    document.formPag.elements['NacionalidadeEmpExp'][idx-1].value = '';
	    document.formPag.elements['NacionalidadeEmpExp'][idx-1].style.visibility='hidden';
		if (docAll)
	    	document.all[id].style.visibility = "hidden";
	  } else {
	    document.formPag.elements['NacionalidadeEmpExp'][idx-1].style.visibility='visible';
		if (docAll)
	    	document.all[id].style.visibility = "visible";
	  }
 }
}

function iniExpVisibility () {
  for (i = 1; i <= QtdeExpProfCand; i++)
    checkExpVisibility (i);
}

function checkSelect (element,idxElement,idxCad) {
  if (! PagLoaded)
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
  else {
	  bInsereItens = false;
	  if (idxElement == -1) {
	    if (document.formPag.elements[element].options[document.formPag.elements[element].selectedIndex].value == '-2') 
		  bInsereItens = true;
	  } else {
	    if (document.formPag.elements[element][idxElement].options[document.formPag.elements[element][idxElement].selectedIndex].value == '-2') 
		  bInsereItens = true;
	  }
	
	  if (bInsereItens) {
	    SelOptions[idxCad] = Math.floor(SelOptions[idxCad] / 10);
		iniSelect(idxCad,true);
	  }
  }
}

function checkSelect2 (element,idxElement,idxCad) {
  if (! PagLoaded)
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
  else {
	  bInsereItens = false;
	  if (idxElement == -1) {
		if (document.formPag.elements[element].length <= 2)
		  	bInsereItens = true;
	  } else {
	  	if (document.formPag.elements[element][idxElement].length <= 2)
			bInsereItens = true;	
	  }
	  if (bInsereItens) {
	    SelOptions[idxCad] = Math.floor(SelOptions[idxCad] / 10);
		iniSelect(idxCad,true);
		// Seta a opcao selecionada
		if (SelSet[idxCad] == null)
			valSelecionado = SelDef[idxCad]
		else
			valSelecionado = SelSet[idxCad]
		if (idxElement == -1) {
			for (j = 0; j <= document.formPag.elements[element].options.length; j++) {
				if (document.formPag.elements[element].options[j].value == valSelecionado) {
					idxSel = j;
					break;
				}
			}
			document.formPag.elements[element].selectedIndex = idxSel;
		}
		else {
			for (j = 0; j <= document.formPag.elements[element][idxElement].options.length; j++) {
				if (document.formPag.elements[element][idxElement].options[j].value == valSelecionado) {
					idxSel = j;
					break;
				}
			}
			document.formPag.elements[element][idxElement].selectedIndex = idxSel;			
		}
	  }
  }
}

function RemForm(idx) {
  if (! PagLoaded)
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
  else {
	  if (document.formPag.Curso[idx-1].value == '' &&
	  	  document.formPag.Instituicao[idx-1].value == '' &&
		  document.formPag.AnoConclusao[idx-1].value == '' &&
		  document.formPag.PaisForm[idx-1].options[document.formPag.PaisForm[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.Tipo[idx-1].options[document.formPag.Tipo[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.Duracao[idx-1].options[document.formPag.Duracao[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.CodStatusForm[idx-1].options[document.formPag.CodStatusForm[idx-1].selectedIndex].value == '-1' &&
		  document.formPag.MesConclusao[idx-1].options[document.formPag.MesConclusao[idx-1].selectedIndex].value == '-1') {
		alert('Esta formacao j� est� vazia.')
		document.formPag.PaisForm[idx-1].options[0].text = ' ';
		document.formPag.UFForm[idx-1].options[0].text = ' ';		
		document.formPag.Tipo[idx-1].options[0].text = ' ';
		document.formPag.Duracao[idx-1].options[0].text = ' ';
		document.formPag.CodStatusForm[idx-1].options[0].text = ' ';
		document.formPag.MesConclusao[idx-1].options[0].text = ' ';
	  }	else {
		  if (confirm('Confirma remo��o desta forma��o?')) {
	    	document.formPag.Curso[idx-1].value = '';
		    document.formPag.Instituicao[idx-1].value = '';
		    document.formPag.AnoConclusao[idx-1].value = '';
		    document.formPag.PaisForm[idx-1].selectedIndex = 0;
			document.formPag.PaisForm[idx-1].options[0].text = ' ';
		    document.formPag.UFForm[idx-1].selectedIndex = 0;
			document.formPag.UFForm[idx-1].options[0].text = ' ';
		    document.formPag.Tipo[idx-1].selectedIndex = 0;
			document.formPag.Tipo[idx-1].options[0].text = ' ';
		    document.formPag.Duracao[idx-1].selectedIndex = 0;
			document.formPag.Duracao[idx-1].options[0].text = ' ';
		    document.formPag.CodStatusForm[idx-1].selectedIndex = 0;
			document.formPag.CodStatusForm[idx-1].options[0].text = ' ';
		    document.formPag.MesConclusao[idx-1].selectedIndex = 0;
			document.formPag.MesConclusao[idx-1].options[0].text = ' ';
	
			checkFormVisibility (idx);
		  }
	  }
  }
}


function checkFormVisibility (idx) {
//  if (document.formPag.PaisForm[idx-1].options[document.formPag.PaisForm[idx-1].selectedIndex].value == -99) {
//    iniSelect(idxPrimPaisForm + (idx-1)*6,true);
//  }
 
//  id = 'UFForm' + idx;
//  if (document.formPag.PaisForm[idx-1].options[document.formPag.PaisForm[idx-1].selectedIndex].value != 31) {
//    document.formPag.elements['UFForm'][idx-1].selectedIndex = 0;;
//    document.formPag.elements['UFForm'][idx-1].style.visibility='hidden';
//	if (docAll)
//    	document.all[id].style.visibility = "hidden";
//  } else {
	//if (document.formPag.elements['UFForm'][idx-1].options.length == 1) {
//	if (SelOptions[idxPrimUFForm + (idx-1)*6] < 5) {
//	  SelOptions[idxPrimUFForm + (idx-1)*6] = 8;
//	  iniSelect(idxPrimUFForm + (idx-1)*6,true); // Init on-the-fly
//	}
//    document.formPag.elements['UFForm'][idx-1].style.visibility='visible';
//	if (docAll)
//    	document.all[id].style.visibility = "visible";
//  }

  idGrad = 'CursoGradForm' + idx;
  if (document.formPag.Tipo[idx-1].options[document.formPag.Tipo[idx-1].selectedIndex].value != 30 && document.formPag.Tipo[idx-1].options[document.formPag.Tipo[idx-1].selectedIndex].value != 1) {
    document.formPag.elements['CursoGradForm'][idx-1].selectedIndex = 0;
	document.formPag.elements['CursoGradForm'][idx-1].options[0].text = ' ';
	document.formPag.elements['CursoGradForm'][idx-1].disabled = true;
	document.formPag.elements['CursoGradForm'][idx-1].style.backgroundColor = "#EEEEEE";
	if (ClassCursoHidden) {
	    document.formPag.elements['CursoGradForm'][idx-1].style.visibility='hidden';
		if (docAll) {
		    document.all[idGrad].style.visibility = 'hidden';
	    	document.all[idGrad].style.position = 'absolute';
		}
	}
  } else {
	//if (document.formPag.elements['CursoGradForm'][idx-1].options.length == 2) {
	//  iniSelect(idxPrimCursoGradForm + (idx-1)*7,true); // Init on-the-fly
	//}
	document.formPag.elements['CursoGradForm'][idx-1].disabled = false;
	document.formPag.elements['CursoGradForm'][idx-1].style.backgroundColor = "#FFFFFF";
	if (ClassCursoHidden) {	
	    document.formPag.elements['CursoGradForm'][idx-1].style.visibility='visible';
		if (docAll) {
		    document.all[idGrad].style.visibility = 'visible';
	    	document.all[idGrad].style.position = 'static';
		}
	}
  }
  idPGrad = 'CursoPGradForm' + idx;
  if (document.formPag.Tipo[idx-1].options[document.formPag.Tipo[idx-1].selectedIndex].value != 40 &&
  	  document.formPag.Tipo[idx-1].options[document.formPag.Tipo[idx-1].selectedIndex].value != 50 &&
  	  document.formPag.Tipo[idx-1].options[document.formPag.Tipo[idx-1].selectedIndex].value != 60 &&
  	  document.formPag.Tipo[idx-1].options[document.formPag.Tipo[idx-1].selectedIndex].value != 70 &&
  	  document.formPag.Tipo[idx-1].options[document.formPag.Tipo[idx-1].selectedIndex].value != 2) {
    document.formPag.elements['CursoPGradForm'][idx-1].selectedIndex = 0;
	document.formPag.elements['CursoPGradForm'][idx-1].options[0].text = ' ';	
	document.formPag.elements['CursoPGradForm'][idx-1].disabled = true;
	document.formPag.elements['CursoPGradForm'][idx-1].style.backgroundColor = "#EEEEEE";
	if (ClassCursoHidden) {	
	    document.formPag.elements['CursoPGradForm'][idx-1].style.visibility='hidden';
		if (docAll) {
		    document.all[idPGrad].style.visibility = 'hidden';
	    	document.all[idPGrad].style.position = 'absolute';
		}
	}
  } else {
	//if (document.formPag.elements['CursoPGradForm'][idx-1].options.length == 2) {
	//  iniSelect(idxPrimCursoPGradForm + (idx-1)*7,true); // Init on-the-fly
	//}
	document.formPag.elements['CursoPGradForm'][idx-1].disabled = false;
	document.formPag.elements['CursoPGradForm'][idx-1].style.backgroundColor = "#FFFFFF";
	if (ClassCursoHidden) {	
	    document.formPag.elements['CursoPGradForm'][idx-1].style.visibility='visible';
		if (docAll) {
		    document.all[idPGrad].style.visibility = 'visible';
	    	document.all[idPGrad].style.position = 'static';
		}
	}
  }
}

function iniFormVisibility () {
  if (FORM_Forms) {
	  for (i = 1; i <= QtdeFormCand; i++)
	    checkFormVisibility (i);
  }
}

function checkStatusCurso(idx) {
  if (document.formPag.CodStatusForm[idx-1].selectedIndex == 3) {
    document.formPag.MesConclusao[idx-1].selectedIndex = 0;
	document.formPag.AnoConclusao[idx-1].value = '';
  }
}

function checkNecEspVisibility() {
  if (document.formPag.NecEspPortador.selectedIndex == 1) {
	if (docAll) {
	    document.all['TipoNecEsp'].style.visibility = 'visible';
    	document.all['TipoNecEsp'].style.position = 'relative';
	}
	
	if (!Unilever2008)											// no cadastro da Unilever 2008, nao tem o novo complemento das def auditiva, fisica e visual
		checkNecEspFisicaCompl();
		
	//checkNecEspComplVisibility('NecEspAuditiva','NecEspAuditivaTipo')
	//checkNecEspComplVisibility('NecEspFala','NecEspFalaTipo')
	//checkNecEspComplVisibility('NecEspFisica','NecEspFisicaTipo')
	//checkNecEspMentalComplVisibility()
	//checkNecEspComplVisibility('NecEspVisual','NecEspVisualTipo')
  } else { 
    document.formPag.elements['NecEspAuditiva'].checked = false;
    document.formPag.elements['NecEspFala'].checked = false;
    document.formPag.elements['NecEspFisica'].checked = false;
    document.formPag.elements['NecEspMental'].checked = false;
    document.formPag.elements['NecEspVisual'].checked = false;
    document.formPag.elements['NecEspAuditivaTipo'].selectedIndex = 0;
    document.formPag.elements['NecEspFalaTipo'].selectedIndex = 0;
    document.formPag.elements['NecEspFisicaTipo'].selectedIndex = 0;
	document.formPag.elements['NecEspComunic'].checked = false;
	document.formPag.elements['NecEspCuidadoPess'].checked = false;
	document.formPag.elements['NecEspHabSocial'].checked = false;
	document.formPag.elements['NecEspRecursosCom'].checked = false;
	document.formPag.elements['NecEspSaudeSeg'].checked = false;
	document.formPag.elements['NecEspHabAcad'].checked = false;
	document.formPag.elements['NecEspLazer'].checked = false;
	document.formPag.elements['NecEspTrabalho'].checked = false;							
    document.formPag.elements['NecEspVisualTipo'].selectedIndex = 0;
	if (!Unilever2008) {
	    document.formPag.elements['NecEspAuditivaUniBi'].selectedIndex = 0;	
	    document.formPag.elements['NecEspFisicaInfSup'].selectedIndex = 0;
	    document.formPag.elements['NecEspVisualUniBi'].selectedIndex = 0;	
	}				
    //document.formPag.elements['NecEspAuditivaTipo'].style.visibility='hidden';
    //document.formPag.elements['NecEspFalaTipo'].style.visibility='hidden';
    //document.formPag.elements['NecEspFisicaTipo'].style.visibility='hidden';
    //document.formPag.elements['NecEspVisualTipo'].style.visibility='hidden';
	if (docAll) {
   		//document.formPag.elements['NecEspAuditivaTipo'].style.visibility = "hidden";
	    //document.formPag.elements['NecEspFalaTipo'].style.visibility = "hidden";
	    //document.formPag.elements['NecEspFisicaTipo'].style.visibility = "hidden";
		//document.all['LimNecEspMental'].style.visibility='hidden';
	    //document.formPag.elements['NecEspVisualTipo'].style.visibility = "hidden";
	    document.all['TipoNecEsp'].style.visibility = 'hidden';
	    document.all['TipoNecEsp'].style.position = 'absolute';
	}
  }
}

function checkNecEspCompl(idChk,idCmb) {
  if (document.formPag.elements[idCmb].selectedIndex == 0)
  	document.formPag.elements[idChk].checked = false;
  else
  	document.formPag.elements[idChk].checked = true;
}

function checkNecEspCompl2(idChk,idCmb, idCmb2) {
  if (document.formPag.elements[idCmb].selectedIndex == 0 && document.formPag.elements[idCmb2].selectedIndex == 0)
  	document.formPag.elements[idChk].checked = false;
  else
  	document.formPag.elements[idChk].checked = true;
}

function checkNecEspMentalCompl () {
  if (document.formPag.elements['NecEspComunic'].checked || document.formPag.elements['NecEspCuidadoPess'].checked || document.formPag.elements['NecEspHabSocial'].checked || 
     document.formPag.elements['NecEspRecursosCom'].checked || document.formPag.elements['NecEspSaudeSeg'].checked || document.formPag.elements['NecEspHabAcad'].checked || 
	 document.formPag.elements['NecEspLazer'].checked || document.formPag.elements['NecEspTrabalho'].checked)
  	document.formPag.elements['NecEspMental'].checked = true;
  else
  	document.formPag.elements['NecEspMental'].checked = false;  
}

function checkNecEspFisicaCompl () {
  i = document.formPag.elements['NecEspFisicaTipo'].selectedIndex;
  if (i == 1 || i == 2 || i == 5 || i == 6 || i == 11 || i == 12) 
	document.formPag.elements['NecEspFisicaInfSup'].style.visibility = 'visible';  
  else {
	document.formPag.elements['NecEspFisicaInfSup'].style.visibility = 'hidden'; 
  	document.formPag.elements['NecEspFisicaInfSup'].selectedIndex = 0;	
  }
}


// as duas funcoes abaixo nao sao mais utilizadas. O complemento aparece mesmo com checkbox desligado.
function checkNecEspComplVisibility(idChk,idCmb) {
 if (document.formPag.elements[idChk].checked) {
    document.formPag.elements[idCmb].style.visibility='visible';
	//if (docAll)
    //	document.all[idCmb].style.visibility = "visible";
 } else {
    document.formPag.elements[idCmb].selectedIndex = 0;
    document.formPag.elements[idCmb].style.visibility='hidden';
	//if (docAll)
    //	document.all[idCmb].style.visibility = "hidden";
 }
}

function checkNecEspMentalComplVisibility() {
	if (document.formPag.elements['NecEspMental'].checked) {
    	document.all['LimNecEspMental'].style.visibility='visible';
	} else {
		document.formPag.elements['NecEspComunic'].checked = false;
		document.formPag.elements['NecEspCuidadoPess'].checked = false;
		document.formPag.elements['NecEspHabSocial'].checked = false;
		document.formPag.elements['NecEspRecursosCom'].checked = false;
		document.formPag.elements['NecEspSaudeSeg'].checked = false;
		document.formPag.elements['NecEspHabAcad'].checked = false;
		document.formPag.elements['NecEspLazer'].checked = false;
		document.formPag.elements['NecEspTrabalho'].checked = false;	
	    document.all['LimNecEspMental'].style.visibility='hidden';								
	}
}

//--------------------------------------
//-- isBlank
function isBlank(val){
	if(val==null){return true;}
	for(var i=0;i<val.length;i++) {
		if ((val.charAt(i)!=' ')&&(val.charAt(i)!="\t")&&(val.charAt(i)!="\n")&&(val.charAt(i)!="\r")){return false;}
		}
	return true;
}

//-- isDigit
function isDigit(num) {
	if (num.length>1) {return false;}
	var string="1234567890";
	if (string.indexOf(num)!=-1){return true;}
	return false;
}

//-- isInteger
function isInteger(val, optional){
	if (isBlank(val)){return optional;}
	for(var i=0;i<val.length;i++){
		if(!isDigit(val.charAt(i))){return false;}
		}
	return true;
}

//-- isDigit2
function isDigit2(num) {
	if (num.length>1) {return false;}
	var string="1234567890-";
	if (string.indexOf(num)!=-1){return true;}
	return false;
}

//-- isInteger2
function isInteger2(val, optional){
	if (isBlank(val)){return optional;}
	for(var i=0;i<val.length;i++){
		if(!isDigit2(val.charAt(i))){return false;}
		}
	return true;
}

//-- isCurrency
function isCurrency (val, optional) {
	//var objRegExp = /^((\d*)|(\d*\,\d{2})|(\d*\.\d{2})|(\d*\.))$/; // dddddd | ddddd,dd | ddddd.dd | ddddd.
	var objRegExp = /^((\d*)|(\d*\,\d{2})|(\d*\.\d{2}))$/; // dddddd | ddddd,dd | ddddd.dd	
	if (optional && isBlank(val))
		return true
	//check if string matches pattern
	return objRegExp.test(val);
}

//-- isYear
function isYear (id, idx, optional) {
  if (idx == -1)
    val = document.formPag.elements[id].value
  else
    val = document.formPag.elements[id][idx].value
  if (optional && isBlank(val)){return true;}
  if (!isInteger(val, false)) {return false;}
  year = parseInt(val,10)
  if (year >= 0 && year <= 99) {
	  year += 1900
	  if ((ahj - year) > 90)
	    year = year + 100
  }
  if (year >= 1900 && year <= ahj + 10) {
      if (idx == -1)
	    document.formPag.elements[id].value = year
	  else
	    document.formPag.elements[id][idx].value = year
	  return true;
  }
  return false
}

//-- isDate
function daysInFebruary (year){
	// February has 29 days in any year evenly divisible by four,
    // EXCEPT for centurial years which are not also divisible by 400.
    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
}
function isDate(strDay,strMonth,strYear){
	var daysInMonth = new Array();
	daysInMonth[1] = 31; daysInMonth[2] = 29; daysInMonth[3] = 31; daysInMonth[4] = 30; daysInMonth[5] = 31; daysInMonth[6] = 30; 
	daysInMonth[7] = 31; daysInMonth[8] = 31; daysInMonth[9] = 30; daysInMonth[10] = 31; daysInMonth[11] = 30; daysInMonth[12] = 31; 
    if (!isInteger(strDay, true) || !isInteger(strMonth, true) || !isInteger(strYear, true)){
		return false
	}
	month = parseInt(strMonth,10)
	day = parseInt(strDay,10)
	year = parseInt(strYear,10)
	if (strMonth.length < 1 || month < 1 || month > 12){
		return false
	}
	if (strDay.length < 1 || day < 1 || day > 31 || (month == 2 && day > daysInFebruary(year)) || day > daysInMonth[month]){
		return false
	}
	if (year <= 99) {
		year += 1900
		if ((ahj - year) > 90)
		  year = year + 100
	}
	return true
}

//-- isCPF_CNPJ
function ClearStr(str, c) {
  while((cx=str.indexOf(c))!=-1)
    str = str.substring(0,cx)+str.substring(cx+1);
  return(str);
}
function ParseNroDoc(c) {
  c=ClearStr(c,'-');
  c=ClearStr(c,'/');
  c=ClearStr(c,',');
  c=ClearStr(c,'.');
  c=ClearStr(c,'(');
  c=ClearStr(c,')');
  c=ClearStr(c,' ');
  if((parseFloat(c) / c != 1)) {
    if(parseFloat(c) * c == 0) {
      return(c);
    } else {
      return(0);
    }
  } else {
    return(c);
  }
}

function TestDigit(nroDoc,tipoDoc,g) {
  var dig=0;
  var ind=2;
  for(f=g;f>0;f--) {
    dig+=parseInt(nroDoc.charAt(f-1),10)*ind;
    if (tipoDoc=='CNPJ') { 
	  if(ind>8) {ind=2} else {ind++} 
	}
    else { ind++ 
	}
  }
  dig%=11;
  if(dig<2) {
    dig=0;
  } else {
    dig=11-dig;
  }
  if(dig!=parseInt(nroDoc.charAt(g),10))
    return false;
  else
    return true;
}

function VerifyCPF_CNPJ(nroDoc,tipoDoc,optional) {
  nroDocIn = nroDoc
  nroDoc=ParseNroDoc(nroDoc)
  if(nroDoc == 0) {
    if (optional && nroDocIn == '')
	  return true;
	else
      return false;
  } else {
    g=nroDoc.length-2;
	if (tipoDoc == 'CPF' && g > 9)
	  return false;
    if(TestDigit(nroDoc,tipoDoc,g)) {
      g=nroDoc.length-1;
      if(TestDigit(nroDoc,tipoDoc,g)) {	
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
}

function isCPF_CNPJ(nroDoc,tipoDoc,optional)
{ // tipoDoc; CPF ou CNPJ
  if(VerifyCPF_CNPJ(nroDoc,tipoDoc,optional))
    return true;
  else
    return false;
}

function CPFCompac (c) {
  c=ClearStr(c,'-');
  c=ClearStr(c,'/');
  c=ClearStr(c,',');
  c=ClearStr(c,'.');
  c=ClearStr(c,'(');
  c=ClearStr(c,')');
  c=ClearStr(c,' ');
  for (i = c.length; i < 11; i++)
    c = '0' + c;
  return c;
}

// isEMail
/*
function isEmail(x) {
	var filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (filter.test(x)) 
	  return true;
	else 
	  return false;
}
*/

function isEmail(x) {
    if (x.search(/^\w+((-+\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/) != -1) // Incluir a possibilidade de digitar quantos "-" precisar.
//    if (x.search(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/) != -1)
        return true;
    else
        return false;
}

// isChar
function isChar(x) {
	var filter  = /^([a-zA-Z])+$/;
	if (filter.test(x)) 
	  return true;
	else 
	  return false;
}

// temDigito
function temDigito(x){
	if (isBlank(x)){return false;}
	for(var i=0;i<x.length;i++){
		if(isDigit(x.charAt(i))){return true;}
		}
	return false;
}


function submitFormChk(action) {
  window.status = 'Verificando informa��es...'
  msgErro = ''
  if (PagLoaded) {
    //-- DADOS PESSOAIS
    if (isBlank(document.formPagHidden.Nome_cand.value)) {
	
		if (temDigito(document.formPag.Nome_cand.value))
		  msgErro += '  - Nome inv�lido: n�o s�o aceitos n�meros no nome.\n';

		if (DP_Endereco) {
			if (document.formPag.CodPais_cand.value == 31 && (!isInteger(document.formPag.Cep_cand_1.value, false) || !isInteger(document.formPag.Cep_cand_2.value, false)))
			  msgErro += '  - CEP inv�lido.\n';
		}
	
		if (DP_DataNasc) {
			if (!isDate(document.formPag.DtNasc_cand_dia.value, document.formPag.DtNasc_cand_mes.value, document.formPag.DtNasc_cand_ano.value))
			  msgErro += '  - Data de nascimento inv�lida.\n';
			else {
			  year = parseInt(document.formPag.DtNasc_cand_ano.value,10)
			  month = parseInt(document.formPag.DtNasc_cand_mes.value,10)
			  day = parseInt(document.formPag.DtNasc_cand_dia.value,10)
			  if (year <= 99) {
				  year += 1900
				  if ((ahj - year) > 90)
				    year = year + 100
			  }
			  if (year < 1900)
			    msgErro += '  - Data de nascimento inv�lida.\n';
			  else
			  	if (year > ahj || (year == ahj && month > mhj) || (year == ahj && month == mhj && day > dhj) )
					msgErro += '  - Data de nascimento inv�lida.\n';
				else
				    document.formPag.DtNasc_cand_ano.value = year;
			}
		}
	
		if (DP_Filhos) {
			if (!isInteger(document.formPag.NroFilhos_cand.value, true))
			  msgErro += '  - Quantidade de filhos inv�lida.\n';
		}

		if (DP_SitesRelPess) {
			if (!isBlank(document.formPag.SitePessoal_cand.value))
				if (document.formPag.SitePessoal_cand.value.substring(0,7) != 'http://')
					msgErro += '  - Endere�o do site pessoal deve iniciar com \'http://\'.\n';
			if (!isBlank(document.formPag.SiteRelacionamento_cand.value))
				if (document.formPag.SiteRelacionamento_cand.value.substring(0,7) != 'http://')
					msgErro += '  - Endere�o do site de relacionamento deve iniciar com \'http://\'.\n';
		}
	
		if (DP_Email) {	
			if (!isEmail(document.formPag.Email_cand.value))
			  msgErro += '  - Endere�o de e-mail inv�lido.\n';
			else
			  if (document.formPag.Email_cand.value != document.formPag.EmailVerif_cand.value)
			    msgErro += '  - Endere�o de e-mail e sua verifica��o n�o conferem.\n';
		}
		
		// Celular
		if (DP_Celular) {	
			// o trecho abaixo foi comentado, pois quando eh um CV novo, vai acordar com aceitaSMS_cand ligado!	
//			if (document.formPag.AceitaSMS_cand.checked) {
//				if (isBlank(document.formPag.Celular_cand.value) || isBlank(document.formPag.CelCodArea_cand.value) || document.formPag.CelCodPais_cand.value == -1)
//					msgErro += '  - Forne�a o pa�s, o c�digo de �rea e o n�mero do celular.\n';
//				else {
//						if (!isInteger2(document.formPag.Celular_cand.value) || !isInteger(document.formPag.CelCodArea_cand.value))
//							msgErro += '  - C�digo de �rea ou celular inv�lido. Verifique sua digita��o.\n';						
//				}
//			}
//			else {
				if (!isBlank(document.formPag.Celular_cand.value)) {
					if (isBlank(document.formPag.CelCodArea_cand.value) || document.formPag.CelCodPais_cand.options[document.formPag.CelCodPais_cand.selectedIndex].value == '-1')
						msgErro += '  - Forne�a o pa�s e o c�digo de �rea do celular.\n';
					else {
						if (!isInteger2(document.formPag.Celular_cand.value) || !isInteger(document.formPag.CelCodArea_cand.value) || document.formPag.Celular_cand.value.length < 5)
							msgErro += '  - C�digo de �rea ou celular inv�lido. Verifique sua digita��o.\n';	
					}
				}
//			}
		}

		// Documentos
		if (DP_Documento) {
			if (QtdeDocCand == 1) {
//				if ((document.formPag.CodTipoDoc.value == -1 && !isBlank(document.formPag.NroDoc.value)) ||
//				    (document.formPag.CodTipoDoc.value != -1 && isBlank(document.formPag.NroDoc.value)))
				if ((document.formPag.CodTipoDoc.options[document.formPag.CodTipoDoc.selectedIndex].value == '-1' && !isBlank(document.formPag.NroDoc.value)))
					msgErro += '  - Forne�a o tipo e o n�mero do documento.\n';
				if ((document.formPag.CodTipoDoc.options[document.formPag.CodTipoDoc.selectedIndex].value == '-1' || isBlank(document.formPag.NroDoc.value)) && DocObrig == 0)
					msgErro += '  - Forne�a pelo menos um tipo de documento.\n';						
				if (DocObrig > 0 && (document.formPag.CodTipoDoc.options[document.formPag.CodTipoDoc.selectedIndex].value != DocObrig || isBlank(document.formPag.NroDoc.value)))
					if (NomeDocObrig == '')
						msgErro += '  - Forne�a um documento principal.\n';										
					else
						msgErro += '  - Forne�a o seguinte documento: ' + NomeDocObrig + '.\n';
				if (document.formPag.CodTipoDoc.options[document.formPag.CodTipoDoc.selectedIndex].value == TIPODOCCPF && !isBlank(document.formPag.NroDoc.value))
			  		if (!isCPF_CNPJ(document.formPag.NroDoc.value,'CPF',!(DocObrig==TIPODOCCPF)))
			    		msgErro += '  - CPF inv�lido.\n';
			}
			else {
				TemDoc = false;
				TemDocEspecif = false;
				for (i = 0; i < QtdeDocCand; i++) {
					if ((document.formPag.CodTipoDoc[i].options[document.formPag.CodTipoDoc[i].selectedIndex].value == '-1' && !isBlank(document.formPag.NroDoc[i].value)) ||
					    (document.formPag.CodTipoDoc[i].options[document.formPag.CodTipoDoc[i].selectedIndex].value != '-1' && isBlank(document.formPag.NroDoc[i].value)))
						msgErro += '  - Forne�a o tipo e o n�mero do documento.\n';
					if (document.formPag.CodTipoDoc[i].options[document.formPag.CodTipoDoc[i].selectedIndex].value != '-1' && !isBlank(document.formPag.NroDoc[i].value)) {
						TemDoc = true;
						if (DocObrig == document.formPag.CodTipoDoc[i].options[document.formPag.CodTipoDoc[i].selectedIndex].value)
							TemDocEspecif = true;
					}
					if (document.formPag.CodTipoDoc[i].options[document.formPag.CodTipoDoc[i].selectedIndex].value == TIPODOCCPF && !isBlank(document.formPag.NroDoc[i].value))
				  		if (!isCPF_CNPJ(document.formPag.NroDoc[i].value,'CPF',!(DocObrig==TIPODOCCPF)))
				    		msgErro += '  - CPF inv�lido.\n';
				}
				for (i = 0; i < QtdeDocCand; i++) {
					for ( j = i+1; j < QtdeDocCand; j++) {
						if (document.formPag.CodTipoDoc[i].options[document.formPag.CodTipoDoc[i].selectedIndex].value == document.formPag.CodTipoDoc[j].options[document.formPag.CodTipoDoc[j].selectedIndex].value && document.formPag.CodTipoDoc[i].options[document.formPag.CodTipoDoc[i].selectedIndex].value != '-1') {
							msgErro += '  - Tipo de documento duplicado.\n';
							i = QtdeDocCand +1;
							break;
						}
					}
				}				
				if (DocObrig != -1) {
					if (DocObrig == 0 && !TemDoc)
						msgErro += '  - Forne�a pelo menos um tipo de documento.\n';
					else if (DocObrig > 0 && !TemDocEspecif)
							msgErro += '  - Forne�a o seguinte documento: ' + NomeDocObrig + '.\n';						
				}
			}		
		}
		
		// Necessidades Especiais
		if (DP_NecEsp) {
			if (document.formPag.NecEspPortador.selectedIndex == 1) {
			  if (!document.formPag.NecEspAuditiva.checked && !document.formPag.NecEspFala.checked && 
			  	  !document.formPag.NecEspFisica.checked && !document.formPag.NecEspMental.checked && 
			  	  !document.formPag.NecEspVisual.checked)
				msgErro += '  - Assinale pelo menos uma defici�ncia.\n'
			  else
			  	  if (!Unilever2008) 
					  if ((document.formPag.NecEspAuditiva.checked && document.formPag.NecEspAuditivaTipo.selectedIndex == 0) ||
					  	  (document.formPag.NecEspAuditiva.checked && document.formPag.NecEspAuditivaTipo.selectedIndex != 0 && document.formPag.NecEspAuditivaUniBi.selectedIndex == 0) ||
					  	  (document.formPag.NecEspFala.checked && document.formPag.NecEspFalaTipo.selectedIndex == 0) ||
					  	  (document.formPag.NecEspFisica.checked && document.formPag.NecEspFisicaTipo.selectedIndex == 0) ||
						  (document.formPag.NecEspFisica.checked && (document.formPag.NecEspFisicaTipo.selectedIndex == 1 || document.formPag.NecEspFisicaTipo.selectedIndex == 2 || document.formPag.NecEspFisicaTipo.selectedIndex == 5 || document.formPag.NecEspFisicaTipo.selectedIndex == 6 || document.formPag.NecEspFisicaTipo.selectedIndex == 11 || document.formPag.NecEspFisicaTipo.selectedIndex == 12) && document.formPag.NecEspFisicaInfSup.selectedIndex == 0) ||
					  	  (document.formPag.NecEspMental.checked && !document.formPag.NecEspComunic.checked && !document.formPag.NecEspCuidadoPess.checked && !document.formPag.NecEspHabSocial.checked && !document.formPag.NecEspRecursosCom.checked && !document.formPag.NecEspSaudeSeg.checked && !document.formPag.NecEspHabAcad.checked && !document.formPag.NecEspLazer.checked && !document.formPag.NecEspTrabalho.checked) ||
					  	  (document.formPag.NecEspVisual.checked && document.formPag.NecEspVisualTipo.selectedIndex == 0))
						msgErro += '  - Selecione o complemento das defici�ncias assinaladas.\n'
				  else
					  if ((document.formPag.NecEspAuditiva.checked && document.formPag.NecEspAuditivaTipo.selectedIndex == 0) ||
					  	  (document.formPag.NecEspFala.checked && document.formPag.NecEspFalaTipo.selectedIndex == 0) ||
					  	  (document.formPag.NecEspFisica.checked && document.formPag.NecEspFisicaTipo.selectedIndex == 0) ||
					  	  (document.formPag.NecEspMental.checked && !document.formPag.NecEspComunic.checked && !document.formPag.NecEspCuidadoPess.checked && !document.formPag.NecEspHabSocial.checked && !document.formPag.NecEspRecursosCom.checked && !document.formPag.NecEspSaudeSeg.checked && !document.formPag.NecEspHabAcad.checked && !document.formPag.NecEspLazer.checked && !document.formPag.NecEspTrabalho.checked) ||
					  	  (document.formPag.NecEspVisual.checked && document.formPag.NecEspVisualTipo.selectedIndex == 0))
						msgErro += '  - Selecione o complemento das defici�ncias assinaladas.\n'
			}
		}
	
		if (IdiomaCV == '' ) {
			if (DP_Endereco) {
				if (isBlank(document.formPag.Bairro_cand.value)) {		//	destacamos o bairro, j� que foi um campo introduzido depois ...
					msgErro += '  - Informe o bairro.\n';
				}
			}
		}
	
		bCampoObrigNaoPreenchido = false;
		if (DP_Email) {	
		  	if (isBlank(document.formPag.Nome_cand.value) ||
				isBlank(document.formPag.Tel_cand.value) ||
				isBlank(document.formPag.Email_cand.value) ||
				isBlank(document.formPag.EmailVerif_cand.value))
				bCampoObrigNaoPreenchido = true;

			if (DP_Endereco)
				if (isBlank(document.formPag.Endereco_cand.value) ||
					document.formPag.CodCidade_cand.options[document.formPag.CodCidade_cand.selectedIndex].value == '-1' ||
					document.formPag.CodUF_cand.options[document.formPag.CodUF_cand.selectedIndex].value == '-1' ||				
					document.formPag.CodPais_cand.options[document.formPag.CodPais_cand.selectedIndex].value == '-1' ||
					(document.formPag.CodPais_cand.options[document.formPag.CodPais_cand.selectedIndex].value == '31' && (document.formPag.CodUF_cand.options[document.formPag.CodUF_cand.selectedIndex].value == '-2' || document.formPag.CodCidade_cand.options[document.formPag.CodCidade_cand.selectedIndex].value == '-2')))
					bCampoObrigNaoPreenchido = true;

			if (DP_Nacionalidade)
				if (document.formPag.CodNacion_cand.options[document.formPag.CodNacion_cand.selectedIndex].value == '-1')
					bCampoObrigNaoPreenchido = true;

			if (DP_EstadoCivil)
				if (document.formPag.CodEstadoCivil_cand.options[document.formPag.CodEstadoCivil_cand.selectedIndex].value == '-1')
					bCampoObrigNaoPreenchido = true;
					
			if (bCampoObrigNaoPreenchido)
				msgErro += '  - Preencha todos os campos marcados com *.\n';							
		}
		else {
		  	if (isBlank(document.formPag.Nome_cand.value) ||
				isBlank(document.formPag.Tel_cand.value))
					bCampoObrigNaoPreenchido = true;
			if (DP_Endereco)
				if (isBlank(document.formPag.Endereco_cand.value) ||
					document.formPag.CodCidade_cand.options[document.formPag.CodCidade_cand.selectedIndex].value == '-1' ||
					document.formPag.CodUF_cand.options[document.formPag.CodUF_cand.selectedIndex].value == '-1' ||				
					document.formPag.CodPais_cand.options[document.formPag.CodPais_cand.selectedIndex].value == '-1' ||
					(document.formPag.CodPais_cand.options[document.formPag.CodPais_cand.selectedIndex].value == '31' && (document.formPag.CodUF_cand.options[document.formPag.CodUF_cand.selectedIndex].value == '-2' || document.formPag.CodCidade_cand.options[document.formPag.CodCidade_cand.selectedIndex].value == '-2')))
					bCampoObrigNaoPreenchido = true;

			if (DP_Nacionalidade)
				if (document.formPag.CodNacion_cand.options[document.formPag.CodNacion_cand.selectedIndex].value == -1)
					bCampoObrigNaoPreenchido = true;

			if (DP_EstadoCivil)
				if (document.formPag.CodEstadoCivil_cand.options[document.formPag.CodEstadoCivil_cand.selectedIndex].value == -1)
					bCampoObrigNaoPreenchido = true;

			if (bCampoObrigNaoPreenchido)
				msgErro += '  - Preencha todos os campos marcados com *.\n';							
		}
	}
		
	if (msgErro != '') {
		window.status = 'Done';
		alert ('*** PREENCHIMENTO INCORRETO ***\n\nNo t�pico DADOS PESSOAIS\n\n' + msgErro);
		return;
	}

    //-- OBJETIVOS PROFISSIONAIS
	if (OBJ_Objetivo) {
		if (document.formPag.Objetivo_cand.value == '')
		  msgErro += '  - Informe o seu objetivo profissional.\n';
	}

    if (OBJ_Objetivo_Classific) {
		if (document.formPag.CodHierarquia[0].options[document.formPag.CodHierarquia[0].selectedIndex].value == '-1' && 
		    document.formPag.CodSetor[0].options[document.formPag.CodSetor[0].selectedIndex].value == '-1' && 
			document.formPag.CodHierarquia[1].options[document.formPag.CodHierarquia[1].selectedIndex].value == '-1' && 
		    document.formPag.CodSetor[1].options[document.formPag.CodSetor[1].selectedIndex].value == '-1' && 
			document.formPag.CodHierarquia[2].options[document.formPag.CodHierarquia[2].selectedIndex].value == '-1' && 
		    document.formPag.CodSetor[2].options[document.formPag.CodSetor[2].selectedIndex].value == '-1' && 
			document.formPag.CodHierarquia[3].options[document.formPag.CodHierarquia[3].selectedIndex].value == '-1' && 
		    document.formPag.CodSetor[3].options[document.formPag.CodSetor[3].selectedIndex].value == '-1' && 
			document.formPag.CodHierarquia[4].options[document.formPag.CodHierarquia[4].selectedIndex].value == '-1' && 
		    document.formPag.CodSetor[4].options[document.formPag.CodSetor[4].selectedIndex].value == '-1') 
		  msgErro += '  - Classifique seu objetivo profissional em pelo menos um par N�vel/�rea.\n';
		else {
			if ((document.formPag.CodHierarquia[0].options[document.formPag.CodHierarquia[0].selectedIndex].value == '-1' && 
			     document.formPag.CodSetor[0].options[document.formPag.CodSetor[0].selectedIndex].value != '-1') ||
				(document.formPag.CodHierarquia[0].options[document.formPag.CodHierarquia[0].selectedIndex].value != '-1' && 
			     document.formPag.CodSetor[0].options[document.formPag.CodSetor[0].selectedIndex].value == '-1') || 
				(document.formPag.CodHierarquia[1].options[document.formPag.CodHierarquia[1].selectedIndex].value == '-1' && 
			     document.formPag.CodSetor[1].options[document.formPag.CodSetor[1].selectedIndex].value != '-1') ||
				(document.formPag.CodHierarquia[1].options[document.formPag.CodHierarquia[1].selectedIndex].value != '-1' && 
			     document.formPag.CodSetor[1].options[document.formPag.CodSetor[1].selectedIndex].value == '-1') || 
				(document.formPag.CodHierarquia[2].options[document.formPag.CodHierarquia[2].selectedIndex].value == '-1' && 
			     document.formPag.CodSetor[2].options[document.formPag.CodSetor[2].selectedIndex].value != '-1') ||
				(document.formPag.CodHierarquia[2].options[document.formPag.CodHierarquia[2].selectedIndex].value != '-1' && 
			     document.formPag.CodSetor[2].options[document.formPag.CodSetor[2].selectedIndex].value == '-1') || 
				(document.formPag.CodHierarquia[3].options[document.formPag.CodHierarquia[3].selectedIndex].value == '-1' && 
			     document.formPag.CodSetor[3].options[document.formPag.CodSetor[3].selectedIndex].value != '-1') ||
				(document.formPag.CodHierarquia[3].options[document.formPag.CodHierarquia[3].selectedIndex].value != '-1' && 
			     document.formPag.CodSetor[3].options[document.formPag.CodSetor[3].selectedIndex].value == '-1') || 
				(document.formPag.CodHierarquia[4].options[document.formPag.CodHierarquia[4].selectedIndex].value == '-1' && 
			     document.formPag.CodSetor[4].options[document.formPag.CodSetor[4].selectedIndex].value != '-1') ||
				(document.formPag.CodHierarquia[4].options[document.formPag.CodHierarquia[4].selectedIndex].value != '-1' && 
			     document.formPag.CodSetor[4].options[document.formPag.CodSetor[4].selectedIndex].value == '-1')) 
			  msgErro += '  - Complemente os pares N�vel/�rea incompletos ou os deixe em branco se quiser remov�-los.\n    (seu objetivo deve ser classificado em pelo menos um par N�vel/�rea).\n';
			else {
			  for (i = 0; i <= 4; i++) {
			    if (document.formPag.CodHierarquia[i].options[document.formPag.CodHierarquia[i].selectedIndex].value != '-1') {
				  for (j = i + 1; j <= 4; j++) {
				    if (document.formPag.CodHierarquia[j].options[document.formPag.CodHierarquia[j].selectedIndex].value == document.formPag.CodHierarquia[i].options[document.formPag.CodHierarquia[i].selectedIndex].value &&
						document.formPag.CodSetor[j].options[document.formPag.CodSetor[j].selectedIndex].value == document.formPag.CodSetor[i].options[document.formPag.CodSetor[i].selectedIndex].value) {
					  msgErro += '  - Classifica��o de objetivo profissional em n�vel e �rea duplicados.'
					  i = 5;
					  break;
					}
				  }
				}
			  }
			}
		}
	}
	if (OBJ_SalPret) {
		if (!isCurrency(document.formPag.ValSalPret_cand.value,true))
		  msgErro += '  - Valor do sal�rio pretendido inv�lido (forne�a o valor no formato dddddd,dd - por exemplo: 1500,00).\n';
	}
	
	if (msgErro != '') {
		window.status = 'Done';
		alert ('*** PREENCHIMENTO INCORRETO ***\n\nNo t�pico OBJETIVOS PROFISSIONAIS\n\n' + msgErro);
		return;
	}
	
	// HISTORICO PROFISSIONAL
	if (HP_UltSal) {
		if (!isCurrency(document.formPag.UltSal_cand.value,true))
		  msgErro += '  - Valor do �ltimo sal�rio inv�lido (forne�a o valor no formato dddddd,dd - por exemplo: 1500,00).\n';
		if (!isBlank(document.formPag.UltSal_cand.value) && document.formPag.UltSalAtualCand[1].checked && (document.formPag.MesUltSalCand.selectedIndex == 0 || !isInteger(document.formPag.AnoUltSalCand.value,false)))
		  msgErro += '  - Complete o m�s e ano de refer�ncia do seu �ltimo sal�rio.\n';
		if (!isBlank(document.formPag.UltSal_cand.value) && document.formPag.UltSalAtualCand[1].checked && !isYear('AnoUltSalCand',-1,false))
	      msgErro += '  - Ano de refer�ncia do seu �ltimo sal�rio inv�lido.\n';
	}
		
	msgErroG = '';
	nMsgErroG = 0;
	if (HP_Exps) {
		for (i = 0; i < QtdeExpProfCand; i++) {
			bPrefix = true;
			if (!isBlank(document.formPag.Empresa[i].value) ||
			    document.formPag.TipoEmpExp[i].selectedIndex != 0 ||
			    document.formPag.CodSegmento[i].selectedIndex != 0 ||
			    document.formPag.CodPorte[i].selectedIndex != 0 ||
			    document.formPag.MesInicio[i].options[document.formPag.MesInicio[i].selectedIndex].value != '-1' ||
			    !isBlank(document.formPag.AnoInicio[i].value) ||
			    document.formPag.MesFim[i].options[document.formPag.MesFim[i].selectedIndex].value != '-1' ||
			    !isBlank(document.formPag.AnoFim[i].value) ||
			    !isBlank(document.formPag.UltimoCargo[i].value) ||
			    !isBlank(document.formPag.Descricao[i].value) ||
			    document.formPag.CodHierarquiaExp1[i].options[document.formPag.CodHierarquiaExp1[i].selectedIndex].value != '-1' ||
			    document.formPag.CodSetorExp1[i].options[document.formPag.CodSetorExp1[i].selectedIndex].value != '-1' ||
				!isBlank(document.formPag.AnoIniExp1[i].value) ||
				!isBlank(document.formPag.AnoFimExp1[i].value) ||
			    document.formPag.CodHierarquiaExp2[i].options[document.formPag.CodHierarquiaExp2[i].selectedIndex].value != '-1' ||
			    document.formPag.CodSetorExp2[i].options[document.formPag.CodSetorExp2[i].selectedIndex].value != '-1' ||
				!isBlank(document.formPag.AnoIniExp2[i].value) ||
				!isBlank(document.formPag.AnoFimExp2[i].value) ||
			    document.formPag.CodHierarquiaExp3[i].options[document.formPag.CodHierarquiaExp3[i].selectedIndex].value != '-1' ||
			    document.formPag.CodSetorExp3[i].options[document.formPag.CodSetorExp3[i].selectedIndex].value != '-1' ||
				!isBlank(document.formPag.AnoIniExp3[i].value) ||
				!isBlank(document.formPag.AnoFimExp3[i].value)) {
				
					nCposBranco = 0;
				    if (isBlank(document.formPag.Empresa[i].value)) {
					  nCposBranco++;
				      MsgErroAux = '     . Informe o nome da empresa.\n';
				    }
				    if (document.formPag.TipoEmpExp[i].selectedIndex == 0) {
					  nCposBranco++;
				      MsgErroAux = '     . Informe a nacionalidade da empresa.\n';
				    }
					if (!Unilever2008) {
						if (isBlank(document.formPag.NacionalidadeEmpExp[i].value)) {
						  nCposBranco++;
					      MsgErroAux = '     . Informe o(s) pa�s(es) de origem da empresa.\n';
					    }
					}
				    if (document.formPag.CodSegmento[i].selectedIndex == 0) {
					  nCposBranco++;
				      MsgErroAux = '     . Informe o segmento da empresa.\n';
				    }
				    if (document.formPag.CodPorte[i].selectedIndex == 0) {
					  nCposBranco++;
				      MsgErroAux = '     . Informe o porte da empresa.\n';
				    }
				    if (document.formPag.MesInicio[i].options[document.formPag.MesInicio[i].selectedIndex].value == '-1') {
					  nCposBranco++;
				      MsgErroAux = '     . Informe o m�s do in�cio da atividade na empresa.\n';
				    }
				    if (isBlank(document.formPag.AnoInicio[i].value)) {
					  nCposBranco++;
				      MsgErroAux = '     . Informe o ano do in�cio da atividade na empresa.\n';
				    }
				    if (isBlank(document.formPag.UltimoCargo[i].value)) {
					  nCposBranco++;
				      MsgErroAux = '     . Informe o seu �ltimo cargo na empresa.\n';
				    }
				    if (isBlank(document.formPag.Descricao[i].value)) {
					  nCposBranco++;
				      MsgErroAux = '     . Forne�a uma descri��o sucinta de suas atividades na empresa.\n';
				    }
					
					if (nCposBranco > 0) {
					  if (nCposBranco > 1) {
						nMsgErroG++;
						if (msgErroG == '')
							msgErroG +=' ' + (i+1);
						else
							msgErroG +=', ' + (i+1);
					  } else {
								msgErro +='  - Empresa ' + (i+1) + ':\n' + MsgErroAux;
					  }
					} else {
						if ((document.formPag.MesFim[i].options[document.formPag.MesFim[i].selectedIndex].value == '-1' && !isBlank(document.formPag.AnoFim[i].value)) ||
							(document.formPag.MesFim[i].options[document.formPag.MesFim[i].selectedIndex].value != '-1' && isBlank(document.formPag.AnoFim[i].value))) {
							if (bPrefix) {
								msgErro +='  - Empresa ' + (i+1) + ':\n';
								bPrefix = false;
							}
							msgErro += '     . Informe o m�s e o ano do t�rmino de atividade na empresa ou deixe em branco se continua nela.\n';
						}
						if (!isYear('AnoInicio',i,true)) {
								if (bPrefix) {
									msgErro += '  - Empresa ' + (i+1) + ':\n';
									bPrefix = false;
								}
								msgErro += '     . Ano do in�cio de atividade na empresa inv�lido.\n';
						}
						
						if (!isYear('AnoFim',i,true)) {
								if (bPrefix) {
									msgErro += '  - Empresa ' + (i+1) + ':\n';
									bPrefix = false;
								}
								msgErro += '     . Ano do t�rmino de atividade na empresa inv�lido.\n';
						} 
	
						if (isYear('AnoInicio',i,true) && isYear('AnoFim',i,true)) {
								if (parseInt(document.formPag.AnoFim[i].value,10) < parseInt(document.formPag.AnoInicio[i].value,10)) {
									if (bPrefix) {
										msgErro += '  - Empresa ' + (i+1) + ':\n';
										bPrefix = false;
									}
									msgErro += '     . Ano do t�rmino deve ser igual ou posterior ao ano do in�cio de atividade na empresa.\n';
								}
						}

						if (document.formPag.CodHierarquiaExp1[i].options[document.formPag.CodHierarquiaExp1[i].selectedIndex].value == '-1' &&
							document.formPag.CodSetorExp1[i].options[document.formPag.CodSetorExp1[i].selectedIndex].value == '-1' &&
							isBlank(document.formPag.AnoIniExp1[i].value) && isBlank(document.formPag.AnoFimExp1[i].value) &&
						    document.formPag.CodHierarquiaExp2[i].options[document.formPag.CodHierarquiaExp2[i].selectedIndex].value == '-1' &&
							document.formPag.CodSetorExp2[i].options[document.formPag.CodSetorExp2[i].selectedIndex].value == '-1' &&
							isBlank(document.formPag.AnoIniExp2[i].value) && isBlank(document.formPag.AnoFimExp2[i].value) &&
						    document.formPag.CodHierarquiaExp3[i].options[document.formPag.CodHierarquiaExp3[i].selectedIndex].value == '-1' &&
							document.formPag.CodSetorExp3[i].options[document.formPag.CodSetorExp3[i].selectedIndex].value == '-1' &&
							isBlank(document.formPag.AnoIniExp3[i].value) && isBlank(document.formPag.AnoFimExp3[i].value)) {
									if (bPrefix) {
										msgErro += '  - Empresa ' + (i+1) + ':\n';
										bPrefix = false;
									}
									msgErro += '     . CLASSIFIQUE pelo menos 1 ocupa��o na empresa (deixe o ano final em branco se ainda a estiver exercendo).\n';
						}

						if (
							(document.formPag.CodHierarquiaExp1[i].options[document.formPag.CodHierarquiaExp1[i].selectedIndex].value == '-1' &&
							 document.formPag.CodSetorExp1[i].options[document.formPag.CodSetorExp1[i].selectedIndex].value != '-1') ||
							(document.formPag.CodHierarquiaExp1[i].options[document.formPag.CodHierarquiaExp1[i].selectedIndex].value != '-1' &&
							 document.formPag.CodSetorExp1[i].options[document.formPag.CodSetorExp1[i].selectedIndex].value == '-1') ||
							(document.formPag.CodHierarquiaExp1[i].options[document.formPag.CodHierarquiaExp1[i].selectedIndex].value != '-1' &&
							 document.formPag.CodSetorExp1[i].options[document.formPag.CodSetorExp1[i].selectedIndex].value != '-1' &&
							 isBlank(document.formPag.AnoIniExp1[i].value)) ||
							(document.formPag.CodHierarquiaExp1[i].options[document.formPag.CodHierarquiaExp1[i].selectedIndex].value == '-1' &&
							 document.formPag.CodSetorExp1[i].options[document.formPag.CodSetorExp1[i].selectedIndex].value == '-1' &&
							 !isBlank(document.formPag.AnoIniExp1[i].value)) ||
							(document.formPag.CodHierarquiaExp1[i].options[document.formPag.CodHierarquiaExp1[i].selectedIndex].value == '-1' &&
							 document.formPag.CodSetorExp1[i].options[document.formPag.CodSetorExp1[i].selectedIndex].value == '-1' &&
							 isBlank(document.formPag.AnoIniExp1[i].value) && !isBlank(document.formPag.AnoFimExp1[i].value)) ||

							(document.formPag.CodHierarquiaExp2[i].options[document.formPag.CodHierarquiaExp2[i].selectedIndex].value == '-1' &&
							 document.formPag.CodSetorExp2[i].options[document.formPag.CodSetorExp2[i].selectedIndex].value != '-1') ||
							(document.formPag.CodHierarquiaExp2[i].options[document.formPag.CodHierarquiaExp2[i].selectedIndex].value != '-1' &&
							 document.formPag.CodSetorExp2[i].options[document.formPag.CodSetorExp2[i].selectedIndex].value == '-1') ||
							(document.formPag.CodHierarquiaExp2[i].options[document.formPag.CodHierarquiaExp2[i].selectedIndex].value != '-1' &&
							 document.formPag.CodSetorExp2[i].options[document.formPag.CodSetorExp2[i].selectedIndex].value != '-1' &&
							 isBlank(document.formPag.AnoIniExp2[i].value)) ||
							(document.formPag.CodHierarquiaExp2[i].options[document.formPag.CodHierarquiaExp2[i].selectedIndex].value == '-1' &&
							 document.formPag.CodSetorExp2[i].options[document.formPag.CodSetorExp2[i].selectedIndex].value == '-1' &&
							 !isBlank(document.formPag.AnoIniExp2[i].value)) ||
							(document.formPag.CodHierarquiaExp2[i].options[document.formPag.CodHierarquiaExp2[i].selectedIndex].value == '-1' &&
							 document.formPag.CodSetorExp2[i].options[document.formPag.CodSetorExp2[i].selectedIndex].value == '-1' &&
							 isBlank(document.formPag.AnoIniExp2[i].value) && !isBlank(document.formPag.AnoFimExp2[i].value)) ||

							(document.formPag.CodHierarquiaExp3[i].options[document.formPag.CodHierarquiaExp3[i].selectedIndex].value == '-1' &&
							 document.formPag.CodSetorExp3[i].options[document.formPag.CodSetorExp3[i].selectedIndex].value != '-1') ||
							(document.formPag.CodHierarquiaExp3[i].options[document.formPag.CodHierarquiaExp3[i].selectedIndex].value != '-1' &&
							 document.formPag.CodSetorExp3[i].options[document.formPag.CodSetorExp3[i].selectedIndex].value == '-1') ||
							(document.formPag.CodHierarquiaExp3[i].options[document.formPag.CodHierarquiaExp3[i].selectedIndex].value != '-1' &&
							 document.formPag.CodSetorExp3[i].options[document.formPag.CodSetorExp3[i].selectedIndex].value != '-1' &&
							 isBlank(document.formPag.AnoIniExp3[i].value)) ||
							(document.formPag.CodHierarquiaExp3[i].options[document.formPag.CodHierarquiaExp3[i].selectedIndex].value == '-1' &&
							 document.formPag.CodSetorExp3[i].options[document.formPag.CodSetorExp3[i].selectedIndex].value == '-1' &&
							 !isBlank(document.formPag.AnoIniExp3[i].value)) ||
							(document.formPag.CodHierarquiaExp3[i].options[document.formPag.CodHierarquiaExp3[i].selectedIndex].value == '-1' &&
							 document.formPag.CodSetorExp3[i].options[document.formPag.CodSetorExp3[i].selectedIndex].value == '-1' &&
							 isBlank(document.formPag.AnoIniExp3[i].value) && !isBlank(document.formPag.AnoFimExp3[i].value))
						   ) {
								if (bPrefix) {
									msgErro += '  - Empresa ' + (i+1) + ':\n';
									bPrefix = false;
								}
								msgErro += '     . Classifica��o INCOMPLETA:.\n        Complemente a classifica��o de suas ocupa��es na empresa fornecendo n�vel, �rea e ano inicial da atividade.\n        Se a atividade j� estiver encerrada forne�a tamb�m o ano final.\n        Voc� deve fornecer PELO MENOS 1 classifica��o podendo deixar as demais em branco.\n';
						}

						if (!isYear('AnoIniExp1',i,true) || !isYear('AnoIniExp2',i,true) || !isYear('AnoIniExp3',i,true)) {
								if (bPrefix) {
									msgErro += '  - Empresa ' + (i+1) + ':\n';
									bPrefix = false;
								}
								msgErro += '     . Ano inicial na classifica��o de ocupa��es inv�lido.\n';
						}
						if (!isYear('AnoFimExp1',i,true) || !isYear('AnoFimExp2',i,true) || !isYear('AnoFimExp3',i,true)) {
								if (bPrefix) {
									msgErro += '  - Empresa ' + (i+1) + ':\n';
									bPrefix = false;
								}
								msgErro += '     . Ano final na classifica��o de ocupa��es inv�lido.\n';
						} else {
								if (parseInt(document.formPag.AnoFimExp1[i].value,10) < parseInt(document.formPag.AnoIniExp1[i].value,10)) {
									if (bPrefix) {
										msgErro += '  - Empresa ' + (i+1) + ':\n';
										bPrefix = false;
									}
									msgErro += '     . Ano final deve ser igual ou posterior ao ano inicial na classifica��o de ocupa��es.\n';
								}
						}
					}
			  }
		}
	}

	if (msgErro != '' || nMsgErroG > 0) {
		if (nMsgErroG > 0) {
		  if (nMsgErroG == 1)
			msgErroG = '  - Empresa' + msgErroG;
		  else
			msgErroG = '  - Empresas' + msgErroG;
		  msgErroG += ':\n     . Preencha todos os campos da experi�ncia que deseja incluir no curr�culo (apenas o campo T�rmino � opcional)\n     . CLASSIFIQUE pelo menos 1 ocupa��o na empresa (deixe o ano final em branco se ainda a estiver exercendo).\n     . Para remover a experi�ncia clique no link "remover".\n';
		}
		window.status = 'Done';
		alert ('*** PREENCHIMENTO INCORRETO ***\n\nNo t�pico HIST�RICO PROFISSIONAL\n\n' + msgErroG + msgErro);
		return;
	}

	// FORMACAO
	if (FORM_Escolaridade) {
		if (document.formPag.CodFormMax_cand.options[document.formPag.CodFormMax_cand.selectedIndex].value == '-1')
		  msgErro += '  - Informe o seu n�vel de escolaridade.\n';
	}

	// IDIOMAS	
	if (FORM_Idiomas) {	
		  for (i = 1; i <= QtdeIdiomasCand; i++) {
		    if (document.formPag.elements['Idioma' + i].options[document.formPag.elements['Idioma' + i].selectedIndex].value != '-1') {
			  for (j = i + 1; j <= QtdeIdiomasCand; j++) {
			    if (document.formPag.elements['Idioma' + j].options[document.formPag.elements['Idioma' + j].selectedIndex].value == document.formPag.elements['Idioma' + i].options[document.formPag.elements['Idioma' + i].selectedIndex].value) {
				  msgErro += '  - Idiomas duplicados.'
				  i = QtdeIdiomasCand;
				  break;
				}
			  }
			}
		  }
	}	
	

	msgErroG = '';
	nMsgErroG = 0;
	bTemGraduacao = false;	
	if (FORM_Forms) {
		for (i = 0; i < QtdeFormCand; i++) {
			bPrefix = true;
			if (document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value == '30')
				bTemGraduacao = true;
			if (!isBlank(document.formPag.Curso[i].value) ||
				!isBlank(document.formPag.Instituicao[i].value) ||
			    document.formPag.PaisForm[i].selectedIndex != 0 ||
				document.formPag.Tipo[i].selectedIndex != 0 ||
				document.formPag.Duracao[i].selectedIndex != 0 ||
				document.formPag.CodStatusForm[i].selectedIndex != 0 ||
				document.formPag.MesConclusao[i].selectedIndex != 0 ||												
				!isBlank(document.formPag.AnoConclusao[i].value)) {
				if (isBlank(document.formPag.Curso[i].value) ||
					isBlank(document.formPag.Instituicao[i].value) ||
					document.formPag.PaisForm[i].options[document.formPag.PaisForm[i].selectedIndex].value == '-1' ||
//					(document.formPag.PaisForm[i].options[document.formPag.PaisForm[i].selectedIndex].value == '31' && document.formPag.UFForm[i].options[document.formPag.UFForm[i].selectedIndex].value == '-1') ||
					document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value == '-1' ||
					((document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value == '30' || document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value == '1')&& document.formPag.CursoGradForm[i].options[document.formPag.CursoGradForm[i].selectedIndex].value == '-1') ||
					((document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value == '40' || document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value == '50' || document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value == '60' || document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value == '70' || document.formPag.Tipo[i].options[document.formPag.Tipo[i].selectedIndex].value == '2')&& document.formPag.CursoPGradForm[i].options[document.formPag.CursoPGradForm[i].selectedIndex].value == '-1') ||
					document.formPag.Duracao[i].options[document.formPag.Duracao[i].selectedIndex].value == '-1' ||
					document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '-1' ||
					((document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '20' || document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '30') &&
					(document.formPag.MesConclusao[i].options[document.formPag.MesConclusao[i].selectedIndex].value == '-1' ||
					isBlank(document.formPag.AnoConclusao[i].value)))) {
					nMsgErroG++;
					if (msgErroG == '')
						msgErroG +=' ' + (i+1);
					else
						msgErroG +=', ' + (i+1);
			   } else {
					if ((document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '20' || document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '30') && !isYear('AnoConclusao',i,true)) {
							if (bPrefix) {
								msgErro += '  - Curso ' + (i+1) + ':\n';
								bPrefix = false;
							}
							msgErro += '     . Ano de Conclus�o inv�lido.\n';
					} else {
						if (document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '20') {
							ano = parseInt(document.formPag.elements['AnoConclusao'][i].value,10)
							mes = parseInt(document.formPag.elements['MesConclusao'][i].value,10)
							if (ano < ahj || (ano == ahj && mes < mhj)) {
								if (bPrefix) {
									msgErro += '  - Curso ' + (i+1) + ':\n';
									bPrefix = false;
								}
								msgErro += '     . Ano de Conclus�o deve ser uma data futura ("cursando").\n';
							}
						} else {
							if (document.formPag.CodStatusForm[i].options[document.formPag.CodStatusForm[i].selectedIndex].value == '30') {
								ano = parseInt(document.formPag.elements['AnoConclusao'][i].value,10)
								mes = parseInt(document.formPag.elements['MesConclusao'][i].value,10)
								if (ano > ahj || (ano == ahj && mes > mhj)) {
									if (bPrefix) {
										msgErro += '  - Curso ' + (i+1) + ':\n';
										bPrefix = false;
									}
									msgErro += '     . Ano de Conclus�o deve ser uma data passada ("curso conclu�do").\n';
								}
							}
						}
					}
			   }
			}
		}
	}

	// se escolaridade > superior cursando, deve ter uma forma��o do tipo gradua��o
	if (FORM_Escolaridade && FORM_Forms) {
		//if (document.formPag.CodFormMax_cand.options[document.formPag.CodFormMax_cand.selectedIndex].value >= '55' && !bTemGraduacao) {
		if (document.formPag.CodFormMax_cand.selectedIndex >= 10 && !bTemGraduacao) {
			msgErro += '  - Informe pelo menos um Curso de Gradua��o.\n';
		}
	}

	if (msgErro != '' || nMsgErroG > 0) {
		if (nMsgErroG > 0) {
		  if (nMsgErroG == 1)
			msgErroG = '  - Curso' + msgErroG;
		  else
			msgErroG = '  - Cursos' + msgErroG;
		  msgErroG += ':\n     . Preencha todos os campos do curso que deseja incluir no curr�culo.\n        (os campos "M�s/Ano de Conclus�o" s�o opcionais se o curso foi interrompido).\n        Para remover o curso clique no link "remover".\n';
		}
		window.status = 'Done';
		alert ('*** PREENCHIMENTO INCORRETO ***\n\nNo t�pico FORMA��O\n\n' + msgErroG + msgErro);
		return;
	}

    window.status = 'Enviando cadastro...'
	
	if (DP_Documento) {
		if (QtdeDocCand == 1) {
			if (document.formPag.CodTipoDoc.options[document.formPag.CodTipoDoc.selectedIndex].value == TIPODOCCPF)
				document.formPagHidden.NroDocCOMPAC.value = CPFCompac(document.formPag.NroDoc.value);
			else
				document.formPagHidden.NroDocCOMPAC.value = document.formPag.NroDoc.value;			
		}
		else {
			for (i = 0; i < QtdeDocCand; i++) {
				if (document.formPag.CodTipoDoc[i].options[document.formPag.CodTipoDoc[i].selectedIndex].value == TIPODOCCPF)
					document.formPagHidden.NroDocCOMPAC[i].value = CPFCompac(document.formPag.NroDoc[i].value);				
				else
					document.formPagHidden.NroDocCOMPAC[i].value = document.formPag.NroDoc[i].value;	
			}
		}
	} else {
	// acho que n�o precisa fazer nada, pois j� foi copiado em CadCand.asp
	}
	
    submitForm(action);
  }
  else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}

function submitFormSav(action) {
  if (PagLoaded) {
    window.status = 'Aguarde...'
	submitForm(action)
  } else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}
