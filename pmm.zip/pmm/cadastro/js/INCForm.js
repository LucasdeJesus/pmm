var cpoInv=null;
var loadFormOK;

function jumpNext(cpo,cpoNext) {
  	if(cpo.maxLength==cpo.value.length)
		cpoNext.focus();
}

/* Prepara formulario para envio */

function loadForm() {
   var i;
   var j;
   var x;
   var xOpc;
   var y;
   var obj;
   loadFormOK = true;
   for (x in Campo) {
	  //alert(x);
      if (document.forms[formName]) {
         if (Campo[x] == "L" || Campo[x] == "LOpc") {
			if (NCampos[x] == 1) {
			    i = document.forms[formName].elements[x].selectedIndex;			   
    	        document.formPagHidden.elements[x].value = document.forms[formName].elements[x].options[i].value;
				if (Campo[x] == "LOpc") {
				  xOpc = x + "_opc"
    	          document.formPagHidden.elements[xOpc].value = document.forms[formName].elements[x].options[i].text;
				}
			}	
			else{
				for (i = 0; i < NCampos[x]; i++) {
		            j = document.forms[formName].elements[x][i].selectedIndex;
    		        document.formPagHidden.elements[x][i].value = document.forms[formName].elements[x][i].options[j].value;
					if (Campo[x] == "LOpc") {
					  xOpc = x + "_opc"
    		          document.formPagHidden.elements[xOpc][i].value = document.forms[formName].elements[x][i].options[j].text;
					}
				}
			}
          }
          else {
	         if (Campo[x] == "R" || Campo[x] == "ROpc") {
				if (NCampos[x] == 1) {
				    document.formPagHidden.elements[x].value = document.forms[formName].elements[x].value;
					if (Campo[x] == "ROpc") {
					  xOpc = x + "_opc"
					  document.formPagHidden.elements[xOpc].value = document.forms[formName].elements[xOpc].value;
					}
				}
				else {
					for (i = 0; i < NCampos[x]; i++)	{
			         	if (document.forms[formName].elements[x][i].checked) {
					    	document.formPagHidden.elements[x].value = document.forms[formName].elements[x][i].value;
							if (Campo[x] == "ROpc") {
							  xOpc = x + "_opc"
							  document.formPagHidden.elements[xOpc].value = document.forms[formName].elements[xOpc][i].value;
							}
							break;
						 }
					}
				}	
			 }
			 else {
				if (Campo[x] == "T") {
					if (NCampos[x] == 1) {
					    document.formPagHidden.elements[x].value = document.forms[formName].elements[x].value;
					}	
					else
						for (i = 0; i < NCampos[x]; i++)	{
							document.formPagHidden.elements[x][i].value = document.forms[formName].elements[x][i].value;
						}	
				}
				else {
					if (Campo[x] == "C") {
						if (NCampos[x] == 1) {
							if (document.forms[formName].elements[x].checked)
								document.formPagHidden.elements[x].value = "ON";
							else
								document.formPagHidden.elements[x].value = "OFF";
						}
						else
							for (i = 0; i < NCampos[x]; i++) {
								if (document.forms[formName].elements[x][i].checked)
									document.formPagHidden.elements[x][i].value = "ON";
								else
									document.formPagHidden.elements[x][i].value = "OFF";
							}
					}
					else {
						if (Campo[x] == "C2") {
							if (NCampos[x] == 1) {
								if (document.forms[formName].elements[x].checked)
									document.formPagHidden.elements[x].value = "ON" + document.forms[formName].elements[x].value;
								else
									document.formPagHidden.elements[x].value = "OFF" + document.forms[formName].elements[x].value;
							}
							else
								for (i = 0; i < NCampos[x]; i++) {
									if (document.forms[formName].elements[x][i].checked)
										document.formPagHidden.elements[x][i].value = "ON" + document.forms[formName].elements[x][i].value;
									else
										document.formPagHidden.elements[x][i].value = "OFF" + document.forms[formName].elements[x][i].value;
								}
						}
						else {
							if (Campo[x] == "LM" || Campo[x] == "LMOpc") {
								if (NCampos[x] == 1) {
									document.formPagHidden.elements[x].value = '';
									for (var j = 0; j < document.forms[formName].elements[x].options.length; j++) {
									   	if (document.forms[formName].elements[x].options[j].selected)
											if (document.formPagHidden.elements[x].value == '') {
												document.formPagHidden.elements[x].value = document.forms[formName].elements[x].options[j].value;
												if (Campo[x] == "LMOpc") {
												  xOpc = x + "_opc"
							    		          document.formPagHidden.elements[xOpc].value = document.forms[formName].elements[x].options[j].text;
												}
											}
											else {
												document.formPagHidden.elements[x].value = document.formPagHidden.elements[x].value + ',' + document.forms[formName].elements[x].options[j].value;
												if (Campo[x] == "LMOpc") {
												  xOpc = x + "_opc"
							    		          document.formPagHidden.elements[xOpc].value = document.formPagHidden.elements[xOpc].value + '<br>' + document.forms[formName].elements[x].options[j].text;
												}
											}
									}
								}				
								else{
									for (i = 0; i < NCampos[x]; i++) {
										document.formPagHidden.elements[x][i].value = '';
										for (var j = 0; j < document.forms[formName].elements[x][i].options.length; j++) {
										   	if (document.forms[formName].elements[x][i].options[j].selected)
												if (document.formPagHidden.elements[x][i].value == '') {
													document.formPagHidden.elements[x][i].value = document.forms[formName].elements[x][i].options[j].value;
													if (Campo[x] == "LMOpc") {
													  xOpc = x + "_opc"
								    		          document.formPagHidden.elements[xOpc][i].value = document.forms[formName].elements[x][i].options[j].text;
													}
												}
												else {
													document.formPagHidden.elements[x][i].value = document.formPagHidden.elements[x][i].value + ',' + document.forms[formName].elements[x][i].options[j].value;
													if (Campo[x] == "LMOpc") {
													  xOpc = x + "_opc"
								    		          document.formPagHidden.elements[xOpc][i].value = document.formPagHidden.elements[xOpc][i].value + '<br>' + document.forms[formName].elements[x][i].options[j].text;
													}
												}
										}
									}
								}
							}
							else {
								if (Campo[x] == "H") {
									y = "cbHTML" + x;
									if (document.forms[formName].elements[y].checked)
							   		 	document.formPagHidden.elements[x].value = document.forms[formName].elements[x].value;
									else {
										parse(x,true,'formPagHidden');
									}
								}
								else {
									if (Campo[x] == "getPto") {
										if (loadFormOK) {
											obj = eval('document.aplMapa');
											if (obj == null) {
												loadFormOK = false;
											    alert ("O mapa para defini��o da regi�o de interesse n�o foi corretamente carregado.\nPressione o bot�o Atualiza��o (Refresh) de seu navegador e aguarde a carga completa da p�gina.\nSe o erro persistir, pode ser que haja algum problema para execu��o de Java em seu navegador. Neste caso, voc� pode utilizar a Pesquisa Simplificada pressionando o link na lateral inferior direita desta p�gina.")
											}
											else
											    document.formPagHidden.elements[x].value = document.aplMapa.getPto();
										}											
									}
									else {
										if (Campo[x] == "getRaio") {
											if (loadFormOK) {
												obj = eval('document.aplMapa');
												if (obj == null) {
													loadFormOK = false;
												    alert ("O mapa para defini��o da regi�o de interesse n�o foi corretamente carregado.\nPressione o bot�o Atualiza��o (Refresh) de seu navegador e aguarde a carga completa da p�gina.\nSe o erro persistir, pode ser que haja algum problema para execu��o de Java em seu navegador. Neste caso, voc� pode utilizar a Pesquisa Simplificada pressionando o link na lateral inferior direita desta p�gina.")
												}
												else
												    document.formPagHidden.elements[x].value = document.aplMapa.getRaio();
											}
										}
										else {
											if (Campo[x] == "getAval") {
										    	document.formPagHidden.elements[x].value = document.aplAval.getAval();
											}
											else {
												if (Campo[x] == "getStrSel") {
													document.formPagHidden.elements[x].value = document.aplAval.getStrSel();
												}
												else {
													if (Campo[x] == "getEstado") {
														document.formPagHidden.elements[x].value = document.aplAval.getEstado();
													}
													else {
														if (Campo[x] == "getStrEliminado") {
															document.formPagHidden.elements[x].value = document.aplAval.getStrEliminado();
														}
											else {
											    if (x != 'forEach') document.formPagHidden.elements[x].value = document.forms[formName].elements[x].value;
														}
													}
												}
											}
										}
									}
								}	
							}
						}
					}
			 	}
          	}
	   	}
	 }
   }
   return;
}

/* Valida campos do formulario */
function validForm() {
   return loadFormOK;
}


/* Monta formulario para submit */
function submitFormChkLoad(action) {
  if (PagLoaded)
    submitForm(action);
  else
    alert ("A p�gina n�o foi completamente carregada.\nAguarde a sua carga ou pressione o bot�o Atualiza��o (Refresh) de seu navegador.")
}

function submitForm(action) {
   loadForm();
   if (validForm()) {
	  document.formPagHidden.elements["Action"].value = action
      document.formPagHidden.submit();
   }
   else {
      if (cpoInv) {
         document.forms[formName].elements[cpoInv].focus();
         cpoInv = null;
      }
   }
   return false;
}

function clearForm() {
   var i;
   var x;
   for (x in Campo) {
      if (document.forms[formName]) {
         if (Campo[x] == "L" || Campo[x] == "LM") {
		   if (NCampos[x] == 1)
             document.forms[formName].elements[x].selectedIndex = 0;
		   else
			 for (i = 0; i < NCampos[x]; i++)	{
				document.forms[formName].elements[x][i].selectedIndex = 0;
			 }
          }
          else {
	         if (Campo[x] == "R") {
		         document.forms[formName].elements[x][0].checked = true;
				for (i = 0; i < NCampos[x]; i++)	{
					document.forms[formName].elements[x][i].checked = false;
				}	
			 }
			 else {
				if (Campo[x] == "T") {
					if (NCampos[x] == 1)
					    document.forms[formName].elements[x].value = "";
					else
						for (i = 0; i < NCampos[x]; i++)	{
							document.forms[formName].elements[x][i].value = "";
						}	
				}
				else {
					if (Campo[x] == "C") {
						if (NCampos[x] == 1) {
							document.forms[formName].elements[x].checked = false;
						}
						else
							for (i = 0; i < NCampos[x]; i++) {
								document.forms[formName].elements[x][i].checked = false;
							}
					}
					else
					    document.forms[formName].elements[x].value = "";
				}
			 }
          }
	   }
   }
   return;
}
