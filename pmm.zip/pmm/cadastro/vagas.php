
<!DOCTYPE html>
<!-- saved from url=(0047) -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">

<meta name="" content="">
<title>VAGAS Tecnologia - l�der em solu��es de e-recruitment </title>

<meta name="google" value="notranslate">
<style type="text/css" media="screen">
<!--
  .iptsml { font-size: 8pt; font-family: verdana; }
-->
</style>



<link rel="stylesheet" type="text/css" href="./js/vagasnet.css">







<!--[if IE 6]>
	<script src="js/ajustes/DD_belatedPNG.js" type="text/javascript"></script>
	<script> DD_belatedPNG.fix('*'); </script> 
<![endif]-->



</head>

<body class="notranslate" bgcolor="#000068" id="RodC" link="#99CCFE" vlink="#99CCFE" alink="#EEEEEE" background="./js/back.gif" onload="startup(); MM_preloadImages(&#39;img/cust/pdncand2/siteOrigem_F02.gif&#39;,&#39;#933570906060&#39;);MM_preloadImages(&#39;img/cust/pdncand2/mail_F02.gif&#39;,&#39;#923437320990&#39;);MM_preloadImages(&#39;img/cust/pdncand2/confirma_F02.gif&#39;,&#39;#923339814720&#39;);MM_preloadImages(&#39;img/cust/pdncand2/limpa_F02.gif&#39;,&#39;#925672599230&#39;);MM_preloadImages(&#39;img/cust/pdncand2/desiste_F02.gif&#39;,&#39;#923351380880&#39;);MM_preloadImages(&#39;img/cust/pdncand2/confirma_F02.gif&#39;,&#39;#924576064410&#39;);MM_preloadImages(&#39;img/cust/pdncand2/DestaqLat-SetaPisc.gif&#39;,&#39;#925856606450&#39;);MM_preloadImages(&#39;img/cust/pdncand2/DestaqLat-Seta.gif&#39;,&#39;#926534025810&#39;);MM_preloadImages(&#39;img/cust/pdncand2/DestaqLat-Seta.gif&#39;,&#39;#930411429910&#39;);MM_preloadImages(&#39;img/cust/pdncand2/DestaqLat-SetaPisc.gif&#39;,&#39;#930411354670&#39;);MM_preloadImages(&#39;img/cust/pdncand2/pvaga_F02.gif&#39;,&#39;#931615501830&#39;);MM_preloadImages(&#39;img/cust/pdncand2/anivagas_over.gif&#39;,&#39;#923425118250&#39;);MM_preloadImages(&#39;img/cust/pdncand2/bullet_F02.gif&#39;,&#39;#933557028530&#39;);MM_preloadImages(&#39;img/cust/pdncand2/Cores_F02.gif&#39;,&#39;#924874210210&#39;);MM_preloadImages(&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)">

<a name="topo"></a>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr bgcolor="#FFFFFF" id="TopC"> 
    <td width="105" height="35" align="left" class="ImgFndTopo1"></td>
    <td height="35" align="center" colspan="2" width="99%" class="ImgFndTopo2">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
       <tbody><tr> 
	    <td height="35" align="center">
		 <font color="#000068" id="TopTtitN" face="Verdana, Arial" size="4"><img src="./js/pointer.gif">
    	 <!--#001-->cadastramento de candidato<!--/#--></font>
		</td>
		
		<td height="35" width="105" align="right">&nbsp;</td>
		
	   </tr>
	  </tbody></table>
	</td>
  </tr>



</tbody></table>

<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" bgcolor="#99CCFF" id="PrC">

        <form name="formPag" method="post" action=""></form>

  <tbody><tr> 
    <td valign="top" width="100%" height="50%"> 
      <table border="0" cellspacing="0" cellpadding="0" align="center" width="100%" bgcolor="#99CCFF" id="PrC">
          <tbody><tr height="50"> 
            <td align="left" valign="top" colspan="3" width="80%"><a name="tab0"></a> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody><tr valign="top" align="left"> 
                  <td>
	                <table width="100%" border="0" cellspacing="0" cellpadding="0">
					 <tbody><tr>
					  <td align="center"  width="100" height="5" colspan="3"></td>
					  
					  <td align="center"  width="100" height="5" colspan="3"></td>
					  
					  <td align="center" width="100" height="5" colspan="3"></td>
					  
					  <td align="center"  width="100" height="5" colspan="3"></td>
					  
					  <td align="center" width="100%"></td>
				     </tr>
					 <tr>
					  <td background="./js/Tabs1Fnd_F01.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F01.gif" border="0"></td>
					  <td background="./js/Tabs1Fnd_F01.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#0000A0"><b><a href="#tab0" class="TabOnL">&nbsp;<!--#t-->dados pessoais<!--/#--></a></b></font></td>
					  <td background="./js/Tabs2Fnd_F01.gif" align="right" valign="top" width="18" height="35"><img src="./js/Tabs2Frt_F01.gif" border="0"></td>
					  
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F02.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab1" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab01&#39;,&#39;document.tab01&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->objetivos profissionais<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="18" height="35"><a href="#tab1" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab01&#39;,&#39;document.tab01&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2Frt_F02.gif" name="tab01" border="0"></a></td>
					  
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F02.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab2" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab02&#39;,&#39;document.tab02&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->hist�rico profissional<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="18" height="35"><a href="#tab2" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab02&#39;,&#39;document.tab02&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2Frt_F02.gif" name="tab02" border="0"></a></td>
					  
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F02.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab3" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab03&#39;,&#39;document.tab03&#39;,&#39;img/tab/Tabs2UltFrt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->forma��o<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="20" height="35"><a href="#tab3" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab03&#39;,&#39;document.tab03&#39;,&#39;img/tab/Tabs2UltFrt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2UltFrt_F02.gif" name="tab03" border="0"></a></td>
					  
					  <td background="./js/TabVazioFnd.gif" width="100%" align="center"><font face="Verdana, Arial" size="1">&nbsp;</font></td>
				     </tr>
					 <tr>
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100%"><font face="Verdana, Arial" size="1"></font></td>
				     </tr>
					</tbody></table>
				  </td>
                </tr>
              </tbody></table>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/TabLatBack.gif" colspan="2" width="20%" valign="top">&nbsp;</td>
          </tr>
		
          <tr> 
  		 	
            <td colspan="2" width="80%"><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#100-->Informe os seus dados pessoais<!--/#--></b></font></td>
            <td>
			   <!-- Curriculo -->
				<script type="text/javascript">
					GA_googleFillSlot("Curriculo");
				</script><script src="./js/ads"></script>
            </td>
			
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq"></td>
            <td bgcolor="#3064C8" id="LtC" width="18%" rowspan="9" valign="top"><font face="Verdana, Arial" size="1" color="#FFFFFF" id="LtTn"><b>

			
			
			  <!--#120--><font color="#FFFF00" id="LtTd">Dica</font>: durante o preenchimento, use<!--/#--><br>
              <a href="#" onclick="showcv(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botVisualiza0&#39;,&#39;document.botVisualiza0&#39;,&#39;img/cust/pdncand2/visualiza_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/visualiza_F01.gif" alt="Curr�culo formatado" name="botVisualiza0" align="absmiddle"></a> 
              <!--#121-->ou<!--/#--> <a href="#" onclick="showcvconf(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botConfidencial0&#39;,&#39;document.botConfidencial0&#39;,&#39;img/cust/pdncand2/confidencial_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/confidencial_F01.gif" alt="Curr�culo em formato confidencial" name="botConfidencial0" align="absmiddle"></a><br>
              <!--#122-->sempre que queira visualizar o seu curr�culo "em constru��o", 
              nos formatos normal e confidencial.<!--/#-->

			  </b></font></td>
          </tr>

          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#210-->E-mail<!--/#--><sup>*</sup></font></td>
            <td> 
              <input type="text" name="Email_cand" size="32" maxlength="60" value="" onkeyup="SetSav(&#39;SavCand&#39;)" onfocus="MM_swapImage(&#39;document.formPag.Destaq03&#39;,&#39;document.Destaq03&#39;,&#39;img/cust/pdncand2/DestaqLat-SetaPisc.gif&#39;,&#39;#925856606450&#39;)" onblur="MM_swapImage(&#39;document.formPag.Destaq03&#39;,&#39;document.Destaq03&#39;,&#39;img/cust/pdncand2/DestaqLat-Seta.gif&#39;,&#39;#926534025810&#39;)" class="iptsml">
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%" rowspan="8">&nbsp;</td>			
          </tr>
       

          <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
            <td width="40%"><font face="Verdana, Arial" size="2" id="PrTn"><!--#130-->Nome completo<!--/#--><sup>*</sup></font></td>
            <td width="35%"> 
              <input type="text" name="Nome_cand" size="32" maxlength="60" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml">
            </td>
		  
          </tr>
		  
		   <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
            <td width="40%"><font face="Verdana, Arial" size="2" id="PrTn"><!--#130-->M�e<!--/#--><sup>*</sup></font></td>
            <td width="35%"> 
              <input type="text" name="mae" size="32" maxlength="60" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml">
            </td>
		  
          </tr>
		  
		   <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
            <td width="40%"><font face="Verdana, Arial" size="2" id="PrTn"><!--#130-->Pai<!--/#--><sup>*</sup></font></td>
            <td width="35%"> 
              <input type="text" name="pai" size="32" maxlength="60" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml">
            </td>
		  
          </tr>
		  
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#180-->Pa�s<!--/#--><sup>*</sup></font></td>
            <td> 
			
              <select name="CodPais_cand" style="font-size: 8pt; font-family: verdana; width: 260px" onfocus="checkSelect2(&#39;CodPais_cand&#39;,-1,0);" onchange="SetSav(&#39;SavRegioes&#39;); SetSav(&#39;SavCand&#39;); alterouPais(false, &#39;CodPais_cand&#39;, -1);">
			<option value="-1"> </option><option value="31">Brasil</option></select>
            </td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#170-->Estado<!--/#--><sup>*</sup></font></td>
            <td> 
			
              <select name="CodUF_cand" style="font-size: 8pt; font-family: verdana; width: 260px" onchange="SetSav(&#39;SavRegioes&#39;); SetSav(&#39;SavCand&#39;); alterouEstado(false);"><option value="-2">(n�o h�)</option></select>
			
            </td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#160-->Cidade<!--/#--><sup>*</sup></font></td>
            <td> 
			
              <select name="CodCidade_cand" style="font-size: 8pt; font-family: verdana; width: 260px" onchange="SetSav(&#39;SavRegioes&#39;); SetSav(&#39;SavCand&#39;);"><option value="-2">(n�o h�)</option></select>
			
            </td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#140-->Endere�o<!--/#--><sup>*</sup></font></td>
            <td> 
              <input type="text" name="Endereco_cand" size="32" maxlength="60" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml">
            </td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#145-->Bairro<!--/#--><sup>*</sup></font></td>
            <td> 
              <input type="text" name="Bairro_cand" size="32" maxlength="30" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml">
            </td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#150-->CEP - C�digo Postal<!--/#--><sup>*</sup></font></td>
            <td> 
			  <input type="text" size="30" maxlength="30" name="Cep_cand_1" value="" onkeyup="SetSav(&#39;SavCand&#39;);trataCEP();" class="iptsml"><b>-</b><input type="text" size="3" maxlength="3" name="Cep_cand_2" value="" onkeyup="SetSav(&#39;SavCand&#39;)" class="iptsml" style="visibility: hidden;">
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#190-->Telefone(s) de contato<!--/#--><sup>*</sup></font></td>
            <td rowspan="2" valign="top"> 
              <textarea name="Tel_cand" onkeyup="SetSav(&#39;SavCand&#39;)" onfocus="MM_swapImage(&#39;document.formPag.Destaq02&#39;,&#39;document.Destaq02&#39;,&#39;img/cust/pdncand2/DestaqLat-SetaPisc.gif&#39;,&#39;#925856606450&#39;)" onblur="MM_swapImage(&#39;document.formPag.Destaq02&#39;,&#39;document.Destaq02&#39;,&#39;img/cust/pdncand2/DestaqLat-Seta.gif&#39;,&#39;#926534025810&#39;)" cols="28" wrap="PHYSICAL" rows="2"></textarea>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq02"></td>
            <td bgcolor="#3064C8" id="LtC" rowspan="2" valign="top" width="18%"><font face="Verdana, Arial" size="1" color="#FFFFFF" id="LtTn"><b><!--#200-->Inclua 
              o DDD e outras informa��es. Ex: <i>(12)3456-7890 (fone/fax); 
              9876-5432 (cel).</i><!--/#--></b></font></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" valign="bottom" width="2%"><img src="./js/DestaqLat-Quebra.gif" name="Quebra"></td>
          </tr>
		  
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#202-->Celular<!--/#--></font>
			<font face="Verdana, Arial" size="1" id="PrTn"><a href="#" onclick="pp=window.open(&#39;SMSSaibaMais.asp&#39;,&#39;pp&#39;,&#39;height=400,width=640,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no&#39;); pp.focus(); return false;" class="PrL"><font color="#FF0000" id="PrTl"><!--#310-->(Saiba mais)<!--/#--></font></a>
			<br><!--#-->(apenas para o Brasil)<!--/#--></font></td>
            <td><font face="Verdana, Arial" size="1" id="PrTn"><!--#-->Pa�s<!--/#-->&nbsp;
			
<!--              <select name="CelCodPais_cand" style="font-size: 8pt; font-family: verdana; width: 150px" onChange="checkSelect('CelCodPais_cand',-1,1)"> -->
              <select name="CelCodPais_cand" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavCand&#39;); checkSelect2(&#39;CelCodPais_cand&#39;,-1,1)">
			<option value="1">Brasil</option></select>
            </font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq05"></td>
            <td bgcolor="#3064C8" id="LtC" rowspan="4" valign="top" width="18%"><font face="Verdana, Arial" size="1" color="#FFFFFF" id="LtTn"><b><br><!--#204-->Cadastre
			  o seu celular para receber mensagens de texto, torpedos SMS.<!--/#--></b></font></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn">&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1" id="PrTn"><!--#-->�rea<!--/#-->  
              <input type="text" name="CelCodArea_cand" size="3" maxlength="3" value="" onkeyup="SetSav(&#39;SavCand&#39;)" onfocus="MM_swapImage(&#39;document.formPag.Destaq05&#39;,&#39;document.Destaq05&#39;,&#39;img/cust/pdncand2/DestaqLat-SetaPisc.gif&#39;,&#39;#925856606450&#39;)" onblur="MM_swapImage(&#39;document.formPag.Destaq05&#39;,&#39;document.Destaq05&#39;,&#39;img/cust/pdncand2/DestaqLat-Seta.gif&#39;,&#39;#926534025810&#39;)" class="iptsml">
			   <!--#-->Fone<!--/#--> <input type="text" name="Celular_cand" size="10" maxlength="10" value="" onkeyup="SetSav(&#39;SavCand&#39;);" onfocus="AceitaSMS();" onblur="MM_swapImage(&#39;document.formPag.Destaq05&#39;,&#39;document.Destaq05&#39;,&#39;img/cust/pdncand2/DestaqLat-Seta.gif&#39;,&#39;#926534025810&#39;)" class="iptsml">
			  </font>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn">&nbsp;</font></td>
            <td><input type="checkbox" name="CelularConfidencial_cand" value="ON" checked="" onclick="SetSav(&#39;SavCand&#39;)">
               <font face="Verdana, Arial" size="1" id="PrTn"><!--#205-->confidencial (celular invis�vel para empresas)<!--/#--></font>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" valign="bottom" width="2%">&nbsp;</td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn">&nbsp;</font></td>
            <td><input type="checkbox" name="AceitaSMS_cand" value="ON" checked="" onclick="SetSav(&#39;SavSMS&#39;); VerificaSMS();">
               <font face="Verdana, Arial" size="1" id="PrTn"><!--#207-->aceito receber torpedos SMS<!--/#--></font>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" valign="bottom" width="2%"><img src="./js/DestaqLat-Quebra.gif" name="Quebra"></td>
          </tr>
		  

          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#230-->Pa�s de Nacionalidade<!--/#--><sup>*</sup></font></td>
            <td> 
			
<!--              <select name="CodNacion_cand" style="font-size: 8pt; font-family: verdana; width: 260px" onChange="checkSelect('CodNacion_cand',-1,2)"> -->
              <select name="CodNacion_cand" style="font-size: 8pt; font-family: verdana; width: 260px" onfocus="SetSav(&#39;SavCand&#39;); checkSelect2(&#39;CodNacion_cand&#39;,-1,2); return;">
			<option value="-1"> </option><option value="31">Brasil</option></select>
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
		  
		    <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#230-->Naturalidade<!--/#--><sup>*</sup></font></td>
            <td> 
			  <input type="text" name="naturalidade" size="32" maxlength="30" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml">

            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#240-->Nascimento<!--/#--><sup>*</sup></font></td>
            <td> 
              <input type="text" size="2" maxlength="2" name="DtNasc_cand_dia" value="" onkeyup="SetSav(&#39;SavCand&#39;);jumpNext(this,document.formPag.DtNasc_cand_mes)" class="iptsml">
              / 
              <input type="text" size="2" maxlength="2" name="DtNasc_cand_mes" value="" onkeyup="SetSav(&#39;SavCand&#39;);jumpNext(this,document.formPag.DtNasc_cand_ano)" class="iptsml">
              / 
              <input type="text" size="4" maxlength="4" name="DtNasc_cand_ano" value="" onkeyup="SetSav(&#39;SavCand&#39;)" class="iptsml">
			  <font face="Verdana, Arial" size="1" id="PrTn"><!--#-->(dd/mm/aaaa)<!--/#--></font></td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#250-->Sexo<!--/#--><sup>*</sup></font></td>
            <td> <font face="Verdana, Arial" size="2" id="PrTn"> 
              <input type="radio" checked="" name="Masc_cand" value="True" onclick="SetSav(&#39;SavCand&#39;)">
              <!--#260-->Masculino<!--/#-->
              <input type="radio" name="Masc_cand" value="False" onclick="SetSav(&#39;SavCand&#39;)">
              <!--#270-->Feminino<!--/#--></font></td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#280-->Estado civil<!--/#--><sup>*</sup></font></td>
            <td>
			
<!--              <select name="CodEstadoCivil_cand" size="1" style="font-size: 8pt; font-family: verdana; width: 150px" onChange="checkSelect('CodEstadoCivil_cand',-1,3)"> -->
				<select name="CodEstadoCivil_cand" size="1" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavCand&#39;); checkSelect2(&#39;CodEstadoCivil_cand&#39;,-1,3);">				
			<option value="">Selecione</option>
					<option value="S">Solteiro(a)</option>
					<option value="C">Casado(a)</option>
					<option value="U">Uni�o Est�vel</option>
					<option value="Q">Desquitado(a)</option>
					<option value="D">Divorciado(a)</option>
					<option value="V">Vi�vo(a)</option>
					<option value="O">Outros</option>

			
			</select>
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#290-->Filhos<!--/#--></font></td>
            <td> 
              <input type="text" size="2" maxlength="2" name="NroFilhos_cand" value="" onkeyup="SetSav(&#39;SavCand&#39;)" class="iptsml">
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
		  
<!--			<a href="#" onClick="fb=window.open('http://192.168.168.107:3000/auth/facebook/33765261', 'fb', 'height=600,width=800,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no'); fb.focus(); return false;" class="PrL"><font color="#FF0000" ID=PrTl>incluir meu perfil</font></a> -->		  
<!--			<a href="#" onClick="fb=window.open('', 'fb', 'height=600,width=800,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no'); fb.focus(); return false;" class="PrL"><font color="#FF0000" ID=PrTl>visualizar</font></a> -->		  

		  
        
        
        
        
		  
          <tr> 
            <td colspan="3" valign="top"><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#295-->Documento principal<!--/#--></b></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" valign="middle" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq"></td>
            <td bgcolor="#3064C8" id="LtC" valign="top" width="18%" rowspan="2"><font face="Verdana, Arial" size="1" color="#FFFFFF" id="LtTn"><b><!--#1030-->Informe o tipo 
              e n�mero de documento que voc� possui. 
			  
			  <!--/#--></b></font></td>
          </tr>

        
		  
		   <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#230-->CPF<!--/#--><sup>*</sup></font></td>
            <td> 
			  <input type="text" name="cpf" size="32" maxlength="30" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml">

            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
		  
		   <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#230-->RG<!--/#--><sup>*</sup></font></td>
            <td> 
			  <input type="text" name="rg" size="32" maxlength="30" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml">

            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
		   <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#230-->Titulo Eleitor<!--/#--><sup>*</sup></font></td>
            <td> 
			  <input type="text" name="titulo" size="32" maxlength="30" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml">
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr> 
		  
		  <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#230-->Zona<!--/#--><sup>*</sup></font></td>
            <td> 
			  <input type="text" name="zona" size="12" maxlength="4" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml"><font id="PrTn" face="Verdana, Arial" size="1"> Se��o</font>  <input type="text" name="secao" size="9" maxlength="4" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml"> 
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
		   
		  <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#230-->Carteira Trabalho<!--/#--><sup>*</sup></font></td>
            <td> 
			  <input type="text" name="ctps" size="12" maxlength="234" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml"><font id="PrTn" face="Verdana, Arial" size="1"> S�rie</font>  <input type="text" name="secao" size="9" maxlength="9" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml"> 
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
		   <tr> 
            <td>&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#230-->PIS/PASEP<!--/#--><sup>*</sup></font></td>
            <td> 
			  <input type="text" name="pis" size="12" maxlength="234" value="" onkeyup="SetSav(&#39;SavCand&#39;);" class="iptsml"> 
			 <font id="PrTn" face="Verdana, Arial" size="1"> CNH</font>
			  <select name="seltipocnh" id="seltipocnh" onChange="Maiuscula(this);EditandoRegistro();" style="width:63px;" tabindex="44">
					<option value="">Selecione</option>
					<option value="A">A</option>
					<option value="B">B</option>
					<option value="C">C</option>
					<option value="D">D</option>
					<option value="E">E</option>
					<option value="AB">AB</option>
					<option value="AC">AC</option>
					<option value="AD">AD</option>
					<option value="AE">AE</option>
				</select>

			  
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
		  
			
          <tr> 
            <td colspan="3"><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#299-->Defici�ncias<!--/#--></b></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" valign="middle" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq"></td>
            <td bgcolor="#3064C8" id="LtC" valign="top" width="18%" rowspan="2"><font face="Verdana, Arial" size="1" color="#FFFFFF" id="LtTn"><b><!--#320-->Aqui 
              voc� especifica se possui alguma defici�ncia.<!--/#--></b></font></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td colspan="2" valign="top"><font face="Verdana, Arial" size="2" id="PrTn"><!--#-->Voc� possui alguma defici�ncia?<!--/#-->
		        <select name="NecEspPortador" onchange="SetSav(&#39;SavNecEsp&#39;);checkNecEspVisibility()" style="font-size: 8pt; font-family: verdana;">
	                 <option selected="" value="-1"><!--#-->N�o<!--/#--></option>
	                 <option value="1"><!--#-->Sim<!--/#--></option>
	            </select></font></td>
            <td bgcolor="#3064C8" id="LtC" width="2%" background="./js/DestaqLat-Fundo.gif">&nbsp;</td>
          </tr>
          <tr id="TipoNecEsp"> 
            <td>&nbsp;</td>
            <td colspan="2">
			  <table border="0" cellspacing="0" cellpadding="0"><tbody><tr><td colspan="2">
			    </td></tr><tr><td colspan="3"><font face="Verdana, Arial" size="2" id="PrTn"><!--#-->Selecione o tipo de defici�ncia:<!--/#--></font></td></tr>
			    <tr><td width="5%">&nbsp;</td>
				    <td width="20%"><font face="Verdana, Arial" size="2" id="PrTn"><input type="checkbox" name="NecEspAuditiva" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;);"><!--#-->Auditiva<!--/#--></font></td>
		            <td><div name="NecEspAuditiva" id="NecEspAuditiva"><font face="Verdana, Arial" size="2" id="PrTn"><select name="NecEspAuditivaTipo" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspCompl2(&#39;NecEspAuditiva&#39;,&#39;NecEspAuditivaTipo&#39;, &#39;NecEspAuditivaUniBi&#39;);" style="font-size: 8pt; font-family: verdana; width: 300px">
							<option selected="" value="-1"><!--#-->Selecione uma op��o<!--/#--></option>
							<option value="10"><!--#-->de 41 a 55 dB � Surdez Moderada<!--/#--></option>
							<option value="15"><!--#-->de 56 a 70 dB � Surdez Acentuada<!--/#--></option>							
							<option value="20"><!--#-->de 71 a 90 dB � Surdez Severa<!--/#--></option>
							<option value="25"><!--#-->Acima de 91 dB � Surdez Profunda<!--/#--></option>							
							<option value="30"><!--#-->Anacusia<!--/#--></option>
						</select>&nbsp;<select name="NecEspAuditivaUniBi" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspCompl2(&#39;NecEspAuditiva&#39;, &#39;NecEspAuditivaTipo&#39;, &#39;NecEspAuditivaUniBi&#39;);" style="font-size: 8pt; font-family: verdana; width: 200px">
							<option selected="" value="-1"><!--#-->Selecione uma op��o<!--/#--></option>
							<option value="270"><!--#-->unilateral<!--/#--></option>
							<option value="280"><!--#-->bilateral<!--/#--></option>							
						</select></font></div></td></tr>
			    <tr><td width="5%">&nbsp;</td>
				    <td><font face="Verdana, Arial" size="2" id="PrTn"><input type="checkbox" name="NecEspFala" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;);"><!--#-->Fala<!--/#--></font></td>
		            <td><div name="NecEspFala" id="NecEspFala"><font face="Verdana, Arial" size="2" id="PrTn"><select name="NecEspFalaTipo" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspCompl(&#39;NecEspFala&#39;,&#39;NecEspFalaTipo&#39;);" style="font-size: 8pt; font-family: verdana; width: 300px">
							<option selected="" value="-1"><!--#-->Selecione uma op��o<!--/#--></option>
							<option value="40"><!--#-->Grandes altera��es na fala<!--/#--></option>
							<option value="50"><!--#-->Mudez<!--/#--></option>
						</select></font></div></td></tr>
			    <tr><td width="5%">&nbsp;</td>
				    <td><font face="Verdana, Arial" size="2" id="PrTn"><input type="checkbox" name="NecEspFisica" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;);"><!--#-->F�sica<!--/#--></font></td>
		            <td><div name="NecEspFisica" id="NecEspFisica"><font face="Verdana, Arial" size="2" id="PrTn"><select name="NecEspFisicaTipo" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspFisicaCompl(); checkNecEspCompl2(&#39;NecEspFisica&#39;, &#39;NecEspFisicaTipo&#39;, &#39;NecEspFisicaInfSup&#39;);" style="font-size: 8pt; font-family: verdana; width: 300px">
							<option selected="" value="-1"><!--#-->Selecione uma op��o<!--/#--></option>
							<option value="130"><!--#-->Monoparesia<!--/#--></option>
							<option value="140"><!--#-->Monoplegia<!--/#--></option>
							<option value="150"><!--#-->Hemiparesia<!--/#--></option>
							<option value="160"><!--#-->Hemiplegia<!--/#--></option>
							<option value="170"><!--#-->Paraparesia<!--/#--></option>
							<option value="180"><!--#-->Paraplegia<!--/#--></option>
							<option value="190"><!--#-->Triparesia<!--/#--></option>
							<option value="200"><!--#-->Triplegia<!--/#--></option>
							<option value="210"><!--#-->Tetraparesia<!--/#--></option>
							<option value="220"><!--#-->Tetraplegia<!--/#--></option>
							<option value="230"><!--#-->Amputa��o ou aus�ncia de membro<!--/#--></option>
							<option value="240"><!--#-->Membros com deformidade cong�nita ou adquirida<!--/#--></option>
							<option value="250"><!--#-->Nanismo<!--/#--></option>
							<option value="260"><!--#-->Ostomia<!--/#--></option>	
						</select>&nbsp;<select name="NecEspFisicaInfSup" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspCompl2(&#39;NecEspFisica&#39;, &#39;NecEspFisicaTipo&#39;, &#39;NecEspFisicaInfSup&#39;);" style="font-size: 8pt; font-family: verdana; width: 200px">
							<option selected="" value="-1"><!--#-->Selecione uma op��o<!--/#--></option>
							<option value="60"><!--#-->membro(s) inferior(es)<!--/#--></option>
							<option value="70"><!--#-->membro(s) superior(es)<!--/#--></option>
							<option value="80"><!--#-->membros superior(es) e inferior(es)<!--/#--></option></select></font></div></td></tr>
			    <tr><td width="5%">&nbsp;</td>
				    <td valign="top"><font face="Verdana, Arial" size="2" id="PrTn"><input type="checkbox" name="NecEspMental" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;);"><!--#-->Mental<!--/#--></font></td>
		            <td><div name="LimNecEspMental" id="LimNecEspMental"><font face="Verdana, Arial" size="1" id="PrTn">
						<!--#-->Limita��es associadas a duas ou mais �reas de habilidades adaptativas, tais como:<!--/#--><br>
					    <table border="0" cellspacing="0" cellpadding="0">
							<tbody><tr><td><font face="Verdana, Arial" size="1" id="PrTn"><input type="checkbox" name="NecEspComunic" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspMentalCompl();"><!--#-->Comunica��o<!--/#--></font></td>
							    <td><font face="Verdana, Arial" size="1" id="PrTn"><input type="checkbox" name="NecEspCuidadoPess" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspMentalCompl();"><!--#-->Cuidado pessoal<!--/#--></font></td></tr>
							<tr><td><font face="Verdana, Arial" size="1" id="PrTn"><input type="checkbox" name="NecEspHabSocial" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspMentalCompl();"><!--#-->Habilidade social<!--/#--></font></td>
							    <td><font face="Verdana, Arial" size="1" id="PrTn"><input type="checkbox" name="NecEspRecursosCom" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspMentalCompl();"><!--#-->Utiliza��o de recursos da comunidade<!--/#--></font></td></tr>
							<tr><td><font face="Verdana, Arial" size="1" id="PrTn"><input type="checkbox" name="NecEspSaudeSeg" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspMentalCompl();"><!--#-->Sa�de e seguran�a<!--/#--></font></td>
							    <td><font face="Verdana, Arial" size="1" id="PrTn"><input type="checkbox" name="NecEspHabAcad" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspMentalCompl();"><!--#-->Habilidade acad�mica<!--/#--></font></td></tr>
							<tr><td><font face="Verdana, Arial" size="1" id="PrTn"><input type="checkbox" name="NecEspLazer" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspMentalCompl();"><!--#-->Lazer<!--/#--></font></td>
							    <td><font face="Verdana, Arial" size="1" id="PrTn"><input type="checkbox" name="NecEspTrabalho" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspMentalCompl();"><!--#-->Trabalho<!--/#--></font></td></tr>
						</tbody></table>
						</font></div></td></tr>
			    <tr><td width="5%">&nbsp;</td>
				    <td><font face="Verdana, Arial" size="2" id="PrTn"><input type="checkbox" name="NecEspVisual" value="ON" onclick="SetSav(&#39;SavNecEsp&#39;);"><!--#-->Visual<!--/#--></font></td>
		            <td><div name="NecEspVisual" id="NecEspVisual"><font face="Verdana, Arial" size="2" id="PrTn"><select name="NecEspVisualTipo" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspCompl2(&#39;NecEspVisual&#39;, &#39;NecEspVisualTipo&#39;, &#39;NecEspVisualUniBi&#39;);" style="font-size: 8pt; font-family: verdana; width: 300px">
							<option selected="" value="-1"><!--#-->Selecione uma op��o<!--/#--></option>
							<option value="110"><!--#-->Vis�o Subnormal ou Baixa Vis�o<!--/#--></option>
							<option value="120"><!--#-->Cegueira<!--/#--></option>
						</select>&nbsp;<select name="NecEspVisualUniBi" onclick="SetSav(&#39;SavNecEsp&#39;); checkNecEspCompl2(&#39;NecEspVisual&#39;, &#39;NecEspVisualTipo&#39;, &#39;NecEspVisualUniBi&#39;);" style="font-size: 8pt; font-family: verdana; width: 200px">
							<option selected="" value="-1"><!--#-->Selecione uma op��o<!--/#--></option>
							<option value="290"><!--#-->unilateral/monocular<!--/#--></option>
							<option value="300"><!--#-->bilateral<!--/#--></option>							
						</select></font></div></td></tr>
			    <tr><td width="5%">&nbsp;</td><td colspan="2"><font face="Verdana, Arial" size="1" id="PrTn"><!--#-->Observa��es:<!--/#--> <font size="1">(<!--#-->informe aparelhos, pr�teses ou infra-estrutura que necessite<!--/#-->)</font></font></td></tr>
				<tr><td width="5%">&nbsp;</td><td colspan="2"><font face="Verdana, Arial" size="2" id="PrTn">
					<textarea name="NecEspObs" rows="3" cols="50" wrap="PHYSICAL" onkeyup="SetSav(&#39;SavNecEsp&#39;)"></textarea>
					</font></td></tr>
			  </tbody></table>
            </td><td bgcolor="#3064C8" id="LtC" width="2%" valign="bottom" background="./js/DestaqLat-Fundo.gif"><img src="./js/DestaqLat-Quebra.gif" name="Destaq"></td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
         
         
	  </tbody></table>
	</td>
  </tr>
</tbody></table>		  

<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" bgcolor="#99CCFF" id="PrC">
  <tbody><tr bgcolor="#3064C8" id="LtC"> 
    <td valign="top" width="100%" height="50%"> 
      <table border="0" cellspacing="0" cellpadding="0" align="center" width="100%" bgcolor="#99CCFF" id="PrC">
          <tbody><tr height="50"> 
            <td align="left" valign="top" colspan="3" width="80%"><a name="tab1"></a> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody><tr valign="top" align="left"> 
                  <td>
	                <table width="100%" border="0" cellspacing="0" cellpadding="0">
					 <tbody><tr>
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100%"><img src="./js/TabTopoFrt.gif" border="0"></td>
				     </tr>
					 <tr>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F03.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab0" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab11&#39;,&#39;document.tab11&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->dados pessoais<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="18" height="35"><a href="#tab0" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab11&#39;,&#39;document.tab11&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2Frt_F02.gif" name="tab11" border="0"></a></td>
					  <td background="./js/Tabs1Fnd_F01.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F01.gif" border="0"></td>
					  <td background="./js/Tabs1Fnd_F01.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#0000A0"><b><a href="#tab1" class="TabOnL">&nbsp;<!--#t-->objetivos profissionais<!--/#--></a></b></font></td>
					  <td background="./js/Tabs2Fnd_F01.gif" align="right" valign="top" width="18" height="35"><img src="./js/Tabs2Frt_F01.gif" border="0"></td>
					  
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F02.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab2" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab12&#39;,&#39;document.tab12&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->hist�rico profissional<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="18" height="35"><a href="#tab2" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab12&#39;,&#39;document.tab12&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2Frt_F02.gif" name="tab12" border="0"></a></td>
					  
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F02.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab3" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab13&#39;,&#39;document.tab13&#39;,&#39;img/tab/Tabs2UltFrt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->forma��o<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="20" height="35"><a href="#tab3" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab13&#39;,&#39;document.tab13&#39;,&#39;img/tab/Tabs2UltFrt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2UltFrt_F02.gif" name="tab13" border="0"></a></td>
					  
					  <td background="./js/TabVazioFnd.gif" width="100%" align="center"><font face="Verdana, Arial" size="1">&nbsp;</font></td>
				     </tr>
					 <tr>
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100%"><font face="Verdana, Arial" size="1"></font></td>
				     </tr>
					</tbody></table>
				  </td>
                </tr>
              </tbody></table>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/TabLatBack.gif" colspan="2" width="20%" valign="top">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td valign="middle" colspan="3" width="80%"><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#400-->Informe 
              seu objetivo profissional<!--/#--></b></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq"></td>
			
            <td bgcolor="#3064C8" id="LtC" valign="top" rowspan="5" width="18%"><font size="1" face="Verdana, Arial" color="#FFFFFF" id="LtTn"> 
              <b><!--#410-->Informe com clareza o cargo ou coloca��o almejada. 
              Por exemplo, <i>Analista de Cargos e Sal�rios</i><!--/#-->.<br>
              <br>
			  
              <!--#425-->A seguir, classifique-o em uma ou mais combina��es 
              de n�vel e �rea para facilitar a sua triagem pelas empresas.<!--/#-->
			  
			  </b></font></td>
			
          </tr>
          <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
            <td colspan="2" width="75%"> 
              <input type="text" name="Objetivo_cand" size="48" maxlength="255" value="" onkeyup="SetSav(&#39;SavCand&#39;);SetSav(&#39;SavTxtChave&#39;)" class="iptsml">
              <sup>*</sup></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%" valign="bottom">&nbsp;</td>
          </tr>
		  
		  <tr>
            <td valign="middle" colspan="3" width="80%"><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#430-->Classifica��es do seu objetivo profissional<!--/#--></b></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%" valign="bottom">&nbsp;</td>
			
		  </tr>
          <tr> 
            <td valign="middle">&nbsp;</td>
            <td colspan="2" valign="top"><font face="Verdana, Arial" size="1" id="PrTn"><!--#431-->Classifique o seu objetivo profissional, descrito acima, em uma ou mais combina��es de n�veis e �reas.
			  <b>N�O</b> coloque aqui o seu hist�rico profissional, mas apenas os n�veis e �reas associados ao seu <b>objetivo atual</b>.<!--/#--></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%" valign="bottom">&nbsp;</td>
		  </tr>
          <tr> 
            <td valign="middle">&nbsp;</td>
            <td colspan="2"> 
	         <table cellpadding="0" cellspacing="0" border="0" width="99%%">

	        <tbody><tr><td valign="top">
	         <table cellpadding="0" cellspacing="0" border="0" width="100%%">
		         <tbody><tr><td valign="top">
		           <table cellpadding="0" cellspacing="0" border="0" width="100%">
        		    <tbody><tr> 
			  			<td valign="center"><font face="Verdana, Arial" size="1" id="PrTn"><br><!--#432-->N�vel<!--/#-->&nbsp;<select name="CodHierarquia" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onchange="SetSav(&#39;SavCandCargos&#39;);" onfocus="checkSelect2(&#39;CodHierarquia&#39;,0,5)"><option value="-1"> </option></select><sup>*</sup>&nbsp;&nbsp;<!--#434-->�rea<!--/#-->&nbsp;<select name="CodSetor" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onchange="SetSav(&#39;SavCandCargos&#39;);" onfocus="checkSelect2(&#39;CodSetor&#39;,0,6)"><option value="-1"> </option></select><sup>*</sup></font></td>
					</tr>
	              </tbody></table>
				</td></tr>
			 </tbody></table>		
	        </td></tr>

	        <tr><td valign="top">
	         <table cellpadding="0" cellspacing="0" border="0" width="100%%">
		         <tbody><tr><td valign="top">
		           <table cellpadding="0" cellspacing="0" border="0" width="100%">
        		    <tbody><tr> 
			  			<td valign="center"><font face="Verdana, Arial" size="1" id="PrTn"><br><!--#432-->N�vel<!--/#-->&nbsp;<select name="CodHierarquia" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onchange="SetSav(&#39;SavCandCargos&#39;);" onfocus="checkSelect2(&#39;CodHierarquia&#39;,1,7)"><option value="-1"> </option></select>&nbsp;&nbsp;&nbsp;<!--#434-->�rea<!--/#-->&nbsp;<select name="CodSetor" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onchange="SetSav(&#39;SavCandCargos&#39;);" onfocus="checkSelect2(&#39;CodSetor&#39;,1,8)"><option value="-1"> </option></select></font></td>
					</tr>
	              </tbody></table>
				</td></tr>
			 </tbody></table>		
	        </td></tr>

	        <tr><td valign="top">
	         <table cellpadding="0" cellspacing="0" border="0" width="100%%">
		         <tbody><tr><td valign="top">
		           <table cellpadding="0" cellspacing="0" border="0" width="100%">
        		    <tbody><tr> 
			  			<td valign="center"><font face="Verdana, Arial" size="1" id="PrTn"><br><!--#432-->N�vel<!--/#-->&nbsp;<select name="CodHierarquia" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onchange="SetSav(&#39;SavCandCargos&#39;);" onfocus="checkSelect2(&#39;CodHierarquia&#39;,2,9)"><option value="-1"> </option></select>&nbsp;&nbsp;&nbsp;<!--#434-->�rea<!--/#-->&nbsp;<select name="CodSetor" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onchange="SetSav(&#39;SavCandCargos&#39;);" onfocus="checkSelect2(&#39;CodSetor&#39;,2,10)"><option value="-1"> </option></select></font></td>
					</tr>
	              </tbody></table>
				</td></tr>
			 </tbody></table>		
	        </td></tr>

	        <tr><td valign="top">
	         <table cellpadding="0" cellspacing="0" border="0" width="100%%">
		         <tbody><tr><td valign="top">
		           <table cellpadding="0" cellspacing="0" border="0" width="100%">
        		    <tbody><tr> 
			  			<td valign="center"><font face="Verdana, Arial" size="1" id="PrTn"><br><!--#432-->N�vel<!--/#-->&nbsp;<select name="CodHierarquia" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onchange="SetSav(&#39;SavCandCargos&#39;);" onfocus="checkSelect2(&#39;CodHierarquia&#39;,3,11)"><option value="-1"> </option></select>&nbsp;&nbsp;&nbsp;<!--#434-->�rea<!--/#-->&nbsp;<select name="CodSetor" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onchange="SetSav(&#39;SavCandCargos&#39;);" onfocus="checkSelect2(&#39;CodSetor&#39;,3,12)"><option value="-1"> </option></select></font></td>
					</tr>
	              </tbody></table>
				</td></tr>
			 </tbody></table>		
	        </td></tr>

	        <tr><td valign="top">
	         <table cellpadding="0" cellspacing="0" border="0" width="100%%">
		         <tbody><tr><td valign="top">
		           <table cellpadding="0" cellspacing="0" border="0" width="100%">
        		    <tbody><tr> 
			  			<td valign="center"><font face="Verdana, Arial" size="1" id="PrTn"><br><!--#432-->N�vel<!--/#-->&nbsp;<select name="CodHierarquia" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onchange="SetSav(&#39;SavCandCargos&#39;);" onfocus="checkSelect2(&#39;CodHierarquia&#39;,4,13)"><option value="-1"> </option></select>&nbsp;&nbsp;&nbsp;<!--#434-->�rea<!--/#-->&nbsp;<select name="CodSetor" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onchange="SetSav(&#39;SavCandCargos&#39;);" onfocus="checkSelect2(&#39;CodSetor&#39;,4,14)"><option value="-1"> </option></select></font></td>
					</tr>
	              </tbody></table>
				</td></tr>
			 </tbody></table>		
	        </td></tr>
	
            </tbody></table>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%" valign="bottom"><img src="./js/DestaqLat-Quebra.gif" name="Quebra"></td>
          </tr>
			
          <tr> 
            <td valign="middle">&nbsp;</td>
            <td valign="middle" colspan="2">
               <input type="checkbox" name="MonitoraObjetivo_cand" value="ON" checked="" onclick="SetSav(&#39;SavCand&#39;)">
			   
               <font face="Verdana, Arial" size="2" id="PrTn"><!--#440-->Desejo receber alerta de vagas compat�veis com meu objetivo profissional.<!--/#--></font></td>
			   
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%" valign="middle"><img src="./js/DestaqLat-Seta.gif"></td>
            <td bgcolor="#3064C8" id="LtC" width="18%" rowspan="2"><font size="1" face="Verdana, Arial" color="#FFFFFF" id="LtTn"> 
             <b><!--#450-->Voc� receber� e-mails do SEMTRE sempre que forem abertas novas
			 vagas compat�veis com o seu objetivo profissional.<!--/#-->
			 </b></font></td>
          </tr>
          <tr> 
            <td valign="middle" colspan="3">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%" valign="bottom"><img src="./js/DestaqLat-Quebra.gif"></td>
          </tr>
			
          <tr> 
            <td valign="middle" colspan="3"><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#460-->Descreva 
              o seu perfil profissional<!--/#--></b></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq"></td>
            <td bgcolor="#3064C8" id="LtC" valign="top" rowspan="2" width="18%"><font size="1" face="Verdana, Arial" color="#FFFFFF" id="LtTn"> 
              <b><!--#470-->Fa�a um resumo de suas qualifica��es, habilidades 
              e realiza��es profissionais. <font color="#FFFF00" id="LtTd">Lembre-se 
              que o seu hist�rico ser� detalhado adiante</font>.<!--/#--><br>
              <br>
              <!--#480-->Escreva "texto corrido", do tamanho que julgar adequado. 
              Para mudar de linha, pressione Enter. Para abrir um t�pico, 
              inicie uma nova linha com um ponto.<!--/#--></b></font></td>
          </tr>
          <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
            <td colspan="2"> 
              <textarea wrap="physical" name="Perfil_cand" rows="10" cols="48" onkeyup="SetSav(&#39;SavCand&#39;);SetSav(&#39;SavTxtChave&#39;)"></textarea>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td valign="middle" colspan="3"><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#490-->Outros 
              objetivos<!--/#--></b></font></td>
            <td valign="middle" bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" valign="top" width="18%">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td valign="middle">&nbsp;</td>
            <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#500-->Pretens�o salarial<!--/#--> <font size="1"><!--#-->(valor mensal)<!--/#--></font></font></td>
            <td> 
              <select name="CodMoeSalPret_cand" size="1" style="font-size: 8pt; font-family: verdana;" onchange="SetSav(&#39;SavCand&#39;)">

                <option value="18">Bol�var venezolano&nbsp;-&nbsp;Bs</option>

                <option value="4">Boliviano&nbsp;-&nbsp;$b</option>

                <option value="7">Col�n costarricense&nbsp;-&nbsp;$</option>

                <option value="13">Cordoba Oro&nbsp;-&nbsp;C$</option>

                <option value="2">D�lar&nbsp;-&nbsp;US$</option>

                <option value="19">Euro&nbsp;-&nbsp;�</option>

                <option value="10">Gourde&nbsp;-&nbsp;$</option>

                <option value="14">Guaran�&nbsp;-&nbsp;$</option>

                <option value="11">Lempira&nbsp;-&nbsp;$</option>

                <option value="15">Nuevo sol&nbsp;-&nbsp;$</option>

                <option value="3">Peso argentino&nbsp;-&nbsp;$</option>

                <option value="5">Peso chileno&nbsp;-&nbsp;$</option>

                <option value="6">Peso colombiano&nbsp;-&nbsp;$</option>

                <option value="8">Peso cubano&nbsp;-&nbsp;$</option>

                <option value="16">Peso dominicano&nbsp;-&nbsp;$</option>

                <option value="12">Peso mexicano&nbsp;-&nbsp;$</option>

                <option value="17">Peso uruguayo&nbsp;-&nbsp;$U</option>

                <option value="9">Quetzal&nbsp;-&nbsp;Q</option>

                <option selected="" value="1">Real&nbsp;-&nbsp;R$</option>

              </select>
              <input type="text" size="10" maxlength="10" name="ValSalPret_cand" value="" onkeyup="SetSav(&#39;SavCand&#39;)" class="iptsml">
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%" valign="top"><img src="./js/DestaqLat-Seta.gif"></td>
            <td bgcolor="#3064C8" id="LtC" valign="top" width="18%"><font size="1" face="Verdana, Arial" color="#FFFFFF" id="LtTn"> 
             <b><!--#-->Forne�a o valor no formato 999999,99. Ex: <i>1500,00</i><!--/#-->
			 </b></font></td>
          </tr>
		  
          <tr> 
            <td align="center" valign="middle" width="5%">&nbsp;</td>
            <td align="left" valign="middle" width="35%"><font face="Verdana, Arial" size="2" id="PrTn"><!--#510-->Regi�o 
              de interesse<!--/#--><sup>*</sup></font></td>
            <td align="left" valign="middle" width="40%">&nbsp; </td>
            <td width="2%" align="left" valign="middle" bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif"><img src="./js/DestaqLat-Seta.gif" width="13" height="10" name="destaq04"></td>
            <td width="18%" bgcolor="#3064C8" id="LtC" align="left" valign="top" rowspan="3"><font size="1" face="Verdana, Arial" color="#FFFF00" id="LtTd"><b><!--#520-->Para 
              escolher outra cidade de refer�ncia, clique<!--/#-->
			  
			  <a href="http://site.SEMTRE/CadCand-Submit.asp" onclick="cidadeRefMapa(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botSelRegiao&#39;,&#39;document.botSelRegiao&#39;,&#39;img/cust/pdncand2/regioes_F02.gif&#39;,&#39;#931615501830&#39;)">
			  
			  <img src="./js/regioes_F01.gif" align="top" border="0" name="botSelRegiao"></a></b></font></td>
          </tr>
          <tr> 
            <td align="center" valign="middle" width="5%">&nbsp;</td>
            <td align="right" width="35%"> 
              <select name="Raio_regCand" style="font-size: 8pt; font-family: verdana;" onchange="SetSav(&#39;SavRegioes&#39;)" onblur="MM_swapImage(&#39;document.formPag.destaq04&#39;,&#39;document.destaq04&#39;,&#39;img/cust/pdncand2/DestaqLat-Seta.gif&#39;,&#39;#930411429910&#39;)" onfocus="MM_swapImage(&#39;document.formPag.destaq04&#39;,&#39;document.destaq04&#39;,&#39;img/cust/pdncand2/DestaqLat-SetaPisc.gif&#39;,&#39;#930411354670&#39;)">
                <option value="100"><!--#530-->Na cidade de<!--/#--></option>
                <option selected="" value="250"><!--#540-->Cidades no raio de 25 km de<!--/#--> </option>
                <option value="500"><!--#550-->Cidades no raio de 50 km de<!--/#--> </option>
                <option value="750"><!--#560-->Cidades no raio de 75 km de<!--/#--> </option>
                <option value="1000"><!--#570-->Cidades no raio de 100 km de<!--/#--> </option>
                <option value="1250"><!--#580-->Cidades no raio de 125 km de<!--/#--> </option>
                <option value="1500"><!--#590-->Cidades no raio de 150 km de<!--/#--> </option>
                <!--option  value="-1">Cidades de todo Brasil</option-->
              </select>
            </td>
            <td align="left" width="40%"> 
              <select name="Local_regCand" style="font-size: 8pt; font-family: verdana;" onchange="SetSav(&#39;SavRegioes&#39;)" onblur="MM_swapImage(&#39;document.formPag.destaq04&#39;,&#39;document.destaq04&#39;,&#39;img/cust/pdncand2/DestaqLat-Seta.gif&#39;,&#39;#930411429910&#39;)" onfocus="MM_swapImage(&#39;document.formPag.destaq04&#39;,&#39;document.destaq04&#39;,&#39;img/cust/pdncand2/DestaqLat-SetaPisc.gif&#39;,&#39;#930411354670&#39;)">
                <option selected="" value="0,0"><!--#600-->meu endere�o<!--/#--></option>
				
              </select>
            </td>
            <td width="2%" align="left" valign="middle" bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
			<td colspan="2">
			  <table>
				  
			         <tbody><tr><td><font size="2" face="Verdana, Arial" id="PrTn"><!--#610-->Consideraria trabalhar em outra cidade?<!--/#--><sup>*</sup></font></td>
			            <td> <font face="Verdana, Arial" size="2" id="PrTn"> 
            			  <input type="radio" name="DispMudEnd_cand" value="True" checked="" onclick="SetSav(&#39;SavCand&#39;)">
			              <!--#612-->Sim<!--/#--> 
			              <input type="radio" name="DispMudEnd_cand" value="False" onclick="SetSav(&#39;SavCand&#39;)">
			              <!--#614-->N�o<!--/#--></font></td></tr><tr>
				  
					 </tr><tr><td><font size="2" face="Verdana, Arial" id="PrTn"><!--#620-->Aceitaria viajar pela empresa?<!--/#--><sup>*</sup></font></td>
			            <td> <font face="Verdana, Arial" size="2" id="PrTn"> 
			              <input type="radio" name="DispViagens_cand" value="True" checked="" onclick="SetSav(&#39;SavCand&#39;)">
			              <!--#622-->Sim<!--/#--> 
			              <input type="radio" name="DispViagens_cand" value="False" onclick="SetSav(&#39;SavCand&#39;)">
			              <!--#624-->N�o<!--/#--></font></td></tr>
				  
			  </tbody></table>
			</td>
			
            <td valign="middle" bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
			
          </tr>
		  
          <tr> 
            <td valign="middle" colspan="3"><b><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN">&nbsp;&nbsp;&nbsp;<!--#630-->Informa��es 
              complementares<!--/#--></font></b></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq"></td>
            <td bgcolor="#3064C8" id="LtC" valign="top" rowspan="2" width="18%"><font size="1" face="Verdana, Arial" color="#FFFFFF" id="LtTn"> 
              <b><!--#640-->Texto livre para voc� complementar seu curr�culo. 
              Voc� pode mencionar, por exemplo, certificados relevantes 
              em sua profiss�o, outras atividades e interesses, etc.<!--/#--></b></font></td>
          </tr>
          <tr> 
            <td valign="middle">&nbsp;</td>
            <td colspan="2"> 
              <textarea wrap="physical" name="InfoCompl_cand" rows="8" cols="48" onkeyup="SetSav(&#39;SavCand&#39;);SetSav(&#39;SavTxtChave&#39;)"></textarea>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td valign="middle" colspan="3" width="80%">&nbsp;</td>
            <td valign="middle" bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" valign="top" width="18%"><a href="#" onclick="showcv(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botVisualiza2&#39;,&#39;document.botVisualiza2&#39;,&#39;img/cust/pdncand2/visualiza_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/visualiza_F01.gif" alt="Curr�culo formatado" name="botVisualiza2"></a><a href="#" onclick="showcvconf(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botConfidencial2&#39;,&#39;document.botConfidencial2&#39;,&#39;img/cust/pdncand2/confidencial_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/confidencial_F01.gif" alt="Curr�culo em formato confidencial" name="botConfidencial2"></a><a href="http://site.SEMTRE/CadCand-Submit.asp" onclick="submitFormChk(&#39;Confirma&#39;); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.Image4&#39;,&#39;document.Image4&#39;,&#39;img/cust/pdncand2/confirma_F02.gif&#39;,&#39;#923339814720&#39;)"><img border="0" src="./js/confirma_F01.gif" alt="Confirma" name="Image4"></a><a href="http://site.SEMTRE/CadCand-Desiste.asp" onclick="javascript:desiste();return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.Image11&#39;,&#39;document.Image11&#39;,&#39;img/cust/pdncand2/desiste_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/desiste_F01.gif" alt="Desiste" name="Image11"></a></td>
          </tr>
	  </tbody></table>
	</td>
  </tr>
</tbody></table>		  

<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" bgcolor="#99CCFF" id="PrC">
  <tbody><tr bgcolor="#3064C8" id="LtC"> 
    <td valign="top" width="100%" height="50%"> 
      <table border="0" cellspacing="0" cellpadding="0" align="center" width="100%" bgcolor="#99CCFF" id="PrC">
          <tbody><tr height="50"> 
            <td align="left" valign="top" colspan="3" width="80%"><a name="tab2"></a> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody><tr valign="top" align="left"> 
                  <td>
	                <table width="100%" border="0" cellspacing="0" cellpadding="0">
					 <tbody><tr>
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100%"><img src="./js/TabTopoFrt.gif" border="0"></td>
				     </tr>
					 <tr>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F03.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab0" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab20&#39;,&#39;document.tab20&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->dados pessoais<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="18" height="35"><a href="#tab0" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab21&#39;,&#39;document.tab21&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2Frt_F02.gif" name="tab20" border="0"></a></td>
					  
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F02.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab1" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab21&#39;,&#39;document.tab21&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->objetivos profissionais<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="18" height="35"><a href="#tab1" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab21&#39;,&#39;document.tab21&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2Frt_F02.gif" name="tab21" border="0"></a></td>
					  
					  <td background="./js/Tabs1Fnd_F01.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F01.gif" border="0"></td>
					  <td background="./js/Tabs1Fnd_F01.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#0000A0"><b><a href="#tab2" class="TabOnL">&nbsp;<!--#t-->hist�rico profissional<!--/#--></a></b></font></td>
					  <td background="./js/Tabs2Fnd_F01.gif" align="right" valign="top" width="18" height="35"><img src="./js/Tabs2Frt_F01.gif" border="0"></td>
					  
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F02.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab3" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab23&#39;,&#39;document.tab23&#39;,&#39;img/tab/Tabs2UltFrt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->forma��o<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="20" height="35"><a href="#tab3" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab23&#39;,&#39;document.tab23&#39;,&#39;img/tab/Tabs2UltFrt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2UltFrt_F02.gif" name="tab23" border="0"></a></td>
					  
					  <td background="./js/TabVazioFnd.gif" width="100%" align="center"><font face="Verdana, Arial" size="1">&nbsp;</font></td>
				     </tr>
					 <tr>
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100%"><font face="Verdana, Arial" size="1"></font></td>
				     </tr>
					</tbody></table>
				  </td>
                </tr>
              </tbody></table>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/TabLatBack.gif" colspan="2" width="20%" valign="top">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td valign="middle" colspan="3" width="80%"><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#700-->Informe o seu �ltimo sal�rio<!--/#--></b></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq"></td>
            <td bgcolor="#3064C8" id="LtC" valign="top" rowspan="6" width="18%"><font size="1" face="Verdana, Arial" color="#FFFFFF" id="LtTn"><b><font color="#FFFF00" id="LtTd"><!--#710-->No 
              valor do �ltimo sal�rio inclua eventuais b�nus e comiss�es.<!--/#--></font><br>
			  <!--#-->Forne�a o valor no formato 999999,99. Ex: <i>1500,00</i><!--/#--><br><br>
              <!--#720-->Informe outros benef�cios n�o monet�rios no campo benef�cios.<!--/#-->
			</b></font></td>
          </tr>
          <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
            <td colspan="2" valign="top"><font face="Verdana, Arial" size="2" id="PrTn"><!--#500-->�ltimo sal�rio <font size="1">(valor mensal)</font><!--/#-->
              &nbsp;&nbsp;&nbsp;<select name="CodMoeUltSal_cand" size="1" style="font-size: 8pt; font-family: verdana;" onchange="SetSav(&#39;SavCand&#39;)">

                <option value="18">Bol�var venezolano&nbsp;-&nbsp;Bs</option>

                <option value="4">Boliviano&nbsp;-&nbsp;$b</option>

                <option value="7">Col�n costarricense&nbsp;-&nbsp;$</option>

                <option value="13">Cordoba Oro&nbsp;-&nbsp;C$</option>

                <option value="2">D�lar&nbsp;-&nbsp;US$</option>

                <option value="19">Euro&nbsp;-&nbsp;�</option>

                <option value="10">Gourde&nbsp;-&nbsp;$</option>

                <option value="14">Guaran�&nbsp;-&nbsp;$</option>

                <option value="11">Lempira&nbsp;-&nbsp;$</option>

                <option value="15">Nuevo sol&nbsp;-&nbsp;$</option>

                <option value="3">Peso argentino&nbsp;-&nbsp;$</option>

                <option value="5">Peso chileno&nbsp;-&nbsp;$</option>

                <option value="6">Peso colombiano&nbsp;-&nbsp;$</option>

                <option value="8">Peso cubano&nbsp;-&nbsp;$</option>

                <option value="16">Peso dominicano&nbsp;-&nbsp;$</option>

                <option value="12">Peso mexicano&nbsp;-&nbsp;$</option>

                <option value="17">Peso uruguayo&nbsp;-&nbsp;$U</option>

                <option value="9">Quetzal&nbsp;-&nbsp;Q</option>

                <option selected="" value="1">Real&nbsp;-&nbsp;R$</option>

              </select>
              <input type="text" size="10" maxlength="10" name="UltSal_cand" value="" onkeyup="SetSav(&#39;SavCand&#39;)" class="iptsml">
			  <font size="1">&nbsp;<!--#505-->(inclua eventuais b�nus e comiss�es)<!--/#--></font></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
          </tr>
          <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
            <td valign="middle" colspan="2"><font face="Verdana, Arial" size="2" id="PrTn"><!--#500-->Data&nbsp;de&nbsp;refer�ncia<!--/#--></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
          </tr>
          <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
            <td valign="middle" colspan="2"><table border="0" cellspacing="0" cellpadding="0"><tbody><tr><td width="5%">&nbsp;</td><td><font face="Verdana, Arial" size="2" id="PrTn">
              <input type="radio" name="UltSalAtualCand" value="True" checked="" onclick="SetSav(&#39;SavCand&#39;);document.formPag.MesUltSalCand.selectedIndex=0;document.formPag.AnoUltSalCand.value=&#39;&#39;;"><!--#-->Atual<!--/#--><br>
              <input type="radio" name="UltSalAtualCand" value="False" onclick="SetSav(&#39;SavCand&#39;);"><!--#-->Em<!--/#-->
				    <select name="MesUltSalCand" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavCand&#39;); checkSelect2(&#39;MesUltSalCand&#39;,-1,15);" onchange="if (document.formPag.MesUltSalCand.selectedIndex != 0) {document.formPag.UltSalAtualCand[1].checked = true;}">
			<option value="-1">Selecione uma op��o</option><option value="1">Janeiro</option><option value="2">Fevereiro</option><option value="3">Mar�o</option><option value="4">Abril</option><option value="5">Maio</option><option value="6">Junho</option><option value="7">Julho</option><option value="8">Agosto</option><option value="9">Setembro</option><option value="10">Outubro</option><option value="11">Novembro</option><option value="12">Dezembro</option></select><!--#-->de<!--/#-->
				    <input type="text" size="4" maxlength="4" name="AnoUltSalCand" value="" onkeyup="SetSav(&#39;SavCand&#39;)" class="iptsml"> <font size="1">(<!--#-->ano<!--/#-->)</font>
			</font></td></tr></tbody></table></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
          </tr>
          <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
            <td valign="top" colspan="2"><font face="Verdana, Arial" size="2" id="PrTn"><!--#500-->Outros benef�cios
			<br><font size="1">Informe aqui outros benef�cios n�o monet�rios que recebe ou recebia, como vale refei��o,
			vale transporte, etc.</font>
			<!--/#--></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
          </tr>
          <tr> 
            <td valign="middle" width="5%">&nbsp;</td>
            <td valign="middle" colspan="2"><table border="0" cellspacing="0" cellpadding="0"><tbody><tr><td width="5%">&nbsp;</td><td><font face="Verdana, Arial" size="2" id="PrTn">
               <textarea name="UltBeneficios_cand" rows="6" cols="50" wrap="PHYSICAL" onkeyup="SetSav(&#39;SavCand&#39;)"></textarea>
			</font></td></tr></tbody></table></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" valign="bottom" width="2%"><img src="./js/DestaqLat-Quebra.gif" name="Quebra"></td>
          </tr>
		  
          <tr> 
            <td valign="middle" colspan="3" width="80%"><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#700-->Descreva 
              a sua trajet�ria profissional<!--/#--></b></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq"></td>
            <td bgcolor="#3064C8" id="LtC" valign="top" rowspan="5" width="18%"><font size="1" face="Verdana, Arial" color="#FFFFFF" id="LtTn"><font color="#FFFF00" id="LtTd"><b><!--#710-->N�o 
              se preocupe com a ordem das experi�ncias.<!--/#--><br>
              </b></font><b><!--#720-->Elas ser�o automaticamente colocadas em ordem 
              cronol�gica inversa.<!--/#--><br>
              <br>
              <!--#730-->Descreva tantas experi�ncias quantas julgar relevantes. Caso 
              j� tenha usado todas as entradas, <a href="http://site.SEMTRE/CadCand-Submit.asp" onclick="submitFormSav(&#39;CadCand-Reload.asp&#39;); return false;" class="LtL">clique 
              aqui</a> para abrir mais algumas.<!--/#--><br>
              <br>
			  
              <!--#740--><font color="#FFFF00" id="LtTd">
			  Empresa</font>: informa��o apresentada 
              apenas no curr�culo normal. No confidencial apresenta-se 
              apenas o segmento da empresa. N�o preencha se quiser mant�-la 
              inc�gnita em ambos os formatos, ou em caso de <font color="#FFFF00" id="LtTd">atividade 
              aut�noma</font>.<!--/#-->
			  
			  <br><br>
              <!--#747--><font color="#FFFF00" id="LtTd">Nacionalidade</font>: informe o(s) pa�s(es) de origem.<!--/#--><br>
			  <br>
              <!--#750--><font color="#FFFF00" id="LtTd">Segmento</font>: �rea de atua��o 
              da empresa.<!--/#--><br>
              <br>
              <!--#760--><font color="#FFFF00" id="LtTd">Porte</font>: observe que aqui voc� 
              informa eventuais atividades aut�nomas.<!--/#--><br>
              <br>
              <!--#770--><font color="#FFFF00" id="LtTd">In�cio/T�rmino</font>: m�s/ano. 
              Se for o seu emprego atual, deixe T�rmino em branco.<!--/#--><br>
              <br>
              <!--#780--><font color="#FFFF00" id="LtTd">�ltimo Cargo</font>: informe o �ltimo cargo 
              ocupado na empresa. Se desejar informar outros, fa�a-o na 
              descri��o.<!--/#--><br>
              <br>
              <!--#790--><font color="#FFFF00" id="LtTd">Descri��o</font>: texto livre 
              para que voc� descreva a experi�ncia em detalhe. Use 
              "texto corrido", do tamanho que julgar adequado. Para 
              mudar de linha, pressione Enter. Para abrir um t�pico, inicie 
              uma nova linha com um ponto.<!--/#--><br>
              <br>
              <!--#795--><font color="#FFFF00" id="LtTd">Classifica��o</font>: Classifique at� 3 principais ocupa��es 
			  que exerceu ou exerce atualmente na empresa. Para cada uma delas informe o ano em que iniciou e encerrou a ocupa��o
			  (se ainda a estiver exercendo n�o preencha <i>Ano final</i>).<!--/#--><br>
              <br>
              <!--#800--><font color="#FFFF00" id="LtTd">Remover</font>: use para excluir a experi�ncia 
              do banco de dados.<!--/#--></b></font></td>
          </tr>

          <tr> 
            <!--td valign="middle" width="5%">&nbsp;</td-->
            <td colspan="3" width="80%"> 
			 <ul>
              <table cellpadding="1" cellspacing="0" width="80%">
                <tbody><tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><b><!--#805-->Empresa 1<!--/#--></b></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn"> 
                    <input type="text" size="32" maxlength="60" name="Empresa" value="" onkeyup="SetSav(&#39;SavExp&#39;)" class="iptsml">
					<a href="javascript:SetSav('SavExp');RemExp(1)" class="PrL"><font color="#FF0000" size="1" id="PrTl"><!--#810-->remover<!--/#--></font></a>
				  </font></td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#835-->Nacionalidade<!--/#--></font></td>
                  <td><table border="0" cellpadding="0" cellspacing="0"><tbody><tr><td><font face="Verdana, Arial" size="2" id="PrTn">
				    
				        <!--select name="TipoEmpExp" onChange="checkExpVisibility(1)" style="font-size: 8pt; font-family: verdana;" >
 		                 <option selected value="-1"> </option>
 	    	             <option  value="10">Nacional</option>
 	        	         <option  value="20">Multinacional</option>
                	    </select-->
				    <select name="TipoEmpExp" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;TipoEmpExp&#39;,0,16);">
					<option value="-1"> </option></select>
						</font></td>
					  <td><div name="NacionalidadeEmpExp1" id="NacionalidadeEmpExp1"><font face="Verdana, Arial" size="2" id="PrTn">&nbsp;&nbsp;<!--#-->Pa�s(es)<!--/#-->&nbsp;<input type="text" size="32" maxlength="60" name="NacionalidadeEmpExp" value="" onkeyup="SetSav(&#39;SavExp&#39;)" class="iptsml"></font></div></td>					  
					</tr></tbody></table></td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#820-->Segmento<!--/#--></font></td>
                  <td> 
				    
                    <select name="CodSegmento" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;CodSegmento&#39;,0,17)">
					<option value="-1"> </option></select>
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#830-->Porte<!--/#--></font></td>
                  <td> 
				    
                    <select name="CodPorte" style="font-size: 8pt; font-family: verdana; width: 200px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;CodPorte&#39;,0,18)">
					<option value="-1"> </option></select>
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#840-->In�cio<!--/#--></font></td>
                  <td> 
				    
				    <select name="MesInicio" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;MesInicio&#39;,0,19)">
					<option value="-1"> </option></select> /
                    <input type="text" size="4" maxlength="4" name="AnoInicio" onkeyup="SetSav(&#39;SavExp&#39;);" value="" class="iptsml">
                    - <font size="2" face="Verdana, Arial" id="PrTn"><!--#850-->T�rmino<!--/#--></font> 
					
				    <select name="MesFim" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;MesFim&#39;,0,20)">
					<option value="-1"> </option></select> /
                    <input type="text" size="4" maxlength="4" name="AnoFim" value="" onkeyup="SetSav(&#39;SavExp&#39;);" class="iptsml">
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#860-->�ltimo Cargo<!--/#--></font></td>
                  <td> 
				    <input type="text" maxlength="60" size="46" name="UltimoCargo" value="" onkeyup="SetSav(&#39;SavExp&#39;);SetSav(&#39;SavTxtChave&#39;)" class="iptsml">
                  </td>
                </tr>
                <tr> 
                  <td valign="top"><font face="Verdana, Arial" size="2" id="PrTn"><!--#870-->Descri��o<!--/#--></font><br>
                  </td>
                  <td> 
                    <textarea name="Descricao" rows="6" cols="45" onkeyup="SetSav(&#39;SavExp&#39;);SetSav(&#39;SavTxtChave&#39;)" wrap="PHYSICAL"></textarea>
                  </td>
                </tr>
                <tr> 
                  <td valign="top" colspan="2"><font face="Verdana, Arial" size="2" id="PrTn"><!--#875-->Classifique suas 3 principais ocupa��es na empresa:<!--/#--></font></td>
                </tr>
                <tr> 
                  <td valign="top" colspan="2"><font face="Verdana, Arial" size="2" id="PrTn">
				    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
					  <tbody><tr><td><font face="Verdana, Arial" size="1" id="PrTn"><!--#-->N�vel<!--/#--></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;<!--#-->�rea<!--/#--></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn"><!--#-->Ano&nbsp;inicial<!--/#--></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;<!--#-->Ano&nbsp;final<!--/#--></font></td>
					  </tr>
					  <tr><td><font face="Verdana, Arial" size="1" id="PrTn">
					  
						<select name="CodHierarquiaExp1" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodHierarquiaExp1&#39;,0,21)"><option value="-1"> </option></select></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">
						  
						  <select name="CodSetorExp1" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodSetorExp1&#39;,0,22)"><option value="-1"> </option></select></font></td>
					      <td align="left"><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;&nbsp;<input type="text" name="AnoIniExp1" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					      <td align="center"><font face="Verdana, Arial" size="1" id="PrTn"><input type="text" name="AnoFimExp1" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					  </tr>
					  <tr><td><font face="Verdana, Arial" size="1" id="PrTn">
					  
						<select name="CodHierarquiaExp2" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodHierarquiaExp2&#39;,0,23)"><option value="-1"> </option></select></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">
						  
						  <select name="CodSetorExp2" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodSetorExp2&#39;,0,24)"><option value="-1"> </option></select></font></td>
					      <td align="left"><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;&nbsp;<input type="text" name="AnoIniExp2" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					      <td align="center"><font face="Verdana, Arial" size="1" id="PrTn"><input type="text" name="AnoFimExp2" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					  </tr>
					  <tr><td><font face="Verdana, Arial" size="1" id="PrTn">
					  
						<select name="CodHierarquiaExp3" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodHierarquiaExp3&#39;,0,25)"><option value="-1"> </option></select></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">
						  
						  <select name="CodSetorExp3" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodSetorExp3&#39;,0,26)"><option value="-1"> </option></select></font></td>
					      <td align="left"><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;&nbsp;<input type="text" name="AnoIniExp3" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					      <td align="center"><font face="Verdana, Arial" size="1" id="PrTn"><input type="text" name="AnoFimExp3" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					  </tr>
					</tbody></table>
				  </font>
                  </td>
                </tr>
              </tbody></table></ul>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
			
          </tr>
		  
          <tr> 
            <!--td valign="middle" width="5%">&nbsp;</td-->
            <td colspan="3" width="80%"> 
			 <ul>
              <table cellpadding="1" cellspacing="0" width="80%">
                <tbody><tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><b><!--#805-->Empresa 2<!--/#--></b></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn"> 
                    <input type="text" size="32" maxlength="60" name="Empresa" value="" onkeyup="SetSav(&#39;SavExp&#39;)" class="iptsml">
					<a href="javascript:SetSav('SavExp');RemExp(2)" class="PrL"><font color="#FF0000" size="1" id="PrTl"><!--#810-->remover<!--/#--></font></a>
				  </font></td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#835-->Nacionalidade<!--/#--></font></td>
                  <td><table border="0" cellpadding="0" cellspacing="0"><tbody><tr><td><font face="Verdana, Arial" size="2" id="PrTn">
				    
				        <!--select name="TipoEmpExp" onChange="checkExpVisibility(2)" style="font-size: 8pt; font-family: verdana;" >
 		                 <option selected value="-1"> </option>
 	    	             <option  value="10">Nacional</option>
 	        	         <option  value="20">Multinacional</option>
                	    </select-->
				    <select name="TipoEmpExp" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;TipoEmpExp&#39;,1,27);">
					<option value="-1"> </option></select>
						</font></td>
					  <td><div name="NacionalidadeEmpExp2" id="NacionalidadeEmpExp2"><font face="Verdana, Arial" size="2" id="PrTn">&nbsp;&nbsp;<!--#-->Pa�s(es)<!--/#-->&nbsp;<input type="text" size="32" maxlength="60" name="NacionalidadeEmpExp" value="" onkeyup="SetSav(&#39;SavExp&#39;)" class="iptsml"></font></div></td>					  
					</tr></tbody></table></td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#820-->Segmento<!--/#--></font></td>
                  <td> 
				    
                    <select name="CodSegmento" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;CodSegmento&#39;,1,28)">
					<option value="-1"> </option></select>
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#830-->Porte<!--/#--></font></td>
                  <td> 
				    
                    <select name="CodPorte" style="font-size: 8pt; font-family: verdana; width: 200px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;CodPorte&#39;,1,29)">
					<option value="-1"> </option></select>
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#840-->In�cio<!--/#--></font></td>
                  <td> 
				    
				    <select name="MesInicio" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;MesInicio&#39;,1,30)">
					<option value="-1"> </option></select> /
                    <input type="text" size="4" maxlength="4" name="AnoInicio" onkeyup="SetSav(&#39;SavExp&#39;);" value="" class="iptsml">
                    - <font size="2" face="Verdana, Arial" id="PrTn"><!--#850-->T�rmino<!--/#--></font> 
					
				    <select name="MesFim" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;MesFim&#39;,1,31)">
					<option value="-1"> </option></select> /
                    <input type="text" size="4" maxlength="4" name="AnoFim" value="" onkeyup="SetSav(&#39;SavExp&#39;);" class="iptsml">
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#860-->�ltimo Cargo<!--/#--></font></td>
                  <td> 
				    <input type="text" maxlength="60" size="46" name="UltimoCargo" value="" onkeyup="SetSav(&#39;SavExp&#39;);SetSav(&#39;SavTxtChave&#39;)" class="iptsml">
                  </td>
                </tr>
                <tr> 
                  <td valign="top"><font face="Verdana, Arial" size="2" id="PrTn"><!--#870-->Descri��o<!--/#--></font><br>
                  </td>
                  <td> 
                    <textarea name="Descricao" rows="6" cols="45" onkeyup="SetSav(&#39;SavExp&#39;);SetSav(&#39;SavTxtChave&#39;)" wrap="PHYSICAL"></textarea>
                  </td>
                </tr>
                <tr> 
                  <td valign="top" colspan="2"><font face="Verdana, Arial" size="2" id="PrTn"><!--#875-->Classifique suas 3 principais ocupa��es na empresa:<!--/#--></font></td>
                </tr>
                <tr> 
                  <td valign="top" colspan="2"><font face="Verdana, Arial" size="2" id="PrTn">
				    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
					  <tbody><tr><td><font face="Verdana, Arial" size="1" id="PrTn"><!--#-->N�vel<!--/#--></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;<!--#-->�rea<!--/#--></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn"><!--#-->Ano&nbsp;inicial<!--/#--></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;<!--#-->Ano&nbsp;final<!--/#--></font></td>
					  </tr>
					  <tr><td><font face="Verdana, Arial" size="1" id="PrTn">
					  
						<select name="CodHierarquiaExp1" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodHierarquiaExp1&#39;,1,32)"><option value="-1"> </option></select></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">
						  
						  <select name="CodSetorExp1" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodSetorExp1&#39;,1,33)"><option value="-1"> </option></select></font></td>
					      <td align="left"><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;&nbsp;<input type="text" name="AnoIniExp1" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					      <td align="center"><font face="Verdana, Arial" size="1" id="PrTn"><input type="text" name="AnoFimExp1" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					  </tr>
					  <tr><td><font face="Verdana, Arial" size="1" id="PrTn">
					  
						<select name="CodHierarquiaExp2" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodHierarquiaExp2&#39;,1,34)"><option value="-1"> </option></select></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">
						  
						  <select name="CodSetorExp2" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodSetorExp2&#39;,1,35)"><option value="-1"> </option></select></font></td>
					      <td align="left"><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;&nbsp;<input type="text" name="AnoIniExp2" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					      <td align="center"><font face="Verdana, Arial" size="1" id="PrTn"><input type="text" name="AnoFimExp2" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					  </tr>
					  <tr><td><font face="Verdana, Arial" size="1" id="PrTn">
					  
						<select name="CodHierarquiaExp3" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodHierarquiaExp3&#39;,1,36)"><option value="-1"> </option></select></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">
						  
						  <select name="CodSetorExp3" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodSetorExp3&#39;,1,37)"><option value="-1"> </option></select></font></td>
					      <td align="left"><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;&nbsp;<input type="text" name="AnoIniExp3" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					      <td align="center"><font face="Verdana, Arial" size="1" id="PrTn"><input type="text" name="AnoFimExp3" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					  </tr>
					</tbody></table>
				  </font>
                  </td>
                </tr>
              </tbody></table></ul>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
			
          </tr>
		  
          <tr> 
            <!--td valign="middle" width="5%">&nbsp;</td-->
            <td colspan="3" width="80%"> 
			 <ul>
              <table cellpadding="1" cellspacing="0" width="80%">
                <tbody><tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><b><!--#805-->Empresa 3<!--/#--></b></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn"> 
                    <input type="text" size="32" maxlength="60" name="Empresa" value="" onkeyup="SetSav(&#39;SavExp&#39;)" class="iptsml">
					<a href="javascript:SetSav('SavExp');RemExp(3)" class="PrL"><font color="#FF0000" size="1" id="PrTl"><!--#810-->remover<!--/#--></font></a>
				  </font></td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#835-->Nacionalidade<!--/#--></font></td>
                  <td><table border="0" cellpadding="0" cellspacing="0"><tbody><tr><td><font face="Verdana, Arial" size="2" id="PrTn">
				    
				        <!--select name="TipoEmpExp" onChange="checkExpVisibility(3)" style="font-size: 8pt; font-family: verdana;" >
 		                 <option selected value="-1"> </option>
 	    	             <option  value="10">Nacional</option>
 	        	         <option  value="20">Multinacional</option>
                	    </select-->
				    <select name="TipoEmpExp" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;TipoEmpExp&#39;,2,38);">
					<option value="-1"> </option></select>
						</font></td>
					  <td><div name="NacionalidadeEmpExp3" id="NacionalidadeEmpExp3"><font face="Verdana, Arial" size="2" id="PrTn">&nbsp;&nbsp;<!--#-->Pa�s(es)<!--/#-->&nbsp;<input type="text" size="32" maxlength="60" name="NacionalidadeEmpExp" value="" onkeyup="SetSav(&#39;SavExp&#39;)" class="iptsml"></font></div></td>					  
					</tr></tbody></table></td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#820-->Segmento<!--/#--></font></td>
                  <td> 
				    
                    <select name="CodSegmento" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;CodSegmento&#39;,2,39)">
					<option value="-1"> </option></select>
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#830-->Porte<!--/#--></font></td>
                  <td> 
				    
                    <select name="CodPorte" style="font-size: 8pt; font-family: verdana; width: 200px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;CodPorte&#39;,2,40)">
					<option value="-1"> </option></select>
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#840-->In�cio<!--/#--></font></td>
                  <td> 
				    
				    <select name="MesInicio" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;MesInicio&#39;,2,41)">
					<option value="-1"> </option></select> /
                    <input type="text" size="4" maxlength="4" name="AnoInicio" onkeyup="SetSav(&#39;SavExp&#39;);" value="" class="iptsml">
                    - <font size="2" face="Verdana, Arial" id="PrTn"><!--#850-->T�rmino<!--/#--></font> 
					
				    <select name="MesFim" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavExp&#39;); checkSelect2(&#39;MesFim&#39;,2,42)">
					<option value="-1"> </option></select> /
                    <input type="text" size="4" maxlength="4" name="AnoFim" value="" onkeyup="SetSav(&#39;SavExp&#39;);" class="iptsml">
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#860-->�ltimo Cargo<!--/#--></font></td>
                  <td> 
				    <input type="text" maxlength="60" size="46" name="UltimoCargo" value="" onkeyup="SetSav(&#39;SavExp&#39;);SetSav(&#39;SavTxtChave&#39;)" class="iptsml">
                  </td>
                </tr>
                <tr> 
                  <td valign="top"><font face="Verdana, Arial" size="2" id="PrTn"><!--#870-->Descri��o<!--/#--></font><br>
                  </td>
                  <td> 
                    <textarea name="Descricao" rows="6" cols="45" onkeyup="SetSav(&#39;SavExp&#39;);SetSav(&#39;SavTxtChave&#39;)" wrap="PHYSICAL"></textarea>
                  </td>
                </tr>
                <tr> 
                  <td valign="top" colspan="2"><font face="Verdana, Arial" size="2" id="PrTn"><!--#875-->Classifique suas 3 principais ocupa��es na empresa:<!--/#--></font></td>
                </tr>
                <tr> 
                  <td valign="top" colspan="2"><font face="Verdana, Arial" size="2" id="PrTn">
				    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
					  <tbody><tr><td><font face="Verdana, Arial" size="1" id="PrTn"><!--#-->N�vel<!--/#--></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;<!--#-->�rea<!--/#--></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn"><!--#-->Ano&nbsp;inicial<!--/#--></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;<!--#-->Ano&nbsp;final<!--/#--></font></td>
					  </tr>
					  <tr><td><font face="Verdana, Arial" size="1" id="PrTn">
					  
						<select name="CodHierarquiaExp1" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodHierarquiaExp1&#39;,2,43)"><option value="-1"> </option></select></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">
						  
						  <select name="CodSetorExp1" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodSetorExp1&#39;,2,44)"><option value="-1"> </option></select></font></td>
					      <td align="left"><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;&nbsp;<input type="text" name="AnoIniExp1" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					      <td align="center"><font face="Verdana, Arial" size="1" id="PrTn"><input type="text" name="AnoFimExp1" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					  </tr>
					  <tr><td><font face="Verdana, Arial" size="1" id="PrTn">
					  
						<select name="CodHierarquiaExp2" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodHierarquiaExp2&#39;,2,45)"><option value="-1"> </option></select></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">
						  
						  <select name="CodSetorExp2" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodSetorExp2&#39;,2,46)"><option value="-1"> </option></select></font></td>
					      <td align="left"><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;&nbsp;<input type="text" name="AnoIniExp2" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					      <td align="center"><font face="Verdana, Arial" size="1" id="PrTn"><input type="text" name="AnoFimExp2" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					  </tr>
					  <tr><td><font face="Verdana, Arial" size="1" id="PrTn">
					  
						<select name="CodHierarquiaExp3" size="1" style="font-size: 8pt; font-family: verdana; width: 180px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodHierarquiaExp3&#39;,2,47)"><option value="-1"> </option></select></font></td>
					      <td><font face="Verdana, Arial" size="1" id="PrTn">
						  
						  <select name="CodSetorExp3" size="1" style="font-size: 8pt; font-family: verdana; width: 300px" onfocus="SetSav(&#39;SavExpOcup&#39;); checkSelect2(&#39;CodSetorExp3&#39;,2,48)"><option value="-1"> </option></select></font></td>
					      <td align="left"><font face="Verdana, Arial" size="1" id="PrTn">&nbsp;&nbsp;<input type="text" name="AnoIniExp3" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					      <td align="center"><font face="Verdana, Arial" size="1" id="PrTn"><input type="text" name="AnoFimExp3" size="4" maxlength="4" value="" onkeyup="SetSav(&#39;SavExpOcup&#39;);" class="iptsml"></font></td>
					  </tr>
					</tbody></table>
				  </font>
                  </td>
                </tr>
              </tbody></table></ul>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%">&nbsp;</td>
			
          </tr>
		  
          <tr> 
            <td valign="middle" colspan="3" width="80%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%"><a href="#" onclick="showcv(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botVisualiza8&#39;,&#39;document.botVisualiza8&#39;,&#39;img/cust/pdncand2/visualiza_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/visualiza_F01.gif" alt="Curr�culo formatado" name="botVisualiza8"></a><a href="#" onclick="showcvconf(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botConfidencial8&#39;,&#39;document.botConfidencial8&#39;,&#39;img/cust/pdncand2/confidencial_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/confidencial_F01.gif" alt="Curr�culo em formato confidencial" name="botConfidencial8"></a><a href="http://site.SEMTRE/CadCand-Submit.asp" onclick="submitFormChk(&#39;Confirma&#39;); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.Image8&#39;,&#39;document.Image8&#39;,&#39;img/cust/pdncand2/confirma_F02.gif&#39;,&#39;#924576064410&#39;)"><img border="0" src="./js/confirma_F01.gif" alt="Confirma" name="Image8"></a><a href="http://site.SEMTRE/CadCand-Desiste.asp" onclick="javascript:desiste();return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.Image9&#39;,&#39;document.Image9&#39;,&#39;img/cust/pdncand2/desiste_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/desiste_F01.gif" alt="Desiste" name="Image9"></a></td>
          </tr>
	  </tbody></table>
	</td>
  </tr>
</tbody></table>		  

<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" bgcolor="#99CCFF" id="PrC">
  <tbody><tr bgcolor="#3064C8" id="LtC"> 
    <td valign="top" width="100%" height="50%"> 
      <table border="0" cellspacing="0" cellpadding="0" align="center" width="100%" bgcolor="#99CCFF" id="PrC">
          <tbody><tr height="50"> 
            <td align="left" valign="top" colspan="3" width="80%"><a name="tab3"></a> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tbody><tr valign="top" align="left"> 
                  <td>
	                <table width="100%" border="0" cellspacing="0" cellpadding="0">
					 <tbody><tr>
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100" height="5" colspan="3"><img src="./js/TabTopoFrt.gif" border="0"></td>
					  
					  <td align="center" bgcolor="#FFFFFF" width="100%"><img src="./js/TabTopoFrt.gif" border="0"></td>
				     </tr>
					 <tr>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F03.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab0" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab30&#39;,&#39;document.tab30&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->dados pessoais<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="18" height="35"><a href="#tab0" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab30&#39;,&#39;document.tab30&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2Frt_F02.gif" name="tab30" border="0"></a></td>
					  
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F02.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab1" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab31&#39;,&#39;document.tab31&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->objetivos profissionais<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="18" height="35"><a href="#tab1" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab31&#39;,&#39;document.tab31&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2Frt_F02.gif" name="tab31" border="0"></a></td>
					  
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F02.gif" border="0"></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs1Fnd_F02.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#99B1E6"><b><a href="#tab2" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab32&#39;,&#39;document.tab32&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)">&nbsp;<!--#t-->hist�rico profissional<!--/#--></a></b></font></td>
					  <td bgcolor="#3064C8" id="TabOffC" background="./js/Tabs2Fnd_F02.gif" align="right" valign="top" width="18" height="35"><a href="#tab2" class="TabOffL" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.tab32&#39;,&#39;document.tab32&#39;,&#39;img/tab/Tabs2Frt_F03.gif&#39;,&#39;#926083685250&#39;)"><img src="./js/Tabs2Frt_F02.gif" name="tab32" border="0"></a></td>
					  
					  <td background="./js/Tabs1Fnd_F01.gif" align="left" valign="top" width="4" height="35"><img src="./js/Tabs0Frt_F01.gif" border="0"></td>
					  <td background="./js/Tabs1Fnd_F01.gif" align="center" valign="middle" width="78" height="35"><font face="Verdana, Arial" size="1" color="#0000A0"><b><a href="#tab3" class="TabOnL">&nbsp;<!--#t-->forma��o<!--/#--></a></b></font></td>
					  <td background="./js/Tabs2Fnd_F01.gif" align="right" valign="top" width="18" height="35"><img src="./js/Tabs2Frt_F01.gif" border="0"></td>
					  
					  <td background="./js/TabVazioFnd.gif" width="100%" align="center"><font face="Verdana, Arial" size="1">&nbsp;</font></td>
				     </tr>
					 <tr>
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100" height="10" colspan="3"><img src="./js/TabBaseFrt.gif" border="0"></td>
					  
					  <td align="center" width="100%"><font face="Verdana, Arial" size="1"></font></td>
				     </tr>
					</tbody></table>
				  </td>
                </tr>
              </tbody></table>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/TabLatBack.gif" colspan="2" width="20%" valign="top">&nbsp;</td>
          </tr>
			
          <tr> 
            <td colspan="3"><font face="Verdana, Arial" size="2" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#900-->Informe 
              o seu n�vel de escolaridade<!--/#--><sup>*</sup></b></font></td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
          <tr> 
            <!--td valign="middle" width="5%">&nbsp;</td-->
            <td colspan="3" width="80%">
              <ul>
			  
			  <select name="CodFormMax_cand" size="1" style="font-size: 8pt; font-family: verdana; width: 350px" onfocus="SetSav(&#39;SavCand&#39;); checkSelect2(&#39;CodFormMax_cand&#39;,-1,49)">
			  <option value="-1"> </option></select></ul>
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%">&nbsp;</td>
          </tr>
		  
          <tr> 
            <td colspan="3"><font size="2" face="Verdana, Arial" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#910-->Preencha 
              com os idiomas em que tenha profici�ncia<!--/#--></b></font></td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" width="2%"><img src="./js/DestaqLat-Seta.gif" name="Destaq"></td>
            <td bgcolor="#3064C8" id="LtC" width="18%" rowspan="2" valign="top"><font size="1" color="#FFFFFF" id="LtTn" face="Verdana, Arial"><b> 
              <!--#920-->Informe tantos idiomas quantos julgar relevantes.  
              Caso j� tenha usado todas as entradas, <a href="http://site.SEMTRE/CadCand-Submit.asp" onclick="submitFormSav(&#39;CadCand-Reload.asp&#39;); return false;" class="LtL">clique 
              aqui</a> 
              para abrir mais algumas.<!--/#--></b></font></td>
          </tr>
          <tr> 
            <!--td>&nbsp;</td-->
            <td colspan="3"> 
			  <ul>
			  <table cellpadding="2" cellspacing="0" width="80%">
                <tbody><tr> 
                  <td><font size="2" face="Verdana, Arial" id="PrTn"><!--#922-->Idioma<!--/#--></font></td>
                  <td><font size="2" face="Verdana, Arial" id="PrTn"><!--#924-->Leitura<!--/#--></font></td>
                  <td><font size="2" face="Verdana, Arial" id="PrTn"><!--#926-->Escrita<!--/#--></font></td>
                  <td><font size="2" face="Verdana, Arial" id="PrTn"><!--#928-->Conversa��o<!--/#--></font></td>
                </tr>

			<tr>
			  <td>
			  
			    <select name="Idioma1" size="1" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Idioma1&#39;,-1,50)">
			  <option value="-1"> </option><option value="7">Ingl�s</option></select></td>
		   <td>
		     
		      <select name="Nleit1" size="1" style="font-size: 8pt; font-family: verdana; width: 120px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Nleit1&#39;,-1,51)">
			 <option value="1">(n�o tem)</option><option value="2">B�sica</option><option value="3">Intermedi�ria</option><option value="4">Avan�ada</option><option value="5">Fluente</option></select></td>
			<td>
			 
			  <select name="Nescr1" size="1" style="font-size: 8pt; font-family: verdana; width: 120px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Nescr1&#39;,-1,52)">
			 <option value="1">(n�o tem)</option><option value="2">B�sica</option><option value="3">Intermedi�ria</option><option value="4">Avan�ada</option><option value="5">Fluente</option></select></td>
			<td>
			  
			  <select name="Nconv1" size="1" style="font-size: 8pt; font-family: verdana; width: 120px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Nconv1&#39;,-1,53)">
			  <option value="1">(n�o tem)</option><option value="2">B�sica</option><option value="3">Intermedi�ria</option><option value="4">Avan�ada</option><option value="5">Fluente</option></select></td>
			</tr>

			<tr>
			  <td>
			  
			    <select name="Idioma2" size="1" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Idioma2&#39;,-1,54)">
			  <option value="-1"> </option><option value="4">Espanhol</option></select></td>
		   <td>
		     
		      <select name="Nleit2" size="1" style="font-size: 8pt; font-family: verdana; width: 120px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Nleit2&#39;,-1,55)">
			 <option value="1">(n�o tem)</option><option value="2">B�sica</option><option value="3">Intermedi�ria</option><option value="4">Avan�ada</option><option value="5">Fluente</option></select></td>
			<td>
			 
			  <select name="Nescr2" size="1" style="font-size: 8pt; font-family: verdana; width: 120px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Nescr2&#39;,-1,56)">
			 <option value="1">(n�o tem)</option><option value="2">B�sica</option><option value="3">Intermedi�ria</option><option value="4">Avan�ada</option><option value="5">Fluente</option></select></td>
			<td>
			  
			  <select name="Nconv2" size="1" style="font-size: 8pt; font-family: verdana; width: 120px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Nconv2&#39;,-1,57)">
			  <option value="1">(n�o tem)</option><option value="2">B�sica</option><option value="3">Intermedi�ria</option><option value="4">Avan�ada</option><option value="5">Fluente</option></select></td>
			</tr>

			<tr>
			  <td>
			  
			    <select name="Idioma3" size="1" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Idioma3&#39;,-1,58)">
			  <option value="-1"> </option></select></td>
		   <td>
		     
		      <select name="Nleit3" size="1" style="font-size: 8pt; font-family: verdana; width: 120px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Nleit3&#39;,-1,59)">
			 <option value="1">(n�o tem)</option><option value="2">B�sica</option><option value="3">Intermedi�ria</option><option value="4">Avan�ada</option><option value="5">Fluente</option></select></td>
			<td>
			 
			  <select name="Nescr3" size="1" style="font-size: 8pt; font-family: verdana; width: 120px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Nescr3&#39;,-1,60)">
			 <option value="1">(n�o tem)</option><option value="2">B�sica</option><option value="3">Intermedi�ria</option><option value="4">Avan�ada</option><option value="5">Fluente</option></select></td>
			<td>
			  
			  <select name="Nconv3" size="1" style="font-size: 8pt; font-family: verdana; width: 120px" onfocus="SetSav(&#39;SavIdiomas&#39;); checkSelect2(&#39;Nconv3&#39;,-1,61)">
			  <option value="1">(n�o tem)</option><option value="2">B�sica</option><option value="3">Intermedi�ria</option><option value="4">Avan�ada</option><option value="5">Fluente</option></select></td>
			</tr>

              </tbody></table>
			  </ul>
            </td>
            <td bgcolor="#3064C8" id="LtC" background="./js/DestaqLat-Fundo.gif" valign="bottom" width="2%"><img src="./js/DestaqLat-Quebra.gif" name="Quebra"></td>
          </tr>
		  
          <tr> 
            <td colspan="3"><font size="2" face="Verdana, Arial" color="#000068" id="PrTtitN"><b>&nbsp;&nbsp;&nbsp;<!--#930-->Informe 
              a sua forma��o acad�mica e complementar<!--/#--></b></font></td>
            <td bgcolor="#3064C8" id="LtC" width="2%" background="./js/DestaqLat-Fundo.gif"><img src="./js/DestaqLat-Seta.gif" name="Destaq"></td>
            <td bgcolor="#3064C8" id="LtC" width="18%" rowspan="5" valign="top"><font size="1" color="#FFFFFF" id="LtTn" face="Verdana, Arial"><b><font color="#FFFF00" id="LtTd"><!--#940-->N�o 
              se preocupe com a ordem das forma��es.<!--/#--></font>
              <!--#950-->Elas ser�o automaticamente agrupadas por tipo e colocadas 
              em ordem cronol�gica.<!--/#--><br>
              <br><br>
              <!--#960-->Informe tantas forma��es quantas julgar relevantes. 
              Caso j� tenha usado todas as entradas, <a href="http://site.SEMTRE/CadCand-Submit.asp" onclick="submitFormSav(&#39;CadCand-Reload.asp&#39;); return false;" class="LtL">clique 
              aqui</a> para abrir mais algumas.<!--/#0-->
			  <br><br>
              <!--#962--><font color="#FFFF00" id="LtTd">Institui��o</font>: 
              informe o nome completo da institui��o onde foi realizado o curso (n�o utilize abrevia��es).<!--/#-->
			  <br><br>
              <!--#964--><font color="#FFFF00" id="LtTd">Pa�s/Estado</font>: 
              informe o pa�s e o estado onde realizou o curso.<!--/#--><!-- Se for Brasil, voc&ecirc; dever&aacute; informar
			  tamb&eacute;m o respectivo estado.-->
			  <br><br>
              <!--#966--><font color="#FFFF00" id="LtTd">Tipo</font>: 
              informe o tipo de curso realizado. Se for <i>Gradua��o</i>, voc� dever� classificar o seu curso
			  na lista de cursos do MEC, e se for <i>P�s-gradua��o</i> voc� dever� informar a respectiva �rea.<!--/#-->
			  <br><br>
              <!--#968--><font color="#FFFF00" id="LtTd">Dura��o</font>: 
              selecione a op��o que melhor corresponde � dura��o TOTAL do curso.<!--/#-->
			  <br><br>
              <!--#970--><font color="#FFFF00" id="LtTd">M�s/Ano de conclus�o</font>: 
              informe o m�s e ano em que a forma��o descrita foi conclu�da ou a previs�o de quando ser�
			  (preencha apenas se o curso j� foi conclu�do ou se ainda estiver cursando).<!--/#-->
			  </b></font></td>
          </tr>

          <tr> 
            <!--td>&nbsp;</td-->
            <td colspan="3"> 
			  <ul>
              <table cellpadding="2" cellspacing="0">
                <tbody><tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><b><!--#980-->Curso 1<!--/#--></b></font></td>
                  <td><font face="Verdana, Arial" size="1" id="PrTn"> 
				    <input type="text" size="45" maxlength="80" name="Curso" value="" onkeyup="SetSav(&#39;SavForm&#39;);SetSav(&#39;SavTxtChave&#39;)" class="iptsml">
					<a href="javascript:SetSav('SavForm');RemForm(1)" class="PrL"><font color="#FF0000" id="PrTl"><!--#985-->remover<!--/#--></font></a>
                  </font></td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#990-->Institui��o<!--/#--></font></td>
                  <td> 
				    <input type="text" size="45" maxlength="60" name="Instituicao" value="" onkeyup="SetSav(&#39;SavForm&#39;);SetSav(&#39;SavTxtChave&#39;)" class="iptsml">
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#995-->Pa�s onde cursou<!--/#--></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn">
				  
				  <select name="PaisForm" style="font-size: 8pt; font-family: verdana; width: 260px" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;PaisForm&#39;,0,62); checkFormVisibility(1)" onchange="alterouPais(false, &#39;PaisForm&#39;, 0);">
				  <option value="-1"> </option><option value="31">Brasil</option></select></font></td>
                </tr>
                <tr> 
				  <td valign="top"><font face="Verdana, Arial" size="2" id="PrTn"><!--#-->Estado onde cursou<!--/#--></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn">
				  
				   <select name="UFForm" style="font-size: 8pt; font-family: verdana; width: 260px" onfocus="SetSav(&#39;SavForm&#39;);">
				  </select></font></td>
				</tr>
                <tr> 
                  <td valign="top"><font size="2" face="Verdana, Arial" id="PrTn"><!--#1000-->Tipo de curso<!--/#--></font></td>
                  <td> 
				   
                    <select name="Tipo" size="1" style="font-size: 8pt; font-family: verdana; width: 370px" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;Tipo&#39;,0,63); checkFormVisibility(1)" onchange="checkFormVisibility(1)">
				   <option value="-1"> </option></select></td>
                </tr>

                <tr id="CursoGradForm1"> 
                  <td><font size="2" face="Verdana, Arial" id="PrTn"><!--#1001-->Classifica��o do curso<!--/#--></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn">
				  	
					    <select name="CursoGradForm" style="font-size: 8pt; font-family: verdana; width: 350px; background-color: rgb(238, 238, 238);" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;CursoGradForm&#39;,0,64);" disabled="">
					<option value="-1"> </option></select></font></td>
                </tr>
                <tr id="CursoPGradForm1"> 
                  <td><font size="2" face="Verdana, Arial" id="PrTn"><!--#1001-->�rea da p�s<!--/#--></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn">
				  	
					    <select name="CursoPGradForm" style="font-size: 8pt; font-family: verdana; width: 400px; background-color: rgb(238, 238, 238);" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;CursoPGradForm&#39;,0,65)" disabled="">
					<option value="-1"> </option></select></font></td>
                </tr>


                <tr> 
                  <td><font size="2" face="Verdana, Arial" id="PrTn"><!--#1001-->Dura��o total<!--/#--></font></td>
                  <td> 
				   
                    <select name="Duracao" size="1" style="font-size: 8pt; font-family: verdana; width: 280px" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;Duracao&#39;,0,66)">
				   <option value="-1"> </option></select>
                  </td>
                </tr>
                <tr> 
                  <td valign="top"><font size="2" face="Verdana, Arial" id="PrTn"><!--#1010-->Situa��o atual<!--/#--></font></td>
                  <td><font size="2" face="Verdana, Arial" id="PrTn">
				   
				    <!--select name="CodStatusForm" style="font-size: 8pt; font-family: verdana;" onChange="checkStatusCurso(1);">
 		                 <option selected value="-1"> </option>
 		                 <option  value="30">Curso conclu&iacute;do</option>
 		                 <option  value="20">Cursando</option>
 		                 <option  value="10">Interrompido</option>
					</select-->
				    <select name="CodStatusForm" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;CodStatusForm&#39;,0,67);checkStatusCurso(1);">
				   <option value="-1"> </option></select>
                  </font></td>
                </tr>
                <tr> 
                  <td valign="top"><font size="2" face="Verdana, Arial" id="PrTn"><!--#1010-->M�s/Ano de Conclus�o<!--/#--></font></td>
                  <td><font size="2" face="Verdana, Arial" id="PrTn">
				   
				    <select name="MesConclusao" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;MesConclusao&#39;,0,68)">
				   <option value="-1"> </option></select> /
				    <input type="text" size="4" maxlength="4" name="AnoConclusao" value="" onkeyup="SetSav(&#39;SavForm&#39;);" class="iptsml">
					<br><font size="1">(<!--#-->Preencha apenas se o curso j� foi concluido ou se estiver ainda cursando<!--/#-->)</font>
                  </font></td>
                </tr>
              </tbody></table>
			  </ul>
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%" background="./js/DestaqLat-Fundo.gif">&nbsp;</td>
			
          </tr>
		
          <tr> 
            <!--td>&nbsp;</td-->
            <td colspan="3"> 
			  <ul>
              <table cellpadding="2" cellspacing="0">
                <tbody><tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><b><!--#980-->Curso 2<!--/#--></b></font></td>
                  <td><font face="Verdana, Arial" size="1" id="PrTn"> 
				    <input type="text" size="45" maxlength="80" name="Curso" value="" onkeyup="SetSav(&#39;SavForm&#39;);SetSav(&#39;SavTxtChave&#39;)" class="iptsml">
					<a href="javascript:SetSav('SavForm');RemForm(2)" class="PrL"><font color="#FF0000" id="PrTl"><!--#985-->remover<!--/#--></font></a>
                  </font></td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#990-->Institui��o<!--/#--></font></td>
                  <td> 
				    <input type="text" size="45" maxlength="60" name="Instituicao" value="" onkeyup="SetSav(&#39;SavForm&#39;);SetSav(&#39;SavTxtChave&#39;)" class="iptsml">
                  </td>
                </tr>
                <tr> 
                  <td><font face="Verdana, Arial" size="2" id="PrTn"><!--#995-->Pa�s onde cursou<!--/#--></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn">
				  
				  <select name="PaisForm" style="font-size: 8pt; font-family: verdana; width: 260px" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;PaisForm&#39;,1,69); checkFormVisibility(2)" onchange="alterouPais(false, &#39;PaisForm&#39;, 1);">
				  <option value="-1"> </option><option value="31">Brasil</option></select></font></td>
                </tr>
                <tr> 
				  <td valign="top"><font face="Verdana, Arial" size="2" id="PrTn"><!--#-->Estado onde cursou<!--/#--></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn">
				  
				   <select name="UFForm" style="font-size: 8pt; font-family: verdana; width: 260px" onfocus="SetSav(&#39;SavForm&#39;);">
				  </select></font></td>
				</tr>
                <tr> 
                  <td valign="top"><font size="2" face="Verdana, Arial" id="PrTn"><!--#1000-->Tipo de curso<!--/#--></font></td>
                  <td> 
				   
                    <select name="Tipo" size="1" style="font-size: 8pt; font-family: verdana; width: 370px" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;Tipo&#39;,1,70); checkFormVisibility(2)" onchange="checkFormVisibility(2)">
				   <option value="-1"> </option></select></td>
                </tr>

                <tr id="CursoGradForm2"> 
                  <td><font size="2" face="Verdana, Arial" id="PrTn"><!--#1001-->Classifica��o do curso<!--/#--></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn">
				  	
					    <select name="CursoGradForm" style="font-size: 8pt; font-family: verdana; width: 350px; background-color: rgb(238, 238, 238);" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;CursoGradForm&#39;,1,71);" disabled="">
					<option value="-1"> </option></select></font></td>
                </tr>
                <tr id="CursoPGradForm2"> 
                  <td><font size="2" face="Verdana, Arial" id="PrTn"><!--#1001-->�rea da p�s<!--/#--></font></td>
                  <td><font face="Verdana, Arial" size="2" id="PrTn">
				  	
					    <select name="CursoPGradForm" style="font-size: 8pt; font-family: verdana; width: 400px; background-color: rgb(238, 238, 238);" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;CursoPGradForm&#39;,1,72)" disabled="">
					<option value="-1"> </option></select></font></td>
                </tr>


                <tr> 
                  <td><font size="2" face="Verdana, Arial" id="PrTn"><!--#1001-->Dura��o total<!--/#--></font></td>
                  <td> 
				   
                    <select name="Duracao" size="1" style="font-size: 8pt; font-family: verdana; width: 280px" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;Duracao&#39;,1,73)">
				   <option value="-1"> </option></select>
                  </td>
                </tr>
                <tr> 
                  <td valign="top"><font size="2" face="Verdana, Arial" id="PrTn"><!--#1010-->Situa��o atual<!--/#--></font></td>
                  <td><font size="2" face="Verdana, Arial" id="PrTn">
				   
				    <!--select name="CodStatusForm" style="font-size: 8pt; font-family: verdana;" onChange="checkStatusCurso(2);">
 		                 <option selected value="-1"> </option>
 		                 <option  value="30">Curso conclu&iacute;do</option>
 		                 <option  value="20">Cursando</option>
 		                 <option  value="10">Interrompido</option>
					</select-->
				    <select name="CodStatusForm" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;CodStatusForm&#39;,1,74);checkStatusCurso(2);">
				   <option value="-1"> </option></select>
                  </font></td>
                </tr>
                <tr> 
                  <td valign="top"><font size="2" face="Verdana, Arial" id="PrTn"><!--#1010-->M�s/Ano de Conclus�o<!--/#--></font></td>
                  <td><font size="2" face="Verdana, Arial" id="PrTn">
				   
				    <select name="MesConclusao" style="font-size: 8pt; font-family: verdana; width: 150px" onfocus="SetSav(&#39;SavForm&#39;); checkSelect2(&#39;MesConclusao&#39;,1,75)">
				   <option value="-1"> </option></select> /
				    <input type="text" size="4" maxlength="4" name="AnoConclusao" value="" onkeyup="SetSav(&#39;SavForm&#39;);" class="iptsml">
					<br><font size="1">(<!--#-->Preencha apenas se o curso j� foi concluido ou se estiver ainda cursando<!--/#-->)</font>
                  </font></td>
                </tr>
              </tbody></table>
			  </ul>
            </td>
            <td bgcolor="#3064C8" id="LtC" width="2%" background="./js/DestaqLat-Fundo.gif">&nbsp;</td>
			
          </tr>
		
          <tr> 
            <!--td>&nbsp;</td-->
            <td colspan="3">&nbsp; </td>
            <td bgcolor="#3064C8" id="LtC" width="2%">&nbsp;</td>
            <td bgcolor="#3064C8" id="LtC" width="18%"><a href="#" onclick="showcv(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botVisualiza4&#39;,&#39;document.botVisualiza4&#39;,&#39;img/cust/pdncand2/visualiza_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/visualiza_F01.gif" alt="Curr�culo formatado" name="botVisualiza4"></a><a href="#" onclick="showcvconf(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botConfidencial4&#39;,&#39;document.botConfidencial4&#39;,&#39;img/cust/pdncand2/confidencial_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/confidencial_F01.gif" alt="Curr�culo em formato confidencial" name="botConfidencial4"></a><a href="http://site.SEMTRE/CadCand-Submit.asp" onclick="submitFormChk(&#39;Confirma&#39;); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.Image1&#39;,&#39;document.Image1&#39;,&#39;img/cust/pdncand2/confirma_F02.gif&#39;,&#39;#924576064410&#39;)"><img border="0" src="./js/confirma_F01.gif" alt="Confirma" name="Image1"></a><a href="http://site.SEMTRE/CadCand-Desiste.asp" onclick="javascript:desiste();return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.Image2&#39;,&#39;document.Image2&#39;,&#39;img/cust/pdncand2/desiste_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/desiste_F01.gif" alt="Desiste" name="Image2"></a></td>
          </tr>


</tbody></table><table width="100%" border="0" cellpadding="0" cellspacing="0" height="1%" align="center">
  <tbody><tr align="center" bgcolor="#3064C8" id="LtC"> 
    <td valign="top">
      <table cellspacing="0" border="0" cellpadding="2">
        <tbody><tr> 
                  <td><a href="#" onclick="showcv(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botInfVisualiza&#39;,&#39;document.botInfVisualiza&#39;,&#39;img/cust/pdncand2/visualiza_F02.gif&#39;,&#39;#923339814720&#39;)"><img border="0" src="./js/visualiza_F01.gif" alt="Curr�culo formatado" name="botInfVisualiza"></a></td>

                  <td><a href="#" onclick="showcvconf(); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botInfConfidencial&#39;,&#39;document.botInfConfidencial&#39;,&#39;img/cust/pdncand2/confidencial_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/confidencial_F01.gif" alt="Curr�culo em formato confidencial" name="botInfConfidencial"></a></td>

                  <td><font face="Verdana, Arial" size="2" color="#FFFFFF" id="LtTn"><b><!--#b-->visualiza<!--/#--></b></font></td>
                  <td><a href="http://site.SEMTRE/CadCand-Submit.asp" onclick="submitFormChk(&#39;Confirma&#39;); return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botInfContinua&#39;,&#39;document.botInfContinua&#39;,&#39;img/cust/pdncand2/confirma_F02.gif&#39;,&#39;#923339814720&#39;)"><img border="0" src="./js/confirma_F01.gif" alt="Confirma" name="botInfContinua"></a></td>
                  <td><font face="Verdana, Arial" size="2" color="#FFFFFF" id="LtTn"><b><!--#b-->confirma<!--/#--></b></font></td>
                  <!--td><a href="#" onClick="LimpaForm(); return false;" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('document.formPag.botInfLimpa','document.botInfLimpa','img/cust/pdncand2/limpa_F02.gif','#925672599230')"><img src="img/cust/pdncand2/limpa_F01.gif" border="0" name="botInfLimpa" alt="Limpa todos os campos."></a></td>
                  <td><font face="Verdana, Arial" size="2" color="#FFFFFF" ID=LtTn><b><!#b>limpa<!/#></b></font></td-->
                  <td><a href="http://site.SEMTRE/CadCand-Desiste.asp" onclick="javascript:desiste();return false;" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.formPag.botInfDesiste&#39;,&#39;document.botInfDesiste&#39;,&#39;img/cust/pdncand2/desiste_F02.gif&#39;,&#39;#923351380880&#39;)"><img border="0" src="./js/desiste_F01.gif" alt="Desiste" name="botInfDesiste"></a></td>
                  <td><font face="Verdana, Arial" size="2" color="#FFFFFF" id="LtTn"><b><!--#b-->desiste<!--/#--></b></font></td>
        </tr>

		
        	
      </tbody></table>
    </td>
    <td align="right" valign="top" bgcolor="#3064C8" id="LtC" width="2%"><font size="1" face="Verdana, Arial" color="#FFFF00" id="LtTd"><b>*</b></font></td>
    <td align="left" valign="top" width="18%" bgcolor="#3064C8" id="LtC"><font size="1" face="Verdana, Arial" color="#FFFF00" id="LtTd"><b><!--#1020-->preenchimento 
      obrigat�rio<!--/#--><br>
      </b></font><font face="Verdana, Arial" size="2" color="#FFFF00"><img src="./js/back-lateral.gif" width="125" height="1"></font></td>
  </tr>
</tbody></table>

<table width="100%" border="0" cellpadding="0" cellspacing="0" height="1%" align="center">
  <tbody><tr bgcolor="#000068" id="RodC"> 
    <td valign="top" width="100%">
	  <table width="100%" border="0" cellspacing="0" cellpadding="2" height="35">
        <tbody><tr align="left" valign="top"> 
		  
	      <td colspan="3"><a href="#topo" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.VaiProTopo&#39;,&#39;document.VaiProTopo&#39;,&#39;img/cust/pdncand2/topo_F02.gif&#39;,&#39;#926020327980&#39;)"><img name="VaiProTopo" border="0" src="./js/topo_F01.gif" align="middle" alt="Topo da p�gina"></a><a href="http://www.SEMTRE/ajuda/" target="_blank" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;document.Suporte&#39;,&#39;document.Suporte&#39;,&#39;img/cust/pdncand2/ajuda_F02.gif&#39;,&#39;#924576064410&#39;)"><img border="0" src="./js/ajuda_F01.gif" alt="Suporte ao usu�rio" name="Suporte" align="middle"></a></td>
		  
          <td align="right"><font color="#99CCFF" id="RodTn" face="Verdana, Arial" size="1"><a href="#" onclick="submitForm(&#39;CondicUso.asp&#39;); return false;" class="RodL"><font color="#99CCFF" id="RodTn" face="Verdana, Arial" size="1"><!--#-->Termos e condi��es de uso<!--/#--></font></a><br>� Copyright 1999 - 2014 VAGAS Tecnologia</font></td>
        </tr>
      </tbody></table>
    </td>
  </tr>
</tbody></table>


<script src="./js/INCCadCandCV4.js"></script>
<script src="./js/INCCadCandSCCads16.js"></script>



</td></tr></tbody></table></body></html>