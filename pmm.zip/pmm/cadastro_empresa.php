<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener'>
		
<script type="text/javascript">
function mascaraMutuario(o,f){
    v_obj=o
    v_fun=f
    setTimeout('execmascara()',1)
}
 
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
 
function cpfCnpj(v){
 
    //Remove tudo o que não é dígito
    v=v.replace(/\D/g,"")
 
    if (v.length <= 13) { //CPF
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        //de novo (para o segundo bloco de números)
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um hífen entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")	
		
		
 
    } else { //CNPJ
 
        //Coloca ponto entre o segundo e o terceiro dígitos
        v=v.replace(/^(\d{2})(\d)/,"$1.$2")
 
        //Coloca ponto entre o quinto e o sexto dígitos
        v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
 
        //Coloca uma barra entre o oitavo e o nono dígitos
        v=v.replace(/\.(\d{3})(\d)/,".$1/$2")
 
        //Coloca um hífen depois do bloco de quatro dígitos
        v=v.replace(/(\d{4})(\d)/,"$1-$2")
 
    }
	
	
	
    return v
 
}
			</script>
			
			<?
			$busca_cnpj = $_GET['txCNPJ'];
		if($busca_cnpj==""){}else{
		$query_noticias = "SELECT * FROM `empresa` WHERE txCNPJ LIKE '%$busca_cnpj%'";
		$rs_noticias    = mysql_query($query_noticias);
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$txCNPJ 	= $campo_noticias['txCNPJ']; 	 		 			 	
		$selTipo	= $campo_noticias['selTipo']; 	 		 			 	
		$txrazaosocial	= $campo_noticias['txrazaosocial']; 	 		 			 	
		$txnome	= $campo_noticias['txnome']; 	 		 			 	
		$selArea	= $campo_noticias['selArea']; 	 		 			 	
		$txinscmunicipal	= $campo_noticias['txinscmunicipal']; 	 		 			 	
		$txinscestadual	= $campo_noticias['txinscestadual']; 	 		 			 	
		$txtendereco	= $campo_noticias['txtendereco']; 	 		 			 	
		$txtbairro	= $campo_noticias['txtbairro']; 	 		 			 	
		$txtcidade	= $campo_noticias['txtcidade']; 	 		 			 	
		$txtestado	= $campo_noticias['txtestado']; 	 		 			 	
		$txtcep	= $campo_noticias['txtcep']; 	 		 			 	
		$txtenderecoentrevista	= $campo_noticias['txtenderecoentrevista']; 	 		 			 	
		$txtbairroentrevista	= $campo_noticias['txtbairroentrevista']; 	 		 			 	
		$txtcidadeentrevista	= $campo_noticias['txtcidadeentrevista']; 	 		 			 	
		$txtPertoDeEntrevista	= $campo_noticias['txtPertoDeEntrevista']; 	 		 			 	
		$txtFalarComEntrevista	= $campo_noticias['txtFalarComEntrevista']; 	 		 			 	
		$txtEmailEntrevista	= $campo_noticias['txtEmailEntrevista']; 	 		 			 	
		$txemailresponsavel	= $campo_noticias['txemailresponsavel']; 	 		 			 	
		$txtel1= $campo_noticias['txtel1']; 	 		 			 	
		$txtel2= $campo_noticias['txtel2']; 	 		 			 	
		$txtel3= $campo_noticias['txtel3']; 	 		 			 	
		$txemail= $campo_noticias['txemail']; 	 		 			 	
		$txHomePage= $campo_noticias['txHomePage']; 	 		 			 	
		$txresponsavel= $campo_noticias['txresponsavel']; 	 		 			 	
		$txcargoresponsavel= $campo_noticias['txcargoresponsavel']; 	 		 			 	
		$txnomecontato= $campo_noticias['txnomecontato']; 	 		 			 	
		$txcargocontato= $campo_noticias['txcargocontato']; 	 		 			 	
		$txemailContato= $campo_noticias['txemailContato']; 	 		 			 	
		$selconsultor= $campo_noticias['selconsultor']; 	 		 			 	
		$selcidaatraves= $campo_noticias['selcidaatraves']; 	 		 			 	
		$txtstatus= $campo_noticias['txtstatus']; 	 		 			 	
		$txtObs= $campo_noticias['txtObs']; 	 
		$id_empresa= $campo_noticias['id_empresa']; 	 
		$txtestadoentrevista= $campo_noticias['txtestadoentrevista']; 	 
		$txtcepentrevista= $campo_noticias['txtcepentrevista']; 	 
		
		}
		}
			?>
<script  type="text/javascript">	
// FUNÇÃO PARA BUSCA NOTICIA
function verifica_cnpj(valor2) {
// Verificando Browser
if(window.XMLHttpRequest) {
req = new XMLHttpRequest();
}
else if(window.ActiveXObject) {
req = new ActiveXObject("Microsoft.XMLHTTP");
}

// Arquivo PHP juntamente com o valor digitado no campo (método GET)

var url = "verifica_cnpj.php?cnpj="+valor2;

// Chamada do método open para processar a requisição
req.open("Get", url, true); 
req.setRequestHeader("Cache-Control","no-cache,no-store");
req.setRequestHeader("Pragma", "no-cache");

// Quando o objeto recebe o retorno, chamamos a seguinte função;
req.onreadystatechange = function() {

// Exibe a mensagem "Buscando Noticias..." enquanto carrega
if(req.readyState == 1) {
document.getElementById('verifica_cnpj').innerHTML = '';
}

// Verifica se o Ajax realizou todas as operações corretamente
if(req.readyState == 4 && req.status == 200) {

// Resposta retornada pelo busca.php
var resposta = req.responseText;

// Abaixo colocamos a(s) resposta(s) na div resultado
document.getElementById('verifica_cnpj').innerHTML = resposta;
}
}
req.send(null);
req.setRequestHeader("Cache-Control", "no-cache");
req.setRequestHeader("Pragma", "no-cache"); 

}


</script>	
<script type="text/javascript">
 function alert_cnpj() {
			$(document).ready(function(){

			
			var $tag = $('#verifica_cnpj').get(0).innerHTML; //'DIV'
			if($tag ==""){}else{
			//var $cnjp = document.getElementsByTagName(name["txCNPJ"]);
			  var cnjp = $('#txCNPJ').val();
			alert("CNPJ/CPF já cadastrado "+cnjp);
			window.location.href="cadastro_empresa.php?txCNPJ="+cnjp;
			
			}
				

			});
 }
 
 $(document).ready(function(){									
										$("#cadastro_empresa").validate();										
										$.validator.setDefaults({
									submitHandler: function() {
										
										}
										});
										});
</script>
			
<form  class="form" method="post" action="script_empresa.php?acao=<?if($id_empresa==""){echo"cadastro";}else{echo"editar";}?>&id_empresa=<?=$id_empresa;?>" id="cadastro_empresa" name='cadastro_empresa'>

	
  	<h2>FICHA</h2>
	
		<div id='verifica_cnpj' name='verifica_cnpj' ></div>
  	<!--<h3>Same fields required example</h3>-->
  	
	<div class="form-row">
	    <div class="label">CPF / CNPJ <font class='simbolo'>&#10045;</font> </div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txCNPJ" id="txCNPJ" required value='<?=$txCNPJ;?>'maxlength="18"  tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)' onblur='verifica_cnpj(this.value);alert_cnpj();' style="width:194px;" type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Tipo <font class='simbolo'>&#10045;</font> </div>
	    <div class="input-container" style='width:546px;'>		
			<select name="selTipo" required id="selTipo"   tabindex="2">
			<option value="<?=$selTipo;?>"><?=$selTipo;?></option>
				<option value="Treinamento">Treinamento</option>
				<option value="Empregador">Empregador</option>
				
				<option value="Ambos">Ambos</option>
			</select>
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Razão Social</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txrazaosocial"  onblur='verifica_cnpj(this.value);alert_cnpj();' onkeyup="this.value = this.value.toUpperCase();" id="txrazaosocial"  value='<?=$txrazaosocial;?>' maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="3" type="text" class="input req-same">
		</div>
	</div>
	<div class="form-row">
	    <div class="label">Nome <font class='simbolo'>&#10045;</font> </div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txnome"  onkeyup="this.value = this.value.toUpperCase();" required id="txnome" onblur='verifica_cnpj(this.value);alert_cnpj();' value='<?=$txnome;?>'  maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="4" 
			type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Segmento de Atuação <font class='simbolo'>&#10045;</font> </div>
	    <div class="input-container" style='width:546px;'>		
			<select name="selArea" required id="selArea" onchange="EditandoRegistro()" tabindex="6" >
				<option value="<?=$selArea;?>"><?=$selArea;?></option>
<option value="ALIMENTAÇÃO">ALIMENTAÇÃO</option><option value="COMÉRCIO">COMÉRCIO</option><option value="HOTELARIA">HOTELARIA</option><option value="INDUSTRIAL">INDUSTRIAL</option><option value="OFFSHORE (INDUSTRIA)">OFFSHORE (INDUSTRIA)</option><option value="OUTROS">OUTROS</option><option value="PRESTAÇÃO DE SERVIÇOS">PRESTAÇÃO DE SERVIÇOS</option><option value="TECNOLOGIA(SUPERI">TECNOLOGIA(SUPERIOR)</option>		
			</select>
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			Inscrição Municipal
			<input name="txinscmunicipal" value='<?=$txinscmunicipal;?>' onblur='verifica_cnpj(this.value);alert_cnpj();'id="txinscmunicipal" maxlength="20" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.txinscmunicipal');" tabindex="7" style="width:161px;" type="text" class="input req-same">
			Inscrição Estadual
			<input name="txinscestadual" value='<?=$txinscestadual;?>'  onblur='verifica_cnpj(this.value);alert_cnpj();' id="txinscestadual" maxlength="18" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.txinscestadual');" tabindex="8" style="width:160px;" type="text" class="input req-same">
		</div>
	</div>
	
	<h2>ENDEREÇO</h2>
	
	<div class="form-row">
	    <div class="label">Endereço <font class='simbolo'>&#10045;</font>  </div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtendereco" required id="txtendereco" onblur='verifica_cnpj(this.value);alert_cnpj();' value='<?=$txtendereco;?>'  maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="9"  type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Bairro <font class='simbolo'>&#10045;</font>  </div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtbairro" required id="txtbairro" onblur='verifica_cnpj(this.value);alert_cnpj();' value='<?=$txtbairro;?>' maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="10"  type="text" class="input req-same">
		</div>
	</div>
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<b>Cidade </b>  <font class='simbolo'>&#10045;</font>  
			<input name="txtcidade" required id="txtcidade"value='<?=$txtcidade;?>'  onblur='verifica_cnpj(this.value);alert_cnpj();' maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="11" style="width:309px;" type="text" class="input req-same">
			<b>Estado</b> <font class='simbolo'>&#10045;</font> 
			<select name="txtestado" required id="txtestado" onchange="EditandoRegistro()" tabindex="12" style="width:40px;">
				<option value="<?=$txtestado;?>"><?=$txtestado;?></option>
				<option value="AC">AC</option>
				<option value="AL">AL</option>
				<option value="AM">AM</option>
				<option value="AP">AP</option>
				<option value="BA">BA</option>
				<option value="CE">CE</option>
				<option value="DF">DF</option>
				<option value="ES">ES</option>
				<option value="GO">GO</option>
				<option value="MA">MA</option>
				<option value="MT">MT</option>
				<option value="MS">MS</option>
				<option value="MG">MG</option>
				<option value="PA">PA</option>
				<option value="PB">PB</option>
				<option value="PR">PR</option>
				<option value="PE">PE</option>
				<option value="PI">PI</option>
				<option value="RJ">RJ</option>
				<option value="RN">RN</option>
				<option value="RS">RS</option>
				<option value="RO">RO</option>
				<option value="RR">RR</option>
				<option value="SC">SC</option>
				<option value="SP">SP</option>
				<option value="SE">SE</option>
				<option value="TO">TO</option>
			</select>
			<b>CEP</b>
			<input name="txtcep" id="txtcep" value='<?=$txtcep;?>' onblur='verifica_cnpj(this.value);alert_cnpj();' maxlength="8" onchange="EditandoRegistro();" onkeyup="verificaNumero('window.document.Ficha.txtcep');" tabindex="13" style="width:65px;" type="text" class="input req-same">
		</div>
	</div>
	
	
	<h2>ENTREVISTA</h2>	
  	<h3>Só preencher o endereço se diferente do acima.</h3>
	
	<div class="form-row">
	    <div class="label">Endereço <font class='simbolo'>&#10045;</font> </div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtenderecoentrevista" value='<?=$txtenderecoentrevista;?>' onblur='verifica_cnpj(this.value);alert_cnpj();' id="txtenderecoentrevista" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="14" type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Bairro <font class='simbolo'>&#10045;</font> </div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtbairroentrevista"  value='<?=$txtbairroentrevista;?>' onblur='verifica_cnpj(this.value);alert_cnpj();' id="txtbairroentrevista" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="15" type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			
			<b>Cidade</b>
			<input name="txtcidadeentrevista"  value='<?=$txtcidadeentrevista;?>' onblur='verifica_cnpj(this.value);alert_cnpj();' id="txtcidadeentrevista" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="16" style="width:309px;" type="text" class="input req-same">
			<b>Estado</b>
			<select name="txtestadoentrevista" id="txtestadoentrevista" onchange="EditandoRegistro()" tabindex="17" style="width:40px;">
				<option value="<?=$txtestadoentrevista;?>"><?=$txtestadoentrevista;?></option>
				<option value="RJ">RJ</option>
				<option value="AC">AC</option>
				<option value="AL">AL</option>
				<option value="AM">AM</option>
				<option value="AP">AP</option>
				<option value="BA">BA</option>
				<option value="CE">CE</option>
				<option value="DF">DF</option>
				<option value="ES">ES</option>
				<option value="GO">GO</option>
				<option value="MA">MA</option>
				<option value="MT">MT</option>
				<option value="MS">MS</option>
				<option value="MG">MG</option>
				<option value="PA">PA</option>
				<option value="PB">PB</option>
				<option value="PR">PR</option>
				<option value="PE">PE</option>
				<option value="PI">PI</option>
				
				<option value="RN">RN</option>
				<option value="RS">RS</option>
				<option value="RO">RO</option>
				<option value="RR">RR</option>
				<option value="SC">SC</option>
				<option value="SP">SP</option>
				<option value="SE">SE</option>
				<option value="TO">TO</option>
			</select>
			<b>CEP</b>
			<input name="txtcepentrevista" value='<?=$txtcepentrevista;?>' id="txtcepentrevista" maxlength="8" onchange="EditandoRegistro();" onkeyup="verificaNumero('window.document.Ficha.txtcepentrevista');" tabindex="18" style="width:65px;" type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Perto de</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtPertoDeEntrevista" value='<?=$txtPertoDeEntrevista;?>' id="txtPertoDeEntrevista" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="19"  type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Falar com</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtFalarComEntrevista"  value='<?=$txtFalarComEntrevista;?>' id="txtFalarComEntrevista" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="20" type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">E-mail</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtEmailEntrevista" value='<?=$txtEmailEntrevista;?>'  onblur='verifica_cnpj(this.value);alert_cnpj();' id="txtEmailEntrevista" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="21" type="text" class="input req-same">
		</div>
	</div>
	
	
	<h2>CONTATOS</h2>
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			Telefones para contato
			<input name="txtel1" placeholder="telefone" id="txtel1" maxlength="14"value='<?=$txtel1;?>'  onkeydown="EditandoRegistro()" onkeyup="VerificaMascara('window.document.Ficha.txtel1','(###)####-####',1);" tabindex="22" style="width:120px;" type="text" class="input req-same">
			&nbsp;/&nbsp;
			<input name="txtel2" id="txtel2" placeholder="celular" maxlength="14" value='<?=$txtel2;?>'  onkeydown="EditandoRegistro()" onkeyup="VerificaMascara('window.document.Ficha.txtel2','(###)####-####',1);" tabindex="23" style="width:120px;" type="text" class="input req-same">
			&nbsp;/&nbsp;
			<input name="txtel3" id="txtel3" maxlength="14" placeholder="outro" value='<?=$txtel3;?>'  onkeydown="EditandoRegistro()" onkeyup="VerificaMascara('window.document.Ficha.txtel3','(###)####-####',1);" tabindex="24" style="width:120px;" type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">E-mail</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txemail" required  id="txemail"value='<?=$txemail;?>'  maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="25"  type="text" class="input req-same">
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Página de Internet</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txHomePage" id="txHomePage" value='<?=$txHomePage;?>' maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="26" type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Responsável</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txresponsavel" id="txresponsavel" value='<?=$txresponsavel;?>' maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="27" type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Cargo de Responsável</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txcargoresponsavel" id="txcargoresponsavel" value='<?=$txcargoresponsavel;?>' maxlength="50" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="28"  type="text" class="input req-same">
		</div>
	</div>
	<div class="form-row">
	    <div class="label">E-mail do Responsável</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txemailresponsavel" id="txemailresponsavel" value='<?=$txemailresponsavel;?>' maxlength="100" onkeydown="EditandoRegistro()" tabindex="29"  type="text" class="input req-same">
		</div>
	</div>

	<div class="form-row">
	    <div class="label">Nome de Contato</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txnomecontato" id="txnomecontato" value='<?=$txnomecontato;?>' maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="30"  type="text" class="input req-same">
		</div>
	</div>
	<div class="form-row">
	    <div class="label">Cargo de Contato</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txcargocontato" id="txcargocontato"  value='<?=$txcargocontato;?>' maxlength="50" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="31" type="text" class="input req-same">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">E-mail do Contato</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txemailContato" id="txemailContato" value='<?=$txemailContato;?>' maxlength="100" onkeydown="EditandoRegistro()" tabindex="32"  type="text" class="input req-same">
		</div>
	</div>
	
	<h2>INFORMAÇÕES ADICIONAIS</h2>
	
		<div class="form-row">
		<div class="label"></div>
		<div class="input-container" style='width:546px;'>		
		Consultor 
		<select name="selconsultor" id="selconsultor" required   onchange="EditandoRegistro()" tabindex="33" style="width:230px;">
		<option value="<?=$selconsultor;?>"><?=$selconsultor;?></option>
				<?
				$query_noticiascp2 = "SELECT * FROM `captadores` ORDER BY `captadores`.`nome` ASC";
				$rs_noticiascp2    = mysql_query($query_noticiascp2);
				while($campo_noticiascp2 = mysql_fetch_array($rs_noticiascp2)){
				$captador       = $campo_noticiascp2['nome'];	

				?>
					<option value="<?=$captador ;?>"><?=$captador ;?></option>
		
				<?}?>
		
		</select>
		Referência
		<select name="selcidaatraves" required  id="selcidaatraves" onchange="EditandoRegistro()" tabindex="34" style="width:175px;">
		<option value="<?=$selcidaatraves;?>"><?=$selcidaatraves;?></option>
		
			<?
			$query_noticiascp2l = "SELECT * FROM `local_captacao` ORDER BY `local_captacao`.`local` ASC";
			$rs_noticiascp2l    = mysql_query($query_noticiascp2l);
			while($campo_noticiascp2l = mysql_fetch_array($rs_noticiascp2l)){
			$local       = $campo_noticiascp2l['local'];	

			?>
		<option value="<?=$local ;?>"><?=$local ;?></option>
		<?}?>
		</select>
		</div>
		</div>
		
		
		
				<div class="form-row">
		<div class="label">Status</div>
		<div class="input-container" style='width:546px;'>		
		<select name="txtstatus" required  id="txtstatus" onchange="EditandoRegistro()" tabindex="35" >
				<option value="<?=$txtstatus?>"><?=$txtstatus?></option>
				<option value="Ativa">Ativa</option>
				<option value="Inativa">Inativa</option>
				<option value="Em Análise">Em Análise</option>
				<option value="Fechada">Fechada</option>
				<option value="Problemática">Problemática</option>
			</select>
		</div>
		</div>

		<div class="form-row">
		<div class="label">Observações</div>
		<div class="input-container" style='width:546px;'>		
			<textarea name="txtObs" id="txtObs" rows="4" class="input req-same" style='width:100%;height:53px;'cols="98" tabindex="36" style="font-size: 12px; font-family: Arial;" onkeyup="funTamanhoCerto('window.document.Ficha.txtObs', 200);" onchange="Maiuscula(this);EditandoRegistro();"><?=$txtObs;?></textarea>
		</div>
		</div>

		
		
	
	
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			
		
			<input id="submitBtn2" value="Salvar" type="submit" class="sendBtn" />
				<div id="errorDiv2" class="error-div"></div>
		</div>
	</div>
	

</form>
	


</body>
</html>
