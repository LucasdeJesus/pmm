j<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>
<script type="text/javascript">
            $().ready(function() {
                $("#txcbonome").autocomplete("789/autoComplete.php", {
                    width: 546,
                   
                    matchContains: true,
					mustMatch: true,
					//minChars: 0,
					//multiple: true,
					highlight: false,
					//multipleSeparator: ",",
					selectFirst: false
                });
				
				
				 $("#selnome").autocomplete("789/consulta.empresa.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
				
				

				
				
				
                  
				
            });
        </script>
<div id="bg-container" class='contener'>


<?
		$id_vaga = $_GET['id_vaga'];
		$query_noticias = "SELECT * FROM `vagas` WHERE id_vaga ='$id_vaga'";	
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){


			$id_vaga= $campo_noticias['id_vaga']; 	 
			$id_empresa= $campo_noticias['id_empresa']; 	 
			$selvagasigilosa = $campo_noticias['selvagasigilosa'];
			$id_empresa = $campo_noticias['id_empresa']; 
			$txcbonome = $campo_noticias['txcbonome'];
			$txtdescrvaga = $campo_noticias['txtdescrvaga'];
			$txcargo = $campo_noticias['txcargo']; 
			$txvagadata = $campo_noticias['txvagadata'];
			$txvagahorario = $campo_noticias['txvagahorario'];
			$selvagadeficiente = $campo_noticias['selvagadeficiente'];
			$txvagaquantidade = $campo_noticias['txvagaquantidade'];
			$txvagapreenchidaCTM = $campo_noticias['txvagapreenchidaCTM']; 
			$txvagapreenchidaOutros = $campo_noticias['txvagapreenchidaOutros'];
			$txvagaCancelada = $campo_noticias['txvagaCancelada']; 
			$txvagasativas = $campo_noticias['txvagasativas']; 
			$txEncaminhar = $campo_noticias['txEncaminhar'];
			$txvagadataenc = $campo_noticias['txvagadataenc'];
			$chktemporaria = $campo_noticias['chktemporaria'];
			$txtcep_local = $campo_noticias['txtcep_local'];
			$txtestado_local = $campo_noticias['txtestado_local'];
			$txtcidade_local = $campo_noticias['txtcidade_local'];
			$txtbairro_local = $campo_noticias['txtbairro_local'];
			$txtendereco_local = $campo_noticias['txtendereco_local']; 
			$txtproximode_local = $campo_noticias['txtproximode_local']; 
			$cbo_on_off_shore = $campo_noticias['cbo_on_off_shore']; 
			$txvagalocal = $campo_noticias['txvagalocal'];
			$txvagasalario = $campo_noticias['txvagasalario'];
			$txvagaComissao = $campo_noticias['txvagaComissao'];
			$txvagaProspeccao = $campo_noticias['txvagaProspeccao'];
			$chkcartao_alimentacao = $campo_noticias['chkcartao_alimentacao']; 
			$chkalimentacao_local = $campo_noticias['chkalimentacao_local']; 
			$chklanche = $campo_noticias['chklanche'];
			$chkcesta_basica = $campo_noticias['chkcesta_basica']; 
			$chkplano_saude = $campo_noticias['chkplano_saude']; 
			$chkplano_odonto = $campo_noticias['chkplano_odonto'];
			$chkseguro_vida = $campo_noticias['chkseguro_vida'];
			$chkcarteira_assinada = $campo_noticias['chkcarteira_assinada']; 
			$chkvale_transporte= $campo_noticias['chkvale_transporte'];
			$chkpremiacao = $campo_noticias['chkpremiacao']; 
			$txvagabeneficios = $campo_noticias['txvagabeneficios'];
			$txvagatempoano = $campo_noticias['txvagatempoano']; 
			$txvagatempomes = $campo_noticias['txvagatempomes']; 
			$txvagaExpeCT = $campo_noticias['txvagaExpeCT'];
			$txvagaidademin = $campo_noticias['txvagaidademin']; 
			$txvagaidademax = $campo_noticias['txvagaidademax']; 
			$selvagaescolaridade = $campo_noticias['selvagaescolaridade'];
			$selvagaescolaridadesituacao = $campo_noticias['selvagaescolaridadesituacao'];
			$selvagacnh= $campo_noticias['selvagacnh']; 
			$selvagasexo = $campo_noticias['selvagasexo'];
			$selvagaestadocivil = $campo_noticias['selvagaestadocivil']; 
			$txvagafilhos = $campo_noticias['txvagafilhos'];
			$selvagatempo_niv = $campo_noticias['selvagatempo_niv']; 
			$selvagaidade_niv = $campo_noticias['selvagaidade_niv']; 
			$selvagaescolaridade_niv = $campo_noticias['selvagaescolaridade_niv']; 
			$selvagacnh_niv = $campo_noticias['selvagacnh_niv'];
			$selvagasexo_niv = $campo_noticias['selvagasexo_niv']; 
			$selvagaestadocivil_niv = $campo_noticias['selvagaestadocivil_niv'];
			$selvagafilhos_niv = $campo_noticias['selvagafilhos_niv'];
			$txvagaregiao = $campo_noticias['txvagaregiao'];
			$txvagahabilidades = $campo_noticias['txvagahabilidades']; 
			$txvagarestricoes = $campo_noticias['txvagarestricoes'];
			$txsemexperiencia = $campo_noticias['txsemexperiencia']; 
			$selvagaidiomas_niv = $campo_noticias['selvagaidiomas_niv'];
			$selvagainformatica_niv = $campo_noticias['selvagainformatica_niv'];
			$txtcep = $campo_noticias['txtcep'];
			$txtestado = $campo_noticias['txtestado'];
			$txtcidade = $campo_noticias['txtcidade'];
			$txtbairro = $campo_noticias['txtbairro'];
			$txtendereco = $campo_noticias['txtendereco']; 
			$txtproximode = $campo_noticias['txtproximode'];
			$txtfalarcom = $campo_noticias['txtfalarcom']; 
			$txtEmailEntrevista = $campo_noticias['txtEmailEntrevista']; 
			$txvagahorarioatend = $campo_noticias['txvagahorarioatend'];
			$selViaEncaminhamento = $campo_noticias['selViaEncaminhamento'];
			$txObs = $campo_noticias['txObs']; 
			$selvagastatus = $campo_noticias['selvagastatus']; 
			$selvagaatraves = $campo_noticias['selvagaatraves'];
			$selcidaatraves = $campo_noticias['selcidaatraves']; 
			$selpublicar = $campo_noticias['selpublicar']; 
			$dia = $campo_noticias['dia']; 
			$mes = $campo_noticias['mes']; 
			$ano = $campo_noticias['ano']; 
}

?>

<?if($id_vaga==""){$acao='cadastro';}else{$acao='editar';}?>
<form  class="form" method="post" action="script_vaga.php?acao=<?=$acao;?>&id_vaga=<?=$id_vaga;?>" id="ajax_form">

  	<h2>CADASTRO DE VAGAS </h2>
  
	
  	<!--<h3>Same fields required example</h3>-->
  	
	<div class="form-row" >
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>
		<b>Id</b>
			<input name="codigoId" value='<?=$id_vaga;?>'id="codigoId" maxlength="8" class="input req-same"onchange="Maiuscula(this);EditandoRegistro();" tabindex="2" style="font-family: Tahoma; font-size: 10px; width:42px;" type="text">
			&nbsp;
			Sigilosa
			<select name="selvagasigilosa" required='' id="selvagasigilosa" onchange="EditandoRegistro()" style="width:50px;" tabindex="4">
				<option value="<?=$selvagasigilosa;?>"><?=$selvagasigilosa;?></option>
				<option value="Não" >Não</option>
				<option value="Sim">Sim</option>
			</select>
			&nbsp;&nbsp;&nbsp;
			<b>Data de Cadastramento desta Vaga</b>
			<input name="txtDataCad"  value="<?=$dia;?>/<?=$mes;?>/<?=$ano;?>"id="txtDataCad" class="input req-same" maxlength="10" readonly="" style="font-family: Tahoma; font-size: 10px; width:55px;" tabindex="5" type="text">
		</div>
	</div >
	
	<h2>FICHA</h2>
	
	<div class="form-row" >
	    <div class="label">Nome da empresa</div>
	    <div class="input-container" >
				
				
				<?
					$id_empresa_get = $_GET['id_empresa']; 			
					$query_noticiasg = "SELECT * FROM `empresa` where id_empresa='$id_empresa_get' ";
					$rs_noticiasg    = mysql_query($query_noticiasg);						
					while($campo_noticiasg = mysql_fetch_array($rs_noticiasg)){
					$txnomeg  	= $campo_noticiasg['txnome']; 	 		 			 	
					$txCNPJg	= $campo_noticiasg['txCNPJ'];
					$id_empresag	= $campo_noticiasg['id_empresa'];
					$txtenderecoentrevista	= $campo_noticiasg['txtenderecoentrevista'];
					$txtbairroentrevista	= $campo_noticiasg['txtbairroentrevista'];
					$txtcidadeentrevista	= $campo_noticiasg['txtcidadeentrevista'];
					$txtestadoentrevista	= $campo_noticiasg['txtestadoentrevista'];
					$txtcepentrevista	= $campo_noticiasg['txtcepentrevista'];
					$txtFalarComEntrevista	= $campo_noticiasg['txtFalarComEntrevista'];
					$txtEmailEntrevista	= $campo_noticiasg['txtEmailEntrevista'];
					$txtPertoDeEntrevista	= $campo_noticiasg['txtPertoDeEntrevista'];
					$txnomecontato	= $campo_noticiasg['txnomecontato'];
					$txtel1	= $campo_noticiasg['txtel1'];
					$txtel2	= $campo_noticiasg['txtel2'];
					$txtel3	= $campo_noticiasg['txtel3'];
					
					$NecEspAuditiva =$campo_noticiasg['NecEspAuditiva']; 
					$NecEspFala =$campo_noticiasg['NecEspFala']; 
					$NecEspFisica =$campo_noticiasg['NecEspFisica']; 
					$NecEspMental =$campo_noticiasg['NecEspMental']; 
					$NecEspVisual =$campo_noticiasg['NecEspVisual']; 
					$NecEspAuditivaTipo =$campo_noticiasg['NecEspAuditivaTipo']; 
					$NecEspAuditivaUniBi =$campo_noticiasg['NecEspAuditivaUniBi']; 
					$NecEspFalaTipo =$campo_noticiasg['NecEspFalaTipo']; 
					$NecEspFisicaTipo =$campo_noticiasg['NecEspFisicaTipo']; 
					$NecEspFisicaInfSup =$campo_noticiasg['NecEspFisicaInfSup']; 
					$NecEspVisualTipo =$campo_noticiasg['NecEspVisualTipo']; 
					$NecEspVisualUniBi =$campo_noticiasg['NecEspVisualUniBi']; 
					$NecEspComunic =$campo_noticiasg['NecEspComunic']; 
					$NecEspHabSocial =$campo_noticiasg['NecEspHabSocial']; 
					$NecEspSaudeSeg =$campo_noticiasg['NecEspSaudeSeg']; 
					$NecEspComunic =$campo_noticiasg['NecEspComunic']; 
					$NecEspHabSocial =$campo_noticiasg['NecEspHabSocial'];  
					$NecEspLazer =$campo_noticiasg['NecEspLazer']; 
					$NecEspCuidadoPess =$campo_noticiasg['NecEspCuidadoPess']; 
					$NecEspRecursosCom =$campo_noticiasg['NecEspRecursosCom']; 
					$NecEspHabAcad =$campo_noticiasg['NecEspHabAcad']; 
					$NecEspTrabalho =$campo_noticiasg['NecEspTrabalho']; 
					}
				?>
				<select name='selnome_get' style='width:546px;'  onchange="location = this.options[this.selectedIndex].value;">	
					<option value='<?=$id_empresag;?>'><?=$txCNPJg;?>-<?=$txnomeg;?></option>	

							
					<?
					if($id_vaga==""){
					$query_noticias = "SELECT * FROM `empresa` ORDER BY `empresa`.`txnome` ASC";
					$rs_noticias    = mysql_query($query_noticias); 
					$total = mysql_num_rows($rs_noticias);	
					while($campo_noticias = mysql_fetch_array($rs_noticias)){
					$txnome  	= $campo_noticias['txnome']; 	 		 			 	
					$txCNPJ	= $campo_noticias['txCNPJ'];
					$id_empresa	= $campo_noticias['id_empresa'];
					?>
					<option value='cadastro_vagas.php?id_empresa=<?=$id_empresa;?>'> <?=$txnome;?> - <?=$txCNPJ;?> </option>
					<?}}
					else
					{}
					?>
					
				</select>
				
			<input type='hidden' name='id_empresa' value='<?=$id_empresa_get;?>'/>
		</div>
	</div >
	
	<?if($id_empresa_get==""){}else{?>
	<!-------------------------------------------------if---------------------------------------------------------------->
	
	<div class="form-row" >
	    <div class="label">Contato:</div>
	    <div class="input-container" style='width:546px;'>
		<input name="selcontatos"value="<?=$txnomecontato;?> - <?=$txtel1;?> / <?=$txtel2;?> / <?=$txtel3;?>" id="selcontatos"class="input req-same"  disabled="" type="text">
		</div>
	</div >
	
	<h2>DADOS DA VAGA</h2>
	
	<div class="form-row" >
	    <div class="label">Ocupação</div>
	    <div class="input-container" style='width:546px;'>		
		<input name="txcbonome" required value="<?=$txcbonome;?>"id="txcbonome" maxlength="200"class="input req-same"onkeydown="EditandoRegistro()" onchange="Maiuscula(this);EditandoRegistro();"  tabindex="8" type="text">
		</div>
	</div >
	
	<div class="form-row" >
	    <div class="label">Descrição da Vaga</div>
	    <div class="input-container" style='width:546px;'>		
			<textarea name="txtdescrvaga" required style='height:63px;' id="txtdescrvaga" rows="3" cols="99" tabindex="11" style="font-size: 12px; font-family: Arial;" class="input req-same" onkeyup="funTamanhoCerto('window.document.Ficha.txtdescrvaga', 500);" onchange="Maiuscula(this);EditandoRegistro();"><?=$txtdescrvaga;?></textarea>
		</div>
	</div >
	
	<div class="form-row" >
	    <div class="label">Cargo</div>
	    <div class="input-container" style='width:546px;'>		
		<input name="txcargo" id="txcargo" required value="<?=$txcargo;?>"maxlength="100" onkeydown="EditandoRegistro()" class="input req-same"tabindex="12" type="text">
		</div>
	</div >
	
	<div class="form-row" >
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
		Data da Vaga
			<input name="txvagadata" value="<?=$txvagadata;?>"  id="txvagadata" maxlength="10" class="input req-same" onkeydown="EditandoRegistro()" onblur="verificaData('window.document.Ficha.txvagadata')" onkeyup="VerificaMascara('window.document.Ficha.txvagadata','##/##/####',1)" style="width:53px;" tabindex="13" type="text">
			Horário de Trabalho
			<input name="txvagahorario" value="<?=$txvagahorario;?>" id="txvagahorario" maxlength="30" class="input req-same" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" style="width:138px;" tabindex="14" type="text">
			Aceita Deficientes
			<select name="selvagadeficiente" id="selvagadeficiente" onchange="EditandoRegistro()" style="width:50px;" tabindex="15">
				<option value="<?=$selvagadeficiente;?>"><?=$selvagadeficiente;?></option>
				<option value="Não" >Não</option>
				<option value="Sim">Sim</option>
			</select>
		</div>
	</div >	
	
	<div class="form-row" >
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
		Disponibilizadas
			<input name="txvagaquantidade" value='<?=$txvagaquantidade;?>'id="txvagaquantidade" maxlength="10"  class="input req-same"onblur="AjustaVagasAtivas();" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.txvagaquantidade');" style="width:24px;" tabindex="16" type="text">
			&nbsp;
			Preenchidas por: CTM
			<input name="txvagapreenchidaCTM" value='<?=$txvagapreenchidaCTM;?>' id="txvagapreenchidaCTM" maxlength="10" class="input req-same" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.txvagapreenchidaCTM');" onblur="AjustaVagasAtivas();" style="width:24px;" tabindex="17" type="text">
			Outros
			<input name="txvagapreenchidaOutros" value='<?=$txvagapreenchidaOutros;?>' id="txvagapreenchidaOutros" class="input req-same"maxlength="10" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.txvagapreenchidaOutros');" onblur="AjustaVagasAtivas();" style="width:24px;" tabindex="18" type="text">
			Canceladas
			<input name="txvagaCancelada" value='<?=$txvagaCancelada;?>' id="txvagaCancelada" maxlength="10" class="input req-same"onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.txvagaCancelada');" onblur="AjustaVagasAtivas();" style="width:24px;" tabindex="19" type="text">
			&nbsp;
			Ativas
			<input name="txvagasativas" value='<?=$txvagasativas;?>'  id="txvagasativas" maxlength="10" class="input req-same" style="width:24px;" tabindex="20" readonly="" type="text">
		</div>
	</div >
	
	
	<div class="form-row" >
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
		Encaminhar para Seleção
			<input name="txEncaminhar" id="txEncaminhar" value='<?=$txEncaminhar;?>'  maxlength="3" class="input req-same"onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" onkeyup="verificaNumero('window.document.Ficha.txEncaminhar');" style="width:31px;" tabindex="21" type="text">
			Até que dia enviar encaminhamentos
			<input name="txvagadataenc" id="txvagadataenc" value='<?=$txvagadataenc;?>'  maxlength="10" class="input req-same" onkeydown="EditandoRegistro()" onblur="verificaData('window.document.Ficha.txvagadataenc')" onkeyup="VerificaMascara('window.document.Ficha.txvagadataenc','##/##/####',1)" style="width:53px;" tabindex="22" type="text">
			&nbsp;
			Temporária ?
			<input name="chktemporaria" id="chktemporaria"   <?if($chktemporaria=="on"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="23" type="Checkbox">
		</div>
	</div >
	
	<h2>Local da Vaga</h2>
	
	
	<div class="form-row" >
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
		<b>CEP</b>
			<input name="txtcep_local" id="txtcep_local" value='<?=$txtcep_local;?>'  maxlength="8" onchange="EditandoRegistro();" class="input req-same" onkeyup="verificaNumero('window.document.Ficha.txtcep_local');" tabindex="24" style="width:65px;" type="text">
			<b>Estado</b>
			<select name="txtestado_local" id="txtestado_local" onchange="EditandoRegistro()" tabindex="25" style="width:40px;">
				<option value="<?=$txtestado_local;?>"><?=$txtestado_local;?></option>
				<option value="AC">AC</option>
				<option value="AL">AL</option>
				<option value="AM">AM</option>
				<option value="AP">AP</option>
				<option value="BA">BA</option>
				<option value="CE">CE</option>
				<option value="DF">DF</option>
				<option value="ES">ES</option>
				<option value="GO">GO</option>
				<option value="MA">MA</option>
				<option value="MT">MT</option>
				<option value="MS">MS</option>
				<option value="MG">MG</option>
				<option value="PA">PA</option>
				<option value="PB">PB</option>
				<option value="PR">PR</option>
				<option value="PE">PE</option>
				<option value="PI">PI</option>
				<option value="RJ">RJ</option>
				<option value="RN">RN</option>
				<option value="RS">RS</option>
				<option value="RO">RO</option>
				<option value="RR">RR</option>
				<option value="SC">SC</option>
				<option value="SP">SP</option>
				<option value="SE">SE</option>
				<option value="TO">TO</option>
			</select>
			<b>Cidade</b>
			<input name="txtcidade_local" value="<?=$txtcidade_local;?>" id="txtcidade_local" maxlength="100" style='width:200px;' onchange="Maiuscula(this);EditandoRegistro();" tabindex="26" class="input req-same" type="text">
		</div>
	</div >
	
	
	
	<div class="form-row">
	    <div class="label">Bairro</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtbairro_local"  value="<?=$txtbairro_local;?>" id="txtbairro_local" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="27" class="input req-same" type="text">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Endereço</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtendereco_local"  value="<?=$txtendereco_local;?>"  id="txtendereco_local"  maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="28" class="input req-same" type="text">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<b>Próximo de</b>
			<input name="txtproximode_local" value="<?=$txtproximode_local;?>"  id="txtproximode_local" class="input req-same" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="29" style="width:383px;" type="text">

			<select name="cbo_on_off_shore" id="cbo_on_off_shore" onchange="EditandoRegistro()" style="width:68px;" tabindex="30">
				<option value="<?=$cbo_on_off_shore;?>"><?=$cbo_on_off_shore;?></option>
				<option value="On-Shore">On-Shore</option>
				<option value="OFF-Shore">Off-Shore</option>
			</select>
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Local da Vaga</div>
	    <div class="input-container" style='width:546px;'>		
			
			<input name="txvagalocal" id="txvagalocal"  value="<?=$txvagalocal;?>"  maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" class="input req-same" tabindex="31" type="text">
		</div>
	</div>
	<h2>SALÁRIOS
	</h2>
	<script type="text/javascript">
		$(function(){
			$("#txvagasalario").maskMoney({symbol:'R$ ',showSymbol:true, thousands:'.', decimal:',', symbolStay: true});
			
		})
		</script>
	<div class="form-row">
	    <div class="label">Salário Fixo</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txvagasalario" value='<?=$txvagasalario;?>' id="txvagasalario" class="input req-same" maxlength="10" onkeydown="EditandoRegistro()" onkeyup="VerificaMascara('window.document.Ficha.txvagasalario','###.###.###,##',0);"  tabindex="32" type="text">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Comissão</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txvagaComissao" value='<?=$txvagaComissao;?>'  id="txvagaComissao" class="input req-same" maxlength="20" onkeydown="EditandoRegistro()" tabindex="33" type="text">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Prospecção</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txvagaProspeccao"  value='<?=$txvagaProspeccao;?>' id="txvagaProspeccao" class="input req-same"maxlength="20" onkeydown="EditandoRegistro()"  tabindex="34" type="text">
		</div>
	</div>
	
		<h2>BENEFÍCIOS</h2>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<table style="width:100%;" align="left" border="0">
	<tbody>
	<tr  align="left">
		<td>
			<input name="chkcartao_alimentacao"  id="chkcartao_alimentacao" <?if($chkcartao_alimentacao=="on"){echo"checked=''";}else{}?>onclick="EditandoRegistro()" tabindex="35" type="Checkbox" />
			Cartão Alimentação
		</td>
		<td>
			<input name="chkplano_saude" id="chkplano_saude" <?if($chkplano_saude=="on"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="36" type="Checkbox">
			Plano de Saúde
		</td>
		<td>
			<input name="chkcarteira_assinada" id="chkcarteira_assinada"  <?if($chkcarteira_assinada=="on"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="37" type="Checkbox">
			Carteira Assinada
		</td>
	</tr>
	<tr align="left">
		<td>
			<input name="chkalimentacao_local" id="chkalimentacao_local" <?if($chkalimentacao_local=="on"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="38" type="Checkbox">
			Alimentação no Local
		</td>
		<td>
			<input name="chkplano_odonto" id="chkplano_odonto" <?if($chkplano_odonto=="on"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="39" type="Checkbox">
			Plano Odontológico
		</td>
		<td>
			<input name="chkvale_transporte" id="chkvale_transporte" <?if($chkvale_transporte=="on"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="40" type="Checkbox">
			Vale Transporte
		</td>
	</tr>
	<tr align="left">
		<td>
			<input name="chklanche" id="chklanche" <?if($chklanche=="on"){echo"checked=''";}else{}?>  onclick="EditandoRegistro()" tabindex="41" type="Checkbox">
			Lanche
		</td>
		<td>
			<input name="chkseguro_vida" id="chkseguro_vida" <?if($chkseguro_vida=="on"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="42" type="Checkbox">
			Seguro de Vida
		</td>
		<td>
			<input name="chkpremiacao" id="chkpremiacao" <?if($chkpremiacao=="on"){echo"checked=''";}else{}?>  onclick="EditandoRegistro()" tabindex="43" type="Checkbox">
			Premiação
		</td>
	</tr>
	<tr align="left">
		<td>
			<input name="chkcesta_basica" id="chkcesta_basica" <?if($chkcesta_basica=="on"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="44" type="Checkbox">
			Cesta Básica
		</td>
		<td colspan="2" align="right">
			Outros Beneficios
			<input name="txvagabeneficios" value='<?=$txvagabeneficios;?>' id="txvagabeneficios" maxlength="100" onkeydown="EditandoRegistro()" class="input req-same" onchange="Maiuscula(this)" style="width:250px;" tabindex="45" type="text">
		</td>
	</tr>
</tbody></table>
		</div>
	</div>
	
	
	
	
	<h2>Requisitos</h2>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			
			<table style="width:100%;" align="left" border="0">
	<tbody><tr align="left" >
		<td colspan="2" align="left" >
			<h2>Requisitos</h2>
	
		</td>
		<td  align="left"  >
			<h2>Importância</h2>
		</td>
	</tr>
	<tr align="left" >
		<td style="width:200px;">
			Tempo de Experiência<font class='simbolo'>&#10045;</font>
		</td>
		<td align="left">
			Anos
			<input name="txvagatempoano" value='<?=$txvagatempoano;?>'  class="input req-same" id="txvagatempoano" maxlength="10" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.txvagatempoano');" style="width:15px;" tabindex="46" type="text">
			Mêses
			<input name="txvagatempomes" value='<?=$txvagatempomes;?>'  class="input req-same" id="txvagatempomes" maxlength="10" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.txvagatempomes');" style="width:15px;" tabindex="47" type="text">
			Comprovada 
			<input name="txvagaExpeCT"  id="txvagaExpeCT" tabindex="48"  <?if($txvagaExpeCT=="on"){echo"checked=''";}else{}?> type="Checkbox">
		</td>
		<td style="width:90px;" align="center">
			<select name="selvagatempo_niv" id="selvagatempo_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="49">
				<option value="<?=$selvagatempo_niv;?>"><?=$selvagatempo_niv;?></option>
				
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td style="width:200px;">
			Idade do Candidato
		</td>
		<td align="left">
			Mínima
			<input name="txvagaidademin" value="<?=$txvagaidademin;?>"class="input req-same"id="txvagaidademin" maxlength="2" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.txvagaidademin');" style="width:15px;" tabindex="50" type="text">
			Máxima
			<input name="txvagaidademax" value="<?=$txvagaidademax;?>" class="input req-same" id="txvagaidademax" maxlength="2" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.txvagaidademax');" style="width:15px;" tabindex="51" type="text">
		</td>
		<td style="width:90px;" align="center">
			<select name="selvagaidade_niv" id="selvagaidade_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="52">
				<option value="<?=$selvagaidade_niv;?>"><?=$selvagaidade_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td>
			Escolaridade / Situação
		</td>
		<td align="left">
			<select name="selvagaescolaridade" id="selvagaescolaridade" onchange="EditandoRegistro()" style="width:90px;" tabindex="53">
				<option value="<?=$selvagaescolaridade;?>"><?=$selvagaescolaridade;?></option>
				<option value="Fundamental">Fundamental</option>
				<option value="Médio">Médio</option>
				<option value="Pós-Médio">Pós-Médio</option>
				<option value="Superior">Superior</option>
			</select>
			

			<select name="selvagaescolaridadesituacao" id="selvagaescolaridadesituacao" onchange="EditandoRegistro()" style="width:90px;" tabindex="54">
				<option value="<?=$selvagaescolaridadesituacao;?>"><?=$selvagaescolaridadesituacao;?></option>
				<option value="Incompleto">Incompleto</option>
				<option value="Cursando">Cursando</option>
				<option value="Completo">Completo</option>
			</select>
		</td>
		<td style="width:90px;" align="center">
			<select name="selvagaescolaridade_niv" id="selvagaescolaridade_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="55">
				<option value="<?=$selvagaescolaridade_niv;?>"><?=$selvagaescolaridade_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td>
			Categoria CNH
		</td>
		<td align="left">
			<select name="selvagacnh" id="selvagacnh" onchange="EditandoRegistro()" style="width:90px;" tabindex="56">
				<option value="<?=$selvagacnh;?>"><?=$selvagacnh;?></option>
				<option value="A">A</option>
				<option value="B">B</option>
				<option value="C">C</option>
				<option value="D">D</option>
				<option value="E">E</option>
				<option value="AB">AB</option>
				<option value="AC">AC</option>
				<option value="AD">AD</option>
				<option value="AE">AE</option>
			</select>
			
		</td>
		<td style="width:90px;" align="center">
			<select name="selvagacnh_niv" id="selvagacnh_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="57">
				<option value="<?=$selvagacnh_niv;?>"><?=$selvagacnh_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td>
			Gênero
		</td>
		<td align="left">
			<select name="selvagasexo" id="selvagasexo" onchange="EditandoRegistro()" style="width:90px;" tabindex="58">
				<option value="<?=$selvagasexo;?>"><?=$selvagasexo;?></option>
				
				<option value="Masculino">Masculino</option>
				<option value="Masculino">Masculino</option>
			</select>
			
		</td>
		<td style="width:90px;" align="center">
			<select name="selvagasexo_niv" id="selvagasexo_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="59">
				<option value="<?=$selvagasexo_niv;?>"><?=$selvagasexo_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td>
			Estado Civil
		</td>
		<td align="left">
			<select name="selvagaestadocivil" id="selvagaestadocivil" onchange="EditandoRegistro()" style="width:90px;" tabindex="60">
					<option value="<?=$selvagaestadocivil;?>"><?=$selvagaestadocivil;?></option>
					<option value="S">Solteiro</option>
					<option value="C">Casado</option>
					<option value="U">União Estável</option>
					<option value="Q">Desquitado</option>
					<option value="D">Divorciado</option>
					<option value="V">Viúvo</option>
			</select>
			
		</td>
		<td style="width:90px;" align="center">
			<select name="selvagaestadocivil_niv" id="selvagaestadocivil_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="61">
				<option value="<?=$selvagaestadocivil_niv;?>"><?=$selvagaestadocivil_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td>
			Número Máximo de Dependentes
		</td>
		<td align="left">
			<input name="txvagafilhos" value="<?=$txvagafilhos;?>" id="txvagafilhos" maxlength="10" onkeydown="EditandoRegistro()" class="input req-same" onkeyup="verificaNumero('window.document.Ficha.txvagafilhos');" style="width:90px;" tabindex="62" type="text">
		</td>
		<td style="width:90px;" align="center">
			<select name="selvagafilhos_niv" id="selvagafilhos_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="63">
				<option value="<?=$selvagafilhos_niv;?>"><?=$selvagafilhos_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td colspan="2">
			Região
			<input name="txvagaregiao"  value="<?=$txvagaregiao;?>" id="txvagaregiao" maxlength="100" onkeydown="EditandoRegistro()" class="input req-same" onchange="Maiuscula(this)" style="width:376px;" tabindex="64" type="text">
		</td>
		<td style="width:90px;display:none;" align="center">
			<select name="selvagaregiao_niv" id="selvagaregiao_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="65">
				<option value="<?=$selvagaregiao_niv;?>"><?=$selvagaregiao_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td colspan="2">
			Habilidades
			<input name="txvagahabilidades" value="<?=$txvagahabilidades;?>" id="txvagahabilidades" maxlength="400" class="input req-same" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" style="width:353px;" tabindex="66" type="text">
		</td>
		<td style="width:90px;display:none;" align="center">
			<select name="selvagahabilidades_niv" id="selvagahabilidades_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="67">
				<option value="<?=$selvagahabilidades_niv;?>"><?=$selvagahabilidades_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td colspan="2">
			Restrições
			<input name="txvagarestricoes" value="<?=$txvagarestricoes;?>"id="txvagarestricoes" maxlength="200" onkeydown="EditandoRegistro()" class="input req-same" onchange="Maiuscula(this)" style="width:358px;" tabindex="68" type="text">
		</td>
		<td style="width:90px;display:none;" align="center">
			<select name="selvagarestricoes_niv" id="selvagarestricoes_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="69">
				<option value="<?=$selvagarestricoes_niv;?>"><?=$selvagarestricoes_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td colspan="3">
			Aceita sem Experiência
			<input name="txsemexperiencia" id="txsemexperiencia"  <?if($txsemexperiencia=="on"){echo"checked=''";}else{}?>  onchange="EditandoRegistro()" tabindex="70" type="Checkbox">
		</td>
	</tr>
	<tr align="left" >
		<td colspan="2">
			<input value="Idiomas" value="<?=$btIdiomas;?>" id="btIdiomas" name="btIdiomas" disabled="" onclick="NovoIdioma()" style="width:417px;" tabindex="71" type="button"> 
		</td>
		<td style="width:90px;" align="center">
			<select name="selvagaidiomas_niv" id="selvagaidiomas_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="72">
				<option value="<?=$selvagaidiomas_niv;?>"><?=$selvagaidiomas_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
	<tr align="left" >
		<td colspan="2">
			<input value="Informática" id="btSoftwares" class="input req-same" name="btSoftwares" disabled="" onclick="NovoInfo()" style="width:417px;" tabindex="73" type="button"> 
		</td>
		<td style="width:90px;" align="center">
			<select name="selvagainformatica_niv" id="selvagainformatica_niv" onchange="EditandoRegistro()" style="width:85px;" tabindex="74">
				<option value="<?=$selvagainformatica_niv;?>"><?=$selvagainformatica_niv;?></option>
				<option value="Desejável">Desejável</option>
				<option value="Imprescindível">Imprescindível</option>
			</select>
		</td>
	</tr>
</tbody></table>
		
		</div>
	</div>
	
	<h2>ENTREVISTA</h2>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<b>CEP</b>
			<input name="txtcep" value="<?if($id_vaga==""){echo $txtcepentrevista;}else{ echo $txtcep;}?>" id="txtcep" maxlength="8" class="input req-same" onchange="EditandoRegistro();" onkeyup="verificaNumero('window.document.Ficha.txtcep');" tabindex="75" style="width:65px;" type="text">
			<b>Estado</b>
			<select name="txtestado" id="txtestado" onchange="EditandoRegistro()" tabindex="76" style="width:40px;">
				<option value="<?if($id_vaga==""){echo $txtestadoentrevista;}else{ echo $txtestado;}?>"><?if($id_vaga==""){echo $txtestadoentrevista;}else{ echo $txtestado;}?></option>
				<option value="AC">AC</option>
				<option value="AL">AL</option>
				<option value="AM">AM</option>
				<option value="AP">AP</option>
				<option value="BA">BA</option>
				<option value="CE">CE</option>
				<option value="DF">DF</option>
				<option value="ES">ES</option>
				<option value="GO">GO</option>
				<option value="MA">MA</option>
				<option value="MT">MT</option>
				<option value="MS">MS</option>
				<option value="MG">MG</option>
				<option value="PA">PA</option>
				<option value="PB">PB</option>
				<option value="PR">PR</option>
				<option value="PE">PE</option>
				<option value="PI">PI</option>
				<option value="RJ">RJ</option>
				<option value="RN">RN</option>
				<option value="RS">RS</option>
				<option value="RO">RO</option>
				<option value="RR">RR</option>
				<option value="SC">SC</option>
				<option value="SP">SP</option>
				<option value="SE">SE</option>
				<option value="TO">TO</option>
			</select>
			<b>Cidade</b>
			<input name="txtcidade" value=" <?if($id_vaga==""){echo $txtcidadeentrevista;}else{ echo $txtcidade;}?>" id="txtcidade" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="77" style="width:307px;" type="text">	
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Bairro</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtbairro" value=" <?if($id_vaga==""){echo $txtbairroentrevista;}else{ echo $txtbairro;}?>"  id="txtbairro" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="78"  type="text">
				
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Endereço</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtendereco" value="<?if($id_vaga==""){echo $txtenderecoentrevista;}else{ echo $txtendereco;}?>"  id="txtendereco" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="79" type="text">
				
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Próximo de</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtproximode" value="<?if($id_vaga==""){echo $txtPertoDeEntrevista;}else{ echo $txtproximode;}?>" id="txtproximode" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="80"  type="text">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Falar com</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtfalarcom" value=" <?if($id_vaga==""){echo $txtFalarComEntrevista;}else{ echo $txtfalarcom;}?>" id="txtfalarcom" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="81"  type="text">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Email</div>
	    <div class="input-container" style='width:546px;'>		
			<input name="txtEmailEntrevista" value="<?if($id_vaga==""){echo $txtEmailEntrevista;}else{ echo $txtEmailEntrevista;}?>" id="txtEmailEntrevista" class="input req-same" maxlength="100" onchange="EditandoRegistro();" tabindex="82"  type="text">
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Horário de Atendimento e outros Detalhes</div>
	    <div class="input-container" style='width:546px;'>		
			<textarea name="txvagahorarioatend" value="<?=$txvagahorarioatend;?>"  id="txvagahorarioatend"  style='width:100%;height:50px;'class="input req-same"  rows="3" cols="99" tabindex="83" style="font-size: 12px; font-family: Arial;" onkeyup="funTamanhoCerto('window.document.Ficha.txvagahorarioatend', 500);" onchange="Maiuscula(this);EditandoRegistro();"><?=$txvagahorarioatend;?></textarea>
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Encaminhar Via</div>
	    <div class="input-container" style='width:546px;'>		
			<select name="selViaEncaminhamento"  required  id="selViaEncaminhamento" onchange="EditandoRegistro()"  tabindex="84">
				<option value="<?=$selViaEncaminhamento;?>"><?=$selViaEncaminhamento;?></option>
				<option value="Ir ao Endereço">Ir ao Endereço</option>
				<option value="Ligar Antes">Ligar Antes</option>
				<option value="Email (Currículo)">Email (Currículo)</option>
			</select>
		</div>
	</div>
	
	
	
	<h2>OBSERVAÇÕES</h2>
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<textarea name="txObs" id="txObs" rows="3" cols="99" style='width:100%;height:50px;'class="input req-same"  tabindex="85" style="font-size: 12px; font-family: Arial;" onkeyup="funTamanhoCerto('window.document.Ficha.txObs', 500);" onchange="Maiuscula(this);EditandoRegistro();"><?=$txObs;?></textarea>
		</div>
	</div>
	
	
	
	
	<div class="form-row">
	    <div class="label">Status da Vaga </div>
	    <div class="input-container" style='width:546px;'>		
			<select name="selvagastatus" required id="selvagastatus" onchange="EditandoRegistro()"  tabindex="86">
				<option value="<?=$selvagastatus;?>"><?=$selvagastatus;?></option>
				<option value="Ativa" >Ativa</option>
				<option value="Suspensa">Suspensa</option>
				<option value="Preenchida pelo CTM">Preenchida pelo CTM</option>
				<option value="Preenchida pelo Solicitante">Preenchida pelo Solicitante</option>
				<option value="Cancelada">Cancelada</option>
				<option value="Encerrada">Encerrada</option>
				<option value="Aguardando Resposta">Aguardando Resposta</option>
				<option value="NPFP">NPFP</option>
			</select>
		</div>
	</div>
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			Através de
			<select name="selvagaatraves" required id="selvagaatraves" onchange="EditandoRegistro()" style="width:235px;" tabindex="88">
				<option value="<?=$selvagaatraves;?>"><?=$selvagaatraves;?></option>
			<option value="ESPONTÂNEA">ESPONTÂNEA</option>&lt;<option value="INTERNET">INTERNET</option>&lt;<option value="TELEMARKETING">TELEMARKETING</option>&lt;<option value="VISITA">VISITA</option>&lt;	
			</select>
			Referência
			<select name="selcidaatraves" required id="selcidaatraves" onchange="EditandoRegistro()" tabindex="89" style="width:162px;">
				<option value="<?=$selcidaatraves;?>"><?=$selcidaatraves;?></option>
						<?
						$query_noticiascp2l = "SELECT * FROM `local_captacao` ORDER BY `local_captacao`.`local` ASC";
						$rs_noticiascp2l    = mysql_query($query_noticiascp2l);
						while($campo_noticiascp2l = mysql_fetch_array($rs_noticiascp2l)){
						$local       = $campo_noticiascp2l['local'];	

						?>
						<option value="<?=$local ;?>"><?=$local ;?></option>
						<?}?>
			</select>
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Publicar em </div>
	    <div class="input-container" style='width:546px;'>		
			<select name="selpublicar" required id="selpublicar" onchange="EditandoRegistro()"  tabindex="90">
				<option value="<?=$selpublicar;?>"><?=$selpublicar;?></option>
				<option value="Não Publicar" >Não Publicar</option>
				<option value="Apenas no Mural">Apenas no Mural</option>
				<option value="Apenas na Internet">Apenas na Internet</option>
				<option value="Todas as Mídias">Todas as Mídias</option>
			</select>
		</div>
	</div>
	
	
	
	
	
	
	
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<input id="submitBtn2" value="Salvar" type="submit" class="sendBtn" />
				<div id="errorDiv2" class="error-div"></div>
		</div>
	</div>
	
	<?}?>
	
<!-------------------------------------------------if---------------------------------------------------------------->
</form>



</body>
</html>
