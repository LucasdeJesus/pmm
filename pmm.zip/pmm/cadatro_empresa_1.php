<?include"interno/input_banco.php"?>

<html>
<?include'topo.php';?>

<body>

		<?include"topo_logo.php";?>
	
	
		<?
			///cadastro usuario
		$senha 	=(string)addslashes($_POST['senha']); 
		$usuario 	=(string)addslashes($_POST['usuario']); 
		$nome 	=(string)addslashes($_POST['nome']); 		
		if($usuario==""){}else{
		$queryusuario="INSERT INTO usuario (`usuario`, `nome`,`senha`,`perfil`)VALUES ('$usuario','$nome','$senha','E' )";	
		$rsusuario= mysql_query($queryusuario);
	

		?>
		
		<SCRIPT language="JavaScript">window.location.href="login.php?msg=Cadastro salvo!Realize seu Login";</SCRIPT>
		<?
			exit;
			}	/// fim cadastro usuario
			
		?>
	
		<div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);margin-top:50px;' align='center' >
			<table width='960px'>
					<tr>
					
					
						<td width='460'>
																	
									<script type="text/javascript">
									
									$(document).ready(function(){									
										$("#cadastro_empresa").validate();										
										$.validator.setDefaults({
									submitHandler: function() {
										
										}
										});
										});
			
									function mascaraMutuario(o,f){
										v_obj=o
										v_fun=f
										setTimeout('execmascara()',1)
									}
									 
									function execmascara(){
										v_obj.value=v_fun(v_obj.value)
									}
									 
									function cpfCnpj(v){
									 
										//Remove tudo o que não é dígito
										v=v.replace(/\D/g,"")
									 
										if (v.length <= 13) { //CPF
									 
											//Coloca um ponto entre o terceiro e o quarto dígitos
											v=v.replace(/(\d{3})(\d)/,"$1.$2")
									 
											//Coloca um ponto entre o terceiro e o quarto dígitos
											//de novo (para o segundo bloco de números)
											v=v.replace(/(\d{3})(\d)/,"$1.$2")
									 
											//Coloca um hífen entre o terceiro e o quarto dígitos
											v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")	
											
											
									 
										} else { //CNPJ
									 
											//Coloca ponto entre o segundo e o terceiro dígitos
											v=v.replace(/^(\d{2})(\d)/,"$1.$2")
									 
											//Coloca ponto entre o quinto e o sexto dígitos
											v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
									 
											//Coloca uma barra entre o oitavo e o nono dígitos
											v=v.replace(/\.(\d{3})(\d)/,".$1/$2")
									 
											//Coloca um hífen depois do bloco de quatro dígitos
											v=v.replace(/(\d{4})(\d)/,"$1-$2")
									 
										}
										
										
										
										return v
									 
									}
												</script>
												
												
												<?
												
																												
																////////////////////////////////////valida cnp pj php
																/**
																 * Valida CNPJ
																 *
																 * @author Luiz Otávio Miranda <contato@tutsup.com>
																 * @param string $cnpj 
																 * @return bool true para CNPJ correto
																 *
																 */
																function valida_cnpj ( $cnpj ) {
																	// Deixa o CNPJ com apenas números
																	$cnpj = preg_replace( '/[^0-9]/', '', $cnpj );
																	
																	// Garante que o CNPJ é uma string
																	$cnpj = (string)$cnpj;
																	
																	// O valor original
																	$cnpj_original = $cnpj;
																	
																	// Captura os primeiros 12 números do CNPJ
																	$primeiros_numeros_cnpj = substr( $cnpj, 0, 12 );
																	
																	/**
																	 * Multiplicação do CNPJ
																	 *
																	 * @param string $cnpj Os digitos do CNPJ
																	 * @param int $posicoes A posição que vai iniciar a regressão
																	 * @return int O
																	 *
																	 */
																	function multiplica_cnpj( $cnpj, $posicao = 5 ) {
																		// Variável para o cálculo
																		$calculo = 0;
																		
																		// Laço para percorrer os item do cnpj
																		for ( $i = 0; $i < strlen( $cnpj ); $i++ ) {
																			// Cálculo mais posição do CNPJ * a posição
																			$calculo = $calculo + ( $cnpj[$i] * $posicao );
																			
																			// Decrementa a posição a cada volta do laço
																			$posicao--;
																			
																			// Se a posição for menor que 2, ela se torna 9
																			if ( $posicao < 2 ) {
																				$posicao = 9;
																			}
																		}
																		// Retorna o cálculo
																		return $calculo;
																	}
																	
																	// Faz o primeiro cálculo
																	$primeiro_calculo = multiplica_cnpj( $primeiros_numeros_cnpj );
																	
																	// Se o resto da divisão entre o primeiro cálculo e 11 for menor que 2, o primeiro
																	// Dígito é zero (0), caso contrário é 11 - o resto da divisão entre o cálculo e 11
																	$primeiro_digito = ( $primeiro_calculo % 11 ) < 2 ? 0 :  11 - ( $primeiro_calculo % 11 );
																	
																	// Concatena o primeiro dígito nos 12 primeiros números do CNPJ
																	// Agora temos 13 números aqui
																	$primeiros_numeros_cnpj .= $primeiro_digito;
																 
																	// O segundo cálculo é a mesma coisa do primeiro, porém, começa na posição 6
																	$segundo_calculo = multiplica_cnpj( $primeiros_numeros_cnpj, 6 );
																	$segundo_digito = ( $segundo_calculo % 11 ) < 2 ? 0 :  11 - ( $segundo_calculo % 11 );
																	
																	// Concatena o segundo dígito ao CNPJ
																	$cnpj = $primeiros_numeros_cnpj . $segundo_digito;
																	
																	// Verifica se o CNPJ gerado é idêntico ao enviado
																	if ( $cnpj === $cnpj_original ) {
																		return true;
																	}
																}
																////////////////////////////////////valida cnp pj php
																
																
													function mask($val, $mask)
													{
													 $maskared = '';
													 $k = 0;
													 for($i = 0; $i<=strlen($mask)-1; $i++)
													 {
													 if($mask[$i] == '#')
													 {
													 if(isset($val[$k]))
													 $maskared .= $val[$k++];
													 }
													 else
													 {
													 if(isset($mask[$i]))
													 $maskared .= $mask[$i];
													 }
													 }
													 return $maskared;
													}



												$busca_cnpjget = $_GET['txCNPJ'];
												$vowels = array(".","-","/"," ","","(",")");
												$format_numero12 = str_replace($vowels, "", "$busca_cnpjget");														
												$busca_cnpj =  mask($format_numero12,'##.###.###/####-##');
												
												if (valida_cnpj('$busca_cnpj') ) {
												
												} else {

												}

												
												if($busca_cnpj==""){header("Location: index.php");}
												
											if($busca_cnpj==""){}else{
											$query_noticias = "SELECT * FROM `empresa` WHERE cnpj LIKE '%$busca_cnpj%'";
											$rs_noticias    = mysql_query($query_noticias);
											while($campo_noticias = mysql_fetch_array($rs_noticias)){
											$cnpj 	= $campo_noticias['cnpj']; 	 		 			 	
											$selTipo	= $campo_noticias['selTipo']; 	 		 			 	
											$razaosocial	= $campo_noticias['razaosocial']; 	 		 			 	
											$nome	= $campo_noticias['nome']; 	 		 			 	
											$segmentoatuacaoid	= $campo_noticias['segmentoatuacaoid']; 	 		 			 	
											$inscmunicipal	= $campo_noticias['inscmunicipal']; 	 		 			 	
											$inscestadual	= $campo_noticias['inscestadual']; 	 		 			 	
											$endereco	= $campo_noticias['endereco']; 	 		 			 	
											$bairro	= $campo_noticias['bairro']; 	 		 			 	
											$cidadeid	= $campo_noticias['cidadeid']; 			 			 	
											$cep	= $campo_noticias['cep']; 
											$emailresponsavel	= $campo_noticias['emailresponsavel']; 	 		 			 	
											$tel1= $campo_noticias['tel1']; 	 		 			 	
											$tel2= $campo_noticias['tel2']; 	 		 			 	
											$tel3= $campo_noticias['tel3']; 	 		 			 	
											$email= $campo_noticias['email']; 	 		 			 	
											$homepage= $campo_noticias['homepage']; 	 		 			 	
											$responsavel= $campo_noticias['responsavel']; 	 		 			 	
											$cargoresponsavel= $campo_noticias['cargoresponsavel']; 	 		 			 	
											$contato= $campo_noticias['contato']; 	 		 			 	
											$cargocontato= $campo_noticias['cargocontato']; 	 		 			 	
											$emailcontato= $campo_noticias['emailcontato']; 	 		 			 	
											$captadorid= $campo_noticias['captadorid']; 	 		 			 	
											$localcaptacaoid= $campo_noticias['localcaptacaoid']; 	 		 			 	
											$status= $campo_noticias['status']; 	 		 			 	
											$observacao= $campo_noticias['observacao']; 	 
											$id= $campo_noticias['id']; 	 
											$txtestadoentrevista= $campo_noticias['txtestadoentrevista']; 	 
											$cepentrevista= $campo_noticias['cepentrevista']; 	 
											$senha= $campo_noticias['senha']; 	 
											$jovemaprendiz= $campo_noticias['jovemaprendiz']; 	 
											$estagios= $campo_noticias['estagios']; 	 
											$contapcd= $campo_noticias['contapcd']; 	 
											$quantempregados= $campo_noticias['quantempregados']; 	 
											$referenciaend= $campo_noticias['referenciaend']; 

											$enderecoentrevista	= $campo_noticias['enderecoentrevista']; 	 		 			 	
											$bairroentrevista	= $campo_noticias['bairroentrevista']; 	 		 			 	
											$cidadeentrevista	= $campo_noticias['cidadeentrevistaid'];		 	
											$cepentrevista	= $campo_noticias['cepentrevista']; 			 	
											$falarcom	= $campo_noticias['falarcom']; 	 		 			 	
											$emailentrevista	= $campo_noticias['emailentrevista']; 	 		 			 	
											$proximode	= $campo_noticias['proximode']; 		
											$id_empresa	= $campo_noticias['id']; 	
											$numero	= $campo_noticias['numero']; 		
											$numeroentrevista	= $campo_noticias['numeroentrevista']; 												
													
																						
											}
											}
											
											
											if($id_empresa =="")
											{
											
											
												?>
									
											<script> 
						function validarConfirmacao(){ 
						var senha = document.cadastro_empresa.senha.value; 
						var csenha = document.cadastro_empresa.csenha.value; 
						if(senha != csenha){ 
						alert("confirmacao e senha diferentes") 
						var elem = document.getElementById("csenha");
						elem.value = "";
						} 
						} 
						</script> 
						
									<form  class="form" style='padding-bottom:150px;'method="post" action="script_empresa.php?acao=<?if($id==""){echo"cadastro";}else{echo"editar";}?>&id=<?=$id;?>" id="cadastro_empresa" name='cadastro_empresa'>

										
										<h2>FICHA</h2>
										
											<div id='verifica_cnpj' name='verifica_cnpj' ></div>
									
										
										<div class="form-row">
											<div class="label">CPF / CNPJ</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cnpj" id="cnpj" readonly="true"  required value='<?=$busca_cnpj;?>'maxlength="18"   onkeyup="alert_cnpj();" tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)' onblur='verifica_cnpj(this.value);alert_cnpj();' style="width:194px;" type="text" class="input req-same">
											</div>
										</div>
										
										
										
										<div class="form-row">
											<div class="label">Razão Social <font class='simbolo'>&#10045;</font></div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" required onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="razaosocial"  onblur='verifica_cnpj(this.value);alert_cnpj();' onkeyup="this.value = this.value.toUpperCase();" id="razaosocial"  value='<?=$razaosocial;?>' maxlength="300" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="3" type="text" class="input req-same">
											</div>
										</div>
										<div class="form-row">
											<div class="label">Nome <font class='simbolo'>&#10045;</font></div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" required onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="nome"  onkeyup="this.value = this.value.toUpperCase();" required id="nome" onblur='verifica_cnpj(this.value);alert_cnpj();' value='<?=$nome;?>'  maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="4" 
												type="text" class="input req-same">
											</div>
										</div>
										
										<div class="form-row">
											<div class="label">Segmento de Atuação</div>
											<div class="input-container" style='width:546px;'>		
												<select name="segmentoatuacaoid" required id="segmentoatuacaoid"   tabindex="6" >
												
												<?
													$query_seguimentoatuacao_db = "SELECT * FROM  `segmentoatuacao` where id='$segmentoatuacaoid' ";
													$rs_seguimentoatuacao_db    = mysql_query($query_seguimentoatuacao_db);
													while($campo_seguimentoatuacao_db = mysql_fetch_array($rs_seguimentoatuacao_db)){		
													$seguimento_id_db 	= $campo_seguimentoatuacao_db['id']; 
													$seguimento_nome_db 	= $campo_seguimentoatuacao_db['nome']; 
													
													?>
													<option value='<?=$seguimento_id_db;?>'><?=$seguimento_nome_db ;?></option>			
													<?}?>
													
													<?
													$query_seguimentoatuacao = "SELECT * FROM  `segmentoatuacao` ORDER BY  `segmentoatuacao`.`nome` ASC ";
													$rs_seguimentoatuacao    = mysql_query($query_seguimentoatuacao);
													while($campo_seguimentoatuacao = mysql_fetch_array($rs_seguimentoatuacao)){		
													$seguimento_id 	= $campo_seguimentoatuacao['id']; 
													$seguimento_nome 	= $campo_seguimentoatuacao['nome']; 
													
													?>
													<option value='<?=$seguimento_id;?>'><?=$seguimento_nome ;?></option>			
													<?}?>
													
																										
													
													
												</select>
											</div>
										</div>
										
										<div class="form-row">
											<div class="label"></div>
											<div class="input-container" style='width:546px;'>		
												Inscrição Municipal
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="inscmunicipal" value='<?=$inscmunicipal;?>' onblur='verifica_cnpj(this.value);alert_cnpj();'id="inscmunicipal" maxlength="20" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.inscmunicipal');" tabindex="7" style="width:161px;" type="text" class="input req-same">
												Inscrição Estadual
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="inscestadual" value='<?=$inscestadual;?>'  onblur='verifica_cnpj(this.value);alert_cnpj();' id="inscestadual" maxlength="20" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.inscestadual');" tabindex="8" style="width:138px;" type="text" class="input req-same">
											</div>
										</div>
										
										
										<h2>POSSUI PROGRAMA ?</h2>
										
											<?
											switch ($jovemaprendiz){										
											case "S":											
												$jovemaprendiz_N = "SIM";
											break;
											
											case "N":
													$jovemaprendiz_N = "NÃO";
											break;
											}
											?>
										<div class="form-row">
											<div class="label">Jovem Aprendiz <font class='simbolo'>&#10045;</font> </div>
											<div class="input-container" style='width:546px;'>		
												<select name='jovemaprendiz' required style="width:161px;">
													<option value='<?=$jovemaprendiz;?>'><?=$jovemaprendiz_N;?></option>
													<option value='S'>SIM</option>
													<option value='N'>NÃO</option>
												</select>
											</div>
										</div>
										
										<?
											switch ($estagios){										
											case "S":											
												$estagios_N = "SIM";
											break;
											
											case "N":
													$estagios_N = "NÃO";
											break;
											}
											?>
											
										<div class="form-row">
											<div class="label">Estágios<font class='simbolo'>&#10045;</font> </div>
											<div class="input-container" style='width:546px;'>		
												<select name='estagios' required style="width:161px;">
													<option value='<?=$estagios;?>'><?=$estagios_N;?></option>
													<option value='S'>SIM</option>
													<option value='N'>NÃO</option>
												</select>
											</div>
										</div>
										
													<?
													switch ($contapcd){										
													case "S":											
													$contapcd_N = "SIM";
													break;

													case "N":
													$contapcd_N = "NÃO";
													break;
													}
													?>
											
										<div class="form-row">
											<div class="label">Contas para PCD<font class='simbolo'>&#10045;</font> </div>
											<div class="input-container" style='width:546px;'>		
												<select name='contapcd' required style="width:161px;">
												<option value='<?=$contapcd;?>'><?=$contapcd_N;?></option>
													<option value='S'>SIM</option>
													<option value='N'>NÃO</option>
												</select>
											</div>
										</div>
										
										
										
										<div class="form-row">
											<div class="label">Quantidade de Empregados<font class='simbolo'>&#10045;</font> </div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="quantempregados" required  value='<?=$quantempregados;?>' onblur='verifica_cnpj(this.value);alert_cnpj();'id="quantempregados"   style="width:161px;" type="number" class="input req-same">
											</div>
										</div>
										
										
										<!--
									
										<h2>SEGURANÇA</h2>
										
										
										<div class="form-row">
											<div class="label">Senha</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="senha" required id="senha" onBlur='verifica_cnpj(this.value);alert_cnpj();' value='<?=$senha;?>'  maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="9"  type="password" class="input req-same">
											</div>
										</div>
										
										<div class="form-row">
											<div class="label">Confirme a senha</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onBlur="validarConfirmacao()" name="csenha" required id="csenha" onBlur="validarConfirmacao()" value='<?=$senha;?>'  maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="9"  type="password" class="input req-same">
											</div>
										</div>-->
										
											<script  type="text/javascript">	
											// FUNÇÃO PARA BUSCA NOTICIA
											function busca_cidade(valor2) {
											// Verificando Browser
											if(window.XMLHttpRequest) {
											req = new XMLHttpRequest();
											}
											else if(window.ActiveXObject) {
											req = new ActiveXObject("Microsoft.XMLHTTP");
											}

											// Arquivo PHP juntamente com o valor digitado no campo (método GET)

											var url = "busca_endereco.php?tipo_busca=cidade&uf="+valor2;

											// Chamada do método open para processar a requisição
											req.open("Get", url, true); 
											req.setRequestHeader("Cache-Control","no-cache,no-store");
											req.setRequestHeader("Pragma", "no-cache");

											// Quando o objeto recebe o retorno, chamamos a seguinte função;
											req.onreadystatechange = function() {

											// Exibe a mensagem "Buscando Noticias..." enquanto carrega
											if(req.readyState == 1) {
											document.getElementById('cidadeid').innerHTML = '<option >buscando</option>';
											}

											// Verifica se o Ajax realizou todas as operações corretamente
											if(req.readyState == 4 && req.status == 200) {

											// Resposta retornada pelo busca.php
											var resposta = req.responseText;

											// Abaixo colocamos a(s) resposta(s) na div resultado
											document.getElementById('cidadeid').innerHTML = resposta;
											}
											}
											req.send(null);
											req.setRequestHeader("Cache-Control", "no-cache");
											req.setRequestHeader("Pragma", "no-cache"); 

											}
											</script>
											
											
					<script  type="text/javascript">	
					// FUNÇÃO PARA BUSCA NOTICIA
					function busca_bairo(cidade) {
					// Verificando Browser
					if(window.XMLHttpRequest) {
					req = new XMLHttpRequest();
					}
					else if(window.ActiveXObject) {
					req = new ActiveXObject("Microsoft.XMLHTTP");
					}

					// Arquivo PHP juntamente com o valor digitado no campo (método GET)

					var url = "busca_endereco.php?tipo_busca=bairro&cidade="+cidade;

					// Chamada do método open para processar a requisição
					req.open("Get", url, true); 
					req.setRequestHeader("Cache-Control","no-cache,no-store");
					req.setRequestHeader("Pragma", "no-cache");

					// Quando o objeto recebe o retorno, chamamos a seguinte função;
					req.onreadystatechange = function() {

					// Exibe a mensagem "Buscando Noticias..." enquanto carrega
					if(req.readyState == 1) {
					document.getElementById('bairro').innerHTML = '<option >buscando</option>';
					}

					// Verifica se o Ajax realizou todas as operações corretamente
					if(req.readyState == 4 && req.status == 200) {

					// Resposta retornada pelo busca.php
					var resposta = req.responseText;

					// Abaixo colocamos a(s) resposta(s) na div resultado
					document.getElementById('bairro').innerHTML = resposta;
					}
					}
					req.send(null);
					req.setRequestHeader("Cache-Control", "no-cache");
					req.setRequestHeader("Pragma", "no-cache"); 

					}
					</script>
										
										<h2>ENDEREÇO</h2>
										
										<div class="form-row">
											<div class="label">Endereço <font class='simbolo'>&#10045;</font></div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="endereco" required id="endereco" onblur='verifica_cnpj(this.value);alert_cnpj();' value='<?=$endereco;?>'  maxlength="400" onchange="Maiuscula(this);EditandoRegistro();" tabindex="9"  type="text" class="input req-same">
											</div>
										</div>
										
										<div class="form-row">
										<div class="label">Numero <font class='simbolo'>&#10045;</font></div>
										<div class="input-container" style='width:546px;'>		
										<i>Favor informa apenas numero</i>		
											<input style='width:146px;' onChange="javascript:this.value=this.value.toUpperCase();" required onChange="javascript:this.value=this.value.toUpperCase();" name="numero"   value="<?echo $numero;?>"  id="numero"  class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="79" type="numbre">
												
										</div>
									</div>
										
										<div class="form-row">
											<div class="label">Bairro</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="bairro" required id="bairro" onblur='verifica_cnpj(this.value);alert_cnpj();' value='<?=$bairro;?>' maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="10"  type="text" class="input req-same">
											</div>
										</div>
										<div class="form-row">
											<div class="label"></div>
											<div class="input-container" style='width:546px;'>		
												<b>Estado <font class='simbolo'><font class='simbolo'>&#10045;</font></font> </b>
												<select name="txtestado" required id="txtestado" onchange="busca_cidade(this.value);" style='width:77px;' >
												<?	
												$query_estado_db = "SELECT * FROM `cidade` where id='$cidadeid' ";
												$rs_estado_db     = mysql_query($query_estado_db );
												while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
												$ufid        = $campo_estado_db ['ufid'];

													$query_estado_dbuf = "SELECT * FROM `uf` where id='$ufid' ";
													$rs_estado_dbuf     = mysql_query($query_estado_dbuf );
													while($campo_estado_dbuf  = mysql_fetch_array($rs_estado_dbuf )){
													$uf_nome        = $campo_estado_dbuf ['uf'];
													$id_uf_db        = $campo_estado_dbuf ['id'];
													}
											
												}	
												?>
												<option value='<?=$id_uf_db;?>'><?=$uf_nome ;?></option>
																						
												<?
												$query_noticias_estado = "SELECT *  FROM  `uf` ORDER BY  `uf`.`uf` ASC ";
												$rs_noticias_estado    = mysql_query($query_noticias_estado);
												while($campo_noticias_estado = mysql_fetch_array($rs_noticias_estado)){		
												$iduf 	= $campo_noticias_estado['id']; 
												$nome_uf 	= $campo_noticias_estado['uf']; 
												
												?>
												<option value='<?=$iduf;?>'><?=$nome_uf ;?></option>			
												<?}?>
												</select>	
												
											<b>Cidade <font class='simbolo'><font class='simbolo'>&#10045;</font></font></b>
												<?	
												$query_noticias_cidadecp = "SELECT * FROM `cidade` where id='$cidadeid' ";
												$rs_noticias_cidadecp    = mysql_query($query_noticias_cidadecp);
												while($campo_noticias_cidadecp = mysql_fetch_array($rs_noticias_cidadecp)){
												$nome_cidade        = $campo_noticias_cidadecp['nome'];	
												$id_cidade        = $campo_noticias_cidadecp['id'];	
												}	
												?>
		
		
											<select name="cidadeid" required id="cidadeid" onchange="busca_bairo(this.value);"  style='width:220px;'>
											<option value='<?=$id_cidade;?>' <?if($id_cidade==""){}else{echo"selected";}?>><?=$nome_cidade;?></option>
													<?	
													$query_noticias_cidadecp2 = "SELECT * FROM `cidade` where ufid='$id_uf_db' ";
													$rs_noticias_cidadecp2    = mysql_query($query_noticias_cidadecp2);
													while($campo_noticias_cidadecp2 = mysql_fetch_array($rs_noticias_cidadecp2)){
													$nome_cidade2        = $campo_noticias_cidadecp2['nome'];	
													$id_cidade2        = $campo_noticias_cidadecp2['id'];	

													?>
													<option value='<?=$id_cidade2;?>'><?=$nome_cidade2;?></option>

													<?}?>
											</select>	
							
												
												<b>CEP</b>
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cep" id="cep" value='<?=$cep;?>' onblur='verifica_cnpj(this.value);alert_cnpj();' maxlength="10" onchange="EditandoRegistro();" onkeyup="verificaNumero('window.document.Ficha.cep');" tabindex="13" style="width:83px;" type="text" class="input req-same">
											</div>
										</div>
										<div class="form-row">
											<div class="label">REFERÊNCIA DO ENDEREÇO</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="referenciaend"   maxlength="98" id="referenciaend" onblur='verifica_cnpj(this.value);alert_cnpj();' value='<?=$referenciaend;?>' maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="10"  type="text" class="input req-same">
											</div>
										</div>
										
										
										<h2>ENTREVISTA </h2><h3>Só preencher o endereço se diferente do acima.</h3>
										<script  type="text/javascript">	
											// FUNÇÃO PARA BUSCA NOTICIA
											function busca_cidade_entrevista(valor2) {
											
											// Verificando Browser
											if(window.XMLHttpRequest) {
											req = new XMLHttpRequest();
											}
											else if(window.ActiveXObject) {
											req = new ActiveXObject("Microsoft.XMLHTTP");
											}

											// Arquivo PHP juntamente com o valor digitado no campo (método GET)

											var url = "busca_endereco.php?tipo_busca=cidade&uf="+valor2;

											// Chamada do método open para processar a requisição
											req.open("Get", url, true); 
											req.setRequestHeader("Cache-Control","no-cache,no-store");
											req.setRequestHeader("Pragma", "no-cache");

											// Quando o objeto recebe o retorno, chamamos a seguinte função;
											req.onreadystatechange = function() {

											// Exibe a mensagem "Buscando Noticias..." enquanto carrega
											if(req.readyState == 1) {
											document.getElementById('cidadeentrevistaid').innerHTML = '<option >buscando</option>';
											}

											// Verifica se o Ajax realizou todas as operações corretamente
											if(req.readyState == 4 && req.status == 200) {

											// Resposta retornada pelo busca.php
											var resposta = req.responseText;

											// Abaixo colocamos a(s) resposta(s) na div resultado
											document.getElementById('cidadeentrevistaid').innerHTML = resposta;
											}
											}
											req.send(null);
											req.setRequestHeader("Cache-Control", "no-cache");
											req.setRequestHeader("Pragma", "no-cache"); 

											}
											</script>
										
										<div class="form-row">
										<div class="label"></div>
										<div class="input-container" style='width:546px;'>	

											
											<b>CEP</b>
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cepentrevista" value="<?echo $cepentrevista;?>" id="cepentrevista" maxlength="8" class="input req-same" onchange="EditandoRegistro();" onkeyup="verificaNumero('window.document.Ficha.cepentrevista');" tabindex="75" style="width:65px;" type="text">
											<b>Estado  </b>
												<select name="estadoentrevista" id="estadoentrevista" onchange="busca_cidade_entrevista(this.value);" style='width:77px;' >

												<?	
												$query_estado_db = "SELECT * FROM `cidade` where id='$cidadeentrevista' ";
												$rs_estado_db     = mysql_query($query_estado_db );
												while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
												$ufid        = $campo_estado_db ['ufid'];

													$query_estado_dbuf = "SELECT * FROM `uf` where id='$ufid' ";
													$rs_estado_dbuf     = mysql_query($query_estado_dbuf );
													while($campo_estado_dbuf  = mysql_fetch_array($rs_estado_dbuf )){
													$uf_nome        = $campo_estado_dbuf ['uf'];
													$id_uf_db        = $campo_estado_dbuf ['id'];
													}
											
												}	
												?>
												<option value='<?=$id_uf_db;?>'><?=$uf_nome ;?></option>
																						
												<?
												$query_noticias_estado = "SELECT *  FROM  `uf` ORDER BY  `uf`.`uf` ASC ";
												$rs_noticias_estado    = mysql_query($query_noticias_estado);
												while($campo_noticias_estado = mysql_fetch_array($rs_noticias_estado)){		
												$iduf 	= $campo_noticias_estado['id']; 
												$nome_uf 	= $campo_noticias_estado['uf']; 
												
												?>
												<option value='<?=$iduf;?>'><?=$nome_uf ;?></option>			
												<?}?>
												</select>	
												
												
											<b>Cidade <font class='simbolo'><font class='simbolo'></font></font></b>
											
											
											

												<?	
												$query_noticias_cidadecp = "SELECT * FROM `cidade` where id='$cidadeentrevista' ";
												$rs_noticias_cidadecp    = mysql_query($query_noticias_cidadecp);
												while($campo_noticias_cidadecp = mysql_fetch_array($rs_noticias_cidadecp)){
												$nome_cidade        = $campo_noticias_cidadecp['nome'];	
												$id_cidade        = $campo_noticias_cidadecp['id'];	
												}	
												?>
		
		
											<select name="cidadeentrevistaid"  id="cidadeentrevistaid" onchange="busca_bairo(this.value);"  style='width:220px;'>
											<option value='<?=$cidadeentrevista;?>'><?=$nome_cidade;?></option>
											</select>	
										</div>
									</div>
									
									
									<div class="form-row">
										<div class="label">Bairro <font class='simbolo'></font></div>
										<div class="input-container" style='width:546px;'>		
										
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="bairroentrevista"  value="<?echo $bairroentrevista;?>"  id="enderecoentrevista" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="79" type="text">
										</div>
									</div>
									
									<div class="form-row">
										<div class="label">Endereço <font class='simbolo'></font></div>
										<div class="input-container" style='width:546px;'>		
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="enderecoentrevista"   value="<?echo $enderecoentrevista;?>"  id="enderecoentrevista" maxlength="400" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="79" type="text">
												
										</div>
									</div>
									
									<div class="form-row">
										<div class="label">Numero <font class='simbolo'></font></div>
										<div class="input-container" style='width:546px;'>
											<i>Favor informa apenas numero</i>		
											<input style='width:146px;' onChange="javascript:this.value=this.value.toUpperCase();"   onChange="javascript:this.value=this.value.toUpperCase();" name="numeroentrevista"   value="<?echo $numeroentrevista;?>"  id="numeroentrevista"  class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="79" type="numbre">
												
										</div>
									</div>
									
									<div class="form-row">
										<div class="label">Próximo de</div>
										<div class="input-container" style='width:546px;'>		
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="proximode" value="<?= $proximode;?>" id="proximode" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="80"  type="text">
										</div>
									</div>
									
									<div class="form-row">
										<div class="label">Falar com <font class='simbolo'> </div>
										<div class="input-container" style='width:546px;'>		
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="falarcom"  value="<?=$falarcom;?>" id="falarcom" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="81"  type="text">
										</div>
									</div>
									
										
										
										
										
										
										
										<h2>CONTATOS</h2>
										<div class="form-row">
											<div class="label"></div>
											<div class="input-container" style='width:546px;'>		
												Tel.de contato <font class='simbolo'>&#10045;</font>
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="tel1" placeholder="telefone" id="tel1" required maxlength="14"value='<?=$tel1;?>'  onkeydown="EditandoRegistro()"  tabindex="22" style="width:120px;" type="text" class="input req-same">
												&nbsp;/&nbsp;
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="tel2" id="tel2" placeholder="celular" maxlength="15" value='<?=$tel2;?>'  onkeydown="EditandoRegistro()" tabindex="23" style="width:120px;" type="text" class="input req-same">
												&nbsp;/&nbsp;
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="tel3" id="tel3" maxlength="14" type='numbre' placeholder="outro Fixo" value='<?=$tel3;?>'  onkeydown="EditandoRegistro()"  tabindex="24" style="width:120px;" type="text" class="input req-same">
											</div>
										</div>
										
										<div class="form-row">
											<div class="label">E-mail</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="email" required  id="email"value='<?=$email;?>'  maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="25"  type="email" class="input req-same">
											</div>
										</div>
										
										
										<div class="form-row">
											<div class="label">Página de Internet</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="homepage" id="homepage" value='<?=$homepage;?>' maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="26" type="text" class="input req-same">
											</div>
										</div>
										
										<div class="form-row">
											<div class="label">Responsável</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="responsavel" id="responsavel" required value='<?=$responsavel;?>' maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="27" type="text" class="input req-same">
											</div>
										</div>
										
										<div class="form-row">
											<div class="label">Cargo do Responsável</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cargoresponsavel" id="cargoresponsavel" required value='<?=$cargoresponsavel;?>' maxlength="50" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="28"  type="text" class="input req-same">
											</div>
										</div>
										<div class="form-row">
											<div class="label">E-mail do Responsável</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="emailresponsavel" id="emailresponsavel" required value='<?=$emailresponsavel;?>' maxlength="100" onkeydown="EditandoRegistro()" tabindex="29"  type="email" class="input req-same">
											</div>
										</div>

										<div class="form-row">
											<div class="label">Nome do Contato</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="contato" id="contato" required value='<?=$contato;?>' maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="30"  type="text" class="input req-same">
											</div>
										</div>
										<div class="form-row">
											<div class="label">Cargo do Contato</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cargocontato" id="cargocontato"  required value='<?=$cargocontato;?>' maxlength="50" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" tabindex="31" type="text" class="input req-same">
											</div>
										</div>
										
										<div class="form-row">
											<div class="label">E-mail do Contato</div>
											<div class="input-container" style='width:546px;'>		
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="emailcontato" id="emailcontato" required value='<?=$emailcontato;?>' maxlength="100" onkeydown="EditandoRegistro()" tabindex="32"  type="email" class="input req-same">
											</div>
										</div>
										
										<h2>INFORMAÇÕES ADICIONAIS</h2>
										
											

											<div class="form-row">
											<div class="label">Observações</div>
											<div class="input-container" style='width:546px;'>		
												<textarea name="observacao" id="observacao" maxlength="500" rows="4" class="input req-same" style='width:100%;height:53px;'cols="98" tabindex="36" style="font-size: 12px; font-family: Arial;" onkeyup="funTamanhoCerto('window.document.Ficha.observacao', 200);" onchange="Maiuscula(this);EditandoRegistro();"><?=$observacao;?></textarea>
											</div>
											</div>

											
											
										
										
										
										<div class="form-row">
											<div class="label"></div>
											<div class="input-container" style='width:546px;'>		
												
											
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar" type="submit" class="sendBtn3" />
													<div id="errorDiv2" class="error-div"></div>
											</div>
										</div>

									</form>
									
									<?}else{?>
									
											<?
															$query_noticias = "SELECT * FROM `usuario` WHERE usuario LIKE '%$busca_cnpj%'";										
															$rs_noticias    = mysql_query($query_noticias);
															while($campo_noticias = mysql_fetch_array($rs_noticias)){
															$idusuario 	= $campo_noticias['id']; 	 		 			 	
															}
															if($idusuario > 0)
															{
															?>
															
															
															<SCRIPT language="JavaScript">window.location.href="login.php?msg=Já possui cadastro, favor realizar Login! ";</SCRIPT>
															
															<?	
																}else{
															?>
														<!-- cadastro usuario-->
														<h3>Parabéns CNPJ: <?=$busca_cnpj;?> já Cadastrado! </h3>														
														<h4>Cadastre seu dados de Acesso! </h4>
														
														<script> 
															function validarConfirmacao(){ 

															var senha = document.formusuario.senha.value; 
															var resenha = document.formusuario.resenha.value; 
															if(senha != resenha){ 
															alert("Confirmação e senha diferentes") 
															document.formusuario.resenha.value=""; 
															} 
															} 
															</script> 
						
														<form method='post'class="form"  action=''name='formusuario' id='formusuario'>
															<input type='hidden' name='usuario' value='<?=$busca_cnpj;?>'/>
															<input type='hidden' name='nome' maxlength="100" value='<?=$nome;?>'/>
															<div class="form-row">
																<div class="label">Senha <font class='simbolo'>&#10045;</font> </div>
																<div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="senha" required  value='<?=$senha;?>'type="password" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="13"  /></div>
															</div>
															
															<div class="form-row">
																<div class="label">Repetir-Senha <font class='simbolo'>&#10045;</font> </div>
																<div class="input-container"><input onBlur="validarConfirmacao()"  name="resenha" required  value='<?=$senha;?>'type="password" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="13"  /></div>
															</div>
															
															
															<div class="form-row" style='padding-bottom:160px;'>
																<div class="label"></div>
																	<div class="input-container" style='width:546px;'>		
																																			
																			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Concluir" type="submit" onclick='carrega3()' class="sendBtn3" />
																		
																			
																	</div>
															</div >
													
														</form>
														<!-- cadastro usuario-->
														<?}?>
											
											
											
											
									<?}?>
					
						</td>	

					</tr>
				</table>
				
		</div>
		
		
		 

		<?include"rodape_novo.php";?>
		
</body>
</html>