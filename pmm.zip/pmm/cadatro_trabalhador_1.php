<?include'conexao.php';?>

<html>
<?include'topo.php';?>

<body>

		<?include"topo_logo.php";?>
	<?php $anofinaldata= date("Y"); ?>


	<script type="text/javascript">		
		$(function() {
		$("#datanascimentop").datepicker({
		changeMonth: true,
		changeYear: true,
		yearRange: '1900:<?=$anofinaldata;?>',
		dateFormat: 'dd/mm/yy',
        dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
        dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
        dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
        monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
        monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
		});
		});
$(document).ready(function(){	$("#datanascimentop").mask("99/99/9999");});	
	  </script>
			<?
			///cadastro usuario
		$senha 	=(string)addslashes($_POST['senha']); 
		$usuario 	=(string)addslashes($_POST['usuario']); 
		$nome 	=(string)addslashes($_POST['nome']); 		
		if($usuario==""){}else{
		$queryusuario="INSERT INTO usuario (`usuario`, `nome`,`senha`,`perfil`)VALUES ('$usuario','$nome','$senha','T' )";	
		$rsusuario= mysql_query($queryusuario);
	

		?>
	
		<SCRIPT language="JavaScript">window.location.href="login.php?msg=Cadastro salvo!Realize seu Login ";</SCRIPT>
		<?
			exit;
			}	/// fim cadastro usuario
			
		?>
	
	
		<div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);margin-top:50px;' align='center' >
			<table width='960px'>
					<tr>
					
					
						<td width='460'>
																	
									<script type="text/javascript">
									
										$(document).ready(function(){									
										$("#cadastro").validate();										
											$.validator.setDefaults({
												submitHandler: function() {
										
											}
										});
										
										$('#nome').click(function()
											{
											$("#cadastro").validate();	
											 if ($('#cadastro').valid()) // check if form is valid
												{
												 
												}
												else 
												{
													
												   // just show validation errors, dont post
												}
										});
										
										
										$('#voltar1').click(function()
											{
											$("#cadastro").validate();	
											 if ($('#cadastro').valid()) // check if form is valid
												{
												 
												}
												else 
												{
													
												   // just show validation errors, dont post
												}
										});
										
										
										$('#voltar2').click(function()
											{
											$("#cadastro").validate();	
											 if ($('#cadastro').valid()) // check if form is valid
												{
												 
												}
												else 
												{
													
												   // just show validation errors, dont post
												}
										});
										
										
										
										$('#cboid1').click(function()
											{
											$("#cadastro").validate();

												if ($('#cadastro').valid()) // check if form is valid
												{
												  
												}
												else 
												{
													
												   // just show validation errors, dont post
												}											
										});
										
										$(window).scroll(function()
											{
											$("#cadastro").validate();

												if ($('#cadastro').valid()) // check if form is valid
												{
												  
												}
												else 
												{
													
												   // just show validation errors, dont post
												}											
										});
										
										
										
										
										
								
									});
										
										
										
									function mascaraMutuario(o,f){
										v_obj=o
										v_fun=f
										setTimeout('execmascara()',1)
									}
									 
									function execmascara(){
										v_obj.value=v_fun(v_obj.value)
									}
									 
									function cpfCnpj(v){
									 
										//Remove tudo o que não é dígito
										v=v.replace(/\D/g,"")
									 
										if (v.length <= 13) { //CPF
									 
											//Coloca um ponto entre o terceiro e o quarto dígitos
											v=v.replace(/(\d{3})(\d)/,"$1.$2")
									 
											//Coloca um ponto entre o terceiro e o quarto dígitos
											//de novo (para o segundo bloco de números)
											v=v.replace(/(\d{3})(\d)/,"$1.$2")
									 
											//Coloca um hífen entre o terceiro e o quarto dígitos
											v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")	
											
											
									 
										} else { //CNPJ
									 
											//Coloca ponto entre o segundo e o terceiro dígitos
											v=v.replace(/^(\d{2})(\d)/,"$1.$2")
									 
											//Coloca ponto entre o quinto e o sexto dígitos
											v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
									 
											//Coloca uma barra entre o oitavo e o nono dígitos
											v=v.replace(/\.(\d{3})(\d)/,".$1/$2")
									 
											//Coloca um hífen depois do bloco de quatro dígitos
											v=v.replace(/(\d{4})(\d)/,"$1-$2")
									 
										}
										
										
										
										return v
									 
									}
												</script>
												
												
												<?
												
																		
									function mask($val, $mask)
									{
									 $maskared = '';
									 $k = 0;
									 for($i = 0; $i<=strlen($mask)-1; $i++)
									 {
									 if($mask[$i] == '#')
									 {
									 if(isset($val[$k]))
									 $maskared .= $val[$k++];
									 }
									 else
									 {
									 if(isset($mask[$i]))
									 $maskared .= $mask[$i];
									 }
									 }
									 return $maskared;
									}

									$busca_cnpjget = $_POST['cpf_trabalhador'];
									if($busca_cnpjget==""){$busca_cnpjget = $_GET['cpf_trabalhador'];}
									$vowels = array(".","-","/"," ","","(",")");
									$format_numero12 = str_replace($vowels, "", "$busca_cnpjget");														
									$cpf_busca =  mask($format_numero12,'###.###.###-##');
									
									
									/**
									 * Valida CPF
									 *
									 * @author Luiz Otávio Miranda <contato@tutsup.com>
									 * @param string $cpf O CPF com ou sem pontos e traço
									 * @return bool True para CPF correto - False para CPF incorreto
									 *
									 */
									function valida_cpf( $cpf = false ) {
										// Exemplo de CPF: 025.462.884-23
										
										/**
										 * Multiplica dígitos vezes posições 
										 *
										 * @param string $digitos Os digitos desejados
										 * @param int $posicoes A posição que vai iniciar a regressão
										 * @param int $soma_digitos A soma das multiplicações entre posições e dígitos
										 * @return int Os dígitos enviados concatenados com o último dígito
										 *
										 */
										function calc_digitos_posicoes( $digitos, $posicoes = 10, $soma_digitos = 0 ) {
											// Faz a soma dos dígitos com a posição
											// Ex. para 10 posições: 
											//   0    2    5    4    6    2    8    8   4
											// x10   x9   x8   x7   x6   x5   x4   x3  x2
											// 	 0 + 18 + 40 + 28 + 36 + 10 + 32 + 24 + 8 = 196
											for ( $i = 0; $i < strlen( $digitos ); $i++  ) {
												$soma_digitos = $soma_digitos + ( $digitos[$i] * $posicoes );
												$posicoes--;
											}
									 
											// Captura o resto da divisão entre $soma_digitos dividido por 11
											// Ex.: 196 % 11 = 9
											$soma_digitos = $soma_digitos % 11;
									 
											// Verifica se $soma_digitos é menor que 2
											if ( $soma_digitos < 2 ) {
												// $soma_digitos agora será zero
												$soma_digitos = 0;
											} else {
												// Se for maior que 2, o resultado é 11 menos $soma_digitos
												// Ex.: 11 - 9 = 2
												// Nosso dígito procurado é 2
												$soma_digitos = 11 - $soma_digitos;
											}
									 
											// Concatena mais um dígito aos primeiro nove dígitos
											// Ex.: 025462884 + 2 = 0254628842
											$cpf = $digitos . $soma_digitos;
											
											// Retorna
											return $cpf;
										}
										
										// Verifica se o CPF foi enviado
										if ( ! $cpf ) {
											return false;
										}
									 
										// Remove tudo que não é número do CPF
										// Ex.: 025.462.884-23 = 02546288423
										$cpf = preg_replace( '/[^0-9]/is', '', $cpf );
									 
										// Verifica se o CPF tem 11 caracteres
										// Ex.: 02546288423 = 11 números
										if ( strlen( $cpf ) != 11 ) {
											return false;
										}	
									 
										// Captura os 9 primeiros dígitos do CPF
										// Ex.: 02546288423 = 025462884
										$digitos = substr($cpf, 0, 9);
										
										// Faz o cálculo dos 9 primeiros dígitos do CPF para obter o primeiro dígito
										$novo_cpf = calc_digitos_posicoes( $digitos );
										
										// Faz o cálculo dos 10 dígitos do CPF para obter o último dígito
										$novo_cpf = calc_digitos_posicoes( $novo_cpf, 11 );
										
										// Verifica se o novo CPF gerado é idêntico ao CPF enviado
										if ( $novo_cpf === $cpf ) {
											// CPF válido
											return true;
										} else {
											// CPF inválido
											return false;
										}
									}

									
									if ( valida_cpf( "$cpf_busca" ) ) {
										
									} else {
										echo"<script language= 'JavaScript'>
													location.href='mensagem.php?msg=CNPJ INVÁLIDO'
													</script>";
									}
																					
										//$cpf_busca = $_POST['cpf_trabalhador'];										
										if($cpf_busca==""){}else{
										$query_noticias = "SELECT * FROM `trabalhador` WHERE cpf LIKE '%$cpf_busca%'";										
										$rs_noticias    = mysql_query($query_noticias);
										while($campo_noticias = mysql_fetch_array($rs_noticias)){
										$cpf 	= $campo_noticias['cpf']; 	 		 			 	
										$id_trabalhador 	= $campo_noticias['id']; 	 		 			 	
										$nometrabalhador 	= $campo_noticias['nome']; 	 		 			 	
											
											}
											
											}
											
											
											if($id_trabalhador =="")
											{
											
											
											?>
											
											
							<?
											
		
										if($cpf_busca==''){} else{
										
												
										
											$query_noticias = "SELECT * FROM `trabalhador` WHERE `cpf` LIKE '%$cpf_busca%'";
											$rs_noticias    = mysql_query($query_noticias);																							
											while($campo_noticias = mysql_fetch_array($rs_noticias)){
											$id= $campo_noticias['id']; 
											$cadbf= $campo_noticias['cadbf']; 
											$cpf_busca= $campo_noticias['cpf']; 
											$nome= $campo_noticias['nome']; 
											$email= $campo_noticias['email']; 
													$cpf 	= $campo_noticias['cpf']; 	 		 			 	
												$nome 	= $campo_noticias['nome']; 
												$mae 	= $campo_noticias['mae'];	 		 			 	
												$pai 	= $campo_noticias['pai'];	 		 			 	
												$datanascimento 	= $campo_noticias['datanascimento']; 	 		 			 	
												$naturalidade 	= $campo_noticias['naturalidade']; 	 		 			 	
												$sexo 	= $campo_noticias['sexo']; 	 		 			 	
												$estadocivil 	= $campo_noticias['estadocivil']; 			 	
													 			 	
												 		 			 	
												$txtfilhosestudantes 	= $campo_noticias['txtfilhosestudantes']; 	 		 			 	
												$txttrabalhando 	= $campo_noticias['txttrabalhando']; 	 		 			 	
												$txtmeres 	= $campo_noticias['txtmeres']; 	 		 			 	
												$txtmenores 	= $campo_noticias['txtmenores']; 	 		 			 	
												$txtmenores 	= $campo_noticias['txtmenores']; 					 	 		 			 	
												$cbolaudo 	= $campo_noticias['cbolaudo']; 	 		 			 	
												$txtlimitacoes 	= $campo_noticias['txtlimitacoes']; 	 		 			 	
												$intencao 	= $campo_noticias['intencao']; 	 		 			 	
												$cboTemporario 	= $campo_noticias['cboTemporario']; 	 		 			 	
												$cboservida 	= $campo_noticias['cboservida']; 	 		 			 	
												$cboNoturno 	= $campo_noticias['cboNoturno']; 	 		 			 	
												$cbotur 	= $campo_noticias['cbotur']; 	 		 			 	
												$cbofeira 	= $campo_noticias['cbofeira']; 	 		 			 	
												$cep 	= $campo_noticias['cep']; 	 		 			 	
												$txtestado 	= $campo_noticias['txtestado']; 	 		 			 	
												$cidadeid 	= $campo_noticias['cidadeid']; 	 		 			 	
												$bairro 	= $campo_noticias['bairro']; 	 		 			 	
												$endereco 	= $campo_noticias['endereco']; 	 		 			 	
												$telres 	= $campo_noticias['telres']; 	 		 			 	
												$telcel 	= $campo_noticias['telcel']; 	 		 			 	
												$telrec 	= $campo_noticias['telrec']; 	 		 			 	
												$nmrecado 	= $campo_noticias['nmrecado']; 	 		 			 	
												$email 	= $campo_noticias['email'];	 		 			 	
												$identidade 	= $campo_noticias['identidade']; 	 		 			 	
												$orgaoexpedidor 	= $campo_noticias['orgaoexpedidor']; 	 		 			 	
												$txttitulo 	= $campo_noticias['txttitulo']; 	 		 			 	
												$txtzona 	= $campo_noticias['txtzona']; 	 		 			 	
												$txtsecao 	= $campo_noticias['txtsecao']; 	 		 			 	
												$tipocnh 	= $campo_noticias['tipocnh']; 	 		 			 	
												$carteiratrabalho 	= $campo_noticias['carteiratrabalho']; 	 		 			 	
												$seriect 	= $campo_noticias['seriect']; 	 		 			 	
												$txtregistroprof 	= $campo_noticias['txtregistroprof']; 	 		 			 	
												$orgaoreg 	= $campo_noticias['orgaoreg']; 	 		 			 	
												$pispasep 	= $campo_noticias['pispasep']; 	 		 			 	
												$passaporte 	= $campo_noticias['passaporte']; 	 		 			 	
												$txtmoracom 	= $campo_noticias['txtmoracom']; 	 		 			 	
												$txtmorapais 	= $campo_noticias['txtmorapais']; 	 		 			 	
												$txtmoracompanheiro 	= $campo_noticias['txtmoracompanheiro']; 	 		 			 	
												$txtmoraoutros 	= $campo_noticias['txtmoraoutros']; 	 		 			 	
												$txtmorafilhos 	= $campo_noticias['txtmorafilhos']; 	 		 			 	
												$txtmorafilhos1 	= $campo_noticias['txtmorafilhos1']; 	 		 			 	
												$txtmorafilhos2 	= $campo_noticias['txtmorafilhos2']; 	 		 			 	
												$txtmorafilhos3 	= $campo_noticias['txtmorafilhos3']; 	 		 			 	
												$txtmorairmaos 	= $campo_noticias['txtmorairmaos']; 	 		 			 	
												$txtmorairmaos1 	= $campo_noticias['txtmorairmaos1']; 	 		 			 	
												$txtmorairmaos2 	= $campo_noticias['txtmorairmaos2']; 	 		 			 	
												$txtmorairmaos22 	= $campo_noticias['txtmorairmaos22']; 	 		 			 	
												$txtmorairmaos3 	= $campo_noticias['txtmorairmaos3']; 	 		 			 	
												$txtrendafamiliar 	= $campo_noticias['txtrendafamiliar']; 	 		 			 	
												$selchefefamilia 	= $campo_noticias['selchefefamilia']; 	 		 			 	
												$programasocialid 	= $campo_noticias['programasocialid']; 	 		 			 	
												$cboprocesso 	= $campo_noticias['cboprocesso']; 	 		 			 	
												$cbosoube_caet 	= $campo_noticias['cbosoube_caet']; 	 		 			 	
												$selcidacaptado 	= $campo_noticias['selcidacaptado']; 	 		 			 	
												$selcidaatraves 	= $campo_noticias['selcidaatraves']; 	 		 			 	
												$selLocalDocs 	= $campo_noticias['selLocalDocs']; 	 		 			 	
												$txthistorico	= $campo_noticias['txthistorico'];
 
												$txthabilidades1 = $campo_noticias['txthabilidades1'];
												$txthabilidades2 = $campo_noticias['txthabilidades2'];
												$txthabilidades3 = $campo_noticias['txthabilidades3'];
												$cboid1 =  $campo_noticias['cboid1'];
												$cboid2 =  $campo_noticias['cboid2'];
												$cboid3 =  $campo_noticias['cboid3'];
												$pretensaosalarial =  $campo_noticias['pretensaosalarial'];
												$ultimosalario =  $campo_noticias['ultimosalario'];
												$escolaridade 	= $campo_noticias['escolaridade']; 
												$senha 	= $campo_noticias['senha']; 
												$situacao 	= $campo_noticias['situacao']; 
												$serie 	= $campo_noticias['serie']; 
												$turno 	= $campo_noticias['turno']; 
												$formacaoacademicaidbusca 	= $campo_noticias['formacaoacademicaidbusca']; 
												$formacaoacademicaid 	= $campo_noticias['formacaoacademicaid']; 
												$outrocurso 	= $campo_noticias['outrocurso']; 
												$instituicao 	= $campo_noticias['instituicao']; 
												$comprovacao 	= $campo_noticias['comprovacao']; 
												$softwareid1 	= $campo_noticias['softwareid1']; 
												$softwareid2 	= $campo_noticias['softwareid2']; 
												$softwareid3 	= $campo_noticias['softwareid3']; 
												$idiomaid1 	= $campo_noticias['idiomaid1']; 
												$idiomaid2 	= $campo_noticias['idiomaid2']; 
												$vagadeficiente 	= $campo_noticias['vagadeficiente']; 
												$idiomaid3 	= $campo_noticias['idiomaid3']; 
												$leitura1 	= $campo_noticias['leitura1']; 
												$leitura2 	= $campo_noticias['leitura2']; 
												$leitura3	= $campo_noticias['leitura3']; 
												$conversacao1	= $campo_noticias['conversacao1']; 
												$conversacao2	= $campo_noticias['conversacao2']; 
												$conversacao3	= $campo_noticias['conversacao3']; 
												$escrita1	= $campo_noticias['escrita1']; 
												$escrita2	= $campo_noticias['escrita2']; 
												$escrita3	= $campo_noticias['escrita3']; 
												
												$cadastrado_por	= $campo_noticias['usuarioid']; 
												$datacadastro	= $campo_noticias['datacadastro']; 
											}			

										}
											
											
											?>
											
												
													<form  class="form" method="post"   id="cadastro" name='cadastro' <?if($id ==""){echo" action='script_cadastro.php?acao=cadastro' "; }else{ echo" action='script_cadastro.php?acao=editar' ";}?> >
														
														
														<h1>Cadastro de Currículo</h1>
													<div><font style='font-size:16px;'>&#10144; </font>Atenção, campos com <font class='simbolo'>&#10045;</font> são obrigatorios!</div>
													
														
														<div class="idTabs" id='idTabs'><!--div pagginação-->
													
														<div id="cadastro1" name='cadastro1'>
														
																	<div style='margin:20px;width:100%;' align='center'>
																	<font style='font-size:15px;color:red;font-weight:bold;'>PASSO 1 &#10132; </font>
																	<font style='font-size:15px;color:#999;font-weight:bold;'>PASSO 2 &#10132; </font>
																	<font style='font-size:15px;color:#999;font-weight:bold;'>PASSO 3  </font>

																	</div>
										

															<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type='hidden' name='id' value='<?=$id;?>'/>
															
														<h2>DADOS PESSOAIS</h2>
														
														<!--<h3>Same fields required example</h3>-->
													<?if($id >0){?>		
														<style onload="deficiente('2');"></style>					
														<div class="form-row" >
														<div class="label"></div>
														<div class="input-container" style='width:541px;'>													
														<?
														$query_atendente = "SELECT *  FROM  `usuario` where  id='$cadastrado_por'";	
														$rs_atendente    = mysql_query($query_atendente); 													
														while($campo_atendente = mysql_fetch_array($rs_atendente)){
														$nome_atendente= $campo_atendente['nome']; 
														}														
														if( $nome_atendente==""){ $usuario_ajaxe="ONLINE"; }else{$usuario_ajaxe="$nome_atendente";};
														?>
														ID: <input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" style='width:170px'  class="input req-same"value='<?=$id;?>'readonly="true"  type="text"   /><br>
														Cadastro: <input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" style='width:170px' class="input req-same" value='<?=$datacadastro;?>'readonly="true"  type="text"   /><br>
														Atualizado: <input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" style='width:170px'  class="input req-same"value='<?=$datacadastro;?>'readonly="true"  type="text"   /><br>
														Atendente : <input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" style='width:170px' class="input req-same" value='<?=$usuario_ajaxe;?>'readonly="true"  type="text"   />
														</div>
														</div>
													<?}?>
														
														
														<div class="form-row">
															<div class="label">Intenção? <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"  style='width:546px;'>
														<select name="intencao" id="intencao" required tabindex="22" style="width:240">
														
														<?
																			switch ($intencao){										
																			case "E":											
																			$intencao_N = "Emprego";
																			break;																			
																			case "T":											
																			$intencao_N = "Estágio";
																			break;
																			case "C":											
																			$intencao_N = "Curso";
																			break;
																			case "D":											
																			$intencao_N = "Emissão de Documentos";
																			break;
																			case "G":											
																			$intencao_N = "Emprego/Curso";
																			break;
																			case "M":											
																			$intencao_N = "Emprego/Emissão de Documentoso";
																			break;
																			case "U":											
																			$intencao_N = "Curso/Emissão de Documentos";
																			break;
																			case "S":											
																			$intencao_N = "Todas";
																			break;
																			
																			}
																			?>
																			
																		<option value="<?=$intencao;?>"><?=$intencao_N;?></option>
																		<option value="E" >Emprego</option>
																		
																		<option value="T">Estágio</option>
																		<option value="C">Curso</option>
																		<option value="D">Emissão de Documentos</option>
																		<option value="G">Emprego/Curso</option>
																		<option value="M">Emprego/Emissão de Documentos</option>
																		<option value="U">Curso/Emissão de Documentos</option>
																		<option value="S">Todas</option>
																	</select>
														</div>
														</div>
														
														
															
														
														
														
														<div class="form-row">
															<div class="label">CPF <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" style='width:200px'  readonly="true" name="cpf" value='<?=$cpf_busca;?>' onkeypress="formatar_mascara(this, '###.###.###-##')" type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="14"  /></div>
														</div>
														<div class="form-row">
															<div class="label">Nome <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="nome" id="nome" required  value='<?=$nome;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
														</div>
														
															
														<script  type="text/javascript">	
						
						
					
					function deficiente(cidade) {
					
					// Verificando Browser
					if(window.XMLHttpRequest) {
					req = new XMLHttpRequest();
					}
					else if(window.ActiveXObject) {
					req = new ActiveXObject("Microsoft.XMLHTTP");
					}
					   
					var valorCombo = document.getElementById("vagadeficiente").value;
					
					// Arquivo PHP juntamente com o valor digitado no campo (método GET)
					if(cidade=="2")				
					{
					
					var url = "deficiente_trabalhador.php?escolha=<?=$vagadeficiente;?>&id_trabalhado=<?=$id;?>&test"+cidade;	
						
					}
					
					else
					{
					
					var url = "deficiente_trabalhador.php?id_trabalhado=<?=$id;?>&escolha="+cidade;				
					
										
					}
					
						
					// Chamada do método open para processar a requisição
					req.open("Get", url, true); 
					req.setRequestHeader("Cache-Control","no-cache,no-store");
					req.setRequestHeader("Pragma", "no-cache");

					// Quando o objeto recebe o retorno, chamamos a seguinte função;
					req.onreadystatechange = function() {

					// Exibe a mensagem "Buscando Noticias..." enquanto carrega
					if(req.readyState == 1) {
					document.getElementById('deficiente').innerHTML = 'Carregando aguarde...';
					}
							
					// Verifica se o Ajax realizou todas as operações corretamente
					if(req.readyState == 4 && req.status == 200) {

					// Resposta retornada pelo busca.php
					var resposta = req.responseText;

					// Abaixo colocamos a(s) resposta(s) na div resultado
					document.getElementById('deficiente').innerHTML = resposta;
					}
					}
					req.send(null);
					req.setRequestHeader("Cache-Control", "no-cache");
					req.setRequestHeader("Pragma", "no-cache"); 
					
				
					
					}
					
								
						
					</script>
					
					
					
										<div class="form-row"   >
												<div class="label"></div>
												<div class="input-container" style='width:546px;'  >		

													Possui deficiência<font class='simbolo'><font class='simbolo'>&#10045;</font></font>
													<select name="vagadeficiente"  required='' id="vagadeficiente" onchange="deficiente(this.value);"style="width:88px;" tabindex="15">
														
														<?
																switch ($vagadeficiente){										
																case "N":											
																$vagadeficiente_N = "Não";
																break;case "S":											
																$vagadeficiente_N = "Sim";
																break;
																}
															if($vagadeficiente=="")	{}else{
														?>
														<option value="<?=$vagadeficiente;?>"><?=$vagadeficiente_N;?></option>
														<?}?>
														<option value='N' >Não</option>
														<option value='S' >Sim</option>
													</select>
													
												</div>
											</div >
											
											
														<div class="form-row">
															<div class="label">Mãe <font class='simbolo'>&#10045;</font></div>
															<div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="mae" required value='<?=$mae;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
														</div>
														<div class="form-row">
															<div class="label">Pai</div>
															<div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="pai" value='<?=$pai;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
														</div>
														
														<script language="JavaScript">

//VALIDAÇÃO DA DATA 

function VerificaData(digData) 
{
	var bis---to = 0;
	var data = digData; 
	var tam = data.length;
	if (tam == 10) 
	{
		var dia = data.substr(0,2)
		var mes = data.substr(3,2)
		var ano = data.substr(6,4)
		if ((ano > 1900)||(ano < 2100))
		{
			switch (mes) 
			{
				case '01':
				case '03':
				case '05':
				case '07':
				case '08':
				case '10':
				case '12':
					if  (dia <= 31) 
					{
						return true;
					}
					break
				
				case '04':		
				case '06':
				case '09':
				case '11':
					if  (dia <= 30) 
					{
						return true;
					}
					break
				case '02':
					/* Validando ano Bis---to / fevereiro / dia */ 
					if ((ano % 4 == 0) || (ano % 100 == 0) || (ano % 400 == 0)) 
					{ 
						bis---to = 1; 
					} 
					if ((bis---to == 1) && (dia <= 29)) 
					{ 
						return true;				 
					} 
					if ((bis---to != 1) && (dia <= 28)) 
					{ 
						return true; 
					}			
					break						
			}
		}
	}	
	alert("A Data "+data+" é inválida!");
	return false;
}
</script><div class="form-row">
															<div class="label">Data Nascimento <font class='simbolo'>&#10045;</font> </div>
															<?$datanascimento2 = implode('/',array_reverse(explode('-',$datanascimento)));?>
															<div class="input-container"><input onBlur="VerificaData(this.value);" name="datanascimento" id='datanascimentop'required  value='<?=$datanascimento2;?>' type="text"    class="input req-same"  /></div>
														</div>
														<div class="form-row">
															<div class="label">Naturalidade <font class='simbolo'>&#10045;</font></div>
															<div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="naturalidade" required value='<?=$naturalidade;?>'  type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="40"  /></div>
														</div>
														
														<div class="form-row">
															<div class="label">Gênero <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"  style='width:546px;'>
															<select name="sexo" id="sexo"  required tabindex="12" width='100px' >
															<?
																			switch ($sexo){										
																			case "M":											
																			$sexo_N = "Masculino";
																			break;

																			case "F":											
																			$sexo_N = "Feminino";
																			break;
																			case "A":											
																			$sexo_N = "Ambos";
																			break;
																			}
																			?>
																			<option value="<?=$sexo;?>"><?=$sexo_N;?></option>																			
																			
																		<option value="M">Masculino</option>
																		<option value="F">Feminino</option>
																	</select></div>
														</div>
														
														
														
														<div class="form-row">
															<div class="label">Estado Civil  </div>
															<div class="input-container"  style='width:546px;'>
															<select name="estadocivil" id="estadocivil"  tabindex="13" style="width:150px">
																		<?
																			switch ($estadocivil){										
																			case "S":											
																			$estadocivil_N = "Solteiro";
																			break;case "C":											
																			$estadocivil_N = "Casado";
																			break;case "U":											
																			$estadocivil_N = "União Estável";
																			break;case "E":											
																			$estadocivil_N = "Desquitado";
																			break;case "D":											
																			$estadocivil_N = "Divorciado";
																			break;case "V":											
																			$estadocivil_N = "Viúvo";
																			break;case "O":											
																			$estadocivil_N = "Outro";
																			break;

																		
																			}
																			?>
																				<option value="<?=$estadocivil;?>"><?=$estadocivil_N;?></option>
																				<option value="S">Solteiro</option>
																				<option value="C">Casado</option>
																				<option value="U">União Estável</option>
																				<option value="E">Desquitado</option>
																				<option value="D">Divorciado</option>
																				<option value="V">Viúvo</option>
																				<option value="O">Outro</option>
																	</select></div>
														</div>
														
														
														
																	<script type="text/javascript">

																$(document).ready(function(){
																 $('#deficiencia').hide();

																 $('#mostrar').click(function(event){
																 event.preventDefault();
																 $("#deficiencia").show("slow");
																 });

																 $('#ocultar').click(function(event){
																 event.preventDefault();
																 $("#deficiencia").hide("slow");
																 });
																 });

																</script>

																
																
											
											<div id='deficiente' name='deficiente'class="form-row" >
											
											</div>
																
																
																
																
																
																
																
																
																
																
																
																
														
														
															


														<h2>ENDEREÇO</h2>
															<div class="form-row">
															<div class="label">CEP</div>
															<div class="input-container">
															<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cep" id="cep" style="width:200px "value="<?=$cep;?>" maxlength="10"  class="input req-same"onkeyup="verificaNumero('window.document.Ficha.cep');" tabindex="27"  type="text" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>

													<script  type="text/javascript">	
													// FUNÇÃO PARA BUSCA NOTICIA
													function busca_cidade(valor2) {
													// Verificando Browser
													if(window.XMLHttpRequest) {
													req = new XMLHttpRequest();
													}
													else if(window.ActiveXObject) {
													req = new ActiveXObject("Microsoft.XMLHTTP");
													}

													// Arquivo PHP juntamente com o valor digitado no campo (método GET)

													var url = "busca_endereco.php?tipo_busca=cidade&uf="+valor2;

													// Chamada do método open para processar a requisição
													req.open("Get", url, true); 
													req.setRequestHeader("Cache-Control","no-cache,no-store");
													req.setRequestHeader("Pragma", "no-cache");

													// Quando o objeto recebe o retorno, chamamos a seguinte função;
													req.onreadystatechange = function() {

													// Exibe a mensagem "Buscando Noticias..." enquanto carrega
													if(req.readyState == 1) {
													document.getElementById('cidadeid').innerHTML = '<option >buscando</option>';
													}

													// Verifica se o Ajax realizou todas as operações corretamente
													if(req.readyState == 4 && req.status == 200) {

													// Resposta retornada pelo busca.php
													var resposta = req.responseText;

													// Abaixo colocamos a(s) resposta(s) na div resultado
													document.getElementById('cidadeid').innerHTML = resposta;
													}
													}
													req.send(null);
													req.setRequestHeader("Cache-Control", "no-cache");
													req.setRequestHeader("Pragma", "no-cache"); 

													}
													</script>
															
															
															<div class="form-row">
															<div class="label">Estado <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container">	
																<select name="txtestado" required id="txtestado" onchange="busca_cidade(this.value);" >
																
																<?	
												$query_estado_db = "SELECT * FROM `cidade` where id='$cidadeid' ";
												$rs_estado_db     = mysql_query($query_estado_db );
												while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
												$ufid        = $campo_estado_db ['ufid'];

													$query_estado_dbuf = "SELECT * FROM `uf` where id='$ufid' ";
													$rs_estado_dbuf     = mysql_query($query_estado_dbuf );
													while($campo_estado_dbuf  = mysql_fetch_array($rs_estado_dbuf )){
													$uf_nome        = $campo_estado_dbuf ['uf'];
													$id_uf_db        = $campo_estado_dbuf ['id'];
													}
											
												}	
												?>
												<option value='<?=$id_uf_db;?>'><?=$uf_nome ;?></option>
																						
												<?
												$query_noticias_estado = "SELECT *  FROM  `uf` ORDER BY  `uf`.`uf` ASC ";
												$rs_noticias_estado    = mysql_query($query_noticias_estado);
												while($campo_noticias_estado = mysql_fetch_array($rs_noticias_estado)){		
												$iduf 	= $campo_noticias_estado['id']; 
												$nome_uf 	= $campo_noticias_estado['uf']; 
												
												?>
												<option value='<?=$iduf;?>'><?=$nome_uf ;?></option>			
												<?}?>
																</select>	
															
															</div>
															</div>
															



															
															
																	<?	
															$query_noticias_cidadecp = "SELECT * FROM `cidade` where id='$cidadeid' ";
															$rs_noticias_cidadecp    = mysql_query($query_noticias_cidadecp);
															while($campo_noticias_cidadecp = mysql_fetch_array($rs_noticias_cidadecp)){
															$nome_cidade        = $campo_noticias_cidadecp['nome'];	
															$id_cidade        = $campo_noticias_cidadecp['id'];	
															}	
															?>
																	<div class="form-row">
															<div class="label">Cidade <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container">
																<select name="cidadeid" required id="cidadeid" onchange="busca_bairo(this.value);" >
																	<option value='<?=$id_cidade;?>'><?=$nome_cidade;?></option>
																</select>			
															</div>
															</div>
															
														
														<div class="form-row">
															<div class="label">Bairro <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container">
																<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="bairro" required id="bairro" value="<?=$bairro;?>" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();"   class="input req-same"tabindex="33"  type="text" onkeyup="this.value = this.value.toUpperCase();">
																
															</div>
															</div>
																	<script type="text/javascript">
																	$().ready(function() {
																	//var id_bairro_ecolhido = $('#bairro option:selected').val();
																	$("#endereco").autocomplete("autoComplete_endereco.php?id_bairro_ecolhido=", {
																	width: 546,
																	matchContains: true,
																	//mustMatch: true,
																	//minChars: 0,
																	//multiple: true,
																	//highlight: false,
																	//multipleSeparator: ",",
																	selectFirst: false
																	});
																	</script>
														<div class="form-row">
															<div class="label">Endereço <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container">
															<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="endereco" id="endereco" required  value="<?=$endereco;?>" maxlength="400" onchange="Maiuscula(this);EditandoRegistro();"   class="input req-same"tabindex="33"  type="text" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>
														<h2>CONTATOS</h2>
														
														<div class="form-row">
															<div class="label"></div>
															<div class="input-container"   style='width:555px;'>
															Tel.: Residencial
																	<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="telres" id="telres" value="<?=$telres;?>" maxlength="12"  class="input req-same"    tabindex="34" style="width:110px;" type="text" /> 
																	&nbsp;Celular <font class='simbolo'>&#10045;</font> 
																	<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="telcel" required id="telcel" value="<?=$telcel;?>" maxlength="14" class="input req-same" tabindex="35" style="width:110px;" type="text" />
																	&nbsp;Recado
																	<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="telrec" id="telrec" value="<?=$telrec;?>" maxlength="14"  class="input req-same" tabindex="36" style="width:110px;" type="text" /> 
															</div>
															</div>
															
														<div class="form-row">
															<div class="label">Contato para Recados</div>
															<div class="input-container"   style='width:546px;'>
															<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="nmrecado" id="nmrecado" value="<?=$nmrecado;?>" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" class="input req-same"tabindex="37"  type="text" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>
														<div class="form-row">
															<div class="label">Email<font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"   style='width:546px;'>
																<input onChange="javascript:this.value=this.value.toUpperCase();" required onChange="javascript:this.value=this.value.toUpperCase();" name="email" id="email" value="<?=$email;?>"  maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" class="input req-same" tabindex="38"  type="email" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>
															
														<h2>DOCUMENTOS</h2>
																<div class="form-row">
																<div class="label"></div>
																<div class="input-container"   style='width:546px;'>
																Identidade <font class='simbolo'>&#10045;</font> 
																<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="identidade" required id="identidade" value="<?=$identidade;?>"class="input req-same" maxlength="15" class="input req-same"tabindex="39" style="width:124px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
																
																Orgão Expedidor <font class='simbolo'>&#10045;</font>
																<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="orgaoexpedidor" required id="orgaoexpedidor" value="<?=$orgaoexpedidor;?>" class="input req-same" maxlength="50" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="40" style="width:179px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
																</div>
																</div>
														
														<div class="form-row">
															<div class="label"></div>
															<div class="input-container"   style='width:546px;'>
																	
																	
																	Possui CNH
																	<select name="tipocnh"  id="tipocnh" onchange="Maiuscula(this);EditandoRegistro();" style="width:63px;" tabindex="44">
																		<option value="<?=$tipocnh;?>"><?=$tipocnh;?></option>
																		<option value="A">A</option>
																		<option value="B">B</option>
																		<option value="C">C</option>
																		<option value="D">D</option>
																		<option value="E">E</option>
																		<option value="AB">AB</option>
																		<option value="AC">AC</option>
																		<option value="AD">AD</option>
																		<option value="AE">AE</option>
																		<option value="NÃO">NÃO</option>
																	</select>
															</div>
															</div>
														
														
														<div class="form-row">
															<div class="label"></div>
															<div class="input-container"   style='width:546px;'>
																	Carteira Trabalho 
																	<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="carteiratrabalho"  value="<?=$carteiratrabalho;?>"id="carteiratrabalho" class="input req-same" maxlength="15" onkeyup="verificaNumero('window.document.Ficha.carteiratrabalho');" tabindex="45" style="width:61px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
																	Série
																	<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="seriect"  value="<?=$seriect;?>"id="seriect" maxlength="10" class="input req-same" onkeyup="VerificaMascara('window.document.Ficha.seriect','####/@@',1)" tabindex="46" style="width:55px;" type="text" onkeyup="this.value = this.value.toUpperCase();">

																	Expedidor 
																	<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="orgaoreg"  value="<?=$orgaoreg;?>"id="orgaoreg" maxlength="10" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="48" style="width:55px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>
														
														<div class="form-row">
															<div class="label"></div>
															<div class="input-container"   style='width:546px;'>
																	PIS/PASEP
																	<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="pispasep" value="<?=$pispasep;?>"id="pispasep" maxlength="20" class="input req-same"tabindex="49" style="width:202px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
																	Passaporte 
																	<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="passaporte" value="<?=$passaporte;?>" id="passaporte" maxlength="10" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="50" style="width:188px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>
																

														

															
															
															<div class="form-row">
															<div class="label">Alguém na residência está inscrito em algum Programa Social  <font class='simbolo'>&#10045;</font></div>
															<div class="input-container"   style='width:546px;'>
																
																	

																					<select name="programasocialid" required id="programasocialid" >
																			
																			<?	
																			$query_programasocialid_bd = "SELECT *  FROM  `programasocial` where id='$programasocialid'";
																			$rs_programasocialid_bd    = mysql_query($query_programasocialid_bd);
																			while($campo_programasocialid_bd = mysql_fetch_array($rs_programasocialid_bd)){
																			$nome_programasocialid_bd         = $campo_programasocialid_bd['nome'];	
																			$id_programasocialid_bd         = $campo_programasocialid_bd['id'];	
																				
																			?><?}?>
																		<option value="<?=$id_programasocialid_bd;?>"><?=$nome_programasocialid_bd;?></option>
																			
																			
																			
																			<?	
																			$query_programasocialid = "SELECT *  FROM  `programasocial` ORDER BY  `programasocial`.`nome` ASC ";
																			$rs_programasocialid    = mysql_query($query_programasocialid);
																			while($campo_programasocialid = mysql_fetch_array($rs_programasocialid)){
																			$nome_programasocialid         = $campo_programasocialid['nome'];	
																			$id_programasocialid         = $campo_programasocialid['id'];	
																				
																			?>
																			<option value='<?=$id_programasocialid;?>'><?=$nome_programasocialid;?></option>
																			<?}?>
																	
																					</select>
															</div>
															</div>
															
															
															<div class="form-row" >
															<div class="label"></div>
															<div class="input-container" style='width:546px;padding-bottom:162px;'>		
																<a  href="#cadastro1" style='display:none;'> DADOS DA VAGA</a>	
																
																
																<a  href="#proficional" class="sendBtn" id='proximo11'   onclick='carrega_historico_proficional();'>Próximo &#9658;<a>	

															</div>
															</div >


												</div>
												
												
											



												<div name='proficional' id='proficional'>
												
																<div style='margin:20px;width:100%;' align='center'>
																	<font style='font-size:15px;color:red;font-weight:bold;'>PASSO 1 &#10132; </font>
																	<font style='font-size:15px;color:red;font-weight:bold;'>PASSO 2 &#10132; </font>
																	<font style='font-size:15px;color:#999;font-weight:bold;'>PASSO 3  </font>

																	</div>


																			<script type="text/javascript">
																			$().ready(function() {
																			$("#cboid1").autocomplete("interno/789/autoComplete.php", {
																			width: 546,
																			//matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});


																			$("#cboid2").autocomplete("interno/789/autoComplete.php", {
																			width: 546,
																			//matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});

																			$("#cboid3").autocomplete("interno/789/autoComplete.php", {
																			width: 546,																			
																			matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});

																			$("#txtocupacao4").autocomplete("interno/789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});
																			
																			
																			
																			$("#cargo").autocomplete("interno/789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});
																			
																			$("#cboid1").autocomplete("interno/789/autoComplete.php", {
																			width: 546,
																		matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});
																			$("#cboid2").autocomplete("interno/789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});
																			
																			$("#cboid3").autocomplete("interno/789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});
																			
																			$("#cboid").autocomplete("interno/789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});
																			
																			
																			});
																			</script>



																			

																			<script type="text/javascript">
																			$(function(){
																			$("#pretensaosalarial").maskMoney({symbol:'R$ ',showSymbol:true, thousands:'.', decimal:',', symbolStay: true});
																			$("#ultimosalario").maskMoney({symbol:'R$ ',showSymbol:true, thousands:'.', decimal:',', symbolStay: true});
																			})
																			</script>








																			<h2>OBJETIVOS </h2>
																			<h4>Ocupações Pretendidas / CBO</h5>


																			<div class="form-row">
																			<div class="label">1- <font class='simbolo'>&#10045;</font></div>
																			<div class="input-container">
																					
																		<?
																		$query_cboid1 = "SELECT * FROM `cbo` where id='$cboid1' ";
																		$rs_cboid1     = mysql_query($query_cboid1 );
																		while($campo_cboid1  = mysql_fetch_array($rs_cboid1 )){
																		$cbo1        = $campo_cboid1 ['cbo'];
																		}
																		?>

																			
																			
																			
																			
																			<input name="cboid1" required placeholder="Escreva sua ocupação pretendida" id="cboid1" value="<?echo $cbo1;?>" onChange="javascript:this.value=this.value.toUpperCase();" class="input req-same" size="60" maxlength="200" onchange="EditandoRegistro2()" tabindex="1"  type="text">
																			
																			</div>
																			</div>


																			<div class="form-row">
																			<div class="label">2- <font class='simbolo'></font></div>
																			<div class="input-container">	

																				<?
																		$query_cboid2 = "SELECT * FROM `cbo` where id='$cboid2' ";
																		$rs_cboid2     = mysql_query($query_cboid2 );
																		while($campo_cboid2  = mysql_fetch_array($rs_cboid2 )){
																		$cbo2        = $campo_cboid2 ['cbo'];
																		}
																		?>	

																			
																			<input  name="cboid2"  placeholder="Escreva sua ocupação pretendida" id="cboid2" class="input req-same" value="<?echo $cbo2;?>" onChange="javascript:this.value=this.value.toUpperCase();" size="60" maxlength="200" onchange="EditandoRegistro2()" tabindex="1"   type="text">		
																			
																			</div>
																			</div>


																			<div class="form-row">
																			<div class="label">3- <font class='simbolo'></font></div>
																			<div class="input-container">		
																			
																			<?
																		$query_cboid3 = "SELECT * FROM `cbo` where id='$cboid3' ";
																		$rs_cboid3     = mysql_query($query_cboid3 );
																		while($campo_cboid3  = mysql_fetch_array($rs_cboid3 )){
																		$cbo3        = $campo_cboid3 ['cbo'];
																		}
																		?>	
																			
																			
																			<input  name="cboid3"  placeholder="Escreva sua ocupação pretendida" id="cboid3" value="<?echo $cbo3;?>"class="input req-same" size="60" onChange="javascript:this.value=this.value.toUpperCase();"  maxlength="200" onchange="EditandoRegistro2()" tabindex="1"  type="text">			
																			
																			
																			</div>
																			</div>



																			<div class="form-row">
																			<div class="label"></div>
																			<div class="input-container" style='width:546px;'>		
																			Pretensão Salarial
																			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="pretensaosalarial"  id="pretensaosalarial" value=" <?echo '' . number_format($pretensaosalarial, 2, ',', '.');?>"  maxlength="14"  class="input req-same"onchange="EditandoRegistro2();" style="font-family: Tahoma; font-size: 10px;width:100px;" tabindex="17" value="" type="text"/> 
																			Último Salário
																			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="ultimosalario" id="ultimosalario" value="<?echo '' . number_format($ultimosalario, 2, ',', '.');?>"  maxlength="14"  class="input req-same" onchange="EditandoRegistro2();" style="font-family: Tahoma; font-size: 10px;width:100px;" tabindex="18" value="" type="text"/> 
																			</div>
																			</div>

													
																			<? include'proficional.php'; ?> 	
																			<div class="form-row" >
																			<div class="label"></div>
																			<div class="input-container" style='width:546px;padding-bottom:162px;'>		
																			<a  href="#cadastro1"  id="voltar1" class="sendBtn2"> &#9668; Anterior</a>	
																			
																			<a  href="#qualificacao" class="sendBtn" id='proximo22'  onclick="carrega_proficional();" >Próximo &#9658;</a>	

																			</div>
																			</div >

											
													
													</div>
													
													
													
													
													
													<div name='qualificacao' id='qualificacao'>
													
														<div style='margin:20px;width:100%;' align='center'>
																	<font style='font-size:15px;color:red;font-weight:bold;'>PASSO 1 &#10132; </font>
																	<font style='font-size:15px;color:red;font-weight:bold;'>PASSO 2 &#10132; </font>
																	<font style='font-size:15px;color:red;font-weight:bold;'>PASSO 3 </font>

																	</div>

													
														<?include'qualificacao.php';?> 
													
													
													<script type="text/javascript">

										var tempo1 = window.setInterval(carrega, 900000);
										function carrega3()
										{
										$('#mensagem').load("menssagem_form.php");

										}
										</script>
															<div class="form-row" style='padding-bottom:160px;'>
													<div class="label"></div>
														<div class="input-container" style='width:546px;'>		
															<a  href="#proficional"  class="sendBtn2" id="voltar2"> &#9668; Anterior</a>	
															<!--<a  href="#emcaminhamentodiv" class="sendBtn"  >Próximo &#9658;</a>	-->
																																		
															<?if($id ==""){?>
																<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Concluir" type="submit" onclick='carrega3()' class="sendBtn3" />
															<?}else{?>	
																<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="&#10004; Concluir cadastro" onclick='carrega3()' type="submit" class="sendBtn3" />
															<?}?>
																
																<div id='mensagem' name='mensagem'></div>
																
														</div>
													</div >
													
													
							
											
														
													</div>

													



															
															
													</div>	<!--div pagginação-->				
															
															
										</form>	
												
																					
														
												
												
									
											
							
						
									<?}else{?>
														
														<?
															$query_noticias = "SELECT * FROM `usuario` WHERE usuario LIKE '%$cpf_busca%'";										
															$rs_noticias    = mysql_query($query_noticias);
															while($campo_noticias = mysql_fetch_array($rs_noticias)){
															$idusuario 	= $campo_noticias['id']; 	 		 			 	
															}
															if($idusuario > 0)
															{
															?>
															
															
															<SCRIPT language="JavaScript">window.location.href="login.php?msg=Já possui cadastro, favor realizar Login!";</SCRIPT>
															
															<?	
																}else{
															?>
														<!-- cadastro usuario-->
														<h3>Parabéns CPF: <?=$cpf_busca;?> já Cadastrado! </h3>														
														<h4>Cadastre seu dados de Acesso! </h4>
														
														<script> 
															function validarConfirmacao(){ 

															var senha = document.formusuario.senha.value; 
															var resenha = document.formusuario.resenha.value; 
															if(senha != resenha){ 
															alert("Confirmação e senha diferentes") 
															document.formusuario.resenha.value=""; 
															} 
															} 
															</script> 
						
														<form method='post'class="form"  action=''name='formusuario' id='formusuario'>
															<input type='hidden' name='usuario' value='<?=$cpf_busca;?>'/>
															<input type='hidden' name='nome' maxlength="100" value='<?=$nometrabalhador;?>'/>
															<div class="form-row">
																<div class="label">Senha <font class='simbolo'>&#10045;</font> </div>
																<div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="senha" required  value='<?=$senha;?>'type="password" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="13"  /></div>
															</div>
															
															<div class="form-row">
																<div class="label">Repetir-Senha <font class='simbolo'>&#10045;</font> </div>
																<div class="input-container"><input onBlur="validarConfirmacao()"  name="resenha" required  value='<?=$senha;?>'type="password" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="13"  /></div>
															</div>
															
															
															<div class="form-row" style='padding-bottom:160px;'>
																<div class="label"></div>
																	<div class="input-container" style='width:546px;'>		
																																			
																			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Concluir" type="submit" onclick='carrega3()' class="sendBtn3" />
																		
																			
																	</div>
															</div >
													
														</form>
														<!-- cadastro usuario-->
														<?}?>
										
									<?}?>
					
						</td>	

					</tr>
				</table>
				
		</div>
		
		<!--------------------cria paginações paginas--------------->
<script type="text/javascript" src="jquery.idTabs.min.js"></script>

<script type="text/javascript"> 
$('div.abas').click(function(){
    $('div.abas').removeClass("abas_ative");
    $(this).addClass("abas_ative");
});
</script>
<!--------------------cria paginações paginas--------------->

		 

		<?include"rodape_novo.php";?>
		
</body>
</html>