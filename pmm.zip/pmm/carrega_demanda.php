<?php
include("conf.php"); // Inclui o arquivo com o sistema de segurança

error_reporting(0);

?>


 <html>
  <head>
    <title>yLog Scroll Tutorial</title>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js" type="text/javascript"></script>  
    <script>
      $(document).ready(function() {
        $("#content").scroll(function() { 
          if ($(this).scrollTop() + $(this).height() == $(this).get(0).scrollHeight) {
            console.log("fim");
            $("#content").append("<option>item x</option>");
 
            $.ajax({
              type: "post",
              url: "/maisitems/",
              success: function(data) {
                  //manipula os dados
                  $("#content").append("<option>" + item + "</option>");
              },
              error: function() {
              }
            });
          }
        });
      });
    </script>
  </head>
  <body>
    <div id="content2" style="width:120; height:100px; overflow-y:scroll;">
      <select id="content" name='content'style="position: relative;">
       <option>item 1</option>
       <option>item 2</option>
       <option>item 3</option>
       <option>item 4</option>
       <option>item 5</option>
       <option>item 6</option>
       <option>item 7</option>
       <option>item 8</option>
       <option>item 9</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
       <option>item 10</option>
      </select>
    </div>
  </body>
</html>