<?include("conf_trabalhado.php"); // Inclui o arquivo com o sistema de segurança

error_reporting(0);
?>

<html>
<?include'topo.php';?>

		
<body onload="">
			
			
			
		<?include"topo_logo_trabalhador.php";?>
	
	
		<div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);margin-top:50px;' align='center' >
			<table width='960px'>
					<tr>
					
					
						<td width=''>
									
							<div style='min-height:400px;'>	
							
						<?
						$query_dados_tra_agendamento = "SELECT cpf,telcel,nome,telres,datanascimento,email FROM `trabalhador` WHERE id='$usuario_id' ";
						$rs_dados_tra_agendamento    = mysql_query($query_dados_tra_agendamento);																							
						while($campo_noticias_dados_tra_agendamento = mysql_fetch_array($rs_dados_tra_agendamento)){
						$cpf_dados_tra_agendamento  = $campo_noticias_dados_tra_agendamento['cpf'];
						$telcel_dados_tra_agendamento  = $campo_noticias_dados_tra_agendamento['telcel'];
						$nome_dados_tra_agendamento  = $campo_noticias_dados_tra_agendamento['nome'];
						$telres_dados_tra_agendamento  = $campo_noticias_dados_tra_agendamento['telres'];
						$datanascimento_tra_agendamento  = $campo_noticias_dados_tra_agendamento['datanascimento'];
						$email_tra_agendamento  = $campo_noticias_dados_tra_agendamento['email'];
						$datanascimento_tra_agendamento = implode('/',array_reverse(explode('-',$datanascimento_tra_agendamento)));
						}

						?>					
							

				<?$url = $_GET['urlifreme'];?>


		
<iframe scrolling="yes" src="<?=$url;?>&nome=<?=$nome_dados_tra_agendamento;?>&telres=<?=$telres_dados_tra_agendamento;?>&telcel=<?=$telcel_dados_tra_agendamento;?>&cpf=<?=$cpf_dados_tra_agendamento;?>&datanascimento_tra_agendamento=<?=$datanascimento_tra_agendamento;?>&email=<?=$email_tra_agendamento;?>" ALLOWTRANSPARENCY="true" style=" top:0px; left:0px; bottom:0px; right:0px; width:100%; height:1500px; border:none; margin:0; padding:0; overflow:hidden; "/>


	
							</div>
									
						</td>	

					</tr>
				</table>
				
		</div>
		
		
		 	 
<script type="text/javascript" src="jquery.idTabs.min.js"></script>

<script type="text/javascript"> 
$('div.abas').click(function(){
    $('div.abas').removeClass("abas_ative");
    $(this).addClass("abas_ative");
});
</script>

		<?include"rodape_novo.php";?>
		
</body>
</html>
