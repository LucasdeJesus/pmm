
<h2>CTPS</h2>

			<div class="form-row">
			<div class="label"></div>
			
			<div class="input-container" style='width:546px;'>	
				Carteira Trabalho	
			<input name="txtcarttrabalho" id="txtcarttrabalho" class="input req-same" maxlength="18" onchange="EditandoRegistro();" onkeyup="verificaNumero('window.document.Ficha.txtcarttrabalho');" tabindex="3" style="width:125px;" type="text">
			<b>Série</b> (9999/AA)
			<input name="txtserie" id="txtserie" maxlength="9" class="input req-same" onchange="EditandoRegistro();" onkeyup="VerificaMascara('window.document.Ficha.txtserie','####/@@',1)" tabindex="4" style="width:55px;" type="text">
			&nbsp;&nbsp;&nbsp;
			Via
			<select name="chk1via" id="chk1via" onchange="EditandoRegistro()" style="width:136px;"  tabindex="5">
				<option value="">Selecione</option>
				<option value="S">1ª Via</option>
				<option value="2">2ª Via</option>
				<option value="C">Continuação</option>
			</select>	
			</select>	

			</div>
			</div>
			
		