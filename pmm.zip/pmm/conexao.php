<?include("interno/input_banco.php");
?>