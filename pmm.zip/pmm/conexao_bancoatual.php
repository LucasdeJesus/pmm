<?include("input_banco.php");
?>