<?php include'conexao.php';?>
<?
include("seguranca_empresa.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>	
