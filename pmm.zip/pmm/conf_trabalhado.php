<?php
include("seguranca_trabalhador.php"); // Inclui o arquivo com o sistema de segurança

?>	
