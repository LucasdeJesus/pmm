


<?
include("interno/input_banco.php"); 
$cpf_buscaagenda=(string)addslashes($_GET['id']);



function validaCPF($cpf)
{	// Verifiva se o número digitado contém todos os digitos
    $cpf = str_pad(ereg_replace('[^0-9]', '', $cpf), 11, '0', STR_PAD_LEFT);
	
	// Verifica se nenhuma das sequências abaixo foi digitada, caso seja, retorna falso
    if (strlen($cpf) != 11 || $cpf == '00000000000' || $cpf == '11111111111' || $cpf == '22222222222' || $cpf == '33333333333' || $cpf == '44444444444' || $cpf == '55555555555' || $cpf == '66666666666' || $cpf == '77777777777' || $cpf == '88888888888' || $cpf == '99999999999')
	{
	return false;
    }
	else
	{   // Calcula os números para verificar se o CPF é verdadeiro
        for ($t = 9; $t < 11; $t++) {
            for ($d = 0, $c = 0; $c < $t; $c++) {
                $d += $cpf{$c} * (($t + 1) - $c);
            }

            $d = ((10 * $d) % 11) % 10;

            if ($cpf{$c} != $d) {
                return false;
            }
        }

        return true;
    }
}
// Verifica se o botão de validação foi acionado
if(isset($cpf_buscaagenda))
	{// Adiciona o numero enviado na variavel $cpf_enviado, poderia ser outro nome, e executa a função acima
	$cpf_enviado = validaCPF($cpf_buscaagenda);
	// Verifica a resposta da função e exibe na tela
	if($cpf_enviado == true)
		$verifica= "V";
	elseif($cpf_enviado == false)
		$verifica= "F";
	}
	if($verifica=="F"){
		
		Echo"CPF Invalido";
		exit;
	}
	
$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where  cpf='$cpf_buscaagenda' ORDER BY `id` DESC ";
				//echo$cpf_buscaagenda; 
				$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
				while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
				$idp  = $campo_noticias_hcpj['id'];
				$cpf_buscap =$campo_noticias_hcpj['cpf'];
				$nomep = $campo_noticias_hcpj['nome'];
				$datanascimentop = $campo_noticias_hcpj['datanascimento'];
				$telcelp = $campo_noticias_hcpj['celular'];
				$telres = $campo_noticias_hcpj['telefone'];					
				$datap = $campo_noticias_hcpj['data'];					
				$horariop = $campo_noticias_hcpj['horario'];					
				$tipo = $campo_noticias_hcpj['tipo'];		
				$status = $campo_noticias_hcpj['status'];		


				switch ($tipo) {
				case "C" :
					$tipoatendimento = "Atendimento CTPS";
					break;
				case "D":
					$tipoatendimento =  "Atendimento DETRAN";
					break;
				case "V":
					$tipoatendimento =  "Atendimento Vagas ";
					break;
				}				
				

				$data = date("d-m-Y", strtotime($datap));
				
				$vowels = array("(", ")", ".", "-");
				$numerocelular = str_replace($vowels, "", $telcelp);
				
				switch ($status) {
				case "A" :
				$status_n = "Ativo";
				break;
				case "C":
				$status_n =  "Cancelado";
				break;
				
				 default:
				$status_n =  "Outros";
				break;
				}		
				
			?>	
			<table>
													
																										
													
											
			
				<tr>
				<td class='td1' >Cancelar</td>
				<td class='td1' >ID</td>
				<td class='td1' >Atendimento </td>
				<td class='td1' >Satus </td>
				<td class='td1' >Data </td>
				<td class='td1' >Horário Previsto </td>
				<td class='td1'>CPF. </td>
				<td class='td1'>Imprimir </td>
				</tr>
			<tr class='tr_tb' >
				
				<td class='td2' ><?if($status=="A") {?>
				
				<a href="#" Onclick="cancelaagendamento('<?=$idp;?>');">Cancelar</a></td>
				<?}else{?>
				<a href="#">-- --</a></td>
				<?}?>
				<td class='td2' > <?=$idp;?> </td>
				<td class='td2' > <?=$tipoatendimento;?> </td>
				
				
				<td class='td2' > <?=$status_n;?> </td>
				<td class='td2' > <?=$data;?> </td>
				<td class='td2' > <?=$horariop;?> </td>
				<td class='td2' > <?=$cpf_buscap;?> </td>
				<td class='td2' > <a href="#" Onclick="Abrir_Pagina('agendamento/imprimeagendamento.php?idp=<?=$idp;?>');">Imprimir</a></td>
				
			</tr>
				</table>
			
			<?}?>
