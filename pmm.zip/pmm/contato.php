<?
?>

<html>
<?include'topo.php';?>

	<script>
 $(document).ready(function(){									
										$("#cadastro_empresa").validate();										
										$.validator.setDefaults({
									submitHandler: function() {
										
										}
										});
										});
</script>	
<body onload="">
			
			
			
		<?include"topo_logo.php";?>
	
	
		<div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);margin-top:50px;' align='center' >
			<table width='960px'>
					<tr>
					
					
						<td width=''>
									
							<div style='min-height:400px;'>	
						
								<?
								
								
								
													$email = $_POST['email'];
													$nome = $_POST['nome'];
													$mensagem = $_POST['mensagem'];
													if($email==""){}else{
													/* Medida preventiva para evitar que outros domínios sejam remetente da sua mensagem. */
													if (eregi('tempsite.ws$|locaweb.com.br$|hospedagemdesites.ws$|websiteseguro.com$', $_SERVER[HTTP_HOST])) {
													$emailsender='ctm@macae.rj.gov.br';
													} else {
													$emailsender = "ctm@macae.rj.gov.br";
													//    Na linha acima estamos forçando que o remetente seja 'webmaster@seudominio',
													// você pode alterar para que o remetente seja, por exemplo, 'contato@seudominio'.
													}

													/* Verifica qual é o sistema operacional do servidor para ajustar o cabeçalho de forma correta. Não alterar */
													if(PHP_OS == "Linux") $quebra_linha = "\n"; //Se for Linux
													elseif(PHP_OS == "WINNT") $quebra_linha = "\r\n"; // Se for Windows
													else die("Este script nao esta preparado para funcionar com o sistema operacional de seu servidor");

													// Passando os dados obtidos pelo formulário para as variáveis abaixo
													$nomeremetente     = "Secretaria Trabalho e Renda";
													$emailremetente    = "ctm@macae.rj.gov.br";
													$emaildestinatario = "$email";
													$comcopia          = "ctm@macae.rj.gov.br";
													$comcopiaoculta    = "";
													$assunto           = "CONTATO SEMTRE CTM 2.0";



													/* Montando a mensagem a ser enviada no corpo do e-mail. */
													$mensagemHTML = "<div style='border:1px solid #ddd;padding:10px' >
													<p> NOME: $nome</p>
													<p> EMAIL: $email</p>
													<p> $mensagem:</p>
													</div>";


													/* Montando o cabeçalho da mensagem */
													$headers = "MIME-Version: 1.1".$quebra_linha;
													$headers .= "Content-type: text/html; charset=ISO-8859-1".$quebra_linha;
													// Perceba que a linha acima contém "text/html", sem essa linha, a mensagem não chegará formatada.
													$headers .= "From: ".$emailsender.$quebra_linha;
													$headers .= "Return-Path: " . $emailsender . $quebra_linha;
													// Esses dois "if's" abaixo são porque o Postfix obriga que se um cabeçalho for especificado, deverá haver um valor.
													// Se não houver um valor, o item não deverá ser especificado.
													if(strlen($comcopia) > 0) $headers .= "Cc: ".$comcopia.$quebra_linha;
													if(strlen($comcopiaoculta) > 0) $headers .= "Bcc: ".$comcopiaoculta.$quebra_linha;
													$headers .= "Reply-To: ".$emailremetente.$quebra_linha;
													// Note que o e-mail do remetente será usado no campo Reply-To (Responder Para)

													/* Enviando a mensagem */
													mail($emaildestinatario, $assunto, $mensagemHTML, $headers, "-r". $emailsender);
													$msg="Obrigado! Seu contato foi enviado , breve responderemos";
													}
								
								?>
			
							<h3><?=$msg;?></h3>
							

							
				<!--<div style='height:225px;border: 3px dotted  red;margin:10px;border-radius: 5px;margin-top:10px;color:red;padding:15px;'>
							<h2>Comunicado Importante!</h2>
							<p>Informamos que devido  mudaça para  novo endereço , não haverá atendimento na AGETRAB / Central do Trabalhador de Macaé no dia <b>04/09/2015 sexta-feira.</b> 
							</p>
							<p>
								<b>Novo Endereço:<br>
								Rodovia Amaral Paixoto, S/n<br>
								Macaé -  RJ<br>
								Ponto de Referência: Em frente ao Estádio Cláudio Moacyr  </b>
							
							</p>
						</div>	-->
						<div>	

							<form  class="form" method="post" action="" id="cadastro_empresa" name='cadastro_empresa'>

							
					<div class="form-row">
						<div class="label">NOME<font class='simbolo'>&#10045;</font> </div>
						<div class="input-container" style='width:546px;'>		
							<input name="nome" id="nome" type='text' required maxlength="18"  tabindex="1" style="width:500px;" type="text" class="input req-same">
						</div>
					</div>
					
							
					<div class="form-row">
						<div class="label">E-mail<font class='simbolo'>&#10045;</font> </div>
						<div class="input-container" style='width:546px;'>		
							<input name="email" id="email" type='mail' maxlength="300"  required  tabindex="1" style="width:500px;" type="text" class="input req-same">
						</div>
					</div>
					
					
					
					<div class="form-row">
						<div class="label">Mensagem<font class='simbolo'>&#10045;</font> </div>
						<div class="input-container" style='width:546px;'>		
							<textarea width="300px" height='400px' name='mensagem'required  class="input req-same" ></textarea>
						</div>
					</div>
					
					<div class="form-row">
						<div class="label"></div>
						<div class="input-container" style='width:546px;'>		
							
						
							<input id="submitBtn2" value="Salvar" type="submit" class="sendBtn" />
								<div id="errorDiv2" class="error-div"></div>
						</div>
					</div>
							<form>



	
							</div>
									
						</td>	

					</tr>
				</table>
				
		</div>
		
		

		<?include"rodape_novo.php";?>
		
</body>
</html>
