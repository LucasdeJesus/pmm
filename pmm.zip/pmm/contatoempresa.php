<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	
	
	
	?>
	
	<div id="getexcel">
	<table border="1" width="100%"  class="sortable">
	<tr>
		<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;N°&nbsp;</b></font>
		</td>
		
		<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;CNPJ/CPF&nbsp;</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Razão Social&nbsp;</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab3" onMouseOver="MouseSobreCab('3')" onMouseOut="MouseSaiCab('3')" onClick="SelecionaCab('3')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Nome&nbsp;</b></font>
		</td>

		
		<td bgcolor="#000080" align="center" id="trCab5" onMouseOver="MouseSobreCab('5')" onMouseOut="MouseSaiCab('5')" onClick="SelecionaCab('5')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Endereço&nbsp;</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Email&nbsp;</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab7" onMouseOver="MouseSobreCab('7')" onMouseOut="MouseSaiCab('7')" onClick="SelecionaCab('7')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Telefone&nbsp;</b></font>
		</td>

		
	</tr>
		
					<?
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			$numero=1;
			
							
		$query_noticias = "SELECT *  FROM `empresa` ORDER BY `empresa`.`nome` DESC ";
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){



										$cnpj 	= $campo_noticias['cnpj']; 	 		 			 	
		$selTipo	= $campo_noticias['selTipo']; 	 		 			 	
		$razaosocial	= $campo_noticias['razaosocial']; 	 		 			 	
		$nome	= $campo_noticias['nome']; 	 		 			 	
		$segmentoatuacaoid	= $campo_noticias['segmentoatuacaoid']; 	 		 			 	
		$inscmunicipal	= $campo_noticias['inscmunicipal']; 	 		 			 	
		$inscestadual	= $campo_noticias['inscestadual']; 	 		 			 	
		$endereco	= $campo_noticias['endereco']; 	 		 			 	
		$bairro	= $campo_noticias['bairro']; 	 		 			 	
		$cidadeid	= $campo_noticias['cidadeid']; 			 			 	
		$cep	= $campo_noticias['cep']; 
		$emailresponsavel	= $campo_noticias['emailresponsavel']; 	 		 			 	
		$tel1= $campo_noticias['tel1']; 	 		 			 	
		$tel2= $campo_noticias['tel2']; 	 		 			 	
		$tel3= $campo_noticias['tel3']; 	 		 			 	
		$email= $campo_noticias['email']; 	 		 			 	
		$homepage= $campo_noticias['homepage']; 	 		 			 	
		$responsavel= $campo_noticias['responsavel']; 	 		 			 	
		$cargoresponsavel= $campo_noticias['cargoresponsavel']; 	 		 			 	
		$contato= $campo_noticias['contato']; 	 		 			 	
		$cargocontato= $campo_noticias['cargocontato']; 	 		 			 	
		$emailcontato= $campo_noticias['emailcontato']; 	 		 			 	
		$captadorid= $campo_noticias['captadorid']; 	 		 			 	
		$localcaptacaoid= $campo_noticias['localcaptacaoid']; 	 		 			 	
		$status= $campo_noticias['status']; 	 		 			 	
		$observacao= $campo_noticias['observacao']; 	 
		$id= $campo_noticias['id']; 	 
		$txtestadoentrevista= $campo_noticias['txtestadoentrevista']; 	 
		$cepentrevista= $campo_noticias['cepentrevista']; 	 
		$senha= $campo_noticias['senha']; 	 
		$jovemaprendiz= $campo_noticias['jovemaprendiz']; 	 
		$estagios= $campo_noticias['estagios']; 	 
		$contapcd= $campo_noticias['contapcd']; 	 
		$quantempregados= $campo_noticias['quantempregados']; 	 
		$referenciaend= $campo_noticias['referenciaend']; 	 
		
			?>
	
	
	<tr class='tr_tb' >		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$cnpj ;?> </td>
				<td class='td2' >  <?=$razaosocial;?></td>				
				<td class='td2' >  <?=$nome;?></td>		
								<?
								$query_estado_db = "SELECT * FROM `cidade` where id='$cidadeid' ";
								$rs_estado_db     = mysql_query($query_estado_db );
								while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
								$ufid        = $campo_estado_db ['ufid'];
								};
								$query_noticias_cidadecp = "SELECT * FROM `cidade` where id='$cidadeid' ";
								$rs_noticias_cidadecp    = mysql_query($query_noticias_cidadecp);
								while($campo_noticias_cidadecp = mysql_fetch_array($rs_noticias_cidadecp)){
								$nome_cidade        = $campo_noticias_cidadecp['nome'];	
								$id_cidade        = $campo_noticias_cidadecp['id'];	
								}	;
								?>	
				<td class='td2' ><?=$endereco;?>, <?=$bairro;?> ,<?=$nome_cidade;?>-<?=$ufid;?>/CEP:<?=$cep;?></td>				
				<td class='td2' >  <?=$email;?></td>				
				<td class='td2' >  <?=$tel1;?>, <?=$tel2;?>, <?=$tel2;?></td>				
			

	
	<?}?>
	
	</table>
	
	</div>