<?include("conf.php"); // Inclui o arquivo com o sistema de segurança

error_reporting(0);

		
		$id_trabalhafo_get = $_GET['id'];
		$nomeg = $_GET['nome'];
		$cpfg = $_GET['cpf'];
		
		$query_noticias_hcp = "SELECT * FROM `cursopalestra` WHERE trabalhadorid ='$id_trabalhafo_get'";
		$rs_noticias_hcp    = mysql_query($query_noticias_hcp);
		while($campo_noticias_hcp = mysql_fetch_array($rs_noticias_hcp)){
		
		$cursos_palestras 	= $campo_noticias_hcp['cursos_palestras']; 		
		$situacaocurso_cp = $campo_noticias_hcp['situacao'];
		$segmentoatuacaoid = $campo_noticias_hcp['segmentoatuacaoid'];
		$curso_cp = $campo_noticias_hcp['curso'];
		$comprovacaocurso = $campo_noticias_hcp['comprovacao'];
		$id = $campo_noticias_hcp['id'];
		
?>


	<tr class='tr_tb' >
					<?
					$query_noticias_hcsa = "SELECT * FROM `segmentoatuacao` where id='$segmentoatuacaoid'";
					$rs_noticias_hcsa    = mysql_query($query_noticias_hcsa);
					while($campo_noticias_hcsa = mysql_fetch_array($rs_noticias_hcsa)){
					$nomeseguimento 	= $campo_noticias_hcsa['nome']; 	
					
					?>
						
					<?}?>
		<td class='td2' width='205px'> <?=$nomeseguimento;?> </td>
		<td class='td2' width='221px'> <?=$curso_cp;?> </td>
		
					<?
			switch ($situacaocurso_cp){										
			case "C":											
			$situacaocurso_cp_N = "Completo";
			break;case "U":											
			$situacaocurso_cp_N = "Cursando";
			break;case "I":											
			$situacaocurso_cp_N = "Incompleto";
			break;
			}
			?>		

			
		<td class='td2' width='83px'>  <?=$situacaocurso_cp_N;?></td>		
			<?
			switch ($comprovacaocurso){										
			case "N":											
			$comprovacaocurso_N = "Não";
			break;case "S":											
			$comprovacaocurso_N = "Sim";
			break;
			}
			?>		
		<td class='td2' width='83px'>  <?=$comprovacaocurso_N;?></td>				
		<td class='td2' width=''><a href="javascript:Abrir_Pagina('editar_curso_palestra.php?id=<?=$id;?>&nome=<?=$nomeg;?>&cpf=<?=$cpfg;?>','scrollbars=yes,width=600,height=500');" title='Saiba mais'><img src='img/busca.png'/></a> </td>
		
	</tr>

<?}?>