<?php
include("conf.php"); // Inclui o arquivo com o sistema de segurança

error_reporting(0);

$id_bairro_ecolhido = $_GET['id_bairro_ecolhido'];
$q = strtolower($_GET["q"]);
if (!$q) return;

$sql = "SELECT * FROM `logradouros` where desc_logradouro LIKE '%$q% '";
$rsd = mysql_query($sql);
while($rs = mysql_fetch_array($rsd)) {
	$desc_logradouro= $rs['desc_logradouro'];
	
	echo "$desc_logradouro\n";
}
?>
