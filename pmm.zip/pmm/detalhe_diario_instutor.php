<?
include'conf.php';
?>
<html> 
<head>
<?//include'head.php';?>
<script language="JavaScript" type="text/JavaScript">
    function doPrint() {
    bdhtml = window.document.body.innerHTML;
    sprnstr = "<!--startprint-->";
    eprnstr = "<!--endprint-->";
    prnhtml = bdhtml.substr(bdhtml.indexOf(sprnstr)+17);
    prnhtml = prnhtml.substring(0,prnhtml.indexOf(eprnstr));
    window.document.body.innerHTML = prnhtml;
    window.print();
    }
</script>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body>



<?
		$id_modulo_i = $_POST['id_modulo'];
		$id_turma_i = $_POST['id_turma'];
		$id_teste_i = $_POST['id_teste'];
		$nota_1_i = $_POST['nota_1'];
		$nota_2_i = $_POST['nota_2'];
		$faltas_i = $_POST['faltas'];
		$resultado_final_i = $_POST['resultado_final'];
		$id_aluno_modulo_i = $_POST['id_aluno_modulo'];
		$totalalunopost = $_POST['totalaluno'];

				
if($id_turma_i=="") 

	{}
	else
	
	{
		
		
/*
		$it=0;				
		$i=0;				
		$i2=0;				
		$i3=0;				
		$i4=0;				
		$i5=0;				
		while ($id_aluno_modulo_i[$it] != NULL) {
		// echo $produto[$i] ."<br>"; 
		//echo $quantidade[$iq] ."<br>"; 
		$i++;
		$it++;
		$i2++;
		$i3++;
		$i4++;
		$i5++;
			$query_noticiasy = "update aluno_modulo SET  nota_1='$nota_1_i[$i]', nota_2='$nota_2_i[$i2]' , faltas='$faltas_i[$i3]', resultado_final='$resultado_final_i[$i4]' where id_aluno_modulo='$id_aluno_modulo_i[$i5]' ";
			$rs_noticiasy    = mysql_query($query_noticiasy);
			echo $query_noticiasy."<br>";
		}*/
	}

?>









<div data-role="page" data-theme="c" id="foo">

	<?//include'head_page.php';?>

	
	
	<div data-role="content" data-theme="c">	
	
<input id="btnPrint" type="image" src="img/impresora.png" width='27px' onclick="doPrint()" />	
<!--startprint-->	
	<script type="text/javascript" language="javascript">
// FUNÇÃO PARA BUSCA NOTICIA
			function inserirajax(url){	
				// Verificando Browser
				if(window.XMLHttpRequest) {
				req = new XMLHttpRequest();
				}
				else if(window.ActiveXObject) {
				req = new ActiveXObject("Microsoft.XMLHTTP");
				}

				// Arquivo PHP juntamente com o valor digitado no campo (método GET)

				

				// Chamada do método open para processar a requisição
				req.open("Get", url, true); 
				req.setRequestHeader("Cache-Control","no-cache,no-store");
				req.setRequestHeader("Pragma", "no-cache");

				// Quando o objeto recebe o retorno, chamamos a seguinte função;
				req.onreadystatechange = function() {

				// Exibe a mensagem "Buscando Noticias..." enquanto carrega
				if(req.readyState == 1) {
				document.getElementById('cidadeid').innerHTML = 'salvando';
				}

				// Verifica se o Ajax realizou todas as operações corretamente
				if(req.readyState == 4 && req.status == 200) {

				// Resposta retornada pelo busca.php
				var resposta = req.responseText;

				// Abaixo colocamos a(s) resposta(s) na div resultado
				document.getElementById('cidadeid').innerHTML = resposta;
				}
				}
				req.send(null);
				req.setRequestHeader("Cache-Control", "no-cache");
				req.setRequestHeader("Pragma", "no-cache"); 

			}							
		
</script>
						

		<?
						
						$id_modulo = $_GET['id_modulo'];
						$id_turma = $_GET['id_turma'];
						
						$query_noticiasta = "select * from turma  where id_turma = '$id_turma' ";
						$rs_noticiasta    = mysql_query($query_noticiasta);
						while($campo_noticiasta = mysql_fetch_array($rs_noticiasta)){
						$turma       = $campo_noticiasta['curso'];
						}
						
						$query_noticias = "select * from tb_modulo  where id_modulo =  '$id_modulo' ";
						$rs_noticias    = mysql_query($query_noticias);
						while($campo_noticias = mysql_fetch_array($rs_noticias)){
						$curso       = $campo_noticias['curso'];
						
						$inicio_curso_modulo       = $campo_noticias['inicio_curso'];
						$instrutor_modulo       = $campo_noticias['instrutor'];
						$id_modulo       = $campo_noticias['id_modulo'];
						$mes_referente       = $campo_noticias['mes_referente'];
						$ch       = $campo_noticias['ch'];
						$limite_faltas2       = $campo_noticias['limite_faltas'];
						$sala       = $campo_noticias['sala'];
						$horario       = $campo_noticias['horario'];
						$sql_ex       = $campo_noticias['sql_ex'];
						
						
						$limite_faltas = str_replace("h","","$limite_faltas2");
						}
						
						$query_noticiasat = "select * from aluno_modulo  where id_modulo =  '$id_modulo' ";
						$rs_noticiasat    = mysql_query($query_noticiasat);
						$total_aluno = mysql_num_rows($rs_noticiasat);
						?>



									<table style="color:#333;font-size:12px;">
									<tr>
									<td><img src="img/logo_cetep.jpg"  height="130"></td>
									</tr>


									<tr >
									<td width="100%"><div align="center" class="style3">PROGRAMA DE QUALIFICA&Ccedil;&Atilde;O E CAPACITA&Ccedil;&Atilde;O PROFISSIONAL - CONV&Ecirc;NIO PRODESMAR </div></td>
									</tr>
									<tr>
									<td><div align="center">Lista de Frequ&ecirc;ncia - M&ecirc;s de <?=$mes_referente;?> - Inicio em <?=$inicio_curso_modulo ;?> </div></td>
									</tr>

									<tr>
									<td>

									<div class="style2" style=" margin:5px; float:left">
									<p><span class="style7"><span class="style8"><b>Módulo:</b> 
									<?=$curso  ;?>
									</span></span></p>
									
									<p><span class="style7"><span class="style8"><b>Curso:</b> 
									<?=$turma ;?>
									</span></span></p>
									<p class="style8"><b>Turma:</b> <?=$id_turma ;?> 
									<font style="margin-left:60px"><b>Sala:</b>
									<?=$sala ;?>
									</font></p>
									<p class="style8"><b>Instrutor:</b><?=$instrutor_modulo ;?></p>
									</div>	
									<div class="style2" style=" margin:5px; float:left; margin-left:50px">
									
									<p><span class="style7"><span class="style8"><b>Carga Horária:</b> 
									<?=$ch ;?>&nbsp;&nbsp;<b>Limite Faltas </b><?=$limite_faltas;?>
									</span></span></p> 
									<!--<p class="style8"><b>Limite de Faltas em horas:</b> 10h</p>-->
									<p class="style8"><b>Hor&aacute;rio: </b> <?=$horario ;?></p>
									</div>

									<div class="style2" style=" margin:5px; float:left; margin-left:50px">
									<p><span class="style7"><span class="style8"><b>Total de alunos :</b>
									<?=$total_aluno;?>




									</span></span></p> 
									</div>	</td>
									</tr> 
									</table>

		<form action='detalhe_diario_instutor.php?id_modulo=<?=$id_modulo;?>&id_turma=<?=$id_turma;?>' method='post' name='form1'>
		<input type='submit' value='salvar' data-inline="true" data-theme="e"/>
		<div id="cidadeid" name="cidadeid">	</div>
		<table class='grid'style="font-size:12px">
				<tr class='tr_tabela'>
				<td>Ord::
					</td>
					<td>Nome:
					</td>
					
					<td>Nota 1:
					</td>
					
					<td>Nota 2:
					</td>
					<td>Media:
					</td>
											
					<td>Faltas:
					</td>
					<td>Resultado Final:
					</td>
					
									
				</tr>
				<input type='hidden' name='id_teste[]' value='34'>
				<input type='hidden' name='nota_1[]' value='34'>
				<input type='hidden' name='nota_2[]' value='34'>
				<input type='hidden' name='resultado_final[]' value='34'>
				<input type='hidden' name='faltas[]' value='34'>
				<input type='hidden' name='id_aluno_modulo[]' value='a34'>
					<?
						$numero =1;
						if($curso =="Introdutório"){
						$query_noticiasa = "select * from aluno_modulo  where id_turma IN ($sql_ex)  and introdutorio='sim' ORDER BY `aluno_modulo`.`nome_aluno` ASC";
						}else{
						$query_noticiasa = "select * from aluno_modulo  where id_modulo =  '$id_modulo'  ORDER BY `aluno_modulo`.`nome_aluno` ASC";
						}
						$rs_noticiasa    = mysql_query($query_noticiasa);
						$totalaluno = mysql_num_rows($rs_noticiasa);
						while($campo_noticiasaa = mysql_fetch_array($rs_noticiasa)){
						$id_aluno      = $campo_noticiasaa['id_aluno'];
						$nota_1      = $campo_noticiasaa['nota_1'];
						$nota_2      = $campo_noticiasaa['nota_2'];
						
						$presensa      = $campo_noticiasaa['presensa'];
						$resultado_final      = $campo_noticiasaa['resultado_final'];
						
						$nome      = $campo_noticiasaa['nome_aluno'];
						$id_aluno_modulo      = $campo_noticiasaa['id_aluno_modulo'];
						
						$query_noticiastaf = "select * from  faltas  where id_aluno_modulo = '$id_aluno_modulo' and faltas='1' ";
						$rs_noticiastaf    = mysql_query($query_noticiastaf);
						$faltas = mysql_num_rows($rs_noticiastaf);
						$media= ($nota_1+ $nota_2)/2;
						
						 $titulo="$nome";
						$limite=27; //Edite aqui o numero de caracteres
						$descricao5= substr($titulo, 0,$limite);
						
						
						
			$media_limit =60;			
			
						$query_noticiasat_total_p = "SELECT * FROM  `faltas` where id_aluno_modulo='$id_aluno_modulo' and `id_modulo` LIKE  '%$id_modulo%' and faltas='0'";
						$rs_noticiasat_total_p    = mysql_query($query_noticiasat_total_p);
						$total_aluno_total_p = mysql_num_rows($rs_noticiasat_total_p);
		?>
		
		<script type="text/javascript" language="javascript">
		
		
				
				function conta_<?=$id_aluno_modulo;?>(dado) {
				var ql_<?=$id_aluno_modulo;?>  = document.form1
				var nota_1_<?=$id_aluno_modulo;?> = document.getElementById("nota_1_<?=$id_aluno_modulo;?>").value ;
				var nota_2_<?=$id_aluno_modulo;?> = document.getElementById("nota_2_<?=$id_aluno_modulo;?>").value ;
				var faltas_<?=$id_aluno_modulo;?> = document.getElementById("faltas_<?=$id_aluno_modulo;?>").value ;
				var id_aluno_modulo_<?=$id_aluno_modulo;?> = document.getElementById("id_aluno_modulo_<?=$id_aluno_modulo;?>").value ;
				
				///cor
				if(faltas_<?=$id_aluno_modulo;?> > <?=$limite_faltas;?>){document.getElementById("faltas_<?=$id_aluno_modulo;?>").style.color="red";}else{document.getElementById("faltas_<?=$id_aluno_modulo;?>").style.color="#00BFFF";};
				if(nota_2_<?=$id_aluno_modulo;?> < <?=$media_limit;?>){document.getElementById("nota_2_<?=$id_aluno_modulo;?>").style.color="red";}else{document.getElementById("nota_2_<?=$id_aluno_modulo;?>").style.color="#00BFFF"};
				if(nota_1_<?=$id_aluno_modulo;?> < <?=$media_limit;?>){document.getElementById("nota_1_<?=$id_aluno_modulo;?>").style.color="red";}else{document.getElementById("nota_1_<?=$id_aluno_modulo;?>").style.color="#00BFFF"};
				///fim cor
				
				
				
				 var soma_<?=$id_aluno_modulo;?>  = (nota_1_<?=$id_aluno_modulo;?> *1) + (nota_2_<?=$id_aluno_modulo;?> *1) ;	  
				 var nota_<?=$id_aluno_modulo;?>  = soma_<?=$id_aluno_modulo;?>  /2;
				
				if(nota_<?=$id_aluno_modulo;?> < <?=$media_limit;?>){document.getElementById("media_<?=$id_aluno_modulo;?>").style.color="red";}else{document.getElementById("media_<?=$id_aluno_modulo;?>").style.color="#00BFFF";};

				document.getElementById("media_<?=$id_aluno_modulo;?>").value = nota_<?=$id_aluno_modulo;?>;
				
				 
				 
				if((faltas_<?=$id_aluno_modulo;?> > <?=$limite_faltas;?>)&&(nota_<?=$id_aluno_modulo;?> > 0))
				{
				var resutadofina_<?=$id_aluno_modulo;?>="Evadido";
				document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").value = "Evadido" ;
				
				}
				else
				{
					///qaqui
					if((faltas_<?=$id_aluno_modulo;?> > <?=$limite_faltas;?>)&&(<?=$total_aluno_total_p ;?> > 0))
					{
					document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").value = "Evadido" ;
					//document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").innerHTML = "<option value='Evadido' selected>Evadido</option><option value='Aprovado'>Aprovado</option>	 <option value='Reprovado'>Reprovado</option> <option value='Desistente'>Desistente</option>";
					//document.getElementById("faltas_<?=$id_aluno_modulo;?>").style.color="#006400";
						var resutadofina_<?=$id_aluno_modulo;?>="Evadido";
					}
					else
					{
					
						if((faltas_<?=$id_aluno_modulo;?> > <?=$limite_faltas;?>)&&(<?=$total_aluno_total_p ;?> < 1))
						{
						document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").value ="Desistente";					
						//document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").innerHTML = "<option value='Desistente' selected>Desistente</option> <option value='Aprovado'>Aprovado</option>	 <option value='Reprovado'>Reprovado</option>	 <option value='Evadido'>Evadido</option> ";					
						document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").style.color="#FF8C00";	
						var resutadofina_<?=$id_aluno_modulo;?>="Desistente";
						;}
						else
						{
					
							if(nota_<?=$id_aluno_modulo;?> < <?=$media_limit;?>) 
							{
							document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").value = "Reprovado";
							//document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").innerHTML = "<option value='Reprovado' selected>Reprovado</option> <option value='Aprovado'>Aprovado</option><option value='Evadido'>Evadido</option> <option value='Desistente'>Desistente</option>";	
							 
							document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").style.color="red";	
							var resutadofina_<?=$id_aluno_modulo;?>="Reprovado";
							}
							else
							{
								document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").value ="Aprovado";
								var resutadofina_<?=$id_aluno_modulo;?>="Aprovado";
								//document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").innerHTML = "<option value='Aprovado' selected>Aprovado</option> <option value='Reprovado'>Reprovado</option>	 <option value='Evadido'>Evadido</option> <option value='Desistente'>Desistente</option>";
								document.getElementById("resultado_final_<?=$id_aluno_modulo;?>").style.color="#00BFFF";	
							}
						}
					}
					
					
					
				}
				
				var url_<?=$id_aluno_modulo;?> = "inserinotaajax.php?nota_1="+nota_1_<?=$id_aluno_modulo;?>+"&nota_2="+nota_2_<?=$id_aluno_modulo;?>+"&faltas="+faltas_<?=$id_aluno_modulo;?>+"&id_aluno_modulo="+id_aluno_modulo_<?=$id_aluno_modulo;?>+"&resultado_final="+resutadofina_<?=$id_aluno_modulo;?>;
				//alert(url_<?=$id_aluno_modulo;?>);	
				inserirajax(url_<?=$id_aluno_modulo;?>);
				
				
				}
		</script>
				<tr bgcolor="#cccccc" >				
					<td><div style="padding:6px;"><?=$numero++ ;?></div></td>
					<td><div style="padding:6px;"><?=$nome ;?></div></td>
								<script>
								
								function validate(evt) {
								var theEvent = evt || window.event;
								var key = ( theEvent.which ) ? theEvent.which : theEvent.keyCode
								key = String.fromCharCode( key );
								var regex = /[0-9]| /;
								if ([evt.keyCode||evt.which]==8) //this is to allow backspace
								return true;
								if( !regex.test(key) ) {
								theEvent.returnValue = false;
								theEvent.preventDefault();
								}
								}

								</script>
								
							</script>
					<td><div style="padding:0px;"><input type='text'onkeypress="return validate(event)"  onkeyup="conta_<?=$id_aluno_modulo;?>(this.value); " id='nota_1_<?=$id_aluno_modulo;?>' data-mini="true"name='nota_1[]' value='<?=$nota_1  ;?>' <?if($nota_1 < $media_limit){$cor="red"; }else{$cor="#00BFFF";}?>style='border:0px;width:50px;height:25px;color:<?=$cor;?>;'/></div></td>
					<td><div style="padding:0px;"><input type='text' onkeypress="return validate(event)" onkeyup="conta_<?=$id_aluno_modulo;?>(this.value); " id='nota_2_<?=$id_aluno_modulo;?>'data-mini="true"name='nota_2[]' value='<?=$nota_2 ;?>' <?if($nota_2 < $media_limit){$cor="red"; }else{$cor="#00BFFF";}?>style='border:0px;width:50px;height:25px;color:<?=$cor;?>'/></div>
					</td>
					
					<td><div style="padding:0px;"><input type='text' id='media_<?=$id_aluno_modulo;?>'data-mini="true" readonly value='<?=$media  ;?>' <?if($media < $media_limit){$cor="red"; }else{$cor="#00BFFF";}?>style='border:0px;width:50px;height:25px;color:<?=$cor;?>'/></div>
					</td>	
					
					<td><div style="padding:0px;"><input type='text' id='faltas_<?=$id_aluno_modulo;?>'name='faltas[]' readonly  onkeyup="conta_<?=$id_aluno_modulo;?>(this.value); " value='<?=$faltas;?>' style='border:0px;width:50px;height:25px;'/></div>
					</td>	
					
					<td><div style="padding:0px;">
					
					<?
				switch ($resultado_final) {
				case "Aprovado":    $cor_r = "#00BFFF";     break;
				case "Evadido":    $cor_r = "#006400";     break;
				case "Desistente":    $cor_r = "#FF8C00";     break;
				case "Reprovado":    $cor_r = "red";     break;
				
				}
					
					?>
					
					<input type='text' style='color:<?=$cor_r;?>'name='resultado_final[]' readonly value='<?if($resultado_final==""){}else{echo"$resultado_final";} ;?>' id='resultado_final_<?=$id_aluno_modulo;?>'data-mini="true"/>
					
					<!--<select style='color:<?=$cor_r;?>' name='resultado_final[]' id='resultado_final_<?=$id_aluno_modulo;?>'data-mini="true"> 
					<?if($resultado_final==""){echo"<option id=''value='--'>--</option>";}else{?> <option id='<?=$id_aluno_modulo;?>1'value='<?=$resultado_final ;?>'><?=$resultado_final ;?></option> <?}?>
					 <option id='<?=$id_aluno_modulo;?>2'value='Aprovado'>Aprovado</option> 
					 <option id='<?=$id_aluno_modulo;?>3'value='Reprovado'>Reprovado</option> 
					  <option id='<?=$id_aluno_modulo;?>4' value='Evadido'>Evadido</option> 
					    <option id='<?=$id_aluno_modulo;?>5' value='Desistente'>Desistente</option> 
					 
					</select-->
						
					</div>
					
					
					</td>					
					
					<input type='hidden' name='id_aluno_modulo[]' id='id_aluno_modulo_<?=$id_aluno_modulo;?>'value='<?=$id_aluno_modulo;?>'>
					<input type='hidden' name='id_teste[]' value='34'>
					<input type='hidden' name='id_turma' value='<?=$id_turma;?>'>
					<input type='hidden' name='id_modulo' value='<?=$id_modulo;?>'>
					<input type='hidden' name='totalaluno' value='<?=$totalaluno;?>'>
				</tr>
			<?}?>	
				<div id="cidadeid" name="cidadeid"></div>
				
				
			</table>
			<input type='submit' value='salvar' data-inline="true" data-theme="e"/>
		</form>	
		
		
		
		
		
		<!--endprint-->
	</div><!-- /content -->

	

	
	
	
	
<!-- /footer -->
<?include'rodape.php';?>

<!-- /footer -->


</div><!-- /page -->

</body>


