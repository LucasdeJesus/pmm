﻿<?include("conf.php"); // Inclui o arquivo com o sistema de segurança

error_reporting(0);

		$id = $_GET['id'];
		$nome = $_GET['nome'];
		$cpf = $_GET['cpf'];
		$acao = $_GET['acao'];
		
		
		
		if($acao==1)
		
		{
		

			$situacaocurso_p 	= $_POST['situacaocurso']; 
			$segmentoatuacaoid_p 	= $_POST['segmentoatuacaoid']; 
			$curso_p 	= $_POST['curso']; 
			$comprovacaocurso_p 	= $_POST['comprovacaocurso']; 
			$query2 =" update  cursopalestra set situacao='$situacaocurso_p', segmentoatuacaoid='$segmentoatuacaoid_p', curso='$curso_p', comprovacao='$comprovacaocurso_p'  where id='$id' ";
			$rs2 = mysql_query($query2);

			?>
			<SCRIPT language="JavaScript">alert("Salvo com sucesso !");</SCRIPT>
			<?	
		}
		else
		{
				if($acao==2)
				
				{
				$query ="DELETE FROM  `cursopalestra` where id='$id' ";
				$rs = mysql_query($query);
					
				?>
				<SCRIPT language="JavaScript">setTimeout("self.close();",5);</SCRIPT>
				<?	
			}
			else{}
			
		}
		
		
		
		$query_noticias_h = "SELECT * FROM `cursopalestra` WHERE id ='$id'";
		$rs_noticias_h    = mysql_query($query_noticias_h);
		while($campo_noticias_hcp = mysql_fetch_array($rs_noticias_h)){		
		
		$cursos_palestrasg 	= $campo_noticias_hcp['cursos_palestras']; 		
		$situacaocursog = $campo_noticias_hcp['situacao'];
		$segmentoatuacaoidg = $campo_noticias_hcp['segmentoatuacaoid'];
		$cursog = $campo_noticias_hcp['curso'];
		$comprovacaocursog = $campo_noticias_hcp['comprovacao'];
		
		}
		
		
		
?>
<head>
	
			<link rel="stylesheet" type="text/css" href="assets/reset.css" />
			<link rel="stylesheet" type="text/css" href="assets/styles.css" />
  
			<script type="text/javascript">
			function formatar_mascara(src, mascara) {
			var campo = src.value.length;
			var saida = mascara.substring(0,1);
			var texto = mascara.substring(campo);
			if(texto.substring(0,1) != saida) {
			src.value += texto.substring(0,1);
			}
			}
			</script>
			
		
</head>

			<script type="text/javascript">

				function acao1() {
				 document.curso_palesta.action = "editar_curso_palestra.php?nome=<?=$nome;?>&cpf=<?=$cpf;?>&id=<?=$id;?>&acao=1";
				}
				function acao2() {
				
					var name= confirm("Deseja excluir?")
					if (name==true)
					{
						document.curso_palesta.action = "editar_curso_palestra.php?nome=<?=$nome;?>&cpf=<?=$cpf;?>&id=<?=$id;?>&acao=2";
					 }
					 else
					 {}
				}
			</script>
				
<form class="form" name='curso_palesta' id='curso_palesta' method="Post" action="" >
				
				
				
			<h2>TRABALHADOR</h2>

			<div class="form-row">
			<div class="label">CPF</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  value="<?echo $cpf;?>" size="60" maxlength="60"  disabled=""class="input req-same" tabindex="22" type="text"/> 
			
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Nome</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?echo $nome;?>" tabindex="23"type="text"/>
			
			</div>
			</div>
			
<div class="form-row">
		<h2>CURSOS / PALESTRAS</h2>
		<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_trabalhador3' type='hidden' value='<?=$id_trabalhador;?>'/>
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
						
						
						Situação
			<select name="situacaocurso" id="situacaocurso" onchange="EditandoRegistro()" tabindex="14" style="width:170px;">
			<?
			switch ($situacaocursog){										
			case "C":											
			$situacaocursog_N = "Completo";
			break;case "U":											
			$situacaocursog_N = "Cursando";
			break;case "I":											
			$situacaocursog_N = "Incompleto";
			break;
			}
			?>		
				<option value="<?=$situacaocursog;?>"  ><?=$situacaocursog_N;?></option>
				<option value="C" >Completo</option>
				<option value="U">Cursando</option>
				<option value="I">Incompleto</option>
			</select>	

		</div>
	</div>

			<div class="label"></div>
	    <div class="input-container" style='width:546px;'>
			Segmento de Atuação
			<select name="segmentoatuacaoid" id="segmentoatuacaoid" onchange="EditandoRegistro();" tabindex="16" style="width:203px;">
			
			<?
					$query_noticias_hcsa3 = "SELECT * FROM `segmentoatuacao` where id='$segmentoatuacaoid'";
					$rs_noticias_hcsa3    = mysql_query($query_noticias_hcsa3);
					while($campo_noticias_hcsa3 = mysql_fetch_array($rs_noticias_hcsa3)){
					$nomeseguimento3 	= $campo_noticias_hcsa3['nome']; 	
					
					?>
							<option value="<?=$segmentoatuacaoid;?>"  ><?=$nomeseguimento3;?></option>
					<?}?>
					
				
					<?
					$query_noticias_hcsa = "SELECT * FROM `segmentoatuacao` ORDER BY `segmentoatuacao`.`nome` ASC";
					$rs_noticias_hcsa    = mysql_query($query_noticias_hcsa);
					while($campo_noticias_hcsa = mysql_fetch_array($rs_noticias_hcsa)){
					$nomeseguimento 	= $campo_noticias_hcsa['nome']; 	
					$idseguimento 	= $campo_noticias_hcsa['id']; 	
					?>
					<option value="<?=$idseguimento;?>"><?=$nomeseguimento;?></option>
					<?}?>
			</select>
				
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Cursos</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="curso" id="curso" value="<?=$cursog;?>" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="17" style="width:480" type="text">
				
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Apresentou Comprovação</div>
	    <div class="input-container" style='width:546px;'>		
			<select name="comprovacaocurso" id="comprovacaocurso" tabindex="19"  onchange="EditandoRegistro();">
			<?
			switch ($comprovacaocursog){										
			case "N":											
			$comprovacaocursog_N = "Não";
			break;case "S":											
			$comprovacaocursog_N = "Sim";
			break;
			}
			?>		
				<option value="<?=$comprovacaocursog;?>" ><?=$comprovacaocursog_N;?></option>
				<option value="N" >Não</option>
				<option value="S">Sim</option>
			</select>	
		</div>
	</div>
	
	
		<div class="form-row">
		<div class="label"></div>
		<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Excluir" onClick="acao2();"type="submit" class="sendBtn" />
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar" onClick="acao1();"type="submit" class="sendBtn" />		
		</div>
		</div>
			
		
		
</form>
<!---------------------------------------------------------empresa 1------------------------------------------------->






