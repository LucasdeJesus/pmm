﻿<?include("conf.php"); // Inclui o arquivo com o sistema de segurança

error_reporting(0);

		$id = $_GET['id_historico'];
		$nome = $_GET['nome'];
		$cpf = $_GET['cpf'];
		$acao = $_GET['acao'];
		
		
		
		if($acao==1)
		
		{
		
			
			$cboid_query = $_POST['cboid'];
			
			$query_cboid = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid_query%'";	
			$rs_cboid    = mysql_query($query_cboid); 													
			while($campo_cboid= mysql_fetch_array($rs_cboid)){		 
			$cboid= $campo_cboid['id']; }
			
			
			$empresa = $_POST['empresa'];
			$cargo = $_POST['cargo'];
			$carteiraassinada = $_POST['carteiraassinada'];
			$ativo = $_POST['ativo'];
			$datainicio = $_POST['datainicio'];
			$datafinal = $_POST['datafinal'];
			
					$datainicio = implode("-",array_reverse(explode("/","$datainicio")));
					$datafinal = implode("-",array_reverse(explode("/","$datafinal")));
					
					
			$tempanos = $_POST['tempanos'];
			$tempomes = $_POST['tempomes'];
			
			$query ="update  `historico` set  cboid='$cboid' , empresa='$empresa' , cargo='$cargo' , carteiraassinada='$carteiraassinada' , ativo='$ativo' , datainicio='$datainicio' , datafinal='$datafinal' , tempanos='$tempanos' , tempomes='$tempomes' where id='$id' ";
			$rs = mysql_query($query);
			
			?>
				<SCRIPT language="JavaScript">alert("Salvo com sucesso!");</SCRIPT>
				<?	
		}
		else
		{
				if($acao==2)
				
				{
				$query ="DELETE FROM  `historico` where id='$id' ";
				$rs = mysql_query($query);
					
				?>
				<SCRIPT language="JavaScript">setTimeout("self.close();",5);</SCRIPT>
				<?	
			}
			else{}
			
		}
		
		
		
		$query_noticias_h = "SELECT * FROM `historico` WHERE id ='$id'";
		$rs_noticias_h    = mysql_query($query_noticias_h);
		while($campo_noticias_h = mysql_fetch_array($rs_noticias_h)){				
		$cboid = $campo_noticias_h['cboid'];
		$empresa = $campo_noticias_h['empresa'];
		$cargo = $campo_noticias_h['cargo'];
		$carteiraassinada = $campo_noticias_h['carteiraassinada'];
		$ativo = $campo_noticias_h['ativo'];
		$datainicio = $campo_noticias_h['datainicio'];
		$datafinal = $campo_noticias_h['datafinal'];
		$tempanos = $campo_noticias_h['tempanos'];
		$tempomes = $campo_noticias_h['tempomes'];
		
		}
		
		
		
?>
<head>
	<script type="text/javascript" src="789/js/jquery-1.4.2.js"></script>
			<script type='text/javascript' src="789/js/jquery.autocomplete.js"></script>
			<link rel="stylesheet" type="text/css" href="789/js/jquery.autocomplete.css" />
			<link rel="stylesheet" type="text/css" href="assets/reset.css" />
			<link rel="stylesheet" type="text/css" href="assets/styles.css" />
  <script type="text/javascript">
            $().ready(function() {
            
				$("#cboid").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });$("#cargo").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
            });
        </script>
		
			<script type="text/javascript">
			function formatar_mascara(src, mascara) {
			var campo = src.value.length;
			var saida = mascara.substring(0,1);
			var texto = mascara.substring(campo);
			if(texto.substring(0,1) != saida) {
			src.value += texto.substring(0,1);
			}
			}
			</script>
			
		
</head>

			<script type="text/javascript">

				function acao1() {
				 document.historico.action = "editar_historico.php?nome=<?=$nome;?>&cpf=<?=$cpf;?>&id_historico=<?=$id;?>&acao=1";
				}
				function acao2() {
				
					var name= confirm("Deseja excluir?")
					if (name==true)
					{
						document.historico.action = "editar_historico.php?nome=<?=$nome;?>&cpf=<?=$cpf;?>&id_historico=<?=$id;?>&acao=2";
					 }
					 else
					 {}
				}
			</script>
				
<form id="historico" name='historico' class="form" method="Post" action="" onload='Ajax();'>
				
				
				
			<h2>TRABALHADOR</h2>

			<div class="form-row">
			<div class="label">CPF</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  value="<?echo $cpf;?>" size="60" maxlength="60"  disabled=""class="input req-same" tabindex="22" type="text"/> 
			
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Nome</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?echo $nome;?>" tabindex="23"type="text"/>
			
			</div>
			</div>
			

<h2>HISTÓRICO PROFISSIONAL</h2>


<!---------------------------------------------------------empresa 1------------------------------------------------->
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_trabalhador' type='hidden' value='<?=$id_trabalhador;?>'/>
			<h4>EMPRESA</h4>
			<div class="form-row">
			<div class="label">Ocupação</div>
			<div class="input-container" style='width:546px;height:;'>		
			
			<?
			$query_cboid = "SELECT * FROM  `cbo` WHERE  id='$cboid'";	
			$rs_cboid    = mysql_query($query_cboid); 													
			while($campo_cboid= mysql_fetch_array($rs_cboid)){		 
			$cbo= $campo_cboid['cbo']; }

			
			
			?>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cboid" id="cboid" size="60" maxlength="200" value="<?echo $cbo;?>" class="input req-same"  tabindex="20" type="text"/>
			
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Empresa</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="empresa" value="<?echo $empresa;?>" size="60" maxlength="60" class="input req-same"id="empresa" tabindex="22" type="text"/> 
			
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Cargo</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cargo" size="60" maxlength="60" class="input req-same" id="cargo" value="<?echo $cargo;?>" tabindex="23"type="text"/>
			
			</div>
			</div>
			
			
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			
				Carteira Assinada?
			<select name="carteiraassinada" id="carteiraassinada"  tabindex="24" style="width:62px;">
			<?
switch ($ativo){										
case "N":											
$ativo_N = "Não";
break;case "S":											
$ativo_N = "Sim";
break;
}

switch ($carteiraassinada){										
case "N":											
$carteiraassinada_N = "Não";
break;case "S":											
$carteiraassinada_N = "Sim";
break;
}
?>

				<option value="<?=$carteiraassinada;?>" ><?=$carteiraassinada_N;?></option>
				<option value="N" >Não</option>
				<option value="S">Sim</option>
			</select>
			&nbsp;
			Ainda Ativo?
			<select name="ativo" id="ativo"  tabindex="25" style="width:62px;">
				<option value="<?=$ativo;?>" ><?=$ativo_N;?></option>
				<option value="N" >Não</option>
				<option value="S">Sim</option>
			</select>
			
			</div>
			</div>
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>	
			Período: Início
				<?$datainicio1 = implode('/',array_reverse(explode('-',$datainicio)));?>
				<?$datafinal2 = implode('/',array_reverse(explode('-',$datafinal)));?>
				
		
				
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="datainicio" id="datainicio" value="<?echo $datainicio1;?>" maxlength="10" class="input req-same" onkeypress="formatar_mascara(this, '##/##/##')" tabindex="26" style="width:105px;" type="text"/>
			Final
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="datafinal" id="datafinal" value="<?echo $datafinal2;?>" maxlength="10" class="input req-same" onkeypress="formatar_mascara(this, '##/##/##')"  tabindex="27" style="width:105px;" type="text"/>
			
			</div>
			
			</div>
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			Caso NÃO saiba o período exato, informar:&nbsp;
			Tempo: Ano(s)
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="tempanos" value="<?echo $tempanos;?>" size="5" maxlength="2" class="input req-same" style="width:56px;" id="tempanos" tabindex="28" type="text"/>
			Mês(es)
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="tempomes" value="<?echo $tempomes;?>" size="5" maxlength="2" class="input req-same"  style="width:56px;" id="tempomes" tabindex="29" type="text"/>
		
			</div>
			</div>
			
			
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>	

				
			
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Excluir" onClick="acao2();"type="submit" class="sendBtn" />
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar" onClick="acao1();"type="submit" class="sendBtn" />
			<div id="errorDiv2" class="error-div"></div>
			</div>
			</div>
			
		
		
</form>
<!---------------------------------------------------------empresa 1------------------------------------------------->






