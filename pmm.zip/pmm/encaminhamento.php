
	
<h2>ENCAMINHAMENTOS</h2>

			<div class="form-row">
			<div class="label">Vaga</div>
			
			<div class="input-container" style='width:546px;'>	
				<select name="selVaga" id="selVaga" onchange="EditandoRegistro()" tabindex="3" >
				<option value="">Selecione</option>
					<option value="10527">10527 - Instalador de som e acessórios de veículos</option>
					<option value="10927">10927 - Manicure</option>
					<option value="11068">11068 - Cortador de pedras</option>
			</select>			
				
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Observações</div>			
			<div class="input-container" style='width:546px;'>	
				<textarea name="txtobs" id="txtobs" rows="4" cols="62"class="input req-same"  style='width:100%;height:100px;'tabindex="4" onchange="EditandoRegistro()"></textarea>
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Status</div>			
			<div class="input-container" style='width:546px;'>	
				<select name="selStatus" id="selStatus" onchange="EditandoRegistro()" tabindex="5" style="width:100px;">
				<option value="1" selected="">Encaminhado</option>
				<option value="2">Inserido</option>
				<option value="3">Não Inserido</option>
			</select>
			</div>
			</div>
			
			
		