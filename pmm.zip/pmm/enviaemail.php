<?
										$pass= $_POST['pass'];
										$cpf_trabalhador_cadastro_POST= $_POST['cpf_trabalhador'];
										
										if($pass == 2){
											$query_user = "SELECT * FROM `usuario` WHERE usuario = '$cpf_trabalhador_cadastro_POST'";										
											$rs_user   = mysql_query($query_user);
											while($campo_user = mysql_fetch_array($rs_user)){
											$iduser 	= $campo_user['id']; 											
											$senhauser 	= $campo_user['senha']; 											
											$usuariouser 	= $campo_user['usuario']; 											
											}	
											
											if($iduser > 0){											
													
													$query_dadoslembrete = "SELECT * FROM `trabalhador` WHERE cpf = '$cpf_trabalhador_cadastro_POST'";										
													$rs_dadoslembrete   = mysql_query($query_dadoslembrete);
													while($campo_dadoslembrete = mysql_fetch_array($rs_dadoslembrete)){
													$idsecao 	= $campo_dadoslembrete['id']; 
													$nometrabalhador 	= $campo_dadoslembrete['nome']; 
													$email 	= $campo_dadoslembrete['email']; 
													$emailresponsavel 	= $campo_dadoslembrete['emailresponsavel']; 
													
													}	
													

													$assunto	= "Solicitação de Senha SISTEMA SEMTRE";
													global $email;
													$data      = date("d/m/y");                     
													$ip        = $_SERVER['REMOTE_ADDR'];          
													$navegador = $_SERVER['HTTP_USER_AGENT'];       
													$hora      = date("H:i");                       
													$remetente      = "semtrevagas@macae.rj.gov.br"  ;                   
													$destinatario      = "$email,$emailresponsavel"  ;               

													
												$headers = "MIME-Version: 1.0\r\n";
												$headers .= "Content-type: text/html; charset=".$charset."\r\n";
												//$headers .= "Cc: semtrevagas@macae.rj.gov.br\r\n";
												$headers .= "Bcc: $email\r\n"; 
												$headers .= "From: ".$remetente."\r\n";
												$corpo=" <div style='border:1px solid #ddd;padding:10px' >Sr(a),$nometrabalhador segue dados de  acesso sistema SEMTRE: <br><br> LOGIN: $usuariouser <br>SENHA: $senhauser\n <br>LINK:  <a href='http://sistemas.macae.rj.gov.br:84/catalogo/semtre'>http://sistemas.macae.rj.gov.br:84/catalogo/semtre</a> </div>";
													
													
													
													if(mail($destinatario, $assunto, $corpo, $headers)) {
														//echo "<script>alert('Dados de Acesso enviado para email $email')</script>";
														//echo "<SCRIPT language='JavaScript'>window.location.href='index.php';</SCRIPT>";
														}
														else {
														echo "<script>alert('Erro: tente novamente')</script>";
														}
														
														
														
														
														
														
														
														
														
														
														
														/* Medida preventiva para evitar que outros domínios sejam remetente da sua mensagem. */
													if (eregi('tempsite.ws$|locaweb.com.br$|hospedagemdesites.ws$|websiteseguro.com$', $_SERVER[HTTP_HOST])) {
													$emailsender='semtrevagas@macae.rj.gov.br';
													} else {
													$emailsender = "semtrevagas@macae.rj.gov.br";
													//    Na linha acima estamos forçando que o remetente seja 'webmaster@seudominio',
													// você pode alterar para que o remetente seja, por exemplo, 'contato@seudominio'.
													}

													/* Verifica qual é o sistema operacional do servidor para ajustar o cabeçalho de forma correta. Não alterar */
													if(PHP_OS == "Linux") $quebra_linha = "\n"; //Se for Linux
													elseif(PHP_OS == "WINNT") $quebra_linha = "\r\n"; // Se for Windows
													else die("Este script nao esta preparado para funcionar com o sistema operacional de seu servidor");

													// Passando os dados obtidos pelo formulário para as variáveis abaixo
													$nomeremetente     = "Secretaria Trabalho e Renda";
													$emailremetente    = "semtrevagas@macae.rj.gov.br";
													$emaildestinatario = "$emailresponsavel";
													$comcopia          = "$email";
													$comcopiaoculta    = "";
													$assunto           = "Solicitação de Senha Sistema SEMTRE CTM 2.0";



													/* Montando a mensagem a ser enviada no corpo do e-mail. */
													$mensagemHTML = "<div style='border:1px solid #ddd;padding:10px' >Sr(a),$nometrabalhador segue dados de  acesso sistema SEMTRE: <br><br> LOGIN: $usuariouser <br>SENHA: $senhauser\n <br>LINK:  <a href='http://sistemas.macae.rj.gov.br:84/catalogo/semtre'>http://sistemas.macae.rj.gov.br:84/catalogo/semtre</a> </div>";


													/* Montando o cabeçalho da mensagem */
													$headers = "MIME-Version: 1.1".$quebra_linha;
													$headers .= "Content-type: text/html; charset=ISO-8859-1".$quebra_linha;
													// Perceba que a linha acima contém "text/html", sem essa linha, a mensagem não chegará formatada.
													$headers .= "From: ".$emailsender.$quebra_linha;
													$headers .= "Return-Path: " . $emailsender . $quebra_linha;
													// Esses dois "if's" abaixo são porque o Postfix obriga que se um cabeçalho for especificado, deverá haver um valor.
													// Se não houver um valor, o item não deverá ser especificado.
													if(strlen($comcopia) > 0) $headers .= "Cc: ".$comcopia.$quebra_linha;
													if(strlen($comcopiaoculta) > 0) $headers .= "Bcc: ".$comcopiaoculta.$quebra_linha;
													$headers .= "Reply-To: ".$emailremetente.$quebra_linha;
													// Note que o e-mail do remetente será usado no campo Reply-To (Responder Para)

													/* Enviando a mensagem */
													mail($emaildestinatario, $assunto, $mensagemHTML, $headers, "-r". $emailsender);

													/* Mostrando na tela as informações enviadas por e-mail */
													echo "<SCRIPT language='JavaScript'>window.location.href='mensagem.php?msg=Dados de Acesso enviado para email $email';</SCRIPT>";
													
													
													
													
													
													
														
											}
										}
										?>
										
										
										
										
											<?
										$pass= $_POST['pass'];
										$txCNPJ_POST= $_POST['txCNPJ'];
										
										if($pass == 1){
											$query_user = "SELECT * FROM `usuario` WHERE usuario = '$txCNPJ_POST'";										
											$rs_user   = mysql_query($query_user);
											while($campo_user = mysql_fetch_array($rs_user)){
											$iduser 	= $campo_user['id']; 											
											$senhauser 	= $campo_user['senha']; 											
											$usuariouser 	= $campo_user['usuario']; 											
											}	
											
											if($iduser > 0){											
													
													$query_dadoslembrete = "SELECT * FROM `empresa` WHERE cnpj = '$txCNPJ_POST'";										
													$rs_dadoslembrete   = mysql_query($query_dadoslembrete);
													while($campo_dadoslembrete = mysql_fetch_array($rs_dadoslembrete)){
													$idsecao 	= $campo_dadoslembrete['id']; 
													$nomeempresa 	= $campo_dadoslembrete['nome']; 
													$email 	= $campo_dadoslembrete['email']; 
													$emailresponsavel 	= $campo_dadoslembrete['emailresponsavel']; 
													
													}	
													

													$assunto	= "Solicitação de Senha SISTEMA SEMTRE";
													global $email;
													$data      = date("d/m/y");                     
													$ip        = $_SERVER['REMOTE_ADDR'];          
													$navegador = $_SERVER['HTTP_USER_AGENT'];       
													$hora      = date("H:i");                       
													$remetente      = "semtrevagas@macae.rj.gov.br"  ;                   
													$destinatario      = "$email,$emailresponsavel"  ;               

													
												$headers = "MIME-Version: 1.0\r\n";
												$headers .= "Content-type: text/html; charset=".$charset."\r\n";
												//$headers .= "Cc: semtrevagas@macae.rj.gov.br\r\n";
												$headers .= "Bcc: $email\r\n"; 
												$headers .= "From: ".$remetente."\r\n";
												$corpo="<div style='border:1px solid #ddd;padding:10px' > $nomeempresa segue dados de  acesso sistema SEMTRE: <br><br> LOGIN: $usuariouser <br>SENHA: $senhauser\n <br>LINK:  <a href='http://sistemas.macae.rj.gov.br:84/catalogo/semtre'>http://sistemas.macae.rj.gov.br:84/catalogo/semtre</a> </div>";
													
													
													
													if(mail($destinatario, $assunto, $corpo, $headers)) {
														//echo "<script>alert('Dados de Acesso enviado para email $email')</script>";
														//echo "<SCRIPT language='JavaScript'>window.location.href='index.php';</SCRIPT>";
														}
														else {
														echo "<script>alert('Erro: tente novamente')</script>";
														}
														
														
														
														
														
														
														/* Medida preventiva para evitar que outros domínios sejam remetente da sua mensagem. */
													if (eregi('tempsite.ws$|locaweb.com.br$|hospedagemdesites.ws$|websiteseguro.com$', $_SERVER[HTTP_HOST])) {
													$emailsender='semtrevagas@macae.rj.gov.br';
													} else {
													$emailsender = "semtrevagas@macae.rj.gov.br";
													//    Na linha acima estamos forçando que o remetente seja 'webmaster@seudominio',
													// você pode alterar para que o remetente seja, por exemplo, 'contato@seudominio'.
													}

													/* Verifica qual é o sistema operacional do servidor para ajustar o cabeçalho de forma correta. Não alterar */
													if(PHP_OS == "Linux") $quebra_linha = "\n"; //Se for Linux
													elseif(PHP_OS == "WINNT") $quebra_linha = "\r\n"; // Se for Windows
													else die("Este script nao esta preparado para funcionar com o sistema operacional de seu servidor");

													// Passando os dados obtidos pelo formulário para as variáveis abaixo
													$nomeremetente     = "Secretaria Trabalho e Renda";
													$emailremetente    = "semtrevagas@macae.rj.gov.br";
													$emaildestinatario = "$emailresponsavel";
													$comcopia          = "$email";
													$comcopiaoculta    = "";
													$assunto           = "Solicitação de Senha Sistema SEMTRE CTM 2.0";



													/* Montando a mensagem a ser enviada no corpo do e-mail. */
													$mensagemHTML = "<div style='border:1px solid #ddd;padding:10px' > $nomeempresa segue dados de  acesso sistema SEMTRE: <br><br> LOGIN: $usuariouser <br>SENHA: $senhauser\n <br>LINK:  <a href='http://sistemas.macae.rj.gov.br:84/catalogo/semtre'>http://sistemas.macae.rj.gov.br:84/catalogo/semtre</a> </div>";


													/* Montando o cabeçalho da mensagem */
													$headers = "MIME-Version: 1.1".$quebra_linha;
													$headers .= "Content-type: text/html; charset=ISO-8859-1".$quebra_linha;
													// Perceba que a linha acima contém "text/html", sem essa linha, a mensagem não chegará formatada.
													$headers .= "From: ".$emailsender.$quebra_linha;
													$headers .= "Return-Path: " . $emailsender . $quebra_linha;
													// Esses dois "if's" abaixo são porque o Postfix obriga que se um cabeçalho for especificado, deverá haver um valor.
													// Se não houver um valor, o item não deverá ser especificado.
													if(strlen($comcopia) > 0) $headers .= "Cc: ".$comcopia.$quebra_linha;
													if(strlen($comcopiaoculta) > 0) $headers .= "Bcc: ".$comcopiaoculta.$quebra_linha;
													$headers .= "Reply-To: ".$emailremetente.$quebra_linha;
													// Note que o e-mail do remetente será usado no campo Reply-To (Responder Para)

													/* Enviando a mensagem */
													mail($emaildestinatario, $assunto, $mensagemHTML, $headers, "-r". $emailsender);

													/* Mostrando na tela as informações enviadas por e-mail */
													echo "<SCRIPT language='JavaScript'>window.location.href='mensagem.php?msg=Dados de Acesso enviado para email $email';</SCRIPT>";
													
													
													
														
											}
										}
										?>