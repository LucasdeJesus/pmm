<?include'input_banco.php';?>


	<?

	$query_noticias = "SELECT nome,email,cboid1 FROM `trabalhador` ";
	$rs_noticias    = mysql_query($query_noticias);																							
	while($campo_noticias = mysql_fetch_array($rs_noticias)){
	$id= $campo_noticias['id']; 
	$cadbf= $campo_noticias['cadbf']; 
	$cpf_busca= $campo_noticias['cpf']; 
	$nome= $campo_noticias['nome']; 
	$email= $campo_noticias['email']; 
	$cboid1= $campo_noticias['cboid1']; 
	$string=explode(" ", $nome);	
	$primeironome= "$string[0]";
		
		
			$query_noticiasw = "SELECT `id`, `codigocbo`, `cbo` FROM `cbo` WHERE `id`='$cboid1'";
			$rs_noticiasw    = mysql_query($query_noticiasw);																							
			while($campo_noticiasw = mysql_fetch_array($rs_noticiasw)){
			$cbo= $campo_noticiasw['cbo']; 
			}
			
			if($email ==""){}else{
	?>
	
	"<?=$primeironome?>";"<?=$email?>";"<?=$cbo?>"<br>
	
	<?}}?>
</body>
</html>