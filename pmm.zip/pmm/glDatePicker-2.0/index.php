<html>
<body>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.min.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">

  <script type="text/javascript">
        $(window).load(function()
{
	// Example #1 - Basic calendar
	$('#example1').glDatePicker(
	{
		showAlways: true
	});

	// Example #2 - Selectable dates and ranges and prevent month/year selection
	$('#example2').glDatePicker(
	{
		showAlways: true,
		allowMonthSelect: false,
		allowYearSelect: false,
		prevArrow: '',
		nextArrow: '',
		selectedDate: new Date(2013, 8, 5),
		selectableDateRange: [
			{ from: new Date(2013, 8, 1), to: new Date(2013, 8, 10) },
			{ from: new Date(2013, 8, 19), to: new Date(2013, 8, 22) },
		],
		selectableDates: [
			{ date: new Date(2013, 8, 24) },
			{ date: new Date(2013, 8, 30) }
		]
	});

	// Example #3 - Custom style, repeating special dates and callback
	$('#example3').glDatePicker(
	{
		showAlways: true,
		cssName: 'darkneon',
		selectedDate: new Date(2013, 0, 5),
		specialDates: [
			{
				date: new Date(2013, 0, 8),
				data: { message: 'Meeting every day 8 of the month' },
				repeatMonth: true
			},
			{
				date: new Date(0, 0, 1),
				data: { message: 'Happy New Year!' },
				repeatYear: true
			},
		],
		onClick: function(target, cell, date, data) {
			target.val(date.getFullYear() + ' - ' +
						date.getMonth() + ' - ' +
						date.getDate());

			if(data != null) {
				alert(data.message + '\n' + date);
			}
		}
	});

	// Example #4 - Day of week offset and restricting date selections
	$('#example4').glDatePicker(
	{
		showAlways: true,
		selectedDate: new Date(2015, 1, 12),
		dowOffset: true,
		selectableYears: true,
		selectableMonths: true,
		selectableDOW: [2,3,4,5,6],
		
		
		selectableDates: [
			{ date: new Date(2015, 1, 24) },
			{ date: new Date(2015, 1, 20) },
			{ date: new Date(2015, 1, 22) },
			{ date: new Date(2015, 1, 12) }
		],
	
	
    onClick: function(target, cell, date, data) {
        target.val(date.getFullYear() + ' - ' +
                    date.getMonth() + ' - ' +
                    date.getDate());

        if(data != null) {
            alert(data.message + '\n' + date);
        }
    }
	
	
	});

});
    </script>
	


	<input type="text" id="example4" style="width:500px;"gldp-id="gldp-6271450305" class="gldp-el">
	<div gldp-el="example4"
         style=" height:300px; position:absolute; top:70px; left:100px;">
    </div>
</body>
</html>