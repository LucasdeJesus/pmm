<?
include'conexao.php';

error_reporting(0);


		$id = $_GET['id'];
		$nomeg = $_GET['nome'];
		$cpfg = $_GET['cpf'];
		$query_noticias_h = "SELECT * FROM `historico` WHERE trabalhadorid ='$id'";
		$rs_noticias_h    = mysql_query($query_noticias_h);
		while($campo_noticias_h = mysql_fetch_array($rs_noticias_h)){
		
		$id_historico 	= $campo_noticias_h['id']; 		
		$cboid 	= $campo_noticias_h['cboid']; 		
		$empresa =$campo_noticias_h['empresa'];			
			$cargo =$campo_noticias_h['cargo'];			
			$carteiraassinada =$campo_noticias_h['carteiraassinada'];
			$ativo =$campo_noticias_h['ativo'];
			$datainicio =$campo_noticias_h['datainicio'];
			$datafinal =$campo_noticias_h['datafinal'];
			$tempanos	 =$campo_noticias_h['tempanos'];
			$tempomes =$campo_noticias_h['tempomes'];
?>


	<tr class='tr_tb' >
		
			<?
			$query_cboid = "SELECT * FROM  `cbo` WHERE  id='$cboid'";	
			$rs_cboid    = mysql_query($query_cboid); 													
			while($campo_cboid= mysql_fetch_array($rs_cboid)){		 
			$cbo= $campo_cboid['cbo']; }

			?>
		<td class='td2' width='215px'><?=$cbo;?> </td>
		<td class='td2' width='174px'><?=$empresa;?> </td>
		<?$datainicio1 = implode('/',array_reverse(explode('-',$datainicio)));?>
				<?$datafinal2 = implode('/',array_reverse(explode('-',$datafinal)));?>
		<td class='td2' width='158px'> <?=$datainicio1;?> -  <?=$datafinal2;?></td>
		<td class='td2' width='176px'><?=$cargo;?> </td>
		
		<?
switch ($carteiraassinada){										
case "N":											
$carteiraassinada_N = "Não";
break;case "S":											
$carteiraassinada_N = "Sim";
break;
}
?>


		<td class='td2' width='55px'><?=$carteiraassinada_N;?>  </td>
<?
switch ($ativo){										
case "N":											
$ativo_N = "Não";
break;case "S":											
$ativo_N = "Sim";
break;
}
?>
														
		<td class='td2' width='55px'><?=$ativo_N;?>  </td>		
		<td class='td2' width='55px'><a href="javascript:Abrir_Pagina('editar_historico.php?id_historico=<?=$id_historico;?>&nome=<?=$nomeg;?>&cpf=<?=$cpfg;?>','scrollbars=yes,width=600,height=500')" title='Saiba mais'><img src='img/busca.png'/></a> </td>
		
	</tr>

<?}?>