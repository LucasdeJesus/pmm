
<h2>Idiomas</h2>

<div class="form-row">
<div class="label">Idiomas</div>
<div class="input-container"><input name="nome" value='<?=$txtcc;?>' type="n"  onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="40" /></div>
</div>
		
		

	