<?include("conf.php"); // Inclui o arquivo com o sistema de segurança

error_reporting(0);
?>

<html>
<?include'topo.php';?>

<body onload="">


		
		
		<?include"topo_logo_trabalhador.php";?>
	
	
		<div style='width:100%;' align='center' >
			<table width='960px'>
					<tr>
					
					
						<td width=''>
									
							<div style='min-height:400px;'>	
							
									
							
										<?
																					
											
											
											
											$query_noticias = "SELECT * FROM `trabalhador` WHERE id_trabalhador='$usuario_id' ";
											$rs_noticias    = mysql_query($query_noticias);																							
											while($campo_noticias = mysql_fetch_array($rs_noticias)){
											$id_trabalhador= $campo_noticias['id_trabalhador']; 
											$cpf_busca= $campo_noticias['cpf']; 
											$nome= $campo_noticias['nome']; 
											$txtemail= $campo_noticias['txtemail']; 
													$cpf 	= $campo_noticias['cpf']; 	 		 			 	
												$nome 	= $campo_noticias['nome']; 
												$mae 	= $campo_noticias['mae'];	 		 			 	
												$pai 	= $campo_noticias['pai'];	 		 			 	
												$data_nsc 	= $campo_noticias['data_nsc']; 	 		 			 	
												$naturidade 	= $campo_noticias['naturidade']; 	 		 			 	
												$cbosexo 	= $campo_noticias['cbosexo']; 	 		 			 	
												$cboestadocivil 	= $campo_noticias['cboestadocivil']; 	 		 			 	
												$cboetnia 	= $campo_noticias['cboetnia']; 	 		 			 	
												$txtfilhosnr 	= $campo_noticias['txtfilhosnr']; 	 		 			 	
												$txtfilhosestudantes 	= $campo_noticias['txtfilhosestudantes']; 	 		 			 	
												$txttrabalhando 	= $campo_noticias['txttrabalhando']; 	 		 			 	
												$txtmeres 	= $campo_noticias['txtmeres']; 	 		 			 	
												$txtmenores 	= $campo_noticias['txtmenores']; 	 		 			 	
												$txtmenores 	= $campo_noticias['txtmenores']; 	 		 			 	
												$cbodeficiencia 	= $campo_noticias['cbodeficiencia']; 	 		 			 	
												$cbolaudo 	= $campo_noticias['cbolaudo']; 	 		 			 	
												$txtlimitacoes 	= $campo_noticias['txtlimitacoes']; 	 		 			 	
												$cboIntencao 	= $campo_noticias['cboIntencao']; 	 		 			 	
												$cboTemporario 	= $campo_noticias['cboTemporario']; 	 		 			 	
												$cboservida 	= $campo_noticias['cboservida']; 	 		 			 	
												$cboNoturno 	= $campo_noticias['cboNoturno']; 	 		 			 	
												$cbotur 	= $campo_noticias['cbotur']; 	 		 			 	
												$cbofeira 	= $campo_noticias['cbofeira']; 	 		 			 	
												$txtcep 	= $campo_noticias['txtcep']; 	 		 			 	
												$txtestado 	= $campo_noticias['txtestado']; 	 		 			 	
												$txtcidade 	= $campo_noticias['txtcidade']; 	 		 			 	
												$txtbairro 	= $campo_noticias['txtbairro']; 	 		 			 	
												$txtendereco 	= $campo_noticias['txtendereco']; 	 		 			 	
												$txttelres 	= $campo_noticias['txttelres']; 	 		 			 	
												$txttelcel 	= $campo_noticias['txttelcel']; 	 		 			 	
												$txttelrec 	= $campo_noticias['txttelrec']; 	 		 			 	
												$txtnmrecado 	= $campo_noticias['txtnmrecado']; 	 		 			 	
												$txtemail 	= $campo_noticias['txtemail'];	 		 			 	
												$txtidentidade 	= $campo_noticias['txtidentidade']; 	 		 			 	
												$txtorgaoexpedidor 	= $campo_noticias['txtorgaoexpedidor']; 	 		 			 	
												$txttitulo 	= $campo_noticias['txttitulo']; 	 		 			 	
												$txtzona 	= $campo_noticias['txtzona']; 	 		 			 	
												$txtsecao 	= $campo_noticias['txtsecao']; 	 		 			 	
												$seltipocnh 	= $campo_noticias['seltipocnh']; 	 		 			 	
												$txtcarttrabalho 	= $campo_noticias['txtcarttrabalho']; 	 		 			 	
												$txtserie 	= $campo_noticias['txtserie']; 	 		 			 	
												$txtregistroprof 	= $campo_noticias['txtregistroprof']; 	 		 			 	
												$txtorgaoreg 	= $campo_noticias['txtorgaoreg']; 	 		 			 	
												$txtpispasep 	= $campo_noticias['txtpispasep']; 	 		 			 	
												$txtpassaporte 	= $campo_noticias['txtpassaporte']; 	 		 			 	
												$txtmoracom 	= $campo_noticias['txtmoracom']; 	 		 			 	
												$txtmorapais 	= $campo_noticias['txtmorapais']; 	 		 			 	
												$txtmoracompanheiro 	= $campo_noticias['txtmoracompanheiro']; 	 		 			 	
												$txtmoraoutros 	= $campo_noticias['txtmoraoutros']; 	 		 			 	
												$txtmorafilhos 	= $campo_noticias['txtmorafilhos']; 	 		 			 	
												$txtmorafilhos1 	= $campo_noticias['txtmorafilhos1']; 	 		 			 	
												$txtmorafilhos2 	= $campo_noticias['txtmorafilhos2']; 	 		 			 	
												$txtmorafilhos3 	= $campo_noticias['txtmorafilhos3']; 	 		 			 	
												$txtmorairmaos 	= $campo_noticias['txtmorairmaos']; 	 		 			 	
												$txtmorairmaos1 	= $campo_noticias['txtmorairmaos1']; 	 		 			 	
												$txtmorairmaos2 	= $campo_noticias['txtmorairmaos2']; 	 		 			 	
												$txtmorairmaos22 	= $campo_noticias['txtmorairmaos22']; 	 		 			 	
												$txtmorairmaos3 	= $campo_noticias['txtmorairmaos3']; 	 		 			 	
												$txtrendafamiliar 	= $campo_noticias['txtrendafamiliar']; 	 		 			 	
												$selchefefamilia 	= $campo_noticias['selchefefamilia']; 	 		 			 	
												$selprogramassociais 	= $campo_noticias['selprogramassociais']; 	 		 			 	
												$cboprocesso 	= $campo_noticias['cboprocesso']; 	 		 			 	
												$cbosoube_caet 	= $campo_noticias['cbosoube_caet']; 	 		 			 	
												$selcidacaptado 	= $campo_noticias['selcidacaptado']; 	 		 			 	
												$selcidaatraves 	= $campo_noticias['selcidaatraves']; 	 		 			 	
												$selLocalDocs 	= $campo_noticias['selLocalDocs']; 	 		 			 	
												$txthistorico	= $campo_noticias['txthistorico'];
												$id_trabalhador 	= $campo_noticias['id_trabalhador']; 
												$txthabilidades1 = $campo_noticias['txthabilidades1'];
												$txthabilidades2 = $campo_noticias['txthabilidades2'];
												$txthabilidades3 = $campo_noticias['txthabilidades3'];
												$txtocupacao1 =  $campo_noticias['txtocupacao1'];
												$txtocupacao2 =  $campo_noticias['txtocupacao2'];
												$txtocupacao3 =  $campo_noticias['txtocupacao3'];
												$txtPretensaoSalarial =  $campo_noticias['txtPretensaoSalarial'];
												$txtUltimoSalario =  $campo_noticias['txtUltimoSalario'];
												$cboescolaridade 	= $campo_noticias['cboescolaridade']; 
												$cbosituacao 	= $campo_noticias['cbosituacao']; 
												$cboserie 	= $campo_noticias['cboserie']; 
												$cboturno 	= $campo_noticias['cboturno']; 
												$cbopos 	= $campo_noticias['cbopos']; 
												$cbocurso 	= $campo_noticias['cbocurso']; 
												$txtoutrocurso 	= $campo_noticias['txtoutrocurso']; 
												$txtinstituicao 	= $campo_noticias['txtinstituicao']; 
												$selcomprovacao 	= $campo_noticias['selcomprovacao']; 
												$txIdioma 	= $campo_noticias['txIdioma']; 
												$txIdioma2 	= $campo_noticias['txIdioma2']; 
												$txIdioma3 	= $campo_noticias['txIdioma3']; 
												$idioma1 	= $campo_noticias['idioma1']; 
												$idioma2 	= $campo_noticias['idioma2']; 
												$selvagadeficiente 	= $campo_noticias['selvagadeficiente']; 
												$idioma3 	= $campo_noticias['idioma3']; 
												$leitura1 	= $campo_noticias['leitura1']; 
												$leitura2 	= $campo_noticias['leitura2']; 
												$leitura3	= $campo_noticias['leitura3']; 
												$convesacao1	= $campo_noticias['convesacao1']; 
												$convesacao2	= $campo_noticias['convesacao2']; 
												$convesacao3	= $campo_noticias['convesacao3']; 
												$escrita1	= $campo_noticias['escrita1']; 
												$escrita2	= $campo_noticias['escrita2']; 
												$escrita3	= $campo_noticias['escrita3']; 
												$data	= $campo_noticias['data']; 
												$dia	= $campo_noticias['dia']; 
												$mes	= $campo_noticias['mes']; 
												$ano	= $campo_noticias['ano']; 
												$cadastrado_por	= $campo_noticias['cadastrado_por']; 
											}											
										
											
											
											?>
									
															
														
												
												
									
											
											
								
							</div>
									
						</td>	

					</tr>
				</table>
				
		</div>
		
		
		 	 
<script type="text/javascript" src="jquery.idTabs.min.js"></script>

<script type="text/javascript"> 
$('div.abas').click(function(){
    $('div.abas').removeClass("abas_ative");
    $(this).addClass("abas_ative");
});
</script>

		<?include"rodape_novo.php";?>
		
</body>
</html>