<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);
		
		
?>


		<?
			$id_trabalhafo_get = $_GET['id_trabalhafo_get'];
			$query_noticias_hcpj = "SELECT * FROM `emcaminhamento`  WHERE id_trabalhandor ='$id_trabalhafo_get' ORDER BY `emcaminhamento`.`id_emcaminhamento` DESC limit 1";
		$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
		while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){		
		
		$id_vaga_ajax  = $campo_noticias_hcpj['id_vaga'];
		$selStatus_ajax  = $campo_noticias_hcpj['status_e'];
		$id_usuario_ajax  = $campo_noticias_hcpj['id_usuario'];
		$dia_ajax  = $campo_noticias_hcpj['dia'];
		$mes_ajax  = $campo_noticias_hcpj['mes'];
		$ano_ajax  = $campo_noticias_hcpj['ano'];
		$obs  = $campo_noticias_hcpj['obs'];
		$id_emcaminhamento  = $campo_noticias_hcpj['id_emcaminhamento'];
		
		?>
		
		<div>
		<img src='img/secretaria.jpg'/>
		</div>
		<table>
			<tr class='tr_tb' >
		
		<td class='td2' width='15px'> <?=$numeo_j++;?> </td>
		<td class='td2' width='63px'> <?=$dia_ajax;?>/<?=$mes_ajax ;?>/<?=$ano_ajax ;?></td>
			<?
			$sql = "select txcbonome from vagas where id_vaga  ='$id_vaga_ajax'";
			$rsd = mysql_query($sql);
			while($rs = mysql_fetch_array($rsd)) {
			$txc_ajax = $rs['txcbonome'];
			$txcbonome_ajax= preg_replace('/[0-9]/', '', $txc_ajax );
			}

			?>
		
		<td class='td2' width='214px'>  <?=$txcbonome_ajax  ;?></td>				
		<td class='td2' width='210px'>  <?=$obs;?></td>	

			<?
			$sql3 = "select usuario  from usuarios where id  ='$id_usuario_ajax'";
			$rsd3 = mysql_query($sql3);
			while($rs3 = mysql_fetch_array($rsd3)) {
			$usuario_ajax = $rs3['usuario'];
			
			}

			?>
			
			
		<td class='td2' width='110px'>  <?=$usuario_ajax;?></td>				
		<td class='td2' width='110px'>  <?=$selStatus_ajax ;?></td>				
		<td class='td2' ><a href="javascript:Abrir_Pagina('imprimi_emcaminhamento.php?id_emcaminhamento=<?=$id_emcaminhamento ;?>','scrollbars=yes,width=800,height=500')" title='imprimir'><img src='img/icone_impressora.gif'></a></td>				
</tr>
		</table>

<?}?>

<script type='text/javascript'>window.print();</script>