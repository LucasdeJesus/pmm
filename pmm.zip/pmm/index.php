<?include'conexao.php';

	
?>

<html>
<?include'topo.php';?>

<body>
	<?include"topo_logo.php";
	
	?>


	
									
<script language="JavaScript">
function cpf_loginfuns(){
var cpf_login = document.cpf_loginF.cpf_login.value;
var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
if(!filtro.test(cpf_login)){
window.alert("CPF inválido. Tente novamente.");
return false;
}

cpf_login = remove(cpf_login, ".");
cpf_login = remove(cpf_login, "-");

if(cpf_login.length != 11 || cpf_login == "00000000000" || cpf_login == "11111111111" ||
cpf_login == "22222222222" || cpf_login == "33333333333" || cpf_login == "44444444444" ||
cpf_login == "55555555555" || cpf_login == "66666666666" || cpf_login == "77777777777" ||
cpf_login == "88888888888" || cpf_login == "99999999999"){
window.alert("cpf inválido. Tente novamente.");
return false;
}

soma = 0;
for(i = 0; i < 9; i++)
soma += parseInt(cpf_login.charAt(i)) * (10 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_login.charAt(9))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
soma = 0;
for(i = 0; i < 10; i ++)
soma += parseInt(cpf_login.charAt(i)) * (11 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_login.charAt(10))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
return true;
}

function remove(str, sub) {
i = str.indexOf(sub);
r = "";
if (i == -1) return str;
r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
return r;
}
</script>	

		
									
<script language="JavaScript">
function cpf_trabalhadorfuns(){
var cpf_trabalhador = document.cpf_trabalhadorF.cpf_trabalhador.value;
var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
if(!filtro.test(cpf_trabalhador)){
window.alert("CPF inválido. Tente novamente.");
return false;
}

cpf_trabalhador = remove(cpf_trabalhador, ".");
cpf_trabalhador = remove(cpf_trabalhador, "-");

if(cpf_trabalhador.length != 11 || cpf_trabalhador == "00000000000" || cpf_trabalhador == "11111111111" ||
cpf_trabalhador == "22222222222" || cpf_trabalhador == "33333333333" || cpf_trabalhador == "44444444444" ||
cpf_trabalhador == "55555555555" || cpf_trabalhador == "66666666666" || cpf_trabalhador == "77777777777" ||
cpf_trabalhador == "88888888888" || cpf_trabalhador == "99999999999"){
window.alert("cpf inválido. Tente novamente.");
return false;
}

soma = 0;
for(i = 0; i < 9; i++)
soma += parseInt(cpf_trabalhador.charAt(i)) * (10 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_trabalhador.charAt(9))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
soma = 0;
for(i = 0; i < 10; i ++)
soma += parseInt(cpf_trabalhador.charAt(i)) * (11 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_trabalhador.charAt(10))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
return true;
}

function remove(str, sub) {
i = str.indexOf(sub);
r = "";
if (i == -1) return str;
r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
return r;
}



</script>	

		
		<div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);height:900px;margin-top:50px;' align='center' >
		
			<div id='paginatoda'  name='paginatoda' align='left'>	
			
			<div style='width:100%;' align='center'>
			
			
			
			
			
			<table width='960px' align='center'>
					<tr>
					
					
						<td width='460'>
							<div style='height:225px;border: 3px dotted  #00B8AD;margin:10px;border-radius: 5px;margin-top:10px;color:#00B8AD;padding:15px;'>
							<h3><img src='img/traba.png'> Trabalhador</h3>
							<h2>
								Procurando uma oportunidade de emprego?
								</h2>
								
							<p>Inscreva-se e participe do processo de intermediação de emprego. Acesse as vagas disponíveis na SEMTRE. Elabore e imprima seu currículo.</p>
								
								
								
								
								
							
								
								
								<form  class="form">
								<a href="#"  class="sendBtn2" data-reveal-id="myModal">
								acessar...
								</a>	
								
								<a href="#"  class="sendBtn" data-reveal-id="cadastro_trabalhador">
								Cadastre-se
								</a>
								
								</form>
								
																
								
								
								
		
		
							</div>							
						</td>	

						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
							<td width='460'>
							<div style='height:225px;border: 3px dotted #F36C34;margin:10px;border-radius: 5px;margin-top:10px;color:#F36C34;padding:15px'>
								<h3><img src='img/empregador.png'> Empregador</h3>
								<h2>
								A SEMTRE ajuda você a encontrar e selecionar as pessoas certas
								</h2>
								<p>
								Cadastre-se e disponibilize vagas para os trabalhadores inscritos na SEMTRE .
								</p>
								
								
								
								<form  class="form">
								<a href="#"  class="sendBtn2" data-reveal-id="myModal2">
								acessar...
								</a>	
								
								<a href="#"  class="sendBtn" data-reveal-id="cadastro_empresa">
								Cadastre-se
								</a>
									
								 <a href="#" class="sendBtn" data-reveal-id="ajuda" >Ajuda</a>
							
								</form>
								
								
								
								
								<div id="ajuda" class="reveal-modal">
								
								
										
										
										
										<img src='img/cadastrosemtre.jpg' width="500px">
										
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
							
							</div>
							
						</td>	
						
						
						
						

						
					</tr>
				</table>
				
				
				
				<h2>Atendimento Agendado</h2>
				
				<table>
					<tr>
						<td> <a href="agendamentoonline.php?urlifreme=agendamento/agendamento.php?tipo=C" title="Agendar atendimento para emissão de CTPS"><img src='img/bt_ctps.png'/></a></td>
						<td><a href="agendamentoonline.php?urlifreme=agendamento/agendamento.php?tipo=D"  title="Agendar atendimento para emissão de RG"><img src='img/bt_detran.png'/></a></td>
						<td><a href="#" data-reveal-id="cadastro_trabalhador"  title="Cadastre-se para acessar todos serviços "><img src='img/bt_vaga.png'/></a></td>
					</tr>
				</table>	
				
				<!--<table>
					<tr>
						<td>
						<br>
						<br>
						<a href="http://vivaoportunidade.com.br/" target="_blanck">
							<img src="viva.jpg" />
							</a>
						</td>
						
					</tr>
				</table>-->
				
			</div>	
			</div>	
				
		</div>
		
		
		
			<?include"rodape_novo.php";?>
	
</body>
</html>