

<html lang="en">
<head>
<meta charset="utf-8" />
<title>jQuery UI Tabs - Default functionality</title>
<link rel="stylesheet" href="aba/jquery-ui.css" />
<script src="aba/jquery-1.9.1.js"></script>
<script src="aba/jquery-ui.js"></script>

<script>
$(function() {
$( "#tabs" ).tabs();
});
</script>
<script>
function SelecionaMenu2(Menu)
{
	parent.FrmDados.location.href = Menu
}

</script>
</head>
<body style='background-color:#157FCC;'>
<div id="tabs">
<ul >
<li  ><a href="tabs-1" onClick="SelecionaMenu2('conteudo.php')"  ><img src='img/icone/user_add.gif'/> <br> Trabalhador</a></li>
<li><a href="tabs-1" onClick="SelecionaMenu2('proficional.php')" > <img src='img/icone/cog_edit.png'/><br> Perfil <br>Profissional </a></li>
<li><a href="tabs-1" onClick="SelecionaMenu2('qualificacao.php')"><img src='img/icone/plugin_add.gif'/> <br>Qualificação<br> Profissional </a></li>
<li><a href="tabs-1" onClick="SelecionaMenu2('idiaomas.php')"><img src='img/icone/feed_add.png'/><br> Idiomas</a></li>
<li><a href="tabs-1" onClick="SelecionaMenu2('socio_economico.php')"><img src='img/icone/information.png'/><br> Perfil <br>Sócio-Econômico </a></li>
<li><a href="tabs-1" onClick="SelecionaMenu2('carteira_trabalho.php')"><img src='img/icone/book.png'/><br> Emissão <br>de CTPS  </a></li>
<li><a href="tabs-1" onClick="SelecionaMenu2('conteudo.php')"><img src='img/icone/user_add.gif'/><br> Economia <br>Popular  </a></li>
<li><a href="tabs-1" onClick="SelecionaMenu2('acompanhamento.php')"><img src='img/icone/application_view_list.png'/><br> Acompanhamento </a></li>
<li><a href="tabs-1" onClick="SelecionaMenu2('encaminhamento.php')"><img src='img/icone/application_go.png'/><br> Encaminhamento</a></li>
</ul>
<div id="tabs-1">

</div>
<div id="tabs-2">
<p></p>
</div>
<div id="tabs-3"></p>
</div>
</div>
</body>
</html>