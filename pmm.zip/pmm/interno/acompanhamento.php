
	
	
<h2>ACOMPANHAMENTO</h2>

			<div class="form-row">
			<div class="label"></div>
			
			<div class="input-container" style='width:546px;'>	
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtExclusivoMulti" id="txtExclusivoMulti" tabindex="3" value="S" type="Checkbox"> Exclusivo para atendimento pela Equipe Multidisciplinar
				
			</div>
			</div>
			<div class="form-row">
			<div class="label"></div>
			
			<div class="input-container" style='width:546px;'>	
				<textarea name="txtacompanhamento" class="input req-same"  style='width:100%;height:300px;' id="txtacompanhamento" rows="20" cols="69" tabindex="4"></textarea>
				
			</div>
			</div>
	