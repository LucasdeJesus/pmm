<?include("../input_banco.php"); // Inclui o arquivo com o sistema de segurança

?>
<html>
<body>


<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	

		
	<?include'../topo.php';?>	
	<?
	$diahoje = date("d");
	$meshoje = date("m");
	if($meshoje =="01"){$meshoje="0";}
	$anohoje = date("Y");
	?>
	<!--------------------valida cpf--------------->										
<script language="JavaScript">
function validar_cpf(){
var cpf_busca = document.cadastro.cpf_busca.value;
var datanascimento = document.cadastro.datanascimento.value;
var nome = document.cadastro.nome.value;
var telcel = document.cadastro.telcel.value;

	
	var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
	if(!filtro.test(cpf_busca)){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	
	
	
	if(datanascimento=="" || datanascimento < 6){
	window.alert("Favor Informe Data Nascimento.");
	return false;
	}
	
	if(nome=="" || nome < 8){
	window.alert("Favor Informe Nome.");
	return false;
	}
	
	
	if(telcel=="" || telcel < 8){
	window.alert("Favor Informe Celular.");
	return false;
	}
	

	cpf_busca = remove(cpf_busca, ".");
	cpf_busca = remove(cpf_busca, "-");

	if(cpf_busca.length != 11 || cpf_busca == "00000000000" || cpf_busca == "11111111111" ||
	cpf_busca == "22222222222" || cpf_busca == "33333333333" || cpf_busca == "44444444444" ||
	cpf_busca == "55555555555" || cpf_busca == "66666666666" || cpf_busca == "77777777777" ||
	cpf_busca == "88888888888" || cpf_busca == "99999999999"){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}

	soma = 0;
	for(i = 0; i < 9; i++)
	soma += parseInt(cpf_busca.charAt(i)) * (10 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(9))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	soma = 0;
	for(i = 0; i < 10; i ++)
	soma += parseInt(cpf_busca.charAt(i)) * (11 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(10))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	return true;
  
}

	function remove(str, sub) {
	i = str.indexOf(sub);
	r = "";
	if (i == -1) return str;
	r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
	return r;
	}
	
</script>
  <script type="text/javascript">
        $(window).load(function()
{
		
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// Example #4 - Day of week offset and restricting date selections
	$('#example4d').glDatePicker(
	{
	
		
		showAlways: true,
		selectedDate: new Date(<?=$anohoje;?>, <?=$meshoje;?>, <?=$diahoje;?>),
		dowOffset: true,
		selectableYears: true,
		selectableMonths: true,
		selectableDOW: [2,3,4,5,6],
		
		
		selectableDates: [
		
				<?
				$query_estado_db = "SELECT * FROM `diaagendamento` where status='A' ";
				$rs_estado_db     = mysql_query($query_estado_db );
				while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
				$datadisponivel        = $campo_estado_db ['data'];
				$pieces = explode("-", $datadisponivel);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia
				$diasoma = $pieces[1] - 1;
				//$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				?>
				{ date: new Date(<?=$pieces[0];?>, <?=$diasoma?>, <?=$pieces[2];?>) },
				<?}?>
				
		],
	
	
    onClick: function(target, cell, date, data) {
	
        target.val(date.getFullYear() + '-' +
                    date.getMonth() + '-' +
                    date.getDate());

        if(data != null) {
            alert(data.message + '\n' + date);
        }
		
		
		var valorinput = $('#example4d').val();
		
		var txt;
		var r = confirm( "Deseja Desativar está data?");
		if (r == true) {
		 /*  $.ajax({
				url: 'script.php?dia='+ valorinput+'&acao=excluir&quatidadedia='+quatidadedia,
				success: function(data) {
				alert(data);
				 window.setTimeout('location.reload()', 300);	
				}
				
				});*/
		} else {
			
		}
		
		
		
		
    }
	
	//alert("oi");
	});

});


    </script>

	
		
<div id="content" name='contente' >
<div id="container">
<?include'topo.php'?>
		<div id="bg-container"   class='contener'>
					
			
			
			
			
			
			
				<form  class="form" method="post" action="agendamentoescolhedia.php"  id="cadastro" name='cadastro' >	
				<h3>Atendimento Agendado - Emissão de Carteira de Trabalho e Previdência Social - CTPS </h3>
				
				<div>
						<p><b>Emissão de Carteira de Trabalho - DOCUMENTAÇÃO</b></p>
						<p><br><br>
						
						<h4> Para emissão de CTPS favor observar vestuário devido à restrições para a fotografia. </h4>
						<font style="color:red;"><b>Usar vestimentos:</b></font><br><br>
							<p>Mais Fechada</p>
							<p>Mais Discreta</p>
							<p>Sem Estampas</p>
							<p>Sem Propagandas, camisa de times ou uniformes </p>
							<p>Não usar veste Branca </p><br>
						
						
						
						
						<font style="color:red;"><b>1ª Via</b></font><br><br>
						<b>1. </b>CPF - CADASTRO DE PESSOA FISICA <br>
						<b>2.</b> DOCUMENTO OFICIAL DE IDENTIFICAÇÃO CIVIL QUE CONTENHA NOME DO INTERESSADO, DATA, MUNICÍPIO E ESTADO DE NASCIMENTO, FILIAÇÃO, NOME DO DOCUMENTO COM ÓRGÃO EMISSOR E DATA DE EMISSÃO<br>
						<b>3. </b>CERTIDÃO DE NASCIMENTO OU CERTIDÃO DE CASAMENTO<br><I>OBS: CASO SEPADADO(A) JUDICIALMENTE CERTIDÃO AVERBADA</I>
						
						
						<b>4.</b>COMPROVANTE DE RESIDÊNCIA <br>
						O comprovante deve possuir o numero do CEP.<br><I>OBS:O COMPROVANTE DEVE POSSUIR NÚMERO DO CEP</I>
						
						</p>
						
						<p><br><br>
						<font style="color:red;"><b>2ª Via</b></font><br><br>
						<b>1.</b> TODOS DOCUMENTOS NECESSÁRIO PARA 1º VIA<br>
						<b>2.</b> Carteira de Trabalho e Previdência Social<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;Carteira de Trabalho anterior em caso de inutilização ou continuação.<br>
						<b>3.</b> BO - Boletim de Ocorrência<br>
						
							&nbsp;	&nbsp;	&nbsp;	&nbsp;Boletim de Ocorrência em caso de perda, roubo, furto ou danos da CTPS.<br>
						<b>4.</b> DOC - Documento que comprove o número da Carteira de Trabalho anterior<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Carteira de Trabalho ou;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- CNIS;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato Análitico;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato FGTS ou;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Rescisão do Contrato de Trabalho.<br>
						<font style="color:red;"><b>5.</b> OBS - Observação<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;CNH - Carteira Nacional de Habilitação não é aceita como documento de identificação para emissão da CTPS</font>
						
						</p>
				</div>		
				
					<h3>Informe dados para Agendamento </h3>
					
				<b>Li e concordo com os termos acima Solicitação de Documentos : <input type="checkbox" value="S" name="checkbox"/></b>
				<div class="form-row">
				<div class="label">CPF:</div>
				<div class="input-container"><input onclick="if(!this.form.checkbox.checked){alert('Marque Li e concordo com os termos acima Solicitação de Documentos');return false}" onBlur="maiuscula(this)" onBlur="maiuscula(this)" onBlur="return validar_cpf()" name="cpf_busca" id='cpf_busca' placeholder="Insira o CPF" type="text"  class="input req-same" maxlength="14"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label">Nome <font class='simbolo'>&#10045;</font> </div>
				<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="nome" required  value='<?=$nome;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label">Data Nascimento <font class='simbolo'>&#10045;</font> </div>
				<?$datanascimento2 = implode('/',array_reverse(explode('-',$datanascimento)));?>
				<div class="input-container"><input onBlur="VerificaData(this.value);" name="datanascimento" id='datanascimento'required  value='<?=$datanascimento2;?>' type="text"    class="input req-same"  /></div>
				</div>
										
				
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container"   style='width:546px;'>
				Tel.: Residencial
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telres" id="telres" value="<?=$telres;?>" maxlength="12"  class="input req-same"    tabindex="34" style="width:100px;" type="text" /> 
				&nbsp;Celular <font class='simbolo'>&#10045;</font> 
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telcel" required id="telcel" value="<?=$telcel;?>" maxlength="13" class="input req-same" tabindex="35" style="width:99px;" type="text" />
				
				</div>
				</div>
				
				
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container" style='width:546px;'>		
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" id="submitBtn2" value="Enviar" type="submit" class="sendBtn"  onclick='return validar_cpf()' />
				<div id="errorDiv2" class="error-div"></div>
				</div>
				</div>
				<input type='hidden' name='buscaform' value='b'>

										
				
				</form>
			
</div>			
</div>


</body>
</html>