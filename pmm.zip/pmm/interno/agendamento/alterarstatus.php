<?
include("../input_banco.php"); // Inclui o arquivo com o sistema de segurança

$acao = $_GET['acao'];
switch ($acao) {
	
	case alterastatus:
		$id_agendamento = $_GET['id'];
		$data = $_GET['data'];
		$status = $_GET['status'];
		
	if($id_agendamento > 0){
		$query="UPDATE `agendamentoctps` SET  status='$status' where id = $id_agendamento ";
		$rs= mysql_query($query);

		if ($rs) 
		{		
			echo"<font style='color:#33bdef;'>Salvo</font>";

		}else
		{
			echo"<font style='color:red;'>Erro</font>";
		}
	}
	break;
	
	
	
	
	
	
	
	case presente:
		$id = $_GET['id'];
		$value = $_GET['value'];
		$query="UPDATE `agendamentoctps` SET  presente='$value' where id = $id ";
		$rs= mysql_query($query);
		
		if ($rs) 
		{		
			echo"<font style='color:#33bdef;'>Salvo</font>";

		}else
		{
			echo"<font style='color:red;'>Erro</font>";
		}
		
		
	break;
	
	
	case chamanome:
		$id = $_GET['id'];
		$nome = $_GET['nome'];
		$tipo = $_GET['tipo'];
		
		$query="INSERT INTO  `chamanome` (`nome` ,`tipo` ,`idagendamento` )
									VALUES ( '$nome', '$tipo','$id')	";
						$rs= mysql_query($query);
		
		if ($rs) 
		{		
			echo"<font style='color:#33bdef;'>chamado</font>";

		}else
		{
			echo"<font style='color:red;'>Erro</font>";
		}
		
		
	break;
	
	
	
}
	
	?>