<?include("../seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<html>
<body>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.js"></script>
    <script src="glDatePicker.min.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	<?
	$diahoje = date("d");
	$meshoje = date("m");
	if($meshoje =="01"){$meshoje="0";}else{$meshoje=$meshoje-1;};
	$anohoje = date("Y");
	
	$datadisponivel= $_GET['data'];
	
	$pieces = explode("-", $datadisponivel);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia
				$diasoma = $pieces[1];
				$diasoma2 = $pieces[1]+1;
				
	$datasalva = $pieces[0]."-".$diasoma2."-".$pieces[2];
	$datasalva1 = $pieces[0]."-".$diasoma."-".$pieces[2];
	?>
  <script type="text/javascript">
        $(window).load(function()
{
	
	// Example #4 - Day of week offset and restricting date selections
	$('#example4').glDatePicker(
	{
		showAlways: true,
		//selectedDate: new Date(<?=$anohoje;?>, <?=$meshoje;?>, <?=$diahoje;?>),
		//dowOffset: true,
		//selectableYears: true,
		//selectableMonths: true,
		//selectableDOW: [2,3,4,5,6],
		
		
		selectableDates: [
	
        {
            date: new Date(<?=$pieces[0];?>, <?=$diasoma?>,  <?=$pieces[2];?>),
            //data: { message: 'Meeting every day 8 of the month' },
            repeatMonth: false
        },
      
    ],	
	});
	
		
});

	$(document).ready(function(){	
	
		$( "#submitBtn2" ).click(function() {
			
			var emprego = $("#emprego").prop('checked'); 
			if(emprego==true){emprego="S"; }else{emprego="N"};
			
			var detran = $("#detran").prop('checked') ;
			if(detran==true){detran="S"; }else{detran="N"};
			
			
			var ctps = $("#ctps").prop('checked') ;
			if(ctps==true){ctps="S"; }else{ctps="N"};
			
		
			
			
			
			
			$.ajax({
				url: 'script.php?dia=<?=$datasalva1;?>&emprego='+emprego+'&detran='+detran+'&ctps='+ctps+'&acao=cadastro',
				success: function(data) {
				alert(data);
				
				}
				
				});
		});
	
	
	
	});

    </script>
	

<table width="900px ">
	<tr>
	
		<td>
			<p>
				<b>Quantidade vagas diária</b><br>
				<input type="number" id="quatidadedia" requered name='quatidadedia'style="width:400px;" value="10" class="gldp-el"/>
			</p>
		</td>
	</tr>
	
	
	<tr>
	
	<td>	
			<h3 style="width:400px;" >Datas </h3>
		<input type="text" id="example4"  readonly="true"style="width:400px;"gldp-id="gldp-6271450305"  value='<?=$datasalva ;?>'class="gldp-el">
		<div gldp-el="gldp-2589183433"
			 style=" height:300px; position:absolute; top:70px; left:100px;">
		</div>	
			
	</td>
	
	<?
		$databusca = date('Y-m-d', strtotime($datasalva));
		$query_noticias1 = "SELECT * FROM `diaagendamento` where data='$databusca'  ";			
		$rs_noticias1    = mysql_query($query_noticias1); 
		$total1 = mysql_num_rows($rs_noticias1);			
		while($campo_noticias1 = mysql_fetch_array($rs_noticias1)){
		$emprego 	= $campo_noticias1['emprego']; 	 
		$ctps 	= $campo_noticias1['ctps']; 	 
		$detran 	= $campo_noticias1['detran']; 	 
		}
		
		echo $emprego;
	?>
	
	<td>
			<h3 style="width:400px;">Data disponível para atendimentos </h3>
		<form  class="form" method="post" action=""  id="cadastro2" name='cadastro2' >		
			<input type="checkbox" name="emprego" id="emprego"   <?if($emprego=="S"){echo"checked='true' ";}?>/> Vaga de Emprego <br>
			<input type="checkbox" name="detran"   id="detran"   <?if($detran=="S"){echo"checked='true'";}?> /> DETRAN <br>
			<input type="checkbox" name="ctps"  id="ctps"   <?if($ctps=="S"){echo"checked='true'";}?> /> CTPS <br>
			
			<p><a id="submitBtn2" href='#'class="sendBtn"  />salvar</a></p>
		</form>	
		
	</td>
	
 </tr>
</table>

</body>
</html>