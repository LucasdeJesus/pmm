<?include("../input_banco.php"); // Inclui o arquivo com o sistema de segurança

?>
<html>
<body bgcolor="#fff" style="background-color:#fff;">


<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	

		
	
	<?
	$diahoje = date("d");
	$meshoje = date("m");
	if($meshoje =="01"){$meshoje="0";}
	$anohoje = date("Y");
	?>
	<!--------------------valida cpf--------------->										
<script language="JavaScript">
function validar_cpf(){
var cpf_busca = document.cadastro.cpf_busca.value;
var datanascimento = document.cadastro.datanascimento.value;
var nome = document.cadastro.nome.value;
var telcel = document.cadastro.telcel.value;

	var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
	if(!filtro.test(cpf_busca)){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	
	
	
	if(datanascimento=="" || datanascimento < 6){
	window.alert("Favor Informe Data Nascimento.");
	return false;
	}
	
	if(nome=="" || nome < 8){
	window.alert("Favor Informe Nome.");
	return false;
	}
	
	if(telcel=="" || telcel < 8){
	window.alert("Favor Informe Celular.");
	return false;
	}
	

	cpf_busca = remove(cpf_busca, ".");
	cpf_busca = remove(cpf_busca, "-");

	if(cpf_busca.length != 11 || cpf_busca == "00000000000" || cpf_busca == "11111111111" ||
	cpf_busca == "22222222222" || cpf_busca == "33333333333" || cpf_busca == "44444444444" ||
	cpf_busca == "55555555555" || cpf_busca == "66666666666" || cpf_busca == "77777777777" ||
	cpf_busca == "88888888888" || cpf_busca == "99999999999"){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}

	soma = 0;
	for(i = 0; i < 9; i++)
	soma += parseInt(cpf_busca.charAt(i)) * (10 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(9))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	soma = 0;
	for(i = 0; i < 10; i ++)
	soma += parseInt(cpf_busca.charAt(i)) * (11 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(10))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	return true;
  
}

	function remove(str, sub) {
	i = str.indexOf(sub);
	r = "";
	if (i == -1) return str;
	r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
	return r;
	}
	
</script>
  <script type="text/javascript">
        $(window).load(function()
{
		
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// Example #4 - Day of week offset and restricting date selections
	$('#example4d').glDatePicker(
	{
	
		
		showAlways: true,
		selectedDate: new Date(<?=$anohoje;?>, <?=$meshoje;?>, <?=$diahoje;?>),
		dowOffset: true,
		selectableYears: true,
		selectableMonths: true,
		selectableDOW: [2,3,4,5,6],
		
		
		selectableDates: [
		
				<?
				$query_estado_db = "SELECT * FROM `diaagendamento` where status='A' ";
				$rs_estado_db     = mysql_query($query_estado_db );
				while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
				$datadisponivel        = $campo_estado_db ['data'];
				$pieces = explode("-", $datadisponivel);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia
				$diasoma = $pieces[1] - 1;
				//$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				?>
				{ date: new Date(<?=$pieces[0];?>, <?=$diasoma?>, <?=$pieces[2];?>) },
				<?}?>
				
		],
	
	
    onClick: function(target, cell, date, data) {
	
        target.val(date.getFullYear() + '-' +
                    date.getMonth() + '-' +
                    date.getDate());

        if(data != null) {
            alert(data.message + '\n' + date);
        }
		
		
		var valorinput = $('#example4d').val();
		var cpf_busca = $('#cpf_busca').val();
		var nome = $('#nome').val();
		var datanascimento = $('#datanascimento').val();
		var telres = $('#telres').val();
		var telcel = $('#telcel').val();
		
		var txt;
		var r = confirm( "Confirmar Agendamento?");
		if (r == true) {
		   $.ajax({
				url: 'script.php?dia='+ valorinput+'&acao=agendar&cpf_busca='+cpf_busca+'&nome='+nome+'&datanascimento='+datanascimento+'&telres='+telres+'&telcel='+telcel,
				success: function(data) {
				alert(data);
				 //window.setTimeout('location.reload()', 300);	
				}
				
				});
		} else {
			
		}
		
		
		
		
    }
	
	//alert("oi");
	});

});


    </script>

		
		
<div id="content" name='contente' >
<div id="container">

		<div id="bg-container"   class='contener'>
					<?					

				$cpfget = $_GET['id'];	
				$idp = $_GET['idp'];	
				if($idp==""){
				$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where status='A' and  cpf='$cpfget' ORDER BY `id` DESC limit 1";
				}else{
				$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where id='$idp'";	
					
				}
				
				$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
				while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
				$id  = $campo_noticias_hcpj['id'];
				$cpf_busca =$campo_noticias_hcpj['cpf'];
				$nome = $campo_noticias_hcpj['nome'];
				$datanascimento = $campo_noticias_hcpj['datanascimento'];
				$telcel = $campo_noticias_hcpj['celular'];
				$telres = $campo_noticias_hcpj['telefone'];					
				$data = $campo_noticias_hcpj['data'];					
				$horario = $campo_noticias_hcpj['horario'];	
				$tipo = $campo_noticias_hcpj['tipo'];	
				}
				switch ($tipo) {
								case "C" :
									$tipoatendimento = "Atendimento CTPS";
									break;
								case "D":
									$tipoatendimento =  "Atendimento Identidade";
									break;
								case "V":
									$tipoatendimento =  "Atendimento Vagas ";
									break;
							}			
				
									
				
				$data = date("d-m-Y", strtotime($data));
					?>
			<form  class="form" method="post" action=""  id="cadastro" name='cadastro' >	
				
				
				
				<div style='width:100%;' align='center' >
				<p>
					<img src='../img/logo.jpg'/>
					<img src="http://chart.googleapis.com/chart?cht=qr&chs=120x120&choe=UTF-8&chld=H&chl=SEMTRE,Candidato: <?=$nome;?>"/>
				</p>
				<b>
				Rua Dr. Télio Barreto, 28 - Centro - Macaé -RJ<br>
				Tel.: (22) 2796-1226 / 2762-4518 / 2762-4740<br>
				wwww.macae.rj.gov.br/trabalhoerenda
				</b>
				</div>
				
				<br><br>
				<h2>Atendimento Agendado </h2>
				
				
				
							
							
				<div class="form-row">
				<div class="label"><b>CPF:</b></div>
				<div class="input-container"><input onBlur="maiuscula(this)" style='border:0px;'value="<?=$cpf_busca;?>"onBlur="maiuscula(this)" readonly="true" onBlur="return validar_cpf()" name="cpf_busca" id='cpf_busca' placeholder="Insira o CPF" type="text"  class="input req-same" maxlength="14"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label"><b>Nome </b><font class='simbolo'></font> </div>
				<div class="input-container"><input onBlur="maiuscula(this)" style='border:0px;'onBlur="maiuscula(this)"readonly="true" name="nome" id="nome"    value='<?=$nome;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label"><b>Data Nascimento</b> <font class='simbolo'></font> </div>
				<?$datanascimento2 = implode('/',array_reverse(explode('-',$datanascimento)));?>
				<div class="input-container"><input onBlur="VerificaData(this.value);" style='border:0px;'readonly="true"name="datanascimento" id='datanascimento'  value='<?=$datanascimento2;?>' type="text"    class="input req-same"  /></div>
				</div>
										
				
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container"   style='width:546px;'>
				<b>Tel.: Residencial</b>
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telres"readonly="true" id="telres" value="<?=$telres;?>" maxlength="12"  class="input req-same"    tabindex="34" style="width:100px;border:0px;" type="text" /> 
				<b>&nbsp;Celular </b><font class='simbolo'></font> 
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telcel" readonly="true" id="telcel" value="<?=$telcel;?>" maxlength="13" class="input req-same" tabindex="35" style="width:99px;border:0px;" type="text" />
				
				</div>
				</div>
				
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container"   style='width:546px;'>
				<b>Data agendada:</b>
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telres"readonly="true" id="telres" value="<?=$data;?>" maxlength="12"  class="input req-same"    tabindex="34" style="width:100px;border:0px;" type="text" /> 
				<b>&nbsp;Horarios Previsto Atendimento: </b><font class='simbolo'></font> 
				<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telcel" readonly="true" id="telcel" value="<?=$horario;?> " maxlength="13" class="input req-same" tabindex="35" style="width:99px;border:0px;" type="text" />
				
				</div>
				</div>
			
				
				
				<?if($tipo=="C"){?>
				<h2> Emissão de Carteira de Trabalho e Previdência Social - CTPS </h2>
				
				<h4>DOCUMENTAÇÃO OBRIGATÓRIO: </h4>
				
				<div>
						<h4> Para emissão de CTPS favor observar vestuário devido à restrições para a fotografia. </h4>
						<font style="color:red;"><b>Usar vestimentos:</b></font><br><br>
							<p>Mais Fechada</p>
							<p>Mais Discreta</p>
							<p>Sem Estampas</p>
							<p>Sem Propagandas, camisa de times ou uniformes </p>
							<p>Não usar veste Branca </p><br>
						
						
						
						
						<font style="color:red;"><b>1ª Via</b></font><br><br>
						<b>1. </b>CPF - CADASTRO DE PESSOA FISICA <br>
						<b>2.</b> DOCUMENTO OFICIAL DE IDENTIFICAÇÃO CIVIL QUE CONTENHA NOME DO INTERESSADO, DATA, MUNICÍPIO E ESTADO DE NASCIMENTO, FILIAÇÃO, NOME DO DOCUMENTO COM ÓRGÃO EMISSOR E DATA DE EMISSÃO<br>
						<b>3. </b>CERTIDÃO DE NASCIMENTO OU CERTIDÃO DE CASAMENTO<br><I>OBS: CASO SEPADADO(A) JUDICIALMENTE CERTIDÃO AVERBADA</I>
						
						<BR>
						<BR>
						<b>4.</b>COMPROVANTE DE RESIDÊNCIA <br>
						O comprovante deve possuir o numero do CEP.<br><I>OBS:O COMPROVANTE DEVE POSSUIR NÚMERO DO CEP</I>
						
						</p>
						
						<p><br><br>
						<font style="color:red;"><b>2ª Via</b></font><br><br>
						<b>1.</b> TODOS DOCUMENTOS NECESSÁRIO PARA 1º VIA<br>
						<b>2.</b> Carteira de Trabalho e Previdência Social<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;Carteira de Trabalho anterior em caso de inutilização ou continuação.<br>
						<b>3.</b> BO - Boletim de Ocorrência<br>
						
							&nbsp;	&nbsp;	&nbsp;	&nbsp;Boletim de Ocorrência em caso de perda, roubo, furto ou danos da CTPS.<br>
						<B><b>4.</b> DOC - Documento que comprove o número da Carteira de Trabalho anterior<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Carteira de Trabalho ou;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- CNIS;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato Análitico;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato FGTS ou;<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;- Rescisão do Contrato de Trabalho.<br></B>
						<font style="color:red;"><b>5.</b> OBS - Observação<br>
							&nbsp;	&nbsp;	&nbsp;	&nbsp;CNH - Carteira Nacional de Habilitação não é aceita como documento de identificação para emissão da CTPS</font>
						
						</p>
				</div>	
				<?}?>
				
				<?if($tipo=="D"){?>
				
				
				<!-- titulo conteúdo -->


    <h2 class="content-title">
      Identificação Civil    </h2>
 
  



<!-- banner -->


<!-- conteúdo -->

  <p>Graças a um convênio firmado com o Identidade, agora é possível fazer a carteira de identidade na Secretaria Municipal de Trabalho e Renda.<br>
&nbsp;</p>
<p><u><strong>DOCUMENTOS NECESSÁRIOS PARA 1º VIA </strong></u><br>
<br>
O requerente deverá apresentar original e cópia ou cópia autenticada dos documentos:<br>
&nbsp;</p>
<p><em><strong>DOCUMENTOS OBRIGATÓRIOS</strong></em></p>
<ul>
    <li><em>Solteiros: </em>certidão de nascimento.</li>
    <li><em>Casados:</em> certidão de casamento.</li>
    <li><em>Estrangeiros naturalizados</em>: certificado de naturalização.</li>
    <li><em>Portugueses com igualdade de direitos:</em> certificado de igualdade&nbsp;de direitos e obrigações civis.</li>
</ul>
<br>
<br>
<p><em><strong>DOCUMENTOS OPCIONAIS</strong></em></p>
<ul>
    <li>CPF</li>
    <li>PIS/PASEP</li>
    <li>1 FOTO 3X4</li>
</ul>
<p>&nbsp;</p>
<p><u><strong>DOCUMENTOS NECESSÁRIOS PARA 2ª VIA </strong></u><strong><br>
</strong><br>
O requerente deverá apresentar original e cópia ou cópia autenticada dos documentos:<br>
&nbsp;</p>
<p><strong><em>DOCUMENTOS OBRIGATÓRIOS</em></strong></p>
<ul>
    <li><em>Solteiros: </em>certidão de nascimento.</li>
    <li><em>Casados: </em>certidão de casamento.</li>
    <li><em>Estrangeiros naturalizados: </em>certificado de naturalização.</li>
    <li><em>Portugueses com igualdade de direitos</em>: certificado de igualdade de direitos e obrigações civis.</li>
    <li><strong>Duda pago, isenção ou registro de ocorrência&nbsp;(não é necessário cópia)</strong></li>
</ul>
<br>
<br>
<p><strong><em>DOCUMENTOS OPCIONAIS</em></strong></p>
<ul>
    <li>CPF</li>
    <li>PIS/PASEP</li>
    <li>1 FOTO 3X4&nbsp;</li>
</ul>
<p>&nbsp;</p>
<p><u><strong>OBSERVAÇÕES IMPORTANTES:<br>
<br>
</strong></u></p>



				<p>
						
					
						<font style='color:red'><i>*MENORES DE 12 ANOS SOMENTE COM A PRESENÇA DE PAI, MÃE OU RESPONSÁVEL LEGAL MUNIDO DE IDENTIDADE ORIGINAL E CÓPIA </i></font>
				
				</p>
				
				<?}?>
				
				<?if($tipoget=="V"){?>
				<!--------------------------------------->
				
				<h3>Atendimento Agendado - Candidatar-se a Vagas de Emprego</h3>
						
					<h4>O agendamento para vagas de emprego deve respeitar os seguintes requisitos:</h4>
					<br>

					<b> Apresentação de documentação original e válida:</b><br>
					&nbsp;&nbsp;&nbsp;-&nbsp;Carteira de trabalho;<br>
					&nbsp;&nbsp;&nbsp;-&nbsp;Carteira de identidade;<br>
					&nbsp;&nbsp;&nbsp;-&nbsp;CPF;<br>
					&nbsp;&nbsp;&nbsp;-&nbsp;Comprovante de Escolaridade, Diplomas e Certificados (caso possua)

					<font style="color:red;"><h4>A secretaria não garante que no momento do seu atendimento a vaga de interesse esteja disponível.</h4></font>
					
				<?}?>
				</form>
				
				
			
			
			
</div>			
</div>

<script type='text/javascript'>window.print();</script>
</body>
</html>