<?include("../input_banco.php"); // Inclui o arquivo com o sistema de segurança



		
		
			
		?>	
			<script>
			
		
function alterastatus(status,id,data){

	
	var id= id ;
	var status= status ;
	
	if (status==""){}else{
				var data= data ;
				var txt;
				var r = confirm("Mudar Status");
				if (r == true) {

							if(window.XMLHttpRequest) {
							req = new XMLHttpRequest();
							}
							else if(window.ActiveXObject) {
							req = new ActiveXObject("Microsoft.XMLHTTP");
							}

							// Arquivo PHP juntamente com o valor digitado no campo (método GET)

							var url = "alterarstatus.php?acao=alterastatus&data="+data+"&id="+id+"&status="+status;

							// Chamada do método open para processar a requisição
							req.open("Get", url, true); 
							req.setRequestHeader("Cache-Control","no-cache,no-store");
							req.setRequestHeader("Pragma", "no-cache");

							// Quando o objeto recebe o retorno, chamamos a seguinte função;
							req.onreadystatechange = function() {

							// Exibe a mensagem "Buscando Noticias..." enquanto carrega
							if(req.readyState == 1) {
							document.getElementById(""+id+"").innerHTML = 'Carregando...';
							}

							// Verifica se o Ajax realizou todas as operações corretamente
							if(req.readyState == 4 && req.status == 200) {

							// Resposta retornada pelo busca.php
							var resposta = req.responseText;

							// Abaixo colocamos a(s) resposta(s) na div resultado
							document.getElementById(""+id+"").innerHTML = resposta;
							}
							}
							req.send(null);
							req.setRequestHeader("Cache-Control", "no-cache");
							req.setRequestHeader("Pragma", "no-cache"); 
							window.location.reload();
						} else {
					alert("Ação Cancelada!");
				}	
	
	}


}	



	
		
function trpresente(value,id){	



							if(value==true){
								 
								 var valueck ="S";
								
							}else{
								
								 var valueck ="N";
							}
	
							if(window.XMLHttpRequest) {
							req = new XMLHttpRequest();
							}
							else if(window.ActiveXObject) {
							req = new ActiveXObject("Microsoft.XMLHTTP");
							}

							// Arquivo PHP juntamente com o valor digitado no campo (método GET)

							var url = "alterarstatus.php?acao=presente&id="+id+"&value="+valueck;
							//alert(url);
							// Chamada do método open para processar a requisição
							req.open("Get", url, true); 
							req.setRequestHeader("Cache-Control","no-cache,no-store");
							req.setRequestHeader("Pragma", "no-cache");

							// Quando o objeto recebe o retorno, chamamos a seguinte função;
							req.onreadystatechange = function() {

							// Exibe a mensagem "Buscando Noticias..." enquanto carrega
							if(req.readyState == 1) {
							document.getElementById(""+id+"").innerHTML = 'Carregando...';
							}

							// Verifica se o Ajax realizou todas as operações corretamente
							if(req.readyState == 4 && req.status == 200) {

							// Resposta retornada pelo busca.php
							var resposta = req.responseText;

							// Abaixo colocamos a(s) resposta(s) na div resultado
							document.getElementById(""+id+"").innerHTML = resposta;
							}
							}
							req.send(null);
							req.setRequestHeader("Cache-Control", "no-cache");
							req.setRequestHeader("Pragma", "no-cache"); 
							window.location.reload();
}	




		
function chamanome(nome,tipo,id){	



						if(tipo =="C"){
							
							var atendimento = "CTPS";
						}
						
						
						if(tipo =="D"){
							
							var atendimento = "Identidade";
						}
						
						if(tipo =="V"){
							
							var atendimento = "Vaga de emprego";
						}
	
							if(window.XMLHttpRequest) {
							req = new XMLHttpRequest();
							}
							else if(window.ActiveXObject) {
							req = new ActiveXObject("Microsoft.XMLHTTP");
							}

							// Arquivo PHP juntamente com o valor digitado no campo (método GET)

							var url = "alterarstatus.php?acao=chamanome&nome="+nome+"&tipo="+atendimento+"&id="+id;
							//alert(url);
							// Chamada do método open para processar a requisição
							req.open("Get", url, true); 
							req.setRequestHeader("Cache-Control","no-cache,no-store");
							req.setRequestHeader("Pragma", "no-cache");

							// Quando o objeto recebe o retorno, chamamos a seguinte função;
							req.onreadystatechange = function() {

							// Exibe a mensagem "Buscando Noticias..." enquanto carrega
							if(req.readyState == 1) {
							document.getElementById(""+id+"").innerHTML = 'Carregando...';
							}

							// Verifica se o Ajax realizou todas as operações corretamente
							if(req.readyState == 4 && req.status == 200) {

							// Resposta retornada pelo busca.php
							var resposta = req.responseText;

							// Abaixo colocamos a(s) resposta(s) na div resultado
							document.getElementById(""+id+"").innerHTML = resposta;
							}
							}
							req.send(null);
							req.setRequestHeader("Cache-Control", "no-cache");
							req.setRequestHeader("Pragma", "no-cache"); 
							window.location.reload();
}	


			</script>
			
			
		
		

<html>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	<?include"../topo.php";?>
<body>



	

		
	
	<?
	$diahoje = date("d");
	$meshoje = date("m");
	if($meshoje =="01"){$meshoje="0";}
	$anohoje = date("Y");
	?>

	<script>
	
	function Abrir_Pagina(URL) {
			  window.open(URL,'','width=500,height=500');      
			} 
			
	</script>
		
<div id="content" name='contente' >
<div id="container">

		<div id="bg-container"   class='contener'>
				<input type="button" name="imprimir" value="Imprimir" onclick="window.print();">	
			
		
			
			<?
			$dataget= $_GET['dia'];
			$tipoescolhido= $_GET['tipo'];
				$pieces = explode("-", $dataget);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia

				$diasoma = $pieces[1] + 1;

				$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				$datadd = $pieces[2]."-".$diasoma."-".$pieces[0];
				
			?>
			<h2>Agendamento CTPS</h2>
			
	
					
			
			<form  class="form" method="post" action=""  id="cadastro2" name='cadastro2' >			

			<div class="form-row">
			
			
			<div class="form-row">
			<div class="label">CPF:</div>
			<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" onBlur="return validar_cpf()" name="cpf" id='cpf' placeholder="Insira o CPF" type="text"  class="input req-same" maxlength="14"  /></div>
			</div>
			
			
			<div class="form-row">
			<div class="label">ID:</div>
			<div class="input-container"><input  name="idtr" id='idtr' placeholder="Insira o ID" type="text"  class="input req-same" maxlength="14"  /></div>
			</div>
			
			
			<h2>Atendimento CTPS</h2>
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			<input  value="Limpar" type="submit" class="sendBtn"   onClick="window.location.reload();" />
			<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" id="submitBtn2" value="Buscar" type="submit" class="sendBtn"  onclick='return validar_cpf()' />
			<div id="errorDiv2" class="error-div"></div>
			</div>
			</div>
			<input type='hidden' name='buscaform' value='b'>
			</form>
			
														
			
			<div>
			<img src="../img/icone/error.png"/> = Não compareceu   / 
			<img src="../img/icone/accept.gif"/> = Atendimento CTM  / 
			 
			<img src="../img/icone/user_comment.png"/> = Aguardando   <br>
			<img src="../img/icone/user_green.png"/> = Atendido  1º via 
			<img src="../img/icone/user_orange.png"/> =Atendido  2º via 
			<img src="../img/icone/cross.gif"/> = Cancelado
			<img src="../img/icone/information.png"/> = Pendência
			
			</div>
			
			
			<table  class="sortable">
			<tr>
				
				
				<td class='td1' >ORD</td>
				<td class='td1' >ICO</td>
				<td class='td1' >ID</td>
				<td class='td1' >Nome </td>
				
				<td class='td1' >Cel </td>
				<td class='td1' >E-mail </td>
				<td class='td1' >Data </td>
				<td class='td1' >Horário </td>
				<td class='td1'>CPF. </td>
				<!--<td class='td1'>Tipo. </td>-->
				<td class='td1'>Data Cadastro </td>
				<td class='td1'>IP </td>
				
				<td class='td1'> </td>
			</tr>
	<form  class="form" method="post" action=""  id="cadastro" name='cadastro' >	
<?
				
				$numero=1;
				$cpf = $_POST['cpf'];
				$idtr = $_POST['idtr'];
			
			
			
				$query_noticias_hcpj2 = "SELECT * FROM `agendamentoctps` where  tipo='C' and email='CONECTIVA.CYBER@GMAIL.COM' GROUP BY data ORDER BY  datacadastro DESC";
				$rs_noticias_hcpj2    = mysql_query($query_noticias_hcpj2);
				while($campo_noticias_hcpj2 = mysql_fetch_array($rs_noticias_hcpj2)){			
				$data33  = $campo_noticias_hcpj2['data'];
				$data33w = date("d-m-Y", strtotime($data33));
				echo"<tr><td></td><td></td><td></td><td><h3>$data33w</h3></td></tr>";
							
				$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where data='$data33' and tipo='C' and email='CONECTIVA.CYBER@GMAIL.COM' order by datacadastro ASC";
				$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
				while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
				$idp  = $campo_noticias_hcpj['id'];
				$cpf_buscap =$campo_noticias_hcpj['cpf'];
				$nomep = $campo_noticias_hcpj['nome'];
				$datanascimentop = $campo_noticias_hcpj['datanascimento'];
				$telcelp = $campo_noticias_hcpj['celular'];
				$telres = $campo_noticias_hcpj['telefone'];					
				$datap = $campo_noticias_hcpj['data'];					
				$horariop = $campo_noticias_hcpj['horario'];					
				$tipo = $campo_noticias_hcpj['tipo'];					
				$status = $campo_noticias_hcpj['status'];					
				$presente = $campo_noticias_hcpj['presente'];					
				$avulso = $campo_noticias_hcpj['avulso'];					
				$datacadastro = $campo_noticias_hcpj['datacadastro'];					
				$email = $campo_noticias_hcpj['email'];					
				$ip = $campo_noticias_hcpj['ip'];					
				
				$datap = date("d-m-Y", strtotime($datap));
				switch ($tipo) {
				case "C" :
					$tipoatendimento = "Atendimento CTPS";
					break;
				case "D":
					$tipoatendimento =  "Atendimento DETRAN";
					break;
				case "V":
					$tipoatendimento =  "Atendimento Vagas ";
					break;
					case "P":
					$tipoatendimento =  "Pendência";
					break;
				}
					switch ($status) {
				case "N" :
					$icone = "error.png";
					break;
				case "A":
					$icone =  "user_comment.png";
					break;
					
				case "A1":
					$icone =  "user_green.png";
					break;
					
					case "T":
					$icone =  "user_green.png";
					break;
					
					case "A2":
					$icone =  "user_orange.png";
					break;
					
					
					case "C":
					$icone =  "cross.gif";
					break;
					case "AT":
					$icone =  "accept.gif";
					break;
					
					case "D":
					$icone =  "image_add.png";
					break;
					
					case "P":
					$icone =  "information.png";
					break;
			}


			$vowels = array("(", ")", ".", "-");
			$numerocelular = str_replace($vowels, "", $telcelp);
				
			?>	
			
			<tr class='tr_tb' >		
				
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <img src="../img/icone/<?=$icone;?>"/> </td>
				<td class='td2' > <?=$idp;?> </td>
				<td class='td2' > <?=$nomep;?> </td>
				
				<td class='td2' > <?=$telcelp;?> </td>
				<td class='td2' > <?=$email;?> </td>
				
				<td class='td2' > <?=$datap;?> </td>
				<td class='td2' > <?=$horariop;?> </td>
				<td class='td2' > <?=$cpf_buscap;?> </td>
				<!--<td class='td2' > <?=$tipoatendimento;?> <?if($avulso=="S"){echo"Encaixe";}?></td>-->
				<td class='td2' > <?=$datacadastro;?> </td>
				<td class='td2' > <?=$ip;?> </td>
				
					
					
					
				
					
			</tr>
			<?}?>
			<?}?>
			</table>
			
			
			
			</form>
		
			
			
		
			
			
</div>			

</div>


</body>
</html>