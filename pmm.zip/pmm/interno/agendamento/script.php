<?php
include("../input_banco.php"); // Inclui o arquivo com o sistema de segurança


$dataget= $_GET['dia'];
$pieces = explode("-", $dataget);
$pieces[0]; // ano
$pieces[1]; // mes
$pieces[2]; // dia

$diasoma = $pieces[1] + 1;

$data = $pieces[0]."-".$diasoma."-".$pieces[2];

//echo $data;


$vaga= $_GET['quatidadedia'];
$acao= $_GET['acao'];

//echo"esse e $dia e $quatidadedia";

	switch ($acao) {
			case cadastro:
			
			$emprego = $_GET['emprego'];
			$ctps = $_GET['ctps'];
			$detran = $_GET['detran'];
			$query_noticias_total_emca = "SELECT * FROM `diaagendamento` where status='A' and data='$data' ";	
			$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
			$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
			
			if($total_total_emca > 0)			
			{
			//echo"Data $data já está Ativa";
			
			$query="update  diaagendamento set emprego='$emprego', ctps='$ctps', detran='$detran' where data='$data' ";
			$rs= mysql_query($query);
				
			echo"Data $data Salva";	
			}else{

					$query="insert INTO `diaagendamento` ( `data`, `vaga`,`status`,`emprego`,`ctps`,`detran`) VALUES  ('$data','$vaga','A','$emprego','$ctps','$detran')";
					$rs= mysql_query($query);
					
				

							if ($rs) {

								echo"Data $data Ativa";

							} else {
									
								echo"Não foi possível cadastrar, tente novamente.";
											
							}
			}
			break;
			

			case excluir:			
				$query_noticias_total_emca = "DELETE FROM  diaagendamento where data='$data'";	
				$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 	

				if ($rs_noticias_total_emca) {

					echo"Data $data Desativada";

				} else {
						
					echo"Não foi possível Desativada, tente novamente.";
								
				}
							
			break;
			
			
			
			case agendar:
			
			
			
				function getIp()
				{
				 
					if (!empty($_SERVER['HTTP_CLIENT_IP']))
					{
				 
						$ip = $_SERVER['HTTP_CLIENT_IP'];
				 
					}
					elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
					{
				 
						$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
				 
					}
					else{
				 
						$ip = $_SERVER['REMOTE_ADDR'];
				 
					}
				 
					return $ip;
				 
				}
				$ipaddress = getIp(); 
			
						$cpf_busca =$_GET['cpf_busca'];
						$nome = $_GET['nome'];
						$datanascimento = $_GET['datanascimento'];
						$telcel = $_GET['telcel'];
						$telres = $_GET['telres'];
						$horario = $_GET['horario'];
			
			$query_noticias_total_emca = "SELECT * FROM `agendamentoctps` where status='A' and cpf='$cpf_busca'";	
			$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
			$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
			
			if($total_total_emca > 0)			
			{
			echo"0";
				
			}else{
					
					$query="insert INTO `agendamentoctps` ( `data`, `cpf`,`status`,`nome`,`datanascimento`,`telefone`,`celular`,`horario`,`ip`) VALUES  ('$data','$cpf_busca','A','$nome','$datanascimento','$telres','$telcel','$horario','$ipaddress')";
					$rs= mysql_query($query);
					
				

							if ($rs) {

								echo"2";

							} else {
									
								echo"1";
											
							}
			}
			break;
			
			
			case cancelaagendamento:
			
			$id= $_GET['id'];
			$query="update  agendamentoctps set status='C' where id='$id' ";
			$rs= mysql_query($query);
			
				if ($rs) {

						echo"2";

					} else {
							
						echo"1";
									
					}
			break;
		}

?>