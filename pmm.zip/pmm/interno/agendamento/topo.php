<?					
						$cpf_busca=(string)addslashes($_POST['cpf_busca']);
						$nome=(string)addslashes($_POST['nome']);
						$datanascimento=(string)addslashes($_POST['datanascimento']);
						$telcel=(string)addslashes($_POST['telcel']);
						$telres=(string)addslashes($_POST['telres']);
						
						
									
					?>
					<?include"../topo_logo.php";?>