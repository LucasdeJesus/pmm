<?include("../input_banco.php"); // Inclui o arquivo com o sistema de segurança



		
		
			
		?>	
			<script>
			
		
function alterastatus(status,id,data){

	
	var id= id ;
	var status= status ;
	
	if (status==""){}else{
				var data= data ;
				var txt;
				var r = confirm("Mudar Status");
				if (r == true) {

							if(window.XMLHttpRequest) {
							req = new XMLHttpRequest();
							}
							else if(window.ActiveXObject) {
							req = new ActiveXObject("Microsoft.XMLHTTP");
							}

							// Arquivo PHP juntamente com o valor digitado no campo (método GET)

							var url = "alterarstatus.php?acao=alterastatus&data="+data+"&id="+id+"&status="+status;

							// Chamada do método open para processar a requisição
							req.open("Get", url, true); 
							req.setRequestHeader("Cache-Control","no-cache,no-store");
							req.setRequestHeader("Pragma", "no-cache");

							// Quando o objeto recebe o retorno, chamamos a seguinte função;
							req.onreadystatechange = function() {

							// Exibe a mensagem "Buscando Noticias..." enquanto carrega
							if(req.readyState == 1) {
							document.getElementById(""+id+"").innerHTML = 'Carregando...';
							}

							// Verifica se o Ajax realizou todas as operações corretamente
							if(req.readyState == 4 && req.status == 200) {

							// Resposta retornada pelo busca.php
							var resposta = req.responseText;

							// Abaixo colocamos a(s) resposta(s) na div resultado
							document.getElementById(""+id+"").innerHTML = resposta;
							}
							}
							req.send(null);
							req.setRequestHeader("Cache-Control", "no-cache");
							req.setRequestHeader("Pragma", "no-cache"); 
							window.location.reload();
						} else {
					alert("Ação Cancelada!");
				}	
	
	}


}	



	
		
function trpresente(value,id){	



							if(value==true){
								 
								 var valueck ="S";
								
							}else{
								
								 var valueck ="N";
							}
	
							if(window.XMLHttpRequest) {
							req = new XMLHttpRequest();
							}
							else if(window.ActiveXObject) {
							req = new ActiveXObject("Microsoft.XMLHTTP");
							}

							// Arquivo PHP juntamente com o valor digitado no campo (método GET)

							var url = "alterarstatus.php?acao=presente&id="+id+"&value="+valueck;
							//alert(url);
							// Chamada do método open para processar a requisição
							req.open("Get", url, true); 
							req.setRequestHeader("Cache-Control","no-cache,no-store");
							req.setRequestHeader("Pragma", "no-cache");

							// Quando o objeto recebe o retorno, chamamos a seguinte função;
							req.onreadystatechange = function() {

							// Exibe a mensagem "Buscando Noticias..." enquanto carrega
							if(req.readyState == 1) {
							document.getElementById(""+id+"").innerHTML = 'Carregando...';
							}

							// Verifica se o Ajax realizou todas as operações corretamente
							if(req.readyState == 4 && req.status == 200) {

							// Resposta retornada pelo busca.php
							var resposta = req.responseText;

							// Abaixo colocamos a(s) resposta(s) na div resultado
							document.getElementById(""+id+"").innerHTML = resposta;
							}
							}
							req.send(null);
							req.setRequestHeader("Cache-Control", "no-cache");
							req.setRequestHeader("Pragma", "no-cache"); 
							window.location.reload();
}	




		
function chamanome(nome,tipo,id){	



						if(tipo =="C"){
							
							var atendimento = "CTPS";
						}
						
						
						if(tipo =="D"){
							
							var atendimento = "Identidade";
						}
						
						if(tipo =="V"){
							
							var atendimento = "Vaga de emprego";
						}
	
							if(window.XMLHttpRequest) {
							req = new XMLHttpRequest();
							}
							else if(window.ActiveXObject) {
							req = new ActiveXObject("Microsoft.XMLHTTP");
							}

							// Arquivo PHP juntamente com o valor digitado no campo (método GET)

							var url = "alterarstatus.php?acao=chamanome&nome="+nome+"&tipo="+atendimento+"&id="+id;
							//alert(url);
							// Chamada do método open para processar a requisição
							req.open("Get", url, true); 
							req.setRequestHeader("Cache-Control","no-cache,no-store");
							req.setRequestHeader("Pragma", "no-cache");

							// Quando o objeto recebe o retorno, chamamos a seguinte função;
							req.onreadystatechange = function() {

							// Exibe a mensagem "Buscando Noticias..." enquanto carrega
							if(req.readyState == 1) {
							document.getElementById(""+id+"").innerHTML = 'Carregando...';
							}

							// Verifica se o Ajax realizou todas as operações corretamente
							if(req.readyState == 4 && req.status == 200) {

							// Resposta retornada pelo busca.php
							var resposta = req.responseText;

							// Abaixo colocamos a(s) resposta(s) na div resultado
							document.getElementById(""+id+"").innerHTML = resposta;
							}
							}
							req.send(null);
							req.setRequestHeader("Cache-Control", "no-cache");
							req.setRequestHeader("Pragma", "no-cache"); 
							window.location.reload();
}	


			</script>
			
			
		
		

<html>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="glDatePicker.js"></script>
	<link href="styles/glDatePicker.default.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="../assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="../assets/styles.css" />
	<?include"../topo.php";?>
<body>



	

		
	
	<?
	$diahoje = date("d");
	$meshoje = date("m");
	if($meshoje =="01"){$meshoje="0";}
	$anohoje = date("Y");
	?>

	<script>
	
	function Abrir_Pagina(URL) {
			  window.open(URL,'','width=500,height=500');      
			} 
			
	</script>
		
<div id="content" name='contente' >
<div id="container">

		<div id="bg-container"   class='contener'>
				<input type="button" name="imprimir" value="Imprimir" onclick="window.print();">	
			
		
			
			<?
			$dataget= $_GET['dia'];
			$tipoescolhido= $_GET['tipo'];
				$pieces = explode("-", $dataget);
				$pieces[0]; // ano
				$pieces[1]; // mes
				$pieces[2]; // dia

				$diasoma = $pieces[1] + 1;

				$data = $pieces[0]."-".$diasoma."-".$pieces[2];
				$datadd = $pieces[2]."-".$diasoma."-".$pieces[0];
				
			?>
			<h2>Agendamento do dia <?=$datadd ;?></h2>
			
			
			<script>
			
			
			function enviasms(value){
				
					$.ajax({
					url: 'http://app.smsconecta.com.br/SendAPI/Send.aspx?usr=cetep&pwd=cetep357&number=55'+value+'&sender=AGETRAB&msg=Sua Carteira de Trabalho ja se encontra na AGETRAB, retirada de segunda a sexta das 15h ate as 16:30min. : Rua Dr. Telio Barreto,28-Centro',
					success: function(data) {	
					//alert (data);
					if($.trim(data)  > 2){
					
					alert("SMS enviada..");
					//document.getElementById("sms").innerHTML = "<h3>Enviamos uma SMS para <?=$numerocelular;?>  com detalhes de acesso ao sistema , favor verificar seu Celular </h3>";		

					}
					}

					});
			}
					
					</script>
					
			
			<form  class="form" method="post" action=""  id="cadastro2" name='cadastro2' >			

			<div class="form-row">
			
			
			<div class="form-row">
			<div class="label">CPF:</div>
			<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" onBlur="return validar_cpf()" name="cpf" id='cpf' placeholder="Insira o CPF" type="text"  class="input req-same" maxlength="14"  /></div>
			</div>
			
			
			<div class="form-row">
			<div class="label">ID:</div>
			<div class="input-container"><input  name="idtr" id='idtr' placeholder="Insira o ID" type="text"  class="input req-same" maxlength="14"  /></div>
			</div>
			
			
			
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			<input  value="Limpar" type="submit" class="sendBtn"   onClick="window.location.reload();" />
			<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" id="submitBtn2" value="Buscar" type="submit" class="sendBtn"  onclick='return validar_cpf()' />
			<div id="errorDiv2" class="error-div"></div>
			</div>
			</div>
			<input type='hidden' name='buscaform' value='b'>
			</form>
			
														
			
			<div>
			<img src="../img/icone/error.png"/> = Não compareceu   / 
			<img src="../img/icone/accept.gif"/> = Atendimento CTM  / 
			 
			<img src="../img/icone/user_comment.png"/> = Aguardando   <br>
			<img src="../img/icone/user_green.png"/> = Atendido  1º via 
			<img src="../img/icone/user_orange.png"/> =Atendido  2º via 
			<img src="../img/icone/cross.gif"/> = Cancelado
			<img src="../img/icone/information.png"/> = Pendência
			
			</div>
			<table style='width:800px' class="sortable">
			<tr>
				
				<td class='td1' ></td>
				<td class='td1' >ORD</td>
				<td class='td1' >ICO</td>
				<td class='td1' >ID</td>
				<td class='td1' >Nome </td>
				<td class='td1' >Tel </td>
				<td class='td1' >Cel </td>
				<td class='td1' >Data </td>
				<td class='td1' >Horário </td>
				<td class='td1'>CPF. </td>
				<td class='td1'>Tipo. </td>
				<td class='td1'>Acão </td>
				<td class='td1'>Impr. </td>
				<td class='td1'> </td>
			</tr>
	<form  class="form" method="post" action=""  id="cadastro" name='cadastro' >	
<?
				
				$numero=1;
				$cpf = $_POST['cpf'];
				$idtr = $_POST['idtr'];
			
				if($tipoescolhido==""){}else{$sqltipo="and tipo='$tipoescolhido'";};
				if($cpf=="" ){
					
					if($idtr=="" ){
							
							$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where status IN ('A','A1','A2','P','N','AT','D','C')  and  data='$data' $sqltipo order by horario ASC";
						}else{
							$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where id='$idtr' ";
							
						}
					
				}else{
					
					
					$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where cpf='$cpf'";	
					
				}
				
				$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
				while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
				$idp  = $campo_noticias_hcpj['id'];
				$cpf_buscap =$campo_noticias_hcpj['cpf'];
				$nomep = $campo_noticias_hcpj['nome'];
				$datanascimentop = $campo_noticias_hcpj['datanascimento'];
				$telcelp = $campo_noticias_hcpj['celular'];
				$telres = $campo_noticias_hcpj['telefone'];					
				$datap = $campo_noticias_hcpj['data'];					
				$horariop = $campo_noticias_hcpj['horario'];					
				$tipo = $campo_noticias_hcpj['tipo'];					
				$status = $campo_noticias_hcpj['status'];					
				$presente = $campo_noticias_hcpj['presente'];					
				$avulso = $campo_noticias_hcpj['avulso'];					
				
				$datap = date("d-m-Y", strtotime($datap));
				switch ($tipo) {
				case "C" :
					$tipoatendimento = "Atendimento CTPS";
					break;
				case "D":
					$tipoatendimento =  "Atendimento DETRAN";
					break;
				case "V":
					$tipoatendimento =  "Atendimento Vagas ";
					break;
					case "P":
					$tipoatendimento =  "Pendência";
					break;
				}
					switch ($status) {
				case "N" :
					$icone = "error.png";
					break;
				case "A":
					$icone =  "user_comment.png";
					break;
					
				case "A1":
					$icone =  "user_green.png";
					break;
					
					case "T":
					$icone =  "user_green.png";
					break;
					
					case "A2":
					$icone =  "user_orange.png";
					break;
					
					
					case "C":
					$icone =  "cross.gif";
					break;
					case "AT":
					$icone =  "accept.gif";
					break;
					
					case "D":
					$icone =  "image_add.png";
					break;
					
					case "P":
					$icone =  "information.png";
					break;
			}


			$vowels = array("(", ")", ".", "-");
			$numerocelular = str_replace($vowels, "", $telcelp);
				
			?>	
			
			<tr class='tr_tb' >		
				<td class='td2' > <input type="checkbox" name="presente"  id="presente" onclick="trpresente(this.checked,<?=$idp;?>)"  <? if($presente=="S"){echo"checked";}?> /></td>
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <img src="../img/icone/<?=$icone;?>"/> </td>
				<td class='td2' > <?=$idp;?> </td>
				<td class='td2' > <?=$nomep;?> </td>
				<td class='td2' > <?=$telres;?> </td>
				<td class='td2' > <?=$telcelp;?> </td>
				
				<td class='td2' > <?=$datap;?> </td>
				<td class='td2' > <?=$horariop;?> </td>
				<td class='td2' > <?=$cpf_buscap;?> </td>
				<td class='td2' > <?=$tipoatendimento;?> </td>
				<!--<td class='td2' > <select name='acao'style='width:60px;font-size:14px:' onchange="location = this.options[this.selectedIndex].value;" >
					<option>--</option>
					<option value='trabalhadores_agendado.php?acao=A&status=A&id=<?=$idp;?>&dia=<?=$dataget;?>'>Aguardando</option>
					<option value='trabalhadores_agendado.php?acao=A&status=N&id=<?=$idp;?>&dia=<?=$dataget;?>'>Não compareceu</option>
					<option value='trabalhadores_agendado.php?acao=A&status=AT&id=<?=$idp;?>&dia=<?=$dataget;?>'>Atendimento Vaga </option>
					<option value='trabalhadores_agendado.php?acao=A&status=D&id=<?=$idp;?>&dia=<?=$dataget;?>'>Atendimento DETRAN </option>					
					<option value='trabalhadores_agendado.php?acao=A&status=A1&id=<?=$idp;?>&dia=<?=$dataget;?>'>Atendido 1º via CTPS </option>					
					<option value='trabalhadores_agendado.php?acao=A&status=A2&id=<?=$idp;?>&dia=<?=$dataget;?>'>Atendido 2º via CTPS</option>					
					<option value='trabalhadores_agendado.php?acao=A&status=P&id=<?=$idp;?>&dia=<?=$dataget;?>'>Pendência </option>					
					</select></td>-->
					
					<td class='td2' > <select name='acao'style='width:60px;font-size:14px:' onchange="alterastatus(this.options[this.selectedIndex].value,<?=$idp;?>,<?=$dataget;?>)" >
					<option>--</option>
					
					<option value='A'>Aguardando</option>
					
					<option value='AT'>Atendido </option>	
					<?if(($tipoescolhido=="D")or ($tipoescolhido=="C")){?>		
					<option value='A1'>Atendido 1º via</option>					
					<option value='A2'>Atendido 2º via</option>	
					<?}?>
					<option value='N'>Não compareceu</option>					
					<option value='P'>Pendência </option>					
					</select>
					<div name="<?=$idp;?>"  id="<?=$idp;?>"></div>
					
					<?if($avulso=="S"){echo"Encaixe";}?>
					</td>
					
					
					
				<td class='td2' > 
				
				<a href="#" Onclick="Abrir_Pagina('imprimeagendamento.php?idp=<?=$idp;?>');">Imprimir</a>
				<a href="#" Onclick="chamanome('<?=$nomep;?>','<?=$tipo;?>','<?=$idp;?>');">chamar</a>
				
				</td>
					
					<?if($tipo=="C"){?>	
							<?if($cpf==""){}else{?>
							<td class='td2' >
							<div id="22997437124" ><a href="#" Onclick="enviasms('<?=$numerocelular;?>');">Enviar sms</div>
							
							</td>
						<?}?>
				<?}?>
			</tr>
			<?}?>
			</table>
			
			
			
			</form>
		
			
			
		
			
			
</div>			

</div>


</body>
</html>