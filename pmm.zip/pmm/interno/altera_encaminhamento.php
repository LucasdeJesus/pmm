﻿<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);
		
		
?>
		<style>
		td{vertical-align: top;}
		body {
    font-family: Arial,Helvetica,sans-serif;
    font-size: 11px;}
	table{ font-size: 11px;}
		</style>
		<?include'topo.php';?>
<body>
		<?
			
			$idencaminhamento = $_GET['idencaminhamento'];
		$query_noticias_hcpj = "SELECT * FROM `encaminhamento`  WHERE id='$idencaminhamento'";
		$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
		while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
		$vagaid  = $campo_noticias_hcpj['vagaid'];
		$selStatus_ajax  = $campo_noticias_hcpj['status'];
		$id_usuario_ajax  = $campo_noticias_hcpj['usuarioid'];
		$dia_ajax  = $campo_noticias_hcpj['dia'];
		$mes_ajax  = $campo_noticias_hcpj['mes'];
		$ano_ajax  = $campo_noticias_hcpj['ano'];
		$obs  = $campo_noticias_hcpj['observacao'];
		$id_emcaminhamento  = $campo_noticias_hcpj['id'];
		$id_trabalhandor  = $campo_noticias_hcpj['trabalhadorid'];
		$datacadastro  = $campo_noticias_hcpj['datacadastro'];
		$idencaminhamento  = $campo_noticias_hcpj['id'];
		
		}
		
		?>
		
			<?

			$query_noticias_hcpjvget = "SELECT * FROM `trabalhador` where id='$id_trabalhandor' ";
			$rs_noticias_hcpjvget    = mysql_query($query_noticias_hcpjvget);
			while($campo_noticias_hcpjvget = mysql_fetch_array($rs_noticias_hcpjvget)){			
			$cpf  = $campo_noticias_hcpjvget['cpf'];
			$idtrabalhado  = $campo_noticias_hcpjvget['id'];
			$nome  = $campo_noticias_hcpjvget['nome'];
			$txttelcel  = $campo_noticias_hcpjvget['telcel'];
			$txttelrec  = $campo_noticias_hcpjvget['telrec'];
			$telres  = $campo_noticias_hcpjvget['telres'];

			}

			?>
		
		
		 <script>
		 
	
				jQuery(document).ready(function(){
				$('#id_vaga_e').val('<?=$vagaid;?>');
				});
				
				function pop_pesquisaempresa(page) {
				
					window.open(page, 'popRelReciboEntregue', 'width=750,height=450,scrollbars');
					//document.emcaminhamentof.action = page;
					//document.emcaminhamentof.target = 'popRelReciboEntregue';
					//document.emcaminhamentof.submit();
				}

				</script>


	<form id="emcaminhamentof"  name='emcaminhamentof'  class="form" method="Post" action="script_emcaminhamento.php?acao=editar" >	
	
	
	<h2>TRABALHADOR</h2>

			<div class="form-row">
			<div class="label">CPF</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  value="<?echo $cpf;?>" size="60" maxlength="60"  disabled=""class="input req-same" tabindex="22" type="text"/> 

			</div>
			</div>

			<div class="form-row">
			<div class="label">Nome</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?echo $nome;?>" tabindex="23"type="text"/>

			</div>
			</div>
			
			<div class="form-row">
			<div class="label">ID</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?=$idtrabalhado;?>" tabindex="23"type="text"/>

			</div>
			</div>
			
			<h2>Encaminhamento</h2>
			
			<div class="label">Vaga</div>
						<div class="input-container" style='width:546px;'>		
						<select required name='id_vaga_e' id='id_vaga_e' style='width:500px;'>
						
						<?	
						$query_noticiasjt = "SELECT * FROM `vaga` where id='$vagaid'";			
						$rs_noticiasjt    = mysql_query($query_noticiasjt);				
						while($campo_noticiasjt = mysql_fetch_array($rs_noticiasjt)){
							$cboidt = $campo_noticiasjt['cboid'];	
							$idvagat = $campo_noticiasjt['id'];	
						
							$query_ocupacaot = "SELECT * FROM `cbo` where id='$cboidt' ";
							$rs_ocupacaot     = mysql_query($query_ocupacaot);
							while($campo_ocupacaot  = mysql_fetch_array($rs_ocupacaot)){
							$txcbonomet        = $campo_ocupacaot ['cbo'];
							}
							
							echo"<option value='$idvagat'>$idvagat - $txcbonomet</option>";
						}?>
						
						
						<?
						$query_noticiasj = "SELECT * FROM `vaga` where status IN ('A') ORDER BY `vaga`.`id` ASC";			
						$rs_noticiasj    = mysql_query($query_noticiasj);				
						while($campo_noticiasj = mysql_fetch_array($rs_noticiasj)){

						$id_vagam= $campo_noticiasj['id']; 			
						$cboid = $campo_noticiasj['cboid'];	
						$txEncaminhar = $campo_noticiasj['quantidadeencaminhar'];	
							$query_ocupacao = "SELECT * FROM `cbo` where id='$cboid' ";
							$rs_ocupacao     = mysql_query($query_ocupacao );
							while($campo_ocupacao  = mysql_fetch_array($rs_ocupacao )){
							$txcbonome        = $campo_ocupacao ['cbo'];
							}
							$query_noticias_total_emca = "SELECT * FROM  encaminhamento  WHERE vagaid ='$id_vagam'";	
							$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
							$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
							
							if($total_total_emca > $txEncaminhar )
							
							{
							}
							else{
							?>
							<option value='<?=$id_vagam;?>'><?=$id_vagam;?> - <?=$txcbonome;?></option>
							<?}
						}?>
						</select>
						
						 <a class="sendBtn" onclick="pop_pesquisaempresa('interno/index.php?lista=encaminhamento')" ><img src='img/busca.png'/></a>
						</div>
					
	
	

				<div class="form-row">
				<div class="label">Observações</div>
				<div class="input-container" style='width:546px;'>		
				<textarea name='obs' id='obs' class="input req-same" rows="2" cols="96" tabindex="21" style="font-size: 12px; font-family: Arial;height:56px;"><?=$obs;?></textarea>				
				</div>
				</div>

				<div class="form-row">
				<div class="label"></div>
				<div class="input-container" style='width:546px;'>	
				<input type='hidden' name='status' id='status' value='E'/>				
				<input type='hidden' name='idencaminhamento' id='idencaminhamento' value='<?=$idencaminhamento;?>'/>				
				<input type='hidden' name='id_trabalhadore_e' id='id_trabalhadore_e' value='<?=$id_trabalhandor;?>'/>				

				</div>
				</div>
				
				
	
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container" style='width:546px;'>					 		
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar"  type="submit" class="sendBtn" />

				</div>
				</div>
				
		

				
		
	</form>
		
		



			


</body>