		<?include("../input_banco.php"); // Inclui o arquivo com o sistema de segurança
 
		$acao = $_GET['acao'];
		$limitget = $_GET['limit'];
		$usuarioid='5422';
		if($limitget==""){$limit="";}else{$limit=" limit $limitget";}
		switch ($acao) {
			case vagacargo:

			$arr = array();

					
					
						$query_noticiasIt = "SELECT * FROM vaga where status='A'   ";
						$rs_noticiasIt  = mysql_query($query_noticiasIt); 
						$totalgeral =0;
						while($campo_ocupacaoA = mysql_fetch_array($rs_noticiasIt)){
						$quantidadedisponivelA        = $campo_ocupacaoA ['quantidadedisponivel'];
						$totalgeral+="$quantidadedisponivelA";
						}
						
					$rs = mysql_query("SELECT * FROM vaga where status='A'  GROUP BY cboid ORDER BY cargo ASC   $limit  ");	
					while($obj = mysql_fetch_object($rs)) {
					
						$cargoobj= $obj->cargo;
						$query_noticiasI = "SELECT * FROM vaga where status='A' and  `cargo`= '$cargoobj'  ";
						$rs_noticiasI  = mysql_query($query_noticiasI); 
						$totalI = mysql_num_rows($rs_noticiasI);
						
						
						
						
						
						
						$obj->totalquantidadevaga = "$totalI";
						$obj->quantidadevaga = "$totalI";
						$obj->totalgeralvaga = "$totalgeral";
					
					$arr[] = $obj;						
					}
					//echo '{"members":'.json_encode($arr).'}';
					
								
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
					
								
				
			
			break;
			
			case buscavagacargo:

			$cargo = $_GET['cargo'];
			$arr = array();

					$rs = mysql_query("SELECT * FROM vaga where status='A'  and cargo ='$cargo' ORDER BY cargo ASC");
					while($obj = mysql_fetch_object($rs)) {
					
						$softwareid1= $obj->softwareid1;
						$query_software1 = "SELECT * FROM `software`where id='$softwareid1'";
						$rs_software1    = mysql_query($query_software1);
						while($campo_software1 = mysql_fetch_array($rs_software1)){																						
						$nome_soft1 	= $campo_software1['nome']; 	
						if($nome_soft1==""){$nome_soft1="";}
							
							
							$obj->nome_soft1 = "$nome_soft1";		
						}
						$softwareid2= $obj->softwareid2;
						$query_software2 = "SELECT * FROM `software`where id='$softwareid2'";
						$rs_software2    = mysql_query($query_software2);
						while($campo_software2 = mysql_fetch_array($rs_software2)){																						
						$nome_soft2 	= $campo_software2['nome']; 	
							if($nome_soft2==""){$nome_soft2="";}
							$obj->nome_soft2 = "$nome_soft2";	
						}
						$softwareid3= $obj->softwareid3;
						$query_software3 = "SELECT * FROM `software`where id='$softwareid3'";
						$rs_software3    = mysql_query($query_software3);
						while($campo_software3 = mysql_fetch_array($rs_software3)){																						
						$nome_soft3 	= $campo_software3['nome']; 	
							if($nome_soft3==""){$nome_soft3="";}
							$obj->nome_soft3 = "$nome_soft3";
						}			
						
						$idiomaid1= $obj->idiomaid1;
						$query_idiomaid1 = "SELECT * FROM `idioma` where id='$idiomaid1'";
						$rs_idiomaid1    = mysql_query($query_idiomaid1);
						while($campo_idiomaid1 = mysql_fetch_array($rs_idiomaid1)){																						
						$nome_idiomaid1 	= $campo_idiomaid1['nome'];
						if($nome_idiomaid1==""){$nome_idiomaid1="";}
						$obj->nome_idiomaid1 = "$nome_idiomaid1";
						
						}		

						$idiomaid2= $obj->idiomaid2;
						$query_idiomaid2 = "SELECT * FROM `idioma` where id='$idiomaid2'";
						$rs_idiomaid2    = mysql_query($query_idiomaid2);
						while($campo_idiomaid2 = mysql_fetch_array($rs_idiomaid2)){																						
						$nome_idiomaid2 	= $campo_idiomaid2['nome'];
						if($nome_idiomaid2==""){$nome_idiomaid2="";}
						$obj->nome_idiomaid2 = "$nome_idiomaid2";
						}
						
						$idiomaid3= $obj->idiomaid3;
						$query_idiomaid3 = "SELECT * FROM `idioma` where id='$idiomaid3'";
						$rs_idiomaid3    = mysql_query($query_idiomaid3);
						while($campo_idiomaid3 = mysql_fetch_array($rs_idiomaid3)){																						
						$nome_idiomaid3 	= $campo_idiomaid3['nome'];
						if($nome_idiomaid3==""){$nome_idiomaid3="";}
						$obj->nome_idiomaid3 = "$nome_idiomaid3";
						}
					
						
						if( $obj->leitura1==""){$obj->leitura1 ="--";};
						
					$arr[] = $obj;
					}
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
					
				break;

				case dataagendamento:
				
					$dataagendamento = $_GET['dataagendamento'];
					$tipo = $_GET['tipo'];
					$hoje = date('Y-m-d');					
					
					if($tipo=="V"){ $sqltipo="and emprego='S'";}
					if($tipo=="D"){ $sqltipo="and Identidade='S'";}
					if($tipo=="C"){ $sqltipo="and ctps='S'";}
					
					
					$arr = array();
					
					$rs = mysql_query("SELECT id,data FROM  `diaagendamento` WHERE data >=  '$hoje' and status='A'  ".$sqltipo." and liberado='S'");
					$totaldata  = mysql_num_rows($rs);			
				
					while($obj = mysql_fetch_object($rs)) {
					$databanco= $obj->data;
					$databr = date('d/m/Y', strtotime($obj->data));
						
						$obj->data = "$databanco";						
						$obj->databr = "$databr";						
						
						$arr[] = $obj;
					}
					
					if($totaldata==0){$obj->databr = "0";$arr[] = $obj;}
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				break;
				
				
				case horarioaagendamento:
				
					$data = $_GET['dataagendamento'];
					$data = date("Y-n-j", strtotime($data));
					$tipo = $_GET['tipo'];
					
					$hoje=date('Y-n-j');
					$agora=date('H:i');
					
					
				$query_vagaagendamento = "SELECT * FROM  `vagaagendamento`  where tipo ='$tipo'";
				$rs_vagaagendamento     = mysql_query($query_vagaagendamento );
				while($campo_vagaagendamento = mysql_fetch_array($rs_vagaagendamento )){
				$vagatotaltipo        = $campo_vagaagendamento['total'];
				$vagaporhoratipo        = $campo_vagaagendamento['totalhora'];
				}
					
					
				switch ($tipo) {
								case "C":	
						///INICIO ATENDIMENTO c cARTEIRA
				
											$valorhorario=$vagaporhoratipo ;;
									/// se for atendimento C Carteira	
									
											
							$query_horario_disponivelc = "SELECT id FROM  `agendamentoctps`  where  data='$data' and tipo='C'   ";
							$rs_noticias_horario_disponivelc    = mysql_query($query_horario_disponivelc);
							$total_horario_disponivelc = mysql_num_rows($rs_noticias_horario_disponivelc);
							if($total_horario_disponivelc >= $vagatotaltipo){
							
							$obj->horario = "00:00";	
							$arr[] = $obj;
							

							}else{	
						
													
													
														if($data=="2015-6-29"){
															
														$_11_45 = "13:45";
														$_12_00 = "14:00";
														$_12_15 = "14:15";														
														$_12_30 = "14:30";
														$_12_45 = "14:45";
														
														$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:45' AND  `horario` <  '11:00' order by  horario ASC";
														}
														else
														{
															
														$_11_45 = "11:45";
														$_12_00 = "12:00";
														$_12_15 = "12:15";														
														$_12_30 = "12:30";
														$_12_45 = "12:45";
														$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:45' AND  `horario` <  '11:00' order by  horario ASC";	
															
														}
													$rs_noticias_horario    = mysql_query($query_horario);
													while($obj = mysql_fetch_object($rs_noticias_horario)) {
													$horario_banco= $obj->horario;;
													
														
														
															$query_horario_disponivel = "SELECT horario FROM  `agendamentoctps`  where horario='$horario_banco' and data='$data'  and tipo='C'  and `status` NOT LIKE  'C'";
															$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
															$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);	
															
														
															//echo $valorhorario;
																if($total_horario_disponivel>=$valorhorario){ $horariosnao ="Atenção não há mais horário disponível para atendimento nesta data , favor escolha outra data!";}else{	
																	
																	
																		if(($horario_banco==$_11_45) or ($horario_banco==$_12_00) or ($horario_banco==$_12_15) or ($horario_banco==$_12_30) or ($horario_banco==$_12_45)){}else{
																		
																				if($hoje == $data ){
																					if($horario_banco > $agora ){
																						$arr[] = $obj;
																						$numeroHdisponivel=1;
																					}
																				}else{
																						$arr[] = $obj;
																						$numeroHdisponivel=1;
																					
																				}
																				
																		
																		
																		
																		
																		}
															
																}
														}
														
														
														
														
														if($numeroHdisponivel=="1"){}else{
															$obj->horario = "00:00";	
															$arr[] = $obj;
														}
								}					
														echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';		
													///FIM ATENDIMENTO c
									break;					
								case "V":
								
								$query_horario_disponivelv = "SELECT id FROM  `agendamentoctps`  where  data='$data' and tipo='V'  and `status`='A' ";
								$rs_noticias_horario_disponivelv    = mysql_query($query_horario_disponivelv);
								$total_horario_disponivelv = mysql_num_rows($rs_noticias_horario_disponivelv);
								if($total_horario_disponivelv >= $vagatotaltipo){
								
								$obj->horario = "00:00";	
								$arr[] = $obj;
								

								}else{
								
								
										$arr = array();										
										$query_horario = "SELECT horario FROM  `horarioatendimento`  where `horario` >  '08:15' AND  `horario` <  '16:30' order by horario ASC ";
										$rs_noticias_horario    = mysql_query($query_horario);										
										while($obj = mysql_fetch_object($rs_noticias_horario)) {
										$horario_banco= $obj->horario;
										
										
												if(($horario_banco > "11:30")&&($horario_banco < "14:30")){$valorhorario=3;}else{$valorhorario=6;};
											
												$query_horario_disponivel = "SELECT horario FROM  `agendamentoctps`  where horario='$horario_banco' and data='$data' and tipo='V'  and `status` NOT LIKE  'C' ";
												$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
												$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);	
												
												
												//echo $valorhorario;
													if($total_horario_disponivel>=$valorhorario){$horariosnao ="Não há mais horário disponível para atendimento nesta  data , favor escolha outra data!";}else{	
														
														
														if($hoje == $data ){
															if($horario_banco > $agora ){
																$arr[] = $obj;
																$numeroHdisponivel=1;
															}
														}else{
																$arr[] = $obj;
																$numeroHdisponivel=1;
															
														}
													}
													
							
											}
									
										
										
										
											
										if($numeroHdisponivel=="1"){}else{
														$obj->horario = "00:00";	
														$arr[] = $obj;
														
													}
													
								}
										echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';	
								break;		


								
								case "D":	
								
								
								$query_horario_disponiveld = "SELECT id FROM  `agendamentoctps`  where  data='$data' and tipo='D'  and `status`='A' ";
								$rs_noticias_horario_disponiveld    = mysql_query($query_horario_disponiveld);
								$total_horario_disponiveld = mysql_num_rows($rs_noticias_horario_disponiveld);
								if($total_horario_disponiveld >= $vagatotaltipo){
								
								$obj->horario = "00:00";	
								$arr[] = $obj;
								

								}else{
								
													$valorhorario=2;;
											/// se for atendimento C Carteira	
													$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:45' AND  `horario` <  '15:30' order by  horario ASC";
													$rs_noticias_horario    = mysql_query($query_horario);
													while($obj = mysql_fetch_object($rs_noticias_horario)) {
													$horario_banco= $obj->horario;;
													
														
														
															$query_horario_disponivel = "SELECT horario FROM  `agendamentoctps`  where horario='$horario_banco' and data='$data'  and tipo='D'   and `status` NOT LIKE  'C'";
															$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
															$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);	
															
														
															//echo $valorhorario;
																if($total_horario_disponivel>=$valorhorario){ $horariosnao ="Atenção não há mais horário disponível para atendimento nesta data , favor escolha outra data!";}else{	
																	
																	
																		
																		if( ($horario_banco=="12:00") or ($horario_banco=="12:15") or ($horario_banco=="12:30") or ($horario_banco=="12:45") or ($horario_banco=="13:00")){}else{
																			
																			
																				if($hoje == $data ){
																					if($horario_banco > $agora ){
																						$arr[] = $obj;
																						$numeroHdisponivel=1;
																					}
																				}else{
																						$arr[] = $obj;
																						$numeroHdisponivel=1;
																					
																				}
														
																			
																			
																		}
															
																}
														}
														
														
														if($numeroHdisponivel=="1"){}else{
															$obj->horario = "00:00";	
															$arr[] = $obj;
															
														}
								}
								echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';	
							///FIM ATENDIMENTO D
								
								break;
						}	
					
					
					
					
					
				
				break;
				
				
				case formagendar:
				
					$dataagendamento = $_GET['dataagendamento'];
					$dataagendamento = date("Y-n-j", strtotime($dataagendamento));
					$tipoatendimento = $_GET['tipoatendimento'];
					$horario = $_GET['horario'];
					$cpf = $_GET['cpf'];
					$datanascimeno = $_GET['datanascimeno'];
					$telres = $_GET['telres'];
					$telcel = $_GET['telcel'];
					$email = $_GET['email'];
					$nome = $_GET['nome'];
					
					/////////////////////////
					
					
						$query_noticiascpa = "SELECT * FROM  `vagaagendamento`  ";
						$rs_noticiascpa    = mysql_query($query_noticiascpa);
						while($campo_noticiascpa = mysql_fetch_array($rs_noticiascpa)){
						$vaga       = $campo_noticiascpa['vaga'];	
						$detran       = $campo_noticiascpa['detran'];	
						$ctps       = $campo_noticiascpa['ctps'];	
						};
					
					switch ($tipoatendimento) {
						
						//////////////////////////////////////////////////////////////////////
						case "C":						
						
								$totalagedamento = mysql_query("SELECT * from agendamentoctps where data='$dataagendamento' and status='A' and horario ='$horario' and  tipo='C'");
								$totalagedamento  = mysql_num_rows($totalagedamento);
								
								if($totalagedamento >= $ctps ){							
									$limit="ok";
								}else{$limit="nao";}
						
						
						break;
						//////////////////////////////////////////////////////////////////////
						case "V":
						
								$totalagedamento = mysql_query("SELECT * from agendamentoctps where data='$dataagendamento' and status='A' and horario ='$horario' and tipo='V'");
								$totalagedamento  = mysql_num_rows($totalagedamento);
								
								if($totalagedamento >= $vaga ){							
									$limit="ok";
								}else{$limit="nao";}
						break;
						
						//////////////////////////////////////////////////////////////////////
						case "D":
						
								$totalagedamento = mysql_query("SELECT * from agendamentoctps where data='$dataagendamento' and status='A' and horario ='$horario' and tipo='D'");
								$totalagedamento  = mysql_num_rows($totalagedamento);
								
								if($totalagedamento >= $detran ){							
									$limit="ok";
								}else{$limit="nao";}
						break;
						//////////////////////////////////////////////////////////////////////
					}
					
					
					/////////////////////////
					$rst = mysql_query("SELECT * from agendamentoctps where cpf='$cpf' and tipo='$tipo' and status='A'");
					$totaldata  = mysql_num_rows($rst);	
					
					$arr = array();
					
						if($limit=="ok"){
							
							$obj->msg = "4";	
						}else{
										
							if($totaldata > 0){
						
							$obj->msg = "3";	
							}else{
								
											$query="insert INTO `agendamentoctps` ( `nome`,`cpf`,`email`,`datanascimento`,`telefone`,`celular`,`data`,`horario`,`tipo`,`status`) VALUES 
															   ('$nome','$cpf','$email','$datanascimeno','$telres','$telcel','$dataagendamento','$horario','$tipo','A')";
											$rs= mysql_query($query);
												
											if ($rs) {
												
												
												/////////////////////////////////enviaemail///////////////////////////////////////////////
												
												$data2 = date("d-m-Y", strtotime($dataagendamento));
												if($tipoget=="C"){
				
				
															$mensagemHTML="<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>"
																	. "<html xmlns='http://www.w3.org/1999/xhtml'>" 
																	. "<head>"
																	. "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" 
																	. "<body>"
															."<h3>Atendimento Agendado - Emissão de Carteira de Trabalho e Previdência Social - CTPS </h3>"
															
															."<p> Parabens ".$nome.", seu agendamento para o dia ".$data2." as ".$horario." </p>"
															. "<div>"
																	. "<p><b>Emissão de Carteira de Trabalho - DOCUMENTAÇÃO</b></p>"
																	. "<p><br><br>"
																	
																	. "<h4> Para emissão de CTPS favor observar vestuário devido à restrições para a fotografia. </h4>"
																	. "<font style='color:red;'><b>Usar vestimentos:</b></font><br><br>"
																		. "<p>Mais Fechada</p>"
																		. "<p>Mais Discreta</p>"
																		. "<p>Sem Estampas</p>"
																		. "<p>Sem Propagandas, camisa de times ou uniformes </p>"
																		. "<p>Não usar veste Branca </p><br>"
																	
																	
																	
																	
																	. "<font style='color:red;'><b>1ª Via</b></font><br><br>"
																	. "<b>1. </b>CPF - Cadastro de Pessoa Física<br>"
																	. "<b>2.</b> RG - Cédula de Identidade ou CN - Certidão de Nascimento ou CC - Certidão de Casamento ou RES - Certificado de" 
																		. "Reservista ou OAB - Carteira da OAB ou CREA - Carteira do CREA<br>"
																	. "<b>3. </b>OBS - Observação<br>"
																	. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- CNH - Carteira Nacional de Habilitação não é aceita como documento de identificação para emissão da CTPS<br>"
																	. "<b>4. </b>CC - Certidão de Casamento<br>"
																		. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Caso o solicitante seja casado.<br>"
																		. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Com fundo branco, com ou sem data, colorida e recente, que identifique plenamente o solicitante.<br>"
																	. "<b>5.</b> CR - Comprovante de Residência<br>"
																	. "O comprovante deve possuir o numero do CEP.<br>"
																	
																	. "</p>"
																	
																	. "<p><br><br>"
																	. "<font style='color:red;'><b>2ª Via</b></font><br><br>"
																	. "<b>1.</b> Todos - Todos os itens da 1ª via<br>"
																	. "<b>2.</b> CTPS - Carteira de Trabalho e Previdência Social<br>"
																		. "&nbsp;	&nbsp;	&nbsp;	&nbsp;Carteira de Trabalho anterior em caso de inutilização ou continuação.<br>"
																	. "<b>3.</b> BO - Boletim de Ocorrência<br>"
																		. "&nbsp;	&nbsp;	&nbsp;	&nbsp;Boletim de Ocorrência em caso de perda, roubo, furto ou danos da CTPS.<br>"
																	. "<b>4.</b> DOC - Documento que comprove o número da Carteira de Trabalho anterior<br>"
																		. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Carteira de Trabalho ou;<br>"
																		. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato Análitico;<br>"
																		. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Extrato FGTS ou;<br>"
																		. "&nbsp;	&nbsp;	&nbsp;	&nbsp;- Rescisão do Contrato de Trabalho.<br>"
																	. "<font style='color:red;'><b>5.</b> OBS - Observação<br>"
																		. "&nbsp;	&nbsp;	&nbsp;	&nbsp;CNH - Carteira Nacional de Habilitação não é aceita como documento de identificação para emissão da CTPS</font>"
																	
																	. "</p>"
															. "</div>	"
																. "</body>"
																	."</html>";				
															}
																
				
				
																	if($tipoget=="D"){
																	


																		$mensagemHTML="<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>"
																			. "<html xmlns='http://www.w3.org/1999/xhtml'>" 
																			. "<head>"
																			. "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" 
																			. "<body>"
																		."<h2 class='content-title'>  Identificação Civil    </h2>"
																		."<p> Parabens ".$nome.", seu agendamento para o dia ".$data2." as ".$horario." </p>"
																		 . "<p>Graças a um convênio firmado com o DETRAN, agora é possível fazer a carteira de identidade na Secretaria Municipal de Trabalho e Renda.<br>"
																		. "&nbsp;</p>"
																		. "<p><u><strong>DOCUMENTOS NECESSÁRIOS PARA 1º VIA </strong></u><br>"
																		. "<br>"
																		. "O requerente deverá apresentar original e cópia ou cópia autenticada dos documentos:<br>"
																		. "&nbsp;</p>"
																		. "<p><em><strong>DOCUMENTOS OBRIGATÓRIOS</strong></em></p>"
																		. "<ul>"
																			. "<li><em>Solteiros: </em>certidão de nascimento.</li>"
																			. "<li><em>Casados:</em> certidão de casamento.</li>"
																			. "<li><em>Estrangeiros naturalizados</em>: certificado de naturalização.</li>"
																			. "<li><em>Portugueses com igualdade de direitos:</em> certificado de igualdade&nbsp;de direitos e obrigações civis.</li>"
																		. "</ul>"
																		. "<br>"
																		. "<br>"
																		. "<p><em><strong>DOCUMENTOS OPCIONAIS</strong></em></p>"
																		. "<ul>"
																			. "<li>CPF</li>"
																			. "<li>PIS/PASEP</li>"
																			. "<li>1 FOTO 3X4</li>"
																		. "</ul>"
																		. "<p>&nbsp;</p>"
																		. "<p><u><strong>DOCUMENTOS NECESSÁRIOS PARA 2ª VIA </strong></u><strong><br>"
																		. "</strong><br>"
																		. "O requerente deverá apresentar original e cópia ou cópia autenticada dos documentos:<br>"
																		. "&nbsp;</p>"
																		. "<p><strong><em>DOCUMENTOS OBRIGATÓRIOS</em></strong></p>"
																		. "<ul>"
																			. "<li><em>Solteiros: </em>certidão de nascimento.</li>"
																			. "<li><em>Casados: </em>certidão de casamento.</li>"
																			. "<li><em>Estrangeiros naturalizados: </em>certificado de naturalização.</li>"
																			. "<li><em>Portugueses com igualdade de direitos</em>: certificado de igualdade de direitos e obrigações civis.</li>"
																			. "<li><strong>Duda pago, isenção ou registro de ocorrência&nbsp;(não é necessário cópia)</strong></li>"
																		. "</ul>"
																		. "<br>"
																		. "<br>"
																		. "<p><strong><em>DOCUMENTOS OPCIONAIS</em></strong></p>"
																		. "<ul>"
																		. "	<li>CPF</li>"
																		. "	<li>PIS/PASEP</li>"
																		. "	<li>1 FOTO 3X4&nbsp;</li>"
																		. "</ul>"
																		. "<p>&nbsp;</p>"
																		. "<p><u><strong>OBSERVAÇÕES IMPORTANTES:<br>"
																		. "<br>"
																		. "</strong></u></p>"



																	. "<p>"
																			
																		
																			. "<font style='color:red'><i>*MENORES DE 12 ANOS SOMENTE COM A PRESENÇA DE PAI, MÃE OU RESPONSÁVEL LEGAL MUNIDO DE IDENTIDADE ORIGINAL E CÓPIA </i></font>"
																	
																	. "</p>"
																	. "</body>"
																			."</html>";	
																	
																	
																	}		
				
				
												if($tipoget=="V"){				
												$mensagemHTML="<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>"
														. "<html xmlns='http://www.w3.org/1999/xhtml'>" 
														. "<head>"
														. "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" 
														. "<body>"
												."<div>"
												. "<h3>Atendimento Agendado - Candidatar-se a Vagas de Emprego</h3>"
														."<p> Parabens ".$nome.", seu agendamento para o dia ".$data2." as ".$horario." </p>"
													. "<h4>O agendamento para vagas de emprego deve respeitar os seguintes requisitos:</h4>"
													. "<br>"

													. "<b> Apresentação de documentação original e válida:</b><br>"
													. "&nbsp;&nbsp;&nbsp;-&nbsp; Carteira de trabalho;<br>"
													. "&nbsp;&nbsp;&nbsp;-&nbsp;Carteira de identidade;<br>"
													. "&nbsp;&nbsp;&nbsp;-&nbsp;CPF;<br>"
													. "&nbsp;&nbsp;&nbsp;-&nbsp;Comprovante de Escolaridade, Diplomas e Certificados (caso possua)"

													. "<font style='color:red;'><h4>A secretaria não garante que no momento do seu atendimento a vaga de interesse esteja disponível.</h4></font>"
												. "</div>	"
												. "</body>"
												."</html>";					
												}
													
													
													
													
													
													
													

													/* Montando o cabeçalho da mensagem */
													$headers = "MIME-Version: 1.1".$quebra_linha;
													$headers .= "Content-type: text/html; charset=utf-8".$quebra_linha;
													// Perceba que a linha acima contém "text/html", sem essa linha, a mensagem não chegará formatada.
													$headers .= "From: ".$emailsender.$quebra_linha;
													$headers .= "Return-Path: " . $emailsender . $quebra_linha;
													// Esses dois "if's" abaixo são porque o Postfix obriga que se um cabeçalho for especificado, deverá haver um valor.
													// Se não houver um valor, o item não deverá ser especificado.
													if(strlen($comcopia) > 0) $headers .= "Cc: ".$comcopia.$quebra_linha;
													if(strlen($comcopiaoculta) > 0) $headers .= "Bcc: ".$comcopiaoculta.$quebra_linha;
													$headers .= "Reply-To: ".$emailremetente.$quebra_linha;
													// Note que o e-mail do remetente será usado no campo Reply-To (Responder Para)

													/* Enviando a mensagem */
													mail($emaildestinatario, $assunto, $mensagemHTML, $headers, "-r". $emailsender);
												
												/////////////////////////////////enviaemail///////////////////////////////////////////////
												
												$obj->msg = "1";	
													
												} else {

													$obj->msg = "2";	
													
												}
								
							}
						}
				
				$arr[] = $obj;

				echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';				
				break;
				
			case cancelaagendamento:
			header('Access-Control-Allow-Origin: *');
			
			$id= $_GET['id'];
			$query="update  agendamentoctps set status='C' where id='$id' ";
			$rs= mysql_query($query);
			
				if ($rs) {

						echo"2";

					} else {
							
						echo"1";
									
					}
			break;
				
				case meusagendamento:
				
					$cpf = $_GET['cpf'];
					$arr = array();
					
					$rs = mysql_query("SELECT * from agendamentoctps where cpf='$cpf' ORDER BY `id` desc");
					$totaldata  = mysql_num_rows($rs);			
				
				
				if($totaldata > 0){
					while($obj = mysql_fetch_object($rs)) {
					$databanco= $obj->data;
					$databr = date('d/m/Y', strtotime($obj->data));
					$tipo=  $obj->tipo;
					$status=  $obj->status;
					
							switch ($tipo) {
						case "C" :
							$tipoatendimento = "Atendimento CTPS";
							break;
						case "D":
							$tipoatendimento =  "Atendimento IDENTIDADE";
							break;
						case "V":
							$tipoatendimento =  "Atendimento Vagas ";
							break;
							case "P":
							$tipoatendimento =  "Pendência";
							break;
							
							 default:
							$tipoatendimento =  "Todos Atendimento";
							break;
						}
						
						
						switch ($status) {
				case "N" :
					$icone = "<font style='color:#DA0DD0;'><b>Não Compareçeu</b></font>";
					break;
				case "A":
					$icone =  "<font style='color:#2B0CF5;'><b>Aguardando Atendimento</b></font>";
					break;
					
				case "A1":
					$icone =  "<font style='color:#0CF51C;'><b>1º via</b></font> ";
					break;
					
					case "T":
					$icone =  "<font style='color:#0CF51C;'><b>2º via</b></font>";
					break;
					
					case "A2":
					$icone =  "<font style='color:#0CF51C;'><b>2º via</b></font>";
					break;
					
					
					case "C":
					$icone =  "<font style='color:red;'><b>Cancelado</b></font>";
					break;
					case "AT":
					$icone =  "<font style='color:#0CF51C;'><b>Atendido";
					break;
					
					case "D":
					$icone =  " <font style='color:#0CF51C;'><b>Atendimento IDENTIDADE</b></font>";
					break;
					
					case "P":
					$icone =  "<font style='color:red;'><b>Não atendido Pendência </b></font>";
					break;
			}
						
						$obj->statusatendimento = "$icone";						
						$obj->tipoagendamento = "$tipoatendimento";						
						$obj->data = "$databanco";						
						$obj->databr = "$databr";						
						
						$arr[] = $obj;
					}
				}
					if($totaldata==0){$obj->databr = "0";$arr[] = $obj;}
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				break;
				
				
				
				case meusdados:
				
					$cpf = $_GET['cpf'];
					$arr = array();
					
					$rs = mysql_query("SELECT * from trabalhador where cpf='$cpf' ");
					$totaldata  = mysql_num_rows($rs);			
				
				
				if($totaldata > 0){
					while($obj = mysql_fetch_object($rs)) {
					$databanco= $obj->data;
					$cidadeid= $obj->cidadeid;
					$databr = date('d/m/Y', strtotime($obj->data));
					$datanascimento = date('d/m/Y', strtotime($obj->datanascimento));
					$obj->datanascimentoconvertida = "$datanascimento";
					
								$query_cidade = "SELECT * FROM  `cidade` WHERE  id='$cidadeid'";
								$rs_noticias_cidade    = mysql_query($query_cidade);
								while($campo_noticias_cidade = mysql_fetch_array($rs_noticias_cidade)){			
								$idcidade  = $campo_noticias_cidade['id'];
								$ufid  = $campo_noticias_cidade['ufid'];
								$cidade  = $campo_noticias_cidade['nome'];
								
								}
								
								$query_uf = "SELECT * FROM  `uf` WHERE  id='$ufid'";
								$rs_noticias_uf    = mysql_query($query_uf);
								while($campo_noticias_uf = mysql_fetch_array($rs_noticias_uf)){			
								$uf  = $campo_noticias_uf['uf'];
								$iduf  = $campo_noticias_uf['id'];
								
								
								}

							$obj->nomecidade = "$cidade";		
							$obj->idcidade = "$idcidade";		
							$obj->estado = "$uf";		
							$obj->idestado = "$iduf";		
									
						
						$arr[] = $obj;
					}
				}
					if($totaldata==0){$obj->databr = "0";$arr[] = $obj;}
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				break;
				
				
				
				case verificasetemcadastro:
				
					$cpf = $_GET['cpf'];
					$arr = array();
					
					$rs = mysql_query("SELECT * from trabalhador where cpf='$cpf' ");
					$total  = mysql_num_rows($rs);	
					
					if($total > 0){
						
						$rs_use = mysql_query("SELECT * from usuario where usuario='$cpf' ");
						$totaluse = mysql_num_rows($rs_use);
						
							if($totaluse > 0){
								
								$obj->databr = "2";	
								
							}else{
								
								$obj->databr = "1";	
							}
												
						
					}else{
						
						$obj->databr = "0";	
					}
					
					
					$arr[] = $obj;
					
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				break;
				
				
				
				case varificadados:
				
					$cpf = $_GET['cpf'];
					$arr = array();
					
					$rs = mysql_query("SELECT * from trabalhador where cpf='$cpf' ");
					$totaldata  = mysql_num_rows($rs);			
				
				
				if($totaldata > 0){
					while($obj = mysql_fetch_object($rs)) {
					$databanco= $obj->data;
					$databr = date('d/m/Y', strtotime($obj->data));
					
						
												
						
						$arr[] = $obj;
					}
				}
					if($totaldata==0){$obj->databr = "0";$arr[] = $obj;}
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				break;
				
				
				
				
				case buscacidade:
				
					$estado = $_GET['estado'];
					$arr = array();
					
					$rs = mysql_query("SELECT * from cidade where ufid='$estado' ");
					$totaldata  = mysql_num_rows($rs);	
					while($obj = mysql_fetch_object($rs)) {
						$arr[] = $obj;
					}
				
				
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				break;
				
				
				///////////////////////////////////////////////////////////historico//////////////////////////////////////////////////////////////
				case salvarprofissional:
				header('Access-Control-Allow-Origin: *');
					$id = $_GET['id'];
					if($id==""){echo"0";}
					
						$cboid_query = $_GET['cboid'];		
						$empresa = $_GET['empresa'];			
						$cargo = $_GET['cargo'];			
						$carteiraassinada = $_GET['carteiraassinada'];
						$ativo = $_GET['ativo'];			
						$datainicio_1 	=$_GET['datainicio'];
						$datafinal_1 	=$_GET['datafinal'];				
						$tempanos	 = $_GET['tempanos'];
						$tempomes = $_GET['tempomes'];
						$idhistorioco = $_GET['idhistorioco'];
						
							
						$query_cboid = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid_query%'";	
						$rs_cboid    = mysql_query($query_cboid); 													
						while($campo_cboid= mysql_fetch_array($rs_cboid)){		 
						$cboid= $campo_cboid['id'];
						}	
						
						$datainicio = implode("-",array_reverse(explode("/","$datainicio_1")));
						$datafinal = implode("-",array_reverse(explode("/","$datafinal_1")));							
				
						
					
				
				
						if($idhistorioco > 0){
							
							
							$query ="update  `historico` set  cboid='$cboid' , empresa='$empresa' , cargo='$cargo' , carteiraassinada='$carteiraassinada' , ativo='$ativo' , datainicio='$datainicio' , datafinal='$datafinal' , tempanos='$tempanos' , tempomes='$tempomes' where id='$idhistorioco' ";
							$rs2 = mysql_query($query);
							
							
							
						}else{
					
							$query2 ="INSERT INTO historico ( `trabalhadorid`, `cboid`, `empresa`, `cargo`, `carteiraassinada`, `ativo`, `datainicio`, `datafinal`, `tempanos`, `tempomes`) VALUES
							( '$id', '$cboid', '$empresa', '$cargo', '$carteiraassinada', '$ativo', '$datainicio', '$datafinal ', '$tempanos', '$tempomes');";
							$rs2 = mysql_query($query2);
						
						}
						
						
						
						$delete="DELETE from historico WHERE empresa=''";
						$deleters= mysql_query($delete);
												
							
					if($rs2){echo"1";}else{echo"0";}
					//echo '{"members":'.json_encode($arr).'}';
					
							
				break;
				
				case historicoprofissional:
				
					$id = $_GET['id'];
					$arr = array();
					
					$rs = mysql_query("SELECT * from historico where trabalhadorid='$id' ");
					$totaldata  = mysql_num_rows($rs);			
				
				
				if($totaldata > 0){
					while($obj = mysql_fetch_object($rs)) {
					$databanco= $obj->data;
				
						$datainicio = date('d/m/Y', strtotime($obj->datainicio));
						$datafinal = date('d/m/Y', strtotime($obj->datafinal));
						$obj->datainiciobr = $datainicio ;
						$obj->datafinalbr = $datafinal ;
											
						
						$arr[] = $obj;
					}
				}
					if($totaldata==0){$obj->databr = "0";$arr[] = $obj;}
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				break;
				
				case excluihistorio:
					header('Access-Control-Allow-Origin: *');

					$id =$_GET['id']; 
						
					$delete="DELETE from historico WHERE id='$id'";
					$rsdelete= mysql_query($delete);
					
					if($rsdelete){echo"1";}else{ echo "0";}
					
				
				break;
				
				case consultahistorio:
					header('Access-Control-Allow-Origin: *');

					$id =$_GET['id']; 
						
						
						$arr = array();
					
					$rs = mysql_query("SELECT * from historico where id='$id' ");
					$totaldata  = mysql_num_rows($rs);	
					while($obj = mysql_fetch_object($rs)) {
						$datainicio = date('d/m/Y', strtotime($obj->datainicio));
						$datafinal = date('d/m/Y', strtotime($obj->datafinal));
						$obj->datainiciobr = $datainicio ;
						$obj->datafinalbr = $datafinal ;
						
						$arr[] = $obj;
					}
				
				
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
					
					
				
				break;
				
				
				///////////////////////////////////////////////////////////historico//////////////////////////////////////////////////////////////
				
				
				
				
				
				///////////////////////////////////////////////////////////escolaridade//////////////////////////////////////////////////////////////
				case salvaescolaridade:
				header('Access-Control-Allow-Origin: *');
					$id = $_GET['id'];
					if($id==""){echo"0";}
					
						$escolaridadep 	= $_GET['escolaridade']; 		
						$situacaop	= $_GET['situacao']; 
						$seriep 	= $_GET['serie']; 
						$turnop 	= $_GET['turno']; 			
						$formacaoacademicaidp 	= $_GET['formacaoacademicaid']; 
						$outrocursop 	= $_GET['outrocurso']; 
						$instituicaop 	= $_GET['instituicao']; 
						$comprovacaop 	= $_GET['comprovacao']; 
						$idescolaridaadeselect = $_GET['idescolaridaadeselect'];
						
							
						
				
				
						if($idescolaridaadeselect > 0){
							
							$query2 =" update escolaridade set escolaridade='$escolaridadep',situacao='$situacaop',	serie='$seriep',turno='$turnop',formacaoacademicaid='$formacaoacademicaidp',outrocurso='$outrocursop',instituicao='$instituicaop',comprovacao='$comprovacaop'	where id='$idescolaridaadeselect' ";
							$rs2 = mysql_query($query2);
							
						}else{
					
							$query2="INSERT INTO escolaridade (`trabalhadorid` , `escolaridade`, `situacao`, `serie`, `turno`, `formacaoacademicaid`, `outrocurso`, `instituicao`, `comprovacao`)VALUES
							( '$id','$escolaridade','$situacao','$serie','$turno','$formacaoacademicaid','$outrocurso','$instituicao','$comprovacao')";	
							$rs2= mysql_query($query2);
				
								$deletecescolaridade="DELETE from escolaridade WHERE escolaridade=''";
								$deleterscescolaridade= mysql_query($deletecescolaridade);
						
						}
						
						
						
					
												
							
					if($rs2){echo"1";}else{echo"0";}
					//echo '{"members":'.json_encode($arr).'}';
					
							
				break;
				
				case listaescolaridade:
				
					$id = $_GET['id'];
					$arr = array();
					
					$rs = mysql_query("SELECT * from escolaridade where trabalhadorid='$id' ");
					$totaldata  = mysql_num_rows($rs);			
				
				
				if($totaldata > 0){
					while($obj = mysql_fetch_object($rs)) {
					/*$databanco= $obj->data;
				
						$datainicio = date('d/m/Y', strtotime($obj->datainicio));
						$datafinal = date('d/m/Y', strtotime($obj->datafinal));
						$obj->datainiciobr = $datainicio ;
						$obj->datafinalbr = $datafinal ;*/
						
							switch ($obj->escolaridade){										
								case "N":											
								$escolaridade_N = "Analfabeto";
								break;
								case "A":											
								$escolaridade_N = "Alfabetizado";
								break;
								case "F":											
								$escolaridade_N = "Fundamental";
								break;
								case "M":											
								$escolaridade_N = "Médio";
								break;
								case "P":											
								$escolaridade_N = "Pós-Médio";
								break;
								case "S":											
								$escolaridade_N = "Superior";
								break;
								case "G":											
								$escolaridade_N = "Pós-Graduação";
								break;
								case "E":											
								$escolaridade_N = "Mestrado";
								break;
								case "D":											
								$escolaridade_N = "Doutorado";
								break;
							}
							
							$obj->escolaridadenome = $escolaridade_N ;
							
							switch ($obj->situacao){										
								case "C":											
								$situacao_N = "Completo";
								break;case "I":											
								$situacao_N = "Incompleto";
								break;case "U":											
								$situacao_N = "Cursando";
								break;
							}
							$obj->situacaonome = $situacao_N ;
							
							switch ($obj->serie){		
								case"1":$serie_N="1º ANO";break;
								case"2":$serie_N="2º ANO";break;
								case"3":$serie_N="3º ANO";break;
								case"4":$serie_N="4º ANO";break;
								case"5":$serie_N="5º ANO";break;
								case"6":$serie_N="6º ANO";break;
								case"7":$serie_N="7º ANO";break;
								case"8":$serie_N="8º ANO";break;
								case"9":$serie_N="9º ANO";break;
								case"C1":$serie_N="CICLO I - ALFA";break;
								case"C2":$serie_N="CICLO II - 1ª E 2ª";break;
								case"C3":$serie_N="CICLO III - 3ª E 4ª";break;
								case"C4":$serie_N="CICLO IV - 5ª E 6ª";break;
								case"C5":$serie_N="CICLO V - 7ª E 8ª";break;
								case"F":$serie_N="ED. ESP. ENS. FUND.";break;
								case"I":$serie_N="ED. ESP. ENS. INF.";break;
								case"J1":$serie_N="EJA - ENS.MED - 1ª ANO";break;
								case"J2":$serie_N="EJA - ENS.MED - 2º ANO";break;
								case"J3":$serie_N="EJA - ENS.MED - 3º ANO";break;
								case"M1":$serie_N="ENS.MED - 1º ANO";break;
								case"M2":$serie_N="ENS.MED - 2º ANO";break;
								case"M3":$serie_N="ENS.MED - 3º ANO";break;
								case"A1":$serie_N="MATERNAL I";break;
								case"A2":$serie_N="MATERNAL II";break;
								case"P1":$serie_N="PRÉ I";break;
								case"P2":$serie_N="PRÉ II";break;
						 
						 }
						 
						 $obj->serienome = $serie_N ;
						 
						 switch ($obj->turno){										
							case "M":											
							$turno_N = "Manhã";
							break;case "T":											
							$turno_N = "Tarde";
							break;case "N":											
							$turno_N = "Noite";
							break;
						}
						
						
						 $obj->turnonome = $turno_N ;
						
						$formacaoidacademinabanco = $obj->formacaoacademicaid;
						$query_formacaoacademica_db = "SELECT * FROM `formacaoacademica` WHERE id='$formacaoidacademinabanco'";
						$rs_formacaoacademica_db    = mysql_query($query_formacaoacademica_db);
						while($campo_formacaoacademica_db = mysql_fetch_array($rs_formacaoacademica_db)){
						$nome_formacaoacademica_db 	= $campo_formacaoacademica_db['nome']; 	
						$id_formacaoacademica_db 	= $campo_formacaoacademica_db['id']; 	
						}
						$obj->nome_formacaoacademica_db = $nome_formacaoacademica_db ;
						$obj->id_formacaoacademica_db = $id_formacaoacademica_db ;
					
					
						switch ($obj->comprovacao){										
						case "N":											
						$comprovacao_N = "Não";
						break;case "S":											
						$comprovacao_N = "Sim";
						break;
						}
						$obj->comprovacaonome = $comprovacao_N ;
											
						
						$arr[] = $obj;
					}
				}
					if($totaldata==0){$obj->databr = "0";$arr[] = $obj;}
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				break;
				
				
				
				
				
				
				case excluiescolaridade:
					header('Access-Control-Allow-Origin: *');

					$id =$_GET['id']; 
						
					$query ="DELETE FROM  `escolaridade` where id='$id' ";
					$rs = mysql_query($query);
					
					if($rs){echo"1";}else{ echo "0";}
					
				
				break;
				
				case consultaescolaridade:
					header('Access-Control-Allow-Origin: *');

					$id =$_GET['id']; 
						
						
						$arr = array();
					
					$rs = mysql_query("SELECT * from escolaridade where id='$id' ");
					$totaldata  = mysql_num_rows($rs);	
					while($obj = mysql_fetch_object($rs)) {
						
						
						
						
							switch ($obj->escolaridade){										
								case "N":											
								$escolaridade_N = "Analfabeto";
								break;
								case "A":											
								$escolaridade_N = "Alfabetizado";
								break;
								case "F":											
								$escolaridade_N = "Fundamental";
								break;
								case "M":											
								$escolaridade_N = "Médio";
								break;
								case "P":											
								$escolaridade_N = "Pós-Médio";
								break;
								case "S":											
								$escolaridade_N = "Superior";
								break;
								case "G":											
								$escolaridade_N = "Pós-Graduação";
								break;
								case "E":											
								$escolaridade_N = "Mestrado";
								break;
								case "D":											
								$escolaridade_N = "Doutorado";
								break;
							}
							
							$obj->escolaridadenome = $escolaridade_N ;
							
							switch ($obj->situacao){										
								case "C":											
								$situacao_N = "Completo";
								break;case "I":											
								$situacao_N = "Incompleto";
								break;case "U":											
								$situacao_N = "Cursando";
								break;
							}
							$obj->situacaonome = $situacao_N ;
							
							switch ($obj->serie){		
								case"1":$serie_N="1º ANO";break;
								case"2":$serie_N="2º ANO";break;
								case"3":$serie_N="3º ANO";break;
								case"4":$serie_N="4º ANO";break;
								case"5":$serie_N="5º ANO";break;
								case"6":$serie_N="6º ANO";break;
								case"7":$serie_N="7º ANO";break;
								case"8":$serie_N="8º ANO";break;
								case"9":$serie_N="9º ANO";break;
								case"C1":$serie_N="CICLO I - ALFA";break;
								case"C2":$serie_N="CICLO II - 1ª E 2ª";break;
								case"C3":$serie_N="CICLO III - 3ª E 4ª";break;
								case"C4":$serie_N="CICLO IV - 5ª E 6ª";break;
								case"C5":$serie_N="CICLO V - 7ª E 8ª";break;
								case"F":$serie_N="ED. ESP. ENS. FUND.";break;
								case"I":$serie_N="ED. ESP. ENS. INF.";break;
								case"J1":$serie_N="EJA - ENS.MED - 1ª ANO";break;
								case"J2":$serie_N="EJA - ENS.MED - 2º ANO";break;
								case"J3":$serie_N="EJA - ENS.MED - 3º ANO";break;
								case"M1":$serie_N="ENS.MED - 1º ANO";break;
								case"M2":$serie_N="ENS.MED - 2º ANO";break;
								case"M3":$serie_N="ENS.MED - 3º ANO";break;
								case"A1":$serie_N="MATERNAL I";break;
								case"A2":$serie_N="MATERNAL II";break;
								case"P1":$serie_N="PRÉ I";break;
								case"P2":$serie_N="PRÉ II";break;
						 
						 }
						 
						 $obj->serienome = $serie_N ;
						 
						 switch ($obj->turno){										
							case "M":											
							$turno_N = "Manhã";
							break;case "T":											
							$turno_N = "Tarde";
							break;case "N":											
							$turno_N = "Noite";
							break;
						}
						
						
						 $obj->turnonome = $turno_N ;
						
						$formacaoidacademinabanco = $obj->formacaoacademicaid;
						$query_formacaoacademica_db = "SELECT * FROM `formacaoacademica` WHERE id='$formacaoidacademinabanco'";
						$rs_formacaoacademica_db    = mysql_query($query_formacaoacademica_db);
						while($campo_formacaoacademica_db = mysql_fetch_array($rs_formacaoacademica_db)){
						$nome_formacaoacademica_db 	= $campo_formacaoacademica_db['nome']; 	
						$id_formacaoacademica_db 	= $campo_formacaoacademica_db['id']; 	
						}
						$obj->nome_formacaoacademica_db = $nome_formacaoacademica_db ;
						$obj->id_formacaoacademica_db = $id_formacaoacademica_db ;
					
					
						switch ($obj->comprovacao){										
						case "N":											
						$comprovacao_N = "Não";
						break;case "S":											
						$comprovacao_N = "Sim";
						break;
						}
						$obj->comprovacaonome = $comprovacao_N ;
											
						
						
						$arr[] = $obj;
					}
				
				
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
					
					
				
				break;
				
				
				///////////////////////////////////////////////////////////escolaridade//////////////////////////////////////////////////////////////
				
				
				
				
				
				
				///////////////////////////////////////////////////////////CURSOS//////////////////////////////////////////////////////////////
				case salvacurso:
				header('Access-Control-Allow-Origin: *');
					$id = $_GET['id'];
					if($id==""){echo"0";}
					
						$idcursoselect = $_GET['idcursoselect'];		
						$situacaocurso = $_GET['situacaocurso'];		
						$segmentoatuacaoid = $_GET['segmentoatuacaoid'];		
						$curso = $_GET['curso'];		
						$comprovacaocurso = $_GET['comprovacaocurso'];
				
				
						if($idcursoselect > 0){
							
							
							$query2 =" update  cursopalestra set situacao='$situacaocurso', segmentoatuacaoid='$segmentoatuacaoid', curso='$curso', comprovacao='$comprovacaocurso'  where id='$idcursoselect' ";
							$rs2 = mysql_query($query2);
							
						}else{

						$query2="INSERT INTO cursopalestra (`trabalhadorid` ,`situacao` ,`segmentoatuacaoid` ,`curso` ,`comprovacao`)VALUES
						( '$id', '$situacaocurso', '$segmentoatuacaoid', '$curso', '$comprovacaocurso')";	
						$rs2= mysql_query($query2);

						$deletec="DELETE from cursopalestra WHERE segmentoatuacaoid=''";
						$deletersc= mysql_query($deletec);
						
						}
						
						
												
							
					if($rs2){echo"1";}else{echo"0";}
					//echo '{"members":'.json_encode($arr).'}';
					
							
				break;
				
				case listacurso:
				
					$id = $_GET['id'];
					$arr = array();
					
					$rs = mysql_query("SELECT * from cursopalestra where trabalhadorid='$id' ");
					$totaldata  = mysql_num_rows($rs);			
				
				
				if($totaldata > 0){
					while($obj = mysql_fetch_object($rs)) {
					//$databanco= $obj->data;
					
						switch ($obj->situacao){										
						case "C":											
						$situacaocursog_N = "Completo";
						break;case "U":											
						$situacaocursog_N = "Cursando";
						break;case "I":											
						$situacaocursog_N = "Incompleto";
						break;
						}
						
						$obj->nomesituacao="$situacaocursog_N";
						$segmentoatuacaoid =$obj->segmentoatuacaoid;	
						$query_noticias_hcsa3 = "SELECT * FROM `segmentoatuacao` where id='$segmentoatuacaoid'";
						$rs_noticias_hcsa3    = mysql_query($query_noticias_hcsa3);
						while($campo_noticias_hcsa3 = mysql_fetch_array($rs_noticias_hcsa3)){
						$nomeseguimento3 	= $campo_noticias_hcsa3['nome']; 	
						}
						
						$obj->nomeseguimento="$nomeseguimento3";
						
						switch ($obj->comprovacao){										
						case "N":											
						$comprovacaocursog_N = "Não";
						break;case "S":											
						$comprovacaocursog_N = "Sim";
						break;
						}
						$obj->nomecomprovacao="$comprovacaocursog_N";					
						
						$arr[] = $obj;
					}
				}
					if($totaldata==0){$obj->databr = "0";$arr[] = $obj;}
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				break;
				
				case excluicurso:
					header('Access-Control-Allow-Origin: *');

					$id =$_GET['id']; 
						
					$delete="DELETE from cursopalestra WHERE id='$id'";
					$rsdelete= mysql_query($delete);
					
					if($rsdelete){echo"1";}else{ echo "0";}
					
				
				break;
				
				case consultacurso:
					header('Access-Control-Allow-Origin: *');

					$id =$_GET['id']; 
						
						
						$arr = array();
					
					$rs = mysql_query("SELECT * from cursopalestra where id='$id' ");
					$totaldata  = mysql_num_rows($rs);	
					while($obj = mysql_fetch_object($rs)) {
						
						$arr[] = $obj;
					}
				
				
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
					
					
				
				break;
				
				
				///////////////////////////////////////////////////////////CURSOS//////////////////////////////////////////////////////////////
				
				
				
				case cadastrotrabalhador:
				
					header('Access-Control-Allow-Origin: *');
					
					
					$idtrabalhadoracesso = $_GET['id'];
					$id 	=(string)addslashes($_POST['id']); 
					$idtrabalhador 	=(string)addslashes($_POST['idtrabalhador']); 					
					$cpf 	=(string)addslashes($_POST['cpf']); 					
					$nome 	=(string)addslashes($_POST['nome']); 
					$senha 	=(string)addslashes($_POST['senha']);	 		 			 	
					$mae 	=(string)addslashes($_POST['mae']);	 		 			 	
					$pai 	=(string)addslashes($_POST['pai']);	 		 			 	
					$datanascimento_1 	=(string)addslashes($_POST['datanascimento']); 
					$datanascimento = implode("-",array_reverse(explode("/",$datanascimento_1)));
					//$data = implode("/",array_reverse(explode("-",$data)));	 		 			 	
					$naturalidade 	=(string)addslashes($_POST['naturalidade']); 	 		 			 	
					$sexo 	=(string)addslashes($_POST['sexo']); 	 		 			 	
					$estadocivil 	=(string)addslashes($_POST['estadocivil']); 
					$intencao 	=(string)addslashes($_POST['intencao']); 
					$cep 	=(string)addslashes($_POST['cep']); 	 		 			 	
					$vagadeficiente 	=(string)addslashes($_POST['vagadeficiente']); 
					$endereco 	=(string)addslashes($_POST['endereco']); 	 		 			 	
					$telres 	=(string)addslashes($_POST['telres']); 	 		 			 	
					$telcel 	=(string)addslashes($_POST['telcel']); 	 		 			 	
					$telrec 	=(string)addslashes($_POST['telrec']); 	 		 			 	
					$nmrecado 	=(string)addslashes($_POST['nmrecado']); 	 		 			 	
					$email 	=(string)addslashes($_POST['email']);	 		 			 	
					$identidade 	=(string)addslashes($_POST['identidade']); 	 		 			 	
					$orgaoexpedidor 	=(string)addslashes($_POST['orgaoexpedidor']); 	 		 			 	
					$txttitulo 	=(string)addslashes($_POST['txttitulo']); 	 		 			 	
					$txtzona 	=(string)addslashes($_POST['txtzona']); 	 		 			 	
					$txtsecao 	=(string)addslashes($_POST['txtsecao']); 	 		 			 	
					$tipocnh 	=(string)addslashes($_POST['tipocnh']); 
					$seriect 	=(string)addslashes($_POST['seriect']);
					$orgaoreg 	=(string)addslashes($_POST['orgaoreg']); 	 		 			 	
					$pispasep 	=(string)addslashes($_POST['pispasep']); 	 		 			 	
					$passaporte 	=(string)addslashes($_POST['passaporte']);
					$programasocialid 	=(string)addslashes($_POST['programasocialid']); 	 		 			 	
					$cboprocesso 	=(string)addslashes($_POST['cboprocesso']); 	 		 			 	
					$cbosoube_caet 	=(string)addslashes($_POST['cbosoube_caet']); 	 		 			 	
					$selcidacaptado 	=(string)addslashes($_POST['selcidacaptado']); 	 		 			 	
					$selcidaatraves 	=(string)addslashes($_POST['selcidaatraves']); 	 		 			 	
					$selLocalDocs 	=(string)addslashes($_POST['selLocalDocs']);
					$codigocid =(string)addslashes($_POST['codigocid']); 


					$necEspAuditiva=(string)addslashes($_POST['necEspAuditiva']); 
					if(empty($necEspAuditiva)){$necEspAuditiva='N';};

					$necEspAuditivaTipo=(string)addslashes($_POST['necEspAuditivaTipo']);
					$necEspAuditivaUniBi=(string)addslashes($_POST['necEspAuditivaUniBi']);
					$necEspFala=(string)addslashes($_POST['necEspFala']);
					if(empty($necEspFala)){$necEspFala='N';};

					$necEspFalaTipo=(string)addslashes($_POST['necEspFalaTipo']);
					$necEspFisica=(string)addslashes($_POST['necEspFisica']);
					if(empty($necEspFisica)){$necEspFisica='N';};

					$necEspFisicaTipo=(string)addslashes($_POST['necEspFisicaTipo']);
					$necEspFisicaInfSup=(string)addslashes($_POST['necEspFisicaInfSup']);
					$necEspMental=(string)addslashes($_POST['necEspMental']);
					if(empty($necEspMental)){$necEspMental='N';};

					$necEspRecursosCom=(string)addslashes($_POST['necEspRecursosCom']);
					if(empty($necEspRecursosCom)){$necEspRecursosCom='N';};
					$necEspCuidadoPess=(string)addslashes($_POST['necEspCuidadoPess']);
					if(empty($necEspCuidadoPess)){$necEspCuidadoPess='N';};
					$necEspLazer=(string)addslashes($_POST['necEspLazer']);
					if(empty($necEspLazer)){$necEspLazer='N';};
					$necEspSaudeSeg=(string)addslashes($_POST['necEspSaudeSeg']);
					if(empty($necEspSaudeSeg)){$necEspSaudeSeg='N';};
					$necEspHabSocial=(string)addslashes($_POST['necEspHabSocial']);
					if(empty($necEspHabSocial)){$necEspHabSocial='N';};
					$necEspHabAcad=(string)addslashes($_POST['necEspHabAcad']);
					if(empty($necEspHabAcad)){$necEspHabAcad='N';};
					$necEspComunic=(string)addslashes($_POST['necEspComunic']);
					if(empty($necEspComunic)){$necEspComunic='N';};
					$necEspTrabalho=(string)addslashes($_POST['necEspTrabalho']);
					if(empty($necEspTrabalho)){$necEspTrabalho='N';};
					$necEspVisual=(string)addslashes($_POST['necEspVisual']);
					if(empty($necEspVisual)){$necEspVisual='N';};
					$necEspVisualTipo=(string)addslashes($_POST['necEspVisualTipo']);
					$necEspVisualUniBi=(string)addslashes($_POST['necEspVisualUniBi']);


					//$cboid1_query =  $_POST['cboid1'];
					$cboid1_query =  "A defenir pela SEMTRE";
					if($cboid1_query==""){$cboid1='';}else{

					$query_cboid1 = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid1_query%'";	
					$rs_cboid1    = mysql_query($query_cboid1); 													
					while($campo_cboid1 = mysql_fetch_array($rs_cboid1)){		 
					$cboid1t= $campo_cboid1['id']; }	

					if($cboid1t==""){


					$querycbo1 = "INSERT INTO `cbo` (`cbo`) VALUES ('$cboid1_query');";
					$rscbo1= mysql_query($querycbo1);

					$query_cboid3221 = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid1_query%'";	
					$rs_cboid3221    = mysql_query($query_cboid3221); 													
					while($campo_cboid3221= mysql_fetch_array($rs_cboid3221)){		 
					$cboid1= $campo_cboid3221['id']; }	


					}else{

					$cboid1 =$cboid1t;

					}


					}


					//$cboid2_query =  $_POST['cboid2'];
					$cboid2_query =  "A defenir pela SEMTRE";
					if($cboid2_query==""){$cboid2='';}else{
					$query_cboid2 = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid2_query%'";	
					$rs_cboid2    = mysql_query($query_cboid2); 													
					while($campo_cboid2= mysql_fetch_array($rs_cboid2)){		 
					$cboid2t= $campo_cboid2['id']; }	


					if($cboid2t==""){


					$querycbo2 = "INSERT INTO `cbo` (`cbo`) VALUES ('$cboid2_query');";
					$rscbo2= mysql_query($querycbo2);

					$query_cboid322 = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid2_query%'";	
					$rs_cboid322    = mysql_query($query_cboid322); 													
					while($campo_cboid322= mysql_fetch_array($rs_cboid322)){		 
					$cboid2= $campo_cboid322['id']; }	


					}else{

					$cboid2 =$cboid2t;
					}
					}


					//$cboid3_query =  $_POST['cboid3'];
					$cboid3_query =   "A defenir pela SEMTRE";
					if($cboid3_query==""){$cboid3='';}else{

					$query_cboid3 = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid3_query%'";	
					$rs_cboid3    = mysql_query($query_cboid3); 													
					while($campo_cboid3= mysql_fetch_array($rs_cboid3)){		 
					$cboid3t= $campo_cboid3['id']; }	

					if($cboid3t==""){


					$querycbo3 = "INSERT INTO `cbo` (`cbo`) VALUES ('$cboid3_query');";
					$rscbo3= mysql_query($querycbo3);

					$query_cboid32 = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid3_query%'";	
					$rs_cboid32    = mysql_query($query_cboid32); 													
					while($campo_cboid32= mysql_fetch_array($rs_cboid32)){		 
					$cboid3= $campo_cboid32['id']; }	


					}else{

					$cboid3 =$cboid3t;
					}
					}


					$pretensaosalarial_1 =  $_POST['pretensaosalarial'];
					$pretensaosalarial1 = str_replace(".","",$pretensaosalarial_1);
					$pretensaosalarial = str_replace(",",".",$pretensaosalarial1);
					//$pretensaosalarial =  number_format($pretensaosalarial12, 2, ',', '.'); 

					$ultimosalario_1 =  $_POST['ultimosalario'];
					$ultimosalario1 = str_replace(".","","$ultimosalario_1");
					$ultimosalario = str_replace(",",".","$ultimosalario1");
					//$ultimosalario =  number_format($ultimosalario12, 2, ',', '.'); 


					$softwareid1=(string)addslashes($_POST['softwareid1']);
					if(empty($softwareid1)){$softwareid1='18';};
					$softwareid2=(string)addslashes($_POST['softwareid2']);
					if(empty($softwareid2)){$softwareid2='18';};
					$softwareid3=(string)addslashes($_POST['softwareid3']);
					if(empty($softwareid3)){$softwareid3='18';};


					$idiomaid1=(string)addslashes($_POST['idiomaid1']);
					if(empty($idiomaid1)){$idiomaid1='21';};
					$idiomaid2=(string)addslashes($_POST['idiomaid2']);
					if(empty($idiomaid2)){$idiomaid2='21';};
					$idiomaid3=(string)addslashes($_POST['idiomaid3']);
					if(empty($idiomaid3)){$idiomaid3='21';};


					$leitura1 	=(string)addslashes($_POST['leitura1']); 
					$leitura2 	=(string)addslashes($_POST['leitura2']); 
					$leitura3	=(string)addslashes($_POST['leitura3']); 
					$conversacao1	=(string)addslashes($_POST['conversacao1']); 
					$conversacao2	=(string)addslashes($_POST['conversacao2']); 
					$conversacao3	=(string)addslashes($_POST['conversacao3']); 
					$escrita1	=(string)addslashes($_POST['escrita1']); 
					$escrita2	=(string)addslashes($_POST['escrita2']); 
					$escrita3	=(string)addslashes($_POST['escrita3']); 	
					$carteiratrabalho	=(string)addslashes($_POST['carteiratrabalho']); 	

					$dia= date("d");
					$mes= date("m");
					$ano= date("Y");
					$hora = date("H:i:s");
					$ano_fixo= date("Y-m-d");  		
					$data_fixa ="$ano_fixo $hora";

					$cidadeid 	=(string)addslashes($_POST['cidadeid']); 	 		 			 	
					$bairro 	=(string)addslashes($_POST['bairro']);
					$txtestado 	=(string)addslashes($_POST['txtestado']);

					$escolaridade 	=$_POST['escolaridade']; 
					$situacao 	=$_POST['situacao']; 
					$serie 	=$_POST['serie']; 
					$turno 	=$_POST['turno']; 				 
					$formacaoacademicaid 	=$_POST['formacaoacademicaid']; 
					$outrocurso 	=$_POST['outrocurso']; 
					$instituicao 	=$_POST['instituicao']; 
					$comprovacao 	=$_POST['comprovacao'];
					
					
					/////////////////////////////////////////infens
					
					if($idtrabalhadoracesso > 0){
						
								$query = "update  trabalhador set
								nome='$nome',
								cpf='$cpf',				
								mae='$mae',
								pai='$pai',
								datanascimento='$datanascimento',
								naturalidade='$naturalidade',
								sexo='$sexo',
								estadocivil='$estadocivil',
								vagadeficiente='$vagadeficiente',
								necEspAuditiva='$necEspAuditiva',
								necEspAuditivaTipo='$necEspAuditivaTipo',
								necEspAuditivaUniBi='$necEspAuditivaUniBi',
								necEspFala='$necEspFala',
								necEspFalaTipo='$necEspFalaTipo',
								necEspFisica='$necEspFisica',
								necEspFisicaTipo='$necEspFisicaTipo',
								necEspFisicaInfSup='$necEspFisicaInfSup',
								necEspMental='$necEspMental',
								necEspRecursosCom='$necEspRecursosCom',
								necEspCuidadoPess='$necEspCuidadoPess',
								necEspLazer='$necEspLazer',
								necEspSaudeSeg='$necEspSaudeSeg',
								necEspHabSocial='$necEspHabSocial',
								necEspHabAcad='$necEspHabAcad',
								necEspComunic='$necEspComunic',
								necEspTrabalho='$necEspTrabalho',
								necEspVisual='$necEspVisual',
								necEspVisualTipo='$necEspVisualTipo',
								necEspVisualUniBi='$necEspVisualUniBi',
								codigocid='$codigocid',
								intencao='$intencao',
								cep='$cep',
								cidadeid='$cidadeid',
								bairro='$bairro',
								endereco='$endereco',
								telres='$telres',
								telcel='$telcel',
								telrec='$telrec',
								nmrecado='$nmrecado',
								email='$email',
								identidade='$identidade',
								orgaoexpedidor='$orgaoexpedidor',
								tipocnh='$tipocnh',
								carteiratrabalho='$carteiratrabalho',
								seriect='$seriect',
								orgaoreg='$orgaoreg',
								pispasep='$pispasep',
								passaporte='$passaporte',
								programasocialid='$programasocialid',
								cboid1='$cboid1',
								cboid2='$cboid2',
								cboid3='$cboid3',
								pretensaosalarial='$pretensaosalarial',
								ultimosalario='$ultimosalario',				
								softwareid1='$softwareid1',
								softwareid2='$softwareid2',
								softwareid3='$softwareid3',
								idiomaid1='$idiomaid1',
								idiomaid2='$idiomaid2',
								idiomaid3='$idiomaid3',
								leitura1='$leitura1',
								leitura2='$leitura2',
								leitura3='$leitura3',
								escrita1='$escrita1',
								escrita2='$escrita2',
								escrita3='$escrita3',
								conversacao1='$conversacao1',
								conversacao2='$conversacao2',
								conversacao3='$conversacao3',
								usuarioID='3',dataupdate= NOW()

								where id ='$idtrabalhadoracesso'";
							$rs= mysql_query($query);
									
							if($rs){
								echo"4";
								
								exit;
							}else{
								
							echo"0";
							exit;	
							}
									
					
						
					}

					
					
					
					
					if($cpf==""){echo"0";exit;}
					$querycarificacadastro = mysql_query("SELECT * from trabalhador where cpf='$cpf' ");
					$totaldatacadastro  = mysql_num_rows($querycarificacadastro);			
					
					$querycarificausuario = mysql_query("SELECT * from usuario where usuario='$cpf' ");
					$totalquerycarificausuario  = mysql_num_rows($querycarificausuario);		
				
					if($totalquerycarificausuario > 0){
					
							if($totalquerycarificausuario > 0){
								echo"3";exit;
							}else{
								
								echo"2";exit;
							}			
					}
					
					/////////////////////////////////////////infens
				
			$query = "INSERT INTO `trabalhador` ( `nome`, `cpf`, `mae`, `pai`, `datanascimento`, `naturalidade`, `sexo`, `estadocivil`, `vagadeficiente`, `necEspAuditiva`, `necEspAuditivaTipo`, `necEspAuditivaUniBi`, `necEspFala`, `necEspFalaTipo`, `necEspFisica`, `necEspFisicaTipo`, `necEspFisicaInfSup`, `necEspMental`, `necEspRecursosCom`, `necEspCuidadoPess`, `necEspLazer`, `necEspSaudeSeg`, `necEspHabSocial`, `necEspHabAcad`, `necEspComunic`, `necEspTrabalho`, `necEspVisual`, `necEspVisualTipo`, `necEspVisualUniBi`, `codigocid`, `intencao`, `cep`, `cidadeid`, `bairro`, `endereco`, `telres`, `telcel`, `telrec`, `nmrecado`, `email`, `identidade`, `orgaoexpedidor`, `tipocnh`, `carteiratrabalho`, `seriect`, `orgaoreg`, `pispasep`, `passaporte`, `programasocialid`, `cboid1`, `cboid2`, `cboid3`, `pretensaosalarial`, `ultimosalario`,`softwareid1`, `softwareid2`, `softwareid3`, `idiomaid1`, `idiomaid2`, `idiomaid3`, `leitura1`, `leitura2`, `leitura3`, `escrita1`, `escrita2`, `escrita3`, `conversacao1`, `conversacao2`, `conversacao3`, `usuarioid`) VALUES 
			( '$nome','$cpf','$mae','$pai','$datanascimento','$naturalidade','$sexo','$estadocivil','$vagadeficiente','$necEspAuditiva','$necEspAuditivaTipo','$necEspAuditivaUniBi','$necEspFala','$necEspFalaTipo','$necEspFisica','$necEspFisicaTipo','$necEspFisicaInfSup','$necEspMental','$necEspRecursosCom','$necEspCuidadoPess','$necEspLazer','$necEspSaudeSeg','$necEspHabSocial','$necEspHabAcad','$necEspComunic','$necEspTrabalho','$necEspVisual','$necEspVisualTipo','$necEspVisualUniBi','$codigocid','$intencao','$cep','$cidadeid','$bairro','$endereco','$telres','$telcel','$telrec','$nmrecado','$email','$identidade','$orgaoexpedidor','$tipocnh','$carteiratrabalho','$seriect','$orgaoreg','$pispasep','$passaporte','$programasocialid','$cboid1','$cboid2','$cboid3','$pretensaosalarial','$ultimosalario','$softwareid1','$softwareid2','$softwareid3','$idiomaid1','$idiomaid2','$idiomaid3','$leitura1','$leitura2','$leitura3','$escrita1','$escrita2','$escrita3','$conversacao1','$conversacao2','$conversacao3','$usuarioid') 

			";
			$rs= mysql_query($query);	
			
			
			
			
			$query_trabalhado = "SELECT * FROM  `trabalhador` WHERE  cpf='$cpf'";	
			$rs_trabalhado    = mysql_query($query_trabalhado); 													
			while($campo_trabalhado= mysql_fetch_array($rs_trabalhado)){		 
			$trabalhadorid= $campo_trabalhado['id'];
			}	
					
			$cboid_query = $_POST['cboid'];		
			$empresa = $_POST['empresa'];			
			$cargo = $_POST['cargo'];			
			$carteiraassinada = $_POST['carteiraassinada'];
			$ativo = $_POST['ativo'];			
			$datainicio_1 	=$_POST['datainicio'];
			$datafinal_1 	=$_POST['datafinal'];				
			$tempanos	 = $_POST['tempanos'];
			$tempomes = $_POST['tempomes'];
			
				$i1=0;				
				$i2=0;				
				$i3=0;				
				$i4=0;				
				$i5=0;				
				$i6=0;				
				$i7=0;				
				$i8=0;				
				$i9=0;				
					
				while ($cboid_query[$i1] != NULL) {
					
				$i1++;				
				$i2++;				
				$i3++;				
				$i4++;				
				$i5++;				
				$i6++;				
				$i7++;				
				$i8++;				
				$i9++;
				
					$query_cboid = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid_query[$i1]%'";	
					$rs_cboid    = mysql_query($query_cboid); 													
					while($campo_cboid= mysql_fetch_array($rs_cboid)){		 
					$cboid= $campo_cboid['id'];
					}	
					
					$datainicio = implode("-",array_reverse(explode("/","$datainicio_1[$i6]")));
					$datafinal = implode("-",array_reverse(explode("/","$datafinal_1[$i7]")));							
			
				
					$query2 ="INSERT INTO historico ( `trabalhadorid`, `cboid`, `empresa`, `cargo`, `carteiraassinada`, `ativo`, `datainicio`, `datafinal`, `tempanos`, `tempomes`) VALUES
					( '$trabalhadorid', '$cboid', '$empresa[$i2]', '$cargo[$i3]', '$carteiraassinada[$i4]', '$ativo[$i5]', '$datainicio', '$datafinal ', '$tempanos[$i8]', '$tempomes[$i9]');";
					$rs2 = mysql_query($query2);
					
					$delete="DELETE from historico WHERE empresa=''";
					$deleters= mysql_query($delete);

				}
				
				
				
				
				/////////////ESCOLARIDADE				
				
				

				
				$escolaridadei1=0;				
				$escolaridadei2=0;				
				$escolaridadei3=0;				
				$escolaridadei4=0;				
				$escolaridadei5=0;				
				$escolaridadei6=0;				
				$escolaridadei7=0;				
				$escolaridadei8=0;				
				
				
				
				while ($escolaridade[$escolaridadei1] != NULL) {
				
				$escolaridadei1++;				
				$escolaridadei2++;				
				$escolaridadei3++;				
				$escolaridadei4++;				
				$escolaridadei5++;				
				$escolaridadei6++;				
				$escolaridadei7++;				
				$escolaridadei8++;				
				
				
				
				$query_curso_escolaridade="INSERT INTO escolaridade (`trabalhadorid` , `escolaridade`, `situacao`, `serie`, `turno`, `formacaoacademicaid`, `outrocurso`, `instituicao`, `comprovacao`)VALUES
				( '$trabalhadorid','$escolaridade[$escolaridadei1]','$situacao[$escolaridadei2]','$serie[$escolaridadei3]','$turno[$escolaridadei4]','$formacaoacademicaid[$escolaridadei5]','$outrocurso[$escolaridadei6]','$instituicao[$escolaridadei7]','$comprovacao[$escolaridadei8]')";	
				$rs2_query_curso_escolaridade= mysql_query($query_curso_escolaridade);
				
				$deletecescolaridade="DELETE from escolaridade WHERE escolaridade=''";
				$deleterscescolaridade= mysql_query($deletecescolaridade);
				
					
				
				}
				
				///////////////FIM ESCOLARIDADE
				$situacaocurso 	= $_POST['situacaocurso']; 
				$segmentoatuacaoid 	= $_POST['segmentoatuacaoid']; 
				$curso 	= $_POST['curso']; 
				$comprovacaocurso 	= $_POST['comprovacaocurso']; 
				
				$i1curso_palestras=0;				
				$i2curso_palestras=0;				
				$i3curso_palestras=0;				
				$i4curso_palestras=0;				
							
					
				while ($segmentoatuacaoid[$i1curso_palestras] != NULL) {
					
				$i1curso_palestras++;				
				$i2curso_palestras++;				
				$i3curso_palestras++;				
				$i4curso_palestras++;	

				$query_curso_palestras="INSERT INTO cursopalestra (`trabalhadorid` ,`situacao` ,`segmentoatuacaoid` ,`curso` ,`comprovacao`)VALUES
				( '$trabalhadorid', '$situacaocurso[$i1curso_palestras]', '$segmentoatuacaoid[$i2curso_palestras]', '$curso[$i3curso_palestras]', '$comprovacaocurso[$i4curso_palestras]')";	
				$rs2_query_curso_palestras= mysql_query($query_curso_palestras);
				
				$deletec="DELETE from cursopalestra WHERE segmentoatuacaoid=''";
				$deletersc= mysql_query($deletec);
				
				}
			
			
				
				if($rs){echo"1";}else{echo"$query";}

				break;
				
				
				case cadadosdeacesso:
				
				$usuario =  $_GET['usuario'];
				$senha =  $_GET['senha'];
				
				$arr = array();
				$rs = mysql_query("SELECT * from usuario where usuario='$usuario' ");
				$totaldata  = mysql_num_rows($rs);				
				while($obj = mysql_fetch_object($rs)) {
					
						$arr[] = $obj;
				}				
				
				
				if($totaldata > 0){
					
				}
				
				else{
					
					
					$query_trabalhado = "SELECT * FROM  `trabalhador` WHERE  cpf='$usuario'";	
					$rs_trabalhado    = mysql_query($query_trabalhado); 													
					while($campo_trabalhado= mysql_fetch_array($rs_trabalhado)){		 
					$trabalhadorid= $campo_trabalhado['id'];
					$nome= $campo_trabalhado['nome'];
					}	
						
					
					$queryusuario = "INSERT INTO `usuario` (`usuario`,`nome`,`senha`,`perfil`) VALUES ('$usuario','$nome','$senha','T');";
					$rsusuario= mysql_query($queryusuario);					
					
				}
				
				
					if($totaldata==0){$obj->id ="0";$arr[] = $obj;}
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				
				break;
				
				
				
				case login:
				
				$usuario =  $_GET['usuariocpf_login'];
				$senha =  $_GET['senha_login'];
				
				
				
				$rs = mysql_query("SELECT * from usuario where usuario='$usuario' and senha='$senha' ");
				$totaldata  = mysql_num_rows($rs);			
				$arr = array();
				
				if($totaldata > 0){
					while($obj = mysql_fetch_object($rs)) {
					
						$arr[] = $obj;
					}
				}
				
				
				
					if($totaldata==0){$obj->id = "0";$arr[] = $obj;}
					//echo '{"members":'.json_encode($arr).'}';
					echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				
				break;
				
				
				
				case lembrarsenha:
				
				
								$arr = array();
								$cpf_trabalhador_cadastro = $_GET['cpf'];													
								$query_noticias_hcpj = "SELECT usuario,senha,id  FROM `usuario` where usuario='$cpf_trabalhador_cadastro'";	
								$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
								while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
								$idusuario  = $campo_noticias_hcpj['id'];														
								$usuariouser  = $campo_noticias_hcpj['usuario'];								
								$senha  = $campo_noticias_hcpj['senha'];								
								}
								
								
								
								if($idusuario > 0){
									
									$query_noticias_dados = "SELECT telcel  FROM `trabalhador` where cpf='$cpf_trabalhador_cadastro'";	
									$rs_noticias_dados    = mysql_query($query_noticias_dados);
									while($campo_noticias_dados = mysql_fetch_array($rs_noticias_dados)){																		
									$telcelp 	= $campo_noticias_dados['telcel'];
									}
									
									$vowels = array("(", ")", ".", "-");
									$numerocelular = str_replace($vowels, "", $telcelp);									
									$resposta ="$numerocelular";
									
									
								}else{
									$resposta ="0";
									
								};
								
								$obj->resposta = "$resposta";
								$obj->login = "$usuariouser";
								$obj->senha = "$senha";
								$arr[] = $obj;
								
								echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				
				break;
				case listahorariossiponivel:
				
				
				header('Access-Control-Allow-Origin: *');
				
				$data = $_GET['data'];
				$tipo = $_GET['tipo'];
				switch ($tipo) {
								case "C":	
								///INICIO ATENDIMENTO c cARTEIRA
						$valorhorario=1;;
									
									
						$query_horario_disponivelc = "SELECT id FROM  `agendamentoctps`  where  data='$data' and tipo='C'  and `status`='A' ";
						$rs_noticias_horario_disponivelc    = mysql_query($query_horario_disponivelc);
						$total_horario_disponivelc = mysql_num_rows($rs_noticias_horario_disponivelc);
				
						if($total_horario_disponivelc >= 21){
							
								
						}else{					
				
									
														if($data=="2015-6-11"){
														$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:45' AND  `horario` <  '11:45' order by  horario ASC";
														}
														else
														{
														$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:45' AND  `horario` <  '15:30' order by  horario ASC";	
															
														}
														$rs_noticias_horario    = mysql_query($query_horario);
														while($campo_noticias_horario = mysql_fetch_array($rs_noticias_horario)){			
														$horario_banco  = $campo_noticias_horario['horario'];
														
															
															
																$query_horario_disponivel = "SELECT horario FROM  `agendamentoctps`  where horario='$horario_banco' and data='$data'  and tipo='C'  and `status` NOT LIKE  'C'";
																$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
																$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);	
																
															
																//echo $valorhorario;
																	if($total_horario_disponivel>=$valorhorario){ $horariosnao ="Atenção não há mais horário disponível para atendimento nesta data , favor escolha outra data!";}else{	
																		
																		
																			
																			if(($horario_banco=="11:45") or ($horario_banco=="12:00") or ($horario_banco=="12:15") or ($horario_banco=="12:30") or ($horario_banco=="12:45")){}else{
																			
																					?>
																						<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																					<?																
																					$numeroHdisponivel=1;
																				
																					}
																
																	}
															}
												
												
									}			
												
												if($numeroHdisponivel>="1"){}else{
													
													echo "<div style='float:left;margin:5px;'>Atenção não há mais horário disponível para atendimento nesta  data , favor escolha outra data!</DIV><h3 style='color:red;'>	
														Nas <b>Sextas-feiras a partir das 17:00 horas :</b> Disponibilidade  de  data para atendimento de<b> Segunda-feira á Quarta-feira</b><br>
														Nas <b>Quartas-feiras a partir das 17:00 horas : </b>Disponibilidade  de  data para atendimento de <b>Quinta-feira e Sexta-feira </b>
													</h3>";
												}
											///FIM ATENDIMENTO c
											
						


					break;					
						case "V":
						
								/// inicio demais atendimento 
								$query_horario = "SELECT horario FROM  `horarioatendimento`  where `horario` >  '08:15' AND  `horario` <  '16:30' order by horario ASC ";
								$rs_noticias_horario    = mysql_query($query_horario);
								while($campo_noticias_horario = mysql_fetch_array($rs_noticias_horario)){			
								$horario_banco  = $campo_noticias_horario['horario'];
								
										if(($horario_banco > "11:30")&&($horario_banco < "14:30")){$valorhorario=5;}else{$valorhorario=8;};
										$query_horario_disponivel = "SELECT horario FROM  `agendamentoctps`  where horario='$horario_banco' and data='$data' and tipo='V'  and `status` NOT LIKE  'C' ";
									
										$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
										$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);	
										
										
										//echo $valorhorario;
											if($total_horario_disponivel>=$valorhorario){$horariosnao ="Não há mais horário disponível para atendimento nesta  data , favor escolha outra data!";}else{	
												
												
																	$hoje=date('Y-n-j');
																	$agora=date('H:i');
																	
																
																if($hoje == $data ){
																	if($horario_banco > $agora ){
																		?>
																			<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																		<?																
																		$numeroHdisponivel=1;
																	}
																}else{
																		?>
																			<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																		<?																
																		$numeroHdisponivel=1;
																	
																}
																	
										
											}
									}
									if($numeroHdisponivel>="1"){}else{
													
													echo "<div style='float:left;margin:5px;'>Atenção não há mais horário disponível para atendimento nesta  data , favor escolha outra data!</DIV><h3 style='color:red;'>	
														Nas <b>Sextas-feiras a partir das 17:00 horas :</b> Disponibilidade  de  data para atendimento de<b> Segunda-feira há Quarta-feira</b><br>
														Nas <b>Quartas-feiras a partir das 17:00 horas : </b>Disponibilidade  de  data para atendimento de <b>Quinta-feira e Sexta-feira </b>
													</h3>";
												}
						break;						
						case "D":	////// fim demais atendimento	
						
						///INICIO ATENDIMENTO c cARTEIRA
						
											$valorhorario=2;;
									/// se for atendimento C Carteira	
											$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` >  '08:45' AND  `horario` <  '15:30' order by  horario ASC";
											$rs_noticias_horario    = mysql_query($query_horario);
											while($campo_noticias_horario = mysql_fetch_array($rs_noticias_horario)){			
											$horario_banco  = $campo_noticias_horario['horario'];
											
												
												
													$query_horario_disponivel = "SELECT horario FROM  `agendamentoctps`  where horario='$horario_banco' and data='$data'  and tipo='D'   and `status` NOT LIKE  'C'";
													$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
													$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);	
													
												
													//echo $valorhorario;
														if($total_horario_disponivel>=$valorhorario){ $horariosnao ="Atenção não há mais horário disponível para atendimento nesta data , favor escolha outra data!";}else{	
															
															
																
																if( ($horario_banco=="12:00") or ($horario_banco=="12:15") or ($horario_banco=="12:30") or ($horario_banco=="12:45") or ($horario_banco=="13:00")){}else{
																
																
																	$hoje=date('Y-n-j');
																	$agora=date('H:i');
																	
																
																if($hoje == $data ){
																	if($horario_banco > $agora ){
																		?>
																			<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																		<?																
																		$numeroHdisponivel=1;
																	}
																}else{
																		?>
																			<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
																		<?																
																		$numeroHdisponivel=1;
																	
																}
																	
																}
													
														}
												}
												
												
												
												
												if($numeroHdisponivel>="1"){}else{
													
													echo "<div style='float:left;margin:5px;'>Atenção não há mais horário disponível para atendimento nesta  data , favor escolha outra data!</DIV><h3 style='color:red;'>	
														Nas <b>Sextas-feiras a partir das 17:00 horas :</b> Disponibilidade  de  data para atendimento de<b> Segunda-feira há Quarta-feira</b><br>
														Nas <b>Quartas-feiras a partir das 17:00 horas : </b>Disponibilidade  de  data para atendimento de <b>Quinta-feira e Sexta-feira </b>
													</h3>";
												}
											///FIM ATENDIMENTO D
						break;
					
						}	
						
				
	
				break;
				
				case palestras:
						
						header('Access-Control-Allow-Origin: *');
						
							
							$palestra="";
							foreach($_POST['palestra'] as $selectedpalestra){
							$valorckeq = $selectedpalestra.",";
							$palestra.="$valorckeq";
							}
							
						
							
							
								
						if($palestra==""){
							echo"Escolha no minimo uma palestra ";exit;
						}
						
						
						$nome = (string)addslashes($_POST['nome']);
						if($nome==""){
							echo"Inform seu Nome";exit;
						}
				
						$email = (string)addslashes($_POST['email']);
						if(empty($email)){
							echo"Inform seu Email";exit;
						}
						
						$cargo = (string)addslashes($_POST['cargo']);
						
						if(empty($cargo)){
							echo"Inform seu cargo";exit;
						}
						
						$celular = (string)addslashes($_POST['celular']);
						
						if(empty($celular)){
							echo"Inform seu Celular";exit;
						}
						$empresa = (string)addslashes($_POST['empresa']);
						$telefone = (string)addslashes($_POST['telefone']);
						
						
				$query_horario_disponivel = "SELECT palestra FROM  where `palestra` LIKE '%$palestra%'  ";
				$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
				$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);
				
				if($total_horario_disponivel >= 20){
					echo"25";exit;
				}
													
						
						$queryusuario = "INSERT INTO `palestra` (`nome`,`email`,`cargo`,`celular`,`empresa`,`telefone`,`palestra`) VALUES ('$nome','$email','$cargo','$celular','$empresa','$telefone','$palestra');";
						$rsusuario= mysql_query($queryusuario);	
						if	($rsusuario){
							
							$vowels = array("(", ")", ".", "-");
							$numerocelular = str_replace($vowels,"", $celular);
							echo "55".$numerocelular;

							
						}else{
							echo "3";
							
						}				
 
				break;
			
		
		}
	
		
		?>		