﻿<?include"conexao.php";?>								
									<html>
<head>

	
	
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Qual ônibus</title>
<link rel="stylesheet" href="js/jquery.mobile-1.0a4.1.min.css" />
<link rel="stylesheet" href="js/stanford.css" />
<link href="js/mobile.css" rel="stylesheet" type="text/css" />
<script src="js/jquery-1.5.2.min.js"></script>
<script src="js/jquery.mobile-1.0a4.1.min.js"></script>
<!-- Google Analytics -->

<script type="text/javascript" src="js/prototype.js"></script>
	<script type="text/javascript" src="js/scriptaculous.js"></script>



	
	
</head>
<body class="home">

<div data-role="page" id="events" data-position="fixed">
<div data-role="header" >


	<a href="javascript:window.history.go(-1)" target="_self"data-icon="back" data-iconpos="left" data-direction="reverse" class="ui-btn-right">Anterior</a>
		<h1>Detalhes do Curso</h1>
		
		
	
	</div>
		
<div data-role="content">	

				<?
								$id_curso = $_GET['id_curso'];
								
								$query_noticias = "SELECT *  FROM  `curso`  WHERE  id_curso='$id_curso'";
								$rs_noticias    = mysql_query($query_noticias);
								while($campo_noticias = mysql_fetch_array($rs_noticias)){
								$matricula_i       = $campo_noticias['matricula_i'];					
								$carga_horaria       = $campo_noticias['carga_horaria'];					
								$curso      = $campo_noticias['curso'];					
								$objetivo      = $campo_noticias['objetivo'];					
								$matricula_i      = $campo_noticias['matricula_i'];					
								$id_curso      = $campo_noticias['id_curso'];					
								$proposta      = $campo_noticias['proposta'];					
								$alvo      = $campo_noticias['alvo'];					
								$area      = $campo_noticias['area'];					
								$img      = $campo_noticias['img'];					
								$manografia      = $campo_noticias['manografia'];					
								$metodologia     = $campo_noticias['metodologia'];					
								$duracao_i     = $campo_noticias['duracao_i'];					
								$online     = $campo_noticias['online'];					
								}
								?>
							<h4 id="Filterreveal"><?=$curso;?></h4> 
									
							<div id="demo-borders" style='margin:10px'>
							
							
							
							<div data-role="collapsible" data-collapsed="false">
							<h4>Detalhes</h4>
							
							Área: <?=$area;?></br>
							Carga Horária: <?=$carga_horaria;?></br>
							<?=$duracao_i;?></br>
							
							</div>


			
							<div data-role="collapsible" data-content-theme="c">
							<h3>Informações </h3>
										<div class="details"> 

										<p><?=$objetivo;?></p>

										<?if($proposta==''){}else{?>
										<H4>Proposta</h4>
										<p><?=$proposta;?></p>
										<?}?>

										<?if($alvo==''){}else{?>
										<H4>Alvo</h4>
										<p><?=$alvo;?></p>
										<?}?>

										<?if($metodologia==''){}else{?>
										<H4>Metodologia</h4>
										<p><?=$metodologia;?></p>
										<?}?>

										<?if($manografia==''){}else{?>
										<H4>Monografia</h4>
										<p><?=$manografia;?></p>
										<?}?>


										</div>
							</div><!-- /collapsible -->
							
							
							
							<div data-role="collapsible" data-content-theme="c">
							<h3> Disciplinas</h3>
								<?
								$query_noticiasd = "SELECT *  FROM  `ementas`  WHERE  id_curso='$id_curso'";
								$rs_noticiasd    = mysql_query($query_noticiasd);
								while($campo_noticiasd = mysql_fetch_array($rs_noticiasd)){
								$id_disciplina_d      = $campo_noticiasd['id_disciplina'];	
								$ementa      = $campo_noticiasd['ementa'];	
								?>
								<?
								$query_noticiasdm = "SELECT *  FROM  `materia`  WHERE  id_materia='$id_disciplina_d'";
								$rs_noticiasdm    = mysql_query($query_noticiasdm);
								while($campo_noticiasdm = mysql_fetch_array($rs_noticiasdm)){
								$materia      = $campo_noticiasdm['materia'];	

								?>
								<p><h4 ><?=$materia;?></h4></p>
								<div><?=$ementa;?></div>

								<?}?>			
								<?}?>		
							</div><!-- /collapsible -->
							
							
							
							<div data-role="collapsible" data-collapsed="false">
							<h4>Inscrição</h4>
							

								<div style='font-size:16px;margin:10px;'>
								

								<div style='font-size:11px;margin-top:10px;'>

								

									<div style='font-size:16px;margin:10px;'>
									<?
									$tira_Rs = str_replace('R$','',$matricula_i);
									$crecimo = $tira_Rs + 230; ?>
								
									<?
								$query_noticiasdp = "SELECT *  FROM  `pagamento` ";
								$rs_noticiasdp    = mysql_query($query_noticiasdp);
								while($campo_noticiasdp = mysql_fetch_array($rs_noticiasdp)){
								$textop      = $campo_noticiasdp['texto'];	
									
									if($online==""){
								?>
										<p><b><font style='font-size:12px;color:#658DA9;'><?=$textop ;?></font></b></p>
								<?}else{			
								
								?>
								
								<p><b><font style='font-size:12px;color:#658DA9;'>Valor para o curso de Qualificação : R$300.00</font></b></p>
								
								<?}
								
								}?>	
									

									</div>
						

								</div>

						</div>
							
							
							
							</div>
							
							
							</div>
							
			
			
			

</div>
</div>
</body>