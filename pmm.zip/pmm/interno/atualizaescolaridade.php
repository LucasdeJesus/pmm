		<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);


			$query_noticiasj = "SELECT * FROM `trabalhador`";			
			$rs_noticiasj    = mysql_query($query_noticiasj);				
			while($campo_noticiasj = mysql_fetch_array($rs_noticiasj)){		
			$escolaridade 	=$campo_noticiasj['escolaridade']; 
			$situacao 	=$campo_noticiasj['situacao']; 
			$serie 	=$campo_noticiasj['serie']; 
			$turno 	=$campo_noticiasj['turno']; 				 
			$formacaoacademicaid 	=$campo_noticiasj['formacaoacademicaid']; 
			$outrocurso 	=$campo_noticiasj['outrocurso']; 
			$instituicao 	=$campo_noticiasj['instituicao']; 
			$comprovacao 	=$campo_noticiasj['comprovacao'];
			$id 	=$campo_noticiasj['id'];
			
				if($escolaridade==""){}else{
				$query_curso_escolaridade="INSERT INTO escolaridade (`trabalhadorid` , `escolaridade`, `situacao`, `serie`, `turno`, `formacaoacademicaid`, `outrocurso`, `instituicao`, `comprovacao`)VALUES
					( '$id','$escolaridade','$situacao','$serie','$turno','$formacaoacademicaid','$outrocurso','$instituicao','$comprovacao')";	
					$rs2_query_curso_escolaridade= mysql_query($query_curso_escolaridade);
			
				}
			}
		?>		