﻿<?include'conexao.php';


$query_noticiasat = "DELETE FROM `test`.`faltas` WHERE faltas = '0'; ";
						$rs_noticiasat    = mysql_query($query_noticiasat);

?>