<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);


	$tipo_busca = $_GET['tipo_busca'];
	$uf = $_GET['uf'];
	$id_bairro = $_GET['cidade'];
	
switch ($tipo_busca) {
	
	case cidade:
		$query_noticiasdcemede = "SELECT * FROM `cidade` where ufid='$uf' ORDER BY  `cidade`.`nome` ASC ";
		$rs_noticiasdcemede    = mysql_query($query_noticiasdcemede);
		while($campo_noticiasdcemede = mysql_fetch_array($rs_noticiasdcemede)){																												
		$cidade = $campo_noticiasdcemede['nome'];
		$cidade_id = $campo_noticiasdcemede['id'];
		
		echo"<option value='$cidade_id'>$cidade</option>";
		}
	break;	
	
	case bairro:
		$query_noticiasdcemedeb = "SELECT * FROM `trabalhador` WHERE `cidadeid` = '$id_bairro' GROUP BY `bairro`";
		$rs_noticiasdcemedeb    = mysql_query($query_noticiasdcemedeb);
		while($campo_noticiasdcemedeb = mysql_fetch_array($rs_noticiasdcemedeb)){																												
		$bairro = $campo_noticiasdcemedeb['bairro'];		
		//echo"$query_noticiasdcemedeb";
		echo"<option value='$bairro '>$bairro </option>";
		}
	break;
	
}?>