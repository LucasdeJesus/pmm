<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>


<div id="bg-container" class='contener'>

 <script type="text/javascript">
            $().ready(function() {
                $("#ocupacao").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });				

            });
        </script>
     
			

	       <script>
            function pop_pesquisaempresa(page) {
				var input = document.getElementById("ocupacao").value;
				var  page='windobuscaempresacbo.php?nomecbo='+input;
                window.open(page, 'popRelReciboEntregue', 'width=750,height=450,scrollbars');
                }

        </script>		
	
<form  class="form" style='width:100%;'action=''method="GET" id='ajax_form' name='ajax_form'>
		<h2>Buscar Trabalhado</h2>
			<div class="form-row">
			<div class="label">Ocupação</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="ocupacao" required id="ocupacao"   tabindex="1"  style="width:204px;" type="text" class="input req-same">
			 Limite :<input  name="limite" required id="limite"   tabindex="1"  style="width:204px;" type="text" class="input req-same">
			<a class="sendBtn" onclick="pop_pesquisaempresa('windobuscaempresacbo.php')" >...</a>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Buscar" type="submit" class="sendBtn" />
			</div>
			</div>			
</form>			


<form  class="form" style='width:100%;'method="post" >

			<?$ocupacao = $_GET['ocupacao'];?>
			<?$limite = $_GET['limite'];?>
				<h4><?=$ocupacao;?>
				Limit mostrar <?=$limite ;?></h4>
			<table width='97%'>
	
				<tr>
				<td class='td1' >N°</td>
				<td class='td1' >Nome</td>
				<td class='td1' >CPF</td>
				<td class='td1' >Tel.</td>
				<td class='td1' >Cel.</td>
				<td class='td1' >Email</td>
				</tr>
				
				<?
				
				
				if($ocupacao==""){}else{
				$numero=1;
				$celulares="";
					$query_noticias2 = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$ocupacao%'";	
					$rs_noticias2    = mysql_query($query_noticias2); 													
					while($campo_noticias2 = mysql_fetch_array($rs_noticias2)){		 
					$cboid= $campo_noticias2['id']; 

					

		
				//$query_noticias = "SELECT * FROM `trabalhador` WHERE txtocupacao1 LIKE '%$ocupacao%' ";	
				
				$query_noticias = "SELECT * FROM `trabalhador` WHERE cboid1 ='$cboid' OR cboid2 ='$cboid' OR cboid3 ='$cboid'  limit $limite";	
				$rs_noticias    = mysql_query($query_noticias); 
				$total = mysql_num_rows($rs_noticias);			
				while($campo_noticias = mysql_fetch_array($rs_noticias)){
				$nome= $campo_noticias['nome']; 	 
				$cpf= $campo_noticias['cpf']; 	 
				$txttelres= $campo_noticias['telres']; 	 
				$txttelcel= $campo_noticias['telcel']; 	 
				$txtemail= $campo_noticias['email']; 	 
				
				
				$vowels = array("(", ")", ".", "-");
				$numerocelular = str_replace($vowels, "", $txttelcel);
				$celulares.=",55".$numerocelular;
				?>

			<tr class='tr_tb' >		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$nome ;?> </td>					
				<td class='td2' >  <?=$cpf;?></td>
				<td class='td2' >  <?=$txttelres;?></td>
				<td class='td2' >  <?=$txttelcel;?></td>
				<td class='td2' >  <?=$txtemail;?></td>
						
						
				<td class='td2' >
				<?$endereco = $_SERVER ['REQUEST_URI'];;?>

				<a href="javascript:Abrir_Pagina('conteudo.php?cpf_busca=<?=$cpf;?>','scrollbars=yes,width=800,height=500')" title='Saiba mais'><img src='img/busca.png'/></a> 
				
									
			</tr>
		<?}}}?>	
		
		
			
		
		
	</table>
	
	<textarea style="width:300px;height:300px"><?=$celulares;?></textarea>
	
			<?
			if($ocupacao=="")
			{}else{
				if($total=="")
				
				{echo"<h3>Nenhum Trabalhador foi encontrado.</h3>";}else{}
			}
			?>

</form>
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
