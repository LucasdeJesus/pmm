<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>

	<?include'topo.php';?>
	<?
	$getform= $_GET['getform'];
	?>
	<script>
	function select_item<?=$getform;?>(item<?=$getform;?>)
	{
	targetitem<?=$getform;?>.value = item<?=$getform;?>;
	top.close();
	return false;
	}
	</script>
	
	

			<?php

			// Configuração do script
			// ========================
			$_BS['PorPagina'] = 80; // Número de registros por página


			// Verifica se foi feita alguma busca
			// Caso contrario, redireciona o visitante
			//if (!isset($_GET['consulta'])) {
			if (!isset($_GET['consulta'])) {
			//header("Location: http://www.meusite.com.br/");
			exit;
			}
			// Se houve busca, continue o script:

			// Salva o que foi buscado em uma variável
			$busca = $_GET['consulta'];
			// Usa a função mysql_real_escape_string() para evitar erros no MySQL
			$busca = mysql_real_escape_string($busca);

			// ============================================

			// Monta a consulta MySQL para saber quantos registros serão encontrados
			$sql = "SELECT COUNT(*) AS total FROM `cbo` WHERE  ((`cbo` LIKE '%".$busca."%') OR ('%".$busca."%'))";
			// Executa a consulta
			$query = mysql_query($sql);
			// Salva o valor da coluna 'total', do primeiro registro encontrado pela consulta
			$total = mysql_result($query, 0, 'total');
			// Calcula o máximo de paginas
			$paginas =  (($total % $_BS['PorPagina']) > 0) ? (int)($total / $_BS['PorPagina']) + 1 : ($total / $_BS['PorPagina']);

			// ============================================

			// Sistema simples de paginação, verifica se há algum argumento 'pagina' na URL
			if (isset($_GET['pagina'])) {
			$pagina = (int)$_GET['pagina'];
			} else {
			$pagina = 1;
			}
			$pagina = max(min($paginas, $pagina), 1);
			$inicio = ($pagina - 1) * $_BS['PorPagina'];

			// ============================================

			// Monta outra consulta MySQL, agora a que fará a busca com paginação
			$sql = "select DISTINCT cbo from cbo  WHERE ((`cbo` LIKE '%".$busca."%') OR ('%".$busca."%')) ORDER BY `cbo` ASC LIMIT ".$inicio.", ".$_BS['PorPagina'];
			// Executa a consulta
			$query = mysql_query($sql);

			// ============================================

			// Começa a exibição dos resultados
			echo "<p>Resultados ".min($total, ($inicio + 1))." - ".min($total, ($inicio + $_BS['PorPagina']))." de ".$total." resultados encontrados para '".$_GET['consulta']."'</p>";
			// <p>Resultados 1 - 20 de 138 resultados encontrados para 'minha busca'</p>

			echo"<table width='100%'>";
			while ($resultado = mysql_fetch_assoc($query)) {
			$cbo = $resultado['cbo'];
			$texto = $resultado['texto'];

			?>
			<tr class='tr_tb' onClick="return select_item<?=$getform;?>('<?=$cbo;?>')" ><td class='td2' ><?=$cbo;?></td></tr>
			<?
			}
			echo"</table>";

			// ============================================

			// Começa a exibição dos paginadores
			if ($total > 0) {
			for($n = 1; $n <= $paginas; $n++) {
			//echo '<a href="?getform='.$getform.'&consulta='.$_GET['consulta'].'&pagina='.$n.'">'.$n.'</a>&nbsp;&nbsp;';
			}
			}

			?>

