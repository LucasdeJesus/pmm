<frameset frameborder="0" framespacing="0" rows="*">
<!--<frame scrolling="No" framespacing="0" marginheight="0" marginwidth="0" noresize="" frameborder="0" name="FrmMenu" src="aba_cadastro.php">-->
<frame framespacing="0" marginheight="0" marginwidth="5" frameborder="0" name="FrmDados" id='FrmDados'src="conteudo.php">
</frameset>