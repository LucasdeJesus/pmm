<?
	include"input_banco.php";
	
	$trabalhadorid = $_GET['id'];
	$query_noticias = "SELECT * FROM `trabalhador` WHERE id='$trabalhadorid'";
	$rs_noticias    = mysql_query($query_noticias);																							
	while($campo_noticias = mysql_fetch_array($rs_noticias)){
	$id= $campo_noticias['id']; 											
	$nome= $campo_noticias['nome']; 
	$email= $campo_noticias['email']; 
		$cpf 	= $campo_noticias['cpf']; 	 		 			 	
		$nome 	= $campo_noticias['nome']; 
		$mae 	= $campo_noticias['mae'];	 		 			 	
		$pai 	= $campo_noticias['pai'];	 		 			 	
		$datanascimento 	= $campo_noticias['datanascimento']; 	 		 			 	
		$naturalidade 	= $campo_noticias['naturalidade']; 	 		 			 	
		$sexo 	= $campo_noticias['sexo']; 	 		 			 	
		$estadocivil 	= $campo_noticias['estadocivil']; 												 		 			 	
		$txtfilhosestudantes 	= $campo_noticias['txtfilhosestudantes']; 	 		 			 	
		$txttrabalhando 	= $campo_noticias['txttrabalhando']; 	 		 			 	
		$txtmeres 	= $campo_noticias['txtmeres']; 	 		 			 	
		$txtmenores 	= $campo_noticias['txtmenores']; 	 		 			 	
		$txtmenores 	= $campo_noticias['txtmenores']; 					 	 		 			 	
		$cbolaudo 	= $campo_noticias['cbolaudo']; 	 		 			 	
		$txtlimitacoes 	= $campo_noticias['txtlimitacoes']; 	 		 			 	
		$intencao 	= $campo_noticias['intencao']; 	 		 			 	
		$cboTemporario 	= $campo_noticias['cboTemporario']; 	 		 			 	
		$cboservida 	= $campo_noticias['cboservida']; 	 		 			 	
		$cboNoturno 	= $campo_noticias['cboNoturno']; 	 		 			 	
		$cbotur 	= $campo_noticias['cbotur']; 	 		 			 	
		$cbofeira 	= $campo_noticias['cbofeira']; 	 		 			 	
		$cep 	= $campo_noticias['cep']; 	 		 			 	
		$txtestado 	= $campo_noticias['txtestado']; 	 		 			 	
		$cidadeid 	= $campo_noticias['cidadeid']; 	 		 			 	
		$bairro 	= $campo_noticias['bairro']; 	 		 			 	
		$endereco 	= $campo_noticias['endereco']; 	 		 			 	
		$telres 	= $campo_noticias['telres']; 	 		 			 	
		$telcel 	= $campo_noticias['telcel']; 	 		 			 	
		$telrec 	= $campo_noticias['telrec']; 	 		 			 	
		$nmrecado 	= $campo_noticias['nmrecado']; 	 		 			 	
		$email 	= $campo_noticias['email'];	 		 			 	
		$identidade 	= $campo_noticias['identidade']; 	 		 			 	
		$orgaoexpedidor 	= $campo_noticias['orgaoexpedidor']; 	 		 			 	
		$txttitulo 	= $campo_noticias['txttitulo']; 	 		 			 	
		$txtzona 	= $campo_noticias['txtzona']; 	 		 			 	
		$txtsecao 	= $campo_noticias['txtsecao']; 	 		 			 	
		$tipocnh 	= $campo_noticias['tipocnh']; 	 		 			 	
		$carteiratrabalho 	= $campo_noticias['carteiratrabalho']; 	 		 			 	
		$seriect 	= $campo_noticias['seriect']; 	 		 			 	
		$txtregistroprof 	= $campo_noticias['txtregistroprof']; 	 		 			 	
		$orgaoreg 	= $campo_noticias['orgaoreg']; 	 		 			 	
		$pispasep 	= $campo_noticias['pispasep']; 	 		 			 	
		$passaporte 	= $campo_noticias['passaporte']; 	 		 			 	
		$txtmoracom 	= $campo_noticias['txtmoracom']; 	 		 			 	
		$txtmorapais 	= $campo_noticias['txtmorapais']; 	 		 			 	
		$txtmoracompanheiro 	= $campo_noticias['txtmoracompanheiro']; 	 		 			 	
		$txtmoraoutros 	= $campo_noticias['txtmoraoutros']; 	 		 			 	
		$txtmorafilhos 	= $campo_noticias['txtmorafilhos']; 	 		 			 	
		$txtmorafilhos1 	= $campo_noticias['txtmorafilhos1']; 	 		 			 	
		$txtmorafilhos2 	= $campo_noticias['txtmorafilhos2']; 	 		 			 	
		$txtmorafilhos3 	= $campo_noticias['txtmorafilhos3']; 	 		 			 	
		$txtmorairmaos 	= $campo_noticias['txtmorairmaos']; 	 		 			 	
		$txtmorairmaos1 	= $campo_noticias['txtmorairmaos1']; 	 		 			 	
		$txtmorairmaos2 	= $campo_noticias['txtmorairmaos2']; 	 		 			 	
		$txtmorairmaos22 	= $campo_noticias['txtmorairmaos22']; 	 		 			 	
		$txtmorairmaos3 	= $campo_noticias['txtmorairmaos3']; 	 		 			 	
		$txtrendafamiliar 	= $campo_noticias['txtrendafamiliar']; 	 		 			 	
		$selchefefamilia 	= $campo_noticias['selchefefamilia']; 	 		 			 	
		$programasocialid 	= $campo_noticias['programasocialid']; 	 		 			 	
		$cboprocesso 	= $campo_noticias['cboprocesso']; 	 		 			 	
		$cbosoube_caet 	= $campo_noticias['cbosoube_caet']; 	 		 			 	
		$selcidacaptado 	= $campo_noticias['selcidacaptado']; 	 		 			 	
		$selcidaatraves 	= $campo_noticias['selcidaatraves']; 	 		 			 	
		$selLocalDocs 	= $campo_noticias['selLocalDocs']; 	 		 			 	
		$txthistorico	= $campo_noticias['txthistorico'];

		$txthabilidades1 = $campo_noticias['txthabilidades1'];
		$txthabilidades2 = $campo_noticias['txthabilidades2'];
		$txthabilidades3 = $campo_noticias['txthabilidades3'];
		$cboid1 =  $campo_noticias['cboid1'];
		$cboid2 =  $campo_noticias['cboid2'];
		$cboid3 =  $campo_noticias['cboid3'];
		$pretensaosalarial =  $campo_noticias['pretensaosalarial'];
		$ultimosalario =  $campo_noticias['ultimosalario'];
		 
		$senha 	= $campo_noticias['senha']; 
		
		$outrocurso 	= $campo_noticias['outrocurso']; 
		$instituicao 	= $campo_noticias['instituicao']; 
		$comprovacao 	= $campo_noticias['comprovacao']; 
		$softwareid1 	= $campo_noticias['softwareid1']; 
		$softwareid2 	= $campo_noticias['softwareid2']; 
		$softwareid3 	= $campo_noticias['softwareid3']; 
		$idiomaid1 	= $campo_noticias['idiomaid1']; 
		$idiomaid2 	= $campo_noticias['idiomaid2']; 
		$vagadeficiente 	= $campo_noticias['vagadeficiente']; 
		$idiomaid3 	= $campo_noticias['idiomaid3']; 
		$leitura1 	= $campo_noticias['leitura1']; 
		$leitura2 	= $campo_noticias['leitura2']; 
		$leitura3	= $campo_noticias['leitura3']; 
		$conversacao1	= $campo_noticias['conversacao1']; 
		$conversacao2	= $campo_noticias['conversacao2']; 
		$conversacao3	= $campo_noticias['conversacao3']; 
		$escrita1	= $campo_noticias['escrita1']; 
		$escrita2	= $campo_noticias['escrita2']; 
		$escrita3	= $campo_noticias['escrita3']; 
		
		$cadastrado_por	= $campo_noticias['usuarioid']; 
		$datacadastro	= $campo_noticias['datacadastro']; 
	}	
	
	
	
		$query_idiomaid1 = "SELECT * FROM `idioma` where id='$idiomaid1'";
		$rs_idiomaid1    = mysql_query($query_idiomaid1);
		while($campo_idiomaid1 = mysql_fetch_array($rs_idiomaid1)){																						
		$nome_idiomaid1 	= $campo_idiomaid1['nome']; 	
		}
		$query_idiomaid2 = "SELECT * FROM `idioma`where id='$idiomaid2'";
		$rs_idiomaid2    = mysql_query($query_idiomaid2);
		while($campo_idiomaid2d = mysql_fetch_array($rs_idiomaid2)){																						
		$nome_idiomaid2 	= $campo_idiomaid2d['nome']; 	
		}
		$query_idiomaid3 = "SELECT * FROM `idioma`where id='$idiomaid3'";
		$rs_idiomaid3    = mysql_query($query_idiomaid3);
		while($campo_idiomaid3 = mysql_fetch_array($rs_idiomaid3)){																						
		$nome_idiomaid3 	= $campo_idiomaid3['nome']; 	
		}
																					
?>

			
			
			<?	
			$query_noticias_cidadecp = "SELECT * FROM `cidade` where id='$cidadeid' ";
			$rs_noticias_cidadecp    = mysql_query($query_noticias_cidadecp);
			while($campo_noticias_cidadecp = mysql_fetch_array($rs_noticias_cidadecp)){
			$nome_cidade        = $campo_noticias_cidadecp['nome'];	
			$id_cidade        = $campo_noticias_cidadecp['id'];	
			}	
			?>
			
			
			<?	
			$query_estado_db = "SELECT * FROM `cidade` where id='$cidadeid' ";
			$rs_estado_db     = mysql_query($query_estado_db );
			while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
			$ufid        = $campo_estado_db ['ufid'];

			$query_estado_dbuf = "SELECT * FROM `uf` where id='$ufid' ";
			$rs_estado_dbuf     = mysql_query($query_estado_dbuf );
			while($campo_estado_dbuf  = mysql_fetch_array($rs_estado_dbuf )){
			$uf_nome        = $campo_estado_dbuf ['uf'];
			$id_uf_db        = $campo_estado_dbuf ['id'];
			}

			}	
			?>
			
			
			<?
			switch ($estadocivil){										
			case "S":											
			$estadocivil_N = "Solteiro";
			break;case "C":											
			$estadocivil_N = "Casado";
			break;case "U":											
			$estadocivil_N = "União Estável";
			break;case "E":											
			$estadocivil_N = "Desquitado";
			break;case "D":											
			$estadocivil_N = "Divorciado";
			break;case "V":											
			$estadocivil_N = "Viúvo";
			break;case "O":											
			$estadocivil_N = "Outro";
			break;


			}
			?>
		
		<div style='font-family: "Trebuchet MS", Helvetica, sans-serif;font-size:12px;'>
			<p style='font-size:25px; color:#ccc;'><?=$nome;?></p>
			<?$datainicio1 = implode('/',array_reverse(explode('-',$datanascimento)));?>
			<?
			function getIdade($aniversario, $curr = 'now') {
				$year_curr = date("Y", strtotime($curr));
				$days = !($year_curr % 4) || !($year_curr % 400) & ($year_curr % 100) ? 366: 355;
				list($d, $m, $y) = explode('/', $aniversario);
				return floor(((strtotime($curr) - mktime(0, 0, 0, $m, $d, $y)) / 86400) / $days);
			}
			$idade = getIdade("$datainicio1");

			?>
			<div>Naturalidade: <?=$naturalidade;?>, <?=$estadocivil_N;?>, <?echo $idade; ?> anos</div>
			<div><?=$endereco;?>, <?=$nome_cidade;?>-<?=$uf_nome;?></div>
			<div>Tel.:<?=$telcel;?>, <?=$tel;?> <?=$telres;?></div>
			<div>Email:<?=$email;?></div> 
			
			<p style='width:100%;border-bottom:1px solid #cdcdcd;padding:4px;margin-top:20px;'><b>OBJETIVO</b></p>
			
			<?
			$query_cboid1 = "SELECT * FROM `cbo` where id='$cboid1' ";
			$rs_cboid1     = mysql_query($query_cboid1 );
			while($campo_cboid1  = mysql_fetch_array($rs_cboid1 )){
			$cbo1        = $campo_cboid1 ['cbo'];
			}
			?>
			<div> &#10004; <?=$cbo1;?></div>
			<?
			$query_cboid2 = "SELECT * FROM `cbo` where id='$cboid2' ";
			$rs_cboid2     = mysql_query($query_cboid2 );
			while($campo_cboid2  = mysql_fetch_array($rs_cboid2 )){
			$cbo2        = $campo_cboid2 ['cbo'];
			}
			?>	
			<div>&#10004; <?=$cbo2;?></div>
			<?
			$query_cboid3 = "SELECT * FROM `cbo` where id='$cboid3' ";
			$rs_cboid3     = mysql_query($query_cboid3 );
			while($campo_cboid3  = mysql_fetch_array($rs_cboid3 )){
			$cbo3        = $campo_cboid3 ['cbo'];
			}
			?>	
			<div> &#10004; <?=$cbo3;?></div>
			
			<p style='width:100%;border-bottom:1px solid #cdcdcd;padding:4px;margin-top:20px;'><b>FORMAÇÃO</b></p>
			
		
		
				
				
			<!-------------------------------------------------------------------------------------------------------------->
							<table style='font-size:12px;'>	
							<tr>								
								<td><b>Escolaridadeformação </b></td>
								<td><b>Sérieformação </b></td>
								<td><b>Situação </b></td>
								<td><b>Form. Académica</b></td>
							</tr>
						<?
						$query_noticias_hcpe = "SELECT * FROM `escolaridade` WHERE trabalhadorid ='$id'";
						$rs_noticias_hcpe    = mysql_query($query_noticias_hcpe);
						while($campo_noticias_hcpe = mysql_fetch_array($rs_noticias_hcpe)){

						$escolaridade 	= $campo_noticias_hcpe['escolaridade']; 		
						$serie = $campo_noticias_hcpe['serie'];
						$formacaoacademicaid = $campo_noticias_hcpe['formacaoacademicaid'];
						$comprovacao	 = $campo_noticias_hcpe['comprovacao'];
						
						$situacao = $campo_noticias_hcpe['situacao'];

						?>

								<?
							$query_formacaoacademica_db = "SELECT * FROM `formacaoacademica` WHERE id='$formacaoacademicaid'";
							$rs_formacaoacademica_db    = mysql_query($query_formacaoacademica_db);
							while($campo_formacaoacademica_db = mysql_fetch_array($rs_formacaoacademica_db)){
							$nome_formacaoacademica_db 	= $campo_formacaoacademica_db['nome']; 	
							$id_formacaoacademica_db 	= $campo_formacaoacademica_db['id']; 	
							?><?}?>

						<?
						switch ($serie){		
						case"1":$serie_N="1º ANO";break;
						case"2":$serie_N="2º ANO";break;
						case"3":$serie_N="3º ANO";break;
						case"4":$serie_N="4º ANO";break;
						case"5":$serie_N="5º ANO";break;
						case"6":$serie_N="6º ANO";break;
						case"7":$serie_N="7º ANO";break;
						case"8":$serie_N="8º ANO";break;
						case"9":$serie_N="9º ANO";break;
						case"C1":$serie_N="CICLO I - ALFA";break;
						case"C2":$serie_N="CICLO II - 1ª E 2ª";break;
						case"C3":$serie_N="CICLO III - 3ª E 4ª";break;
						case"C4":$serie_N="CICLO IV - 5ª E 6ª";break;
						case"C5":$serie_N="CICLO V - 7ª E 8ª";break;
						case"F":$serie_N="ED. ESP. ENS. FUND.";break;
						case"I":$serie_N="ED. ESP. ENS. INF.";break;
						case"J1":$serie_N="EJA - ENS.MED - 1ª ANO";break;
						case"J2":$serie_N="EJA - ENS.MED - 2º ANO";break;
						case"J3":$serie_N="EJA - ENS.MED - 3º ANO";break;
						case"M1":$serie_N="ENS.MED - 1º ANO";break;
						case"M2":$serie_N="ENS.MED - 2º ANO";break;
						case"M3":$serie_N="ENS.MED - 3º ANO";break;
						case"A1":$serie_N="MATERNAL I";break;
						case"A2":$serie_N="MATERNAL II";break;
						case"P1":$serie_N="PRÉ I";break;
						case"P2":$serie_N="PRÉ II";break;

						}

						?>
						<?
						switch ($escolaridade){										
						case "N":											
						$escolaridade_N = "Analfabeto";
						break;
						case "A":											
						$escolaridade_N = "Alfabetizado";
						break;
						case "F":											
						$escolaridade_N = "Fundamental";
						break;
						case "M":											
						$escolaridade_N = "Médio";
						break;
						case "P":											
						$escolaridade_N = "Pós-Médio";
						break;
						case "S":											
						$escolaridade_N = "Superior";
						break;
						case "G":											
						$escolaridade_N = "Pós-Graduação";
						break;
						case "E":											
						$escolaridade_N = "Mestrado";
						break;
						case "D":											
						$escolaridade_N = "Doutorado";
						break;
						}
						?>

						<tr class='tr_tb' >

						
						<td class='td2' width='205px'> <?=$escolaridade_N;?> </td>
						<td class='td2' width='221px'> <?=$serie_N;?> </td>

						<?
						switch ($situacao){										
						case "C":											
						$situacaocurso_cp_N = "Completo";
						break;case "U":											
						$situacaocurso_cp_N = "Cursando";
						break;case "I":											
						$situacaocurso_cp_N = "Incompleto";
						break;
						}
						?>		


						<td class='td2' width='83px'>  <?=$situacaocurso_cp_N;?></td>		
						<td class='td2' >  <?=$nome_formacaoacademica_db;?></td>		
							
						</tr>

						<?}?>
		</table>				
		<!-------------------------------------------------------------------------------------------------------------->	
		
			
			
	<p style='width:100%;border-bottom:1px solid #cdcdcd;padding:4px;margin-top:20px;'><b>EXPERIÊNCIA PROFISSIONAL</b></p>
	
	<?
		$query_noticias_h2 = "SELECT * FROM `historico` WHERE trabalhadorid ='$id'";
		$rs_noticias_h2    = mysql_query($query_noticias_h2);
		
		while($campo_noticias_h = mysql_fetch_array($rs_noticias_h2)){				
		$cboidh = $campo_noticias_h['cboid'];
		$empresah = $campo_noticias_h['empresa'];
		$cargoh = $campo_noticias_h['cargo'];
		$carteiraassinadah = $campo_noticias_h['carteiraassinada'];
		$ativoh = $campo_noticias_h['ativo'];
		$datainicioh = $campo_noticias_h['datainicio'];
		$datafinalh = $campo_noticias_h['datafinal'];
		$tempanosh = $campo_noticias_h['tempanos'];
		$tempomesh = $campo_noticias_h['tempomes'];
		
	?>
	 
		<?
		$query_cboidh = "SELECT * FROM  `cbo` WHERE  id='$cboidh'";	
		$rs_cboidh    = mysql_query($query_cboidh); 													
		while($campo_cboidh= mysql_fetch_array($rs_cboidh)){		 
		$cboh= $campo_cboidh['cbo']; }

		?>
		<?$datainicio1 = implode('/',array_reverse(explode('-',$datainicioh)));?>
		<?$datafinal2 = implode('/',array_reverse(explode('-',$datafinalh)));?>
		
	 <div><b>&#10148; <?=$datainicio1;?> - <?=$datafinal2;?> - <?=$empresah;?></b></div> 
	 <div>&nbsp;&nbsp;&nbsp; Cargo: <?=$cboh;?></div> 
	 <div>&nbsp;&nbsp;&nbsp; Principal atividade: <?=$cargoh;?></div> 
	
	
	<?}?>		
	
	
	
	

	
	<p style='width:100%;border-bottom:1px solid #cdcdcd;padding:4px;margin-top:20px;'><b>QUALIFICAÇÕES E ATIVIDADES COMPLEMENTARES</b></p>
	
	<div style='margin-left:20px;' >
		
			<?
			$query_software1 = "SELECT * FROM `software`where id='$softwareid1'";
			$rs_software1    = mysql_query($query_software1);
			while($campo_software1 = mysql_fetch_array($rs_software1)){																						
			$nome_soft1 	= $campo_software1['nome']; 	
			}
			if($nome_soft1=="--"){}else{echo"<p style='width:20%;border-bottom:1px solid #cdcdcd;padding:4px;margin-let:10px;'><b>&#9679; INFORMÁTICA</b></p> <div style='margin-left:20px;'>&#9642; $nome_soft1</div>";}
			?>	
			<?
			$query_software2 = "SELECT * FROM `software`where id='$softwareid2'";
			$rs_software2    = mysql_query($query_software2);
			while($campo_software2 = mysql_fetch_array($rs_software2)){																						
			$nome_soft2 	= $campo_software2['nome']; 	
			}
			if($nome_soft2=="--"){}else{echo"<div  style='margin-left:20px;'>&#9642; $nome_soft2</div>";}
			?>
			<?
			$query_software3 = "SELECT * FROM `software`where id='$softwareid3'";
			$rs_software3    = mysql_query($query_software3);
			while($campo_software3 = mysql_fetch_array($rs_software3)){																						
			$nome_soft3 	= $campo_software3['nome']; 	
			}			
			if($nome_soft3=="--"){}else{echo"<div  style='margin-left:20px;' >&#9642; $nome_soft3</div>";}
			?>	
			
			<p style='width:20%;border-bottom:1px solid #cdcdcd;padding:4px;margin-let:10px;margin-top:10px;'><b>&#9679; IDIOMAS</b></p>
			
			<?if($nome_idiomaid1=="--"){}else{?>
			<table align='left' style='font-family: "Trebuchet MS", Helvetica, sans-serif;font-size:12px;width:90%;'>
																				
																				<tr style='background-color:#ccc;'  style='font-family: "Trebuchet MS", Helvetica, sans-serif;font-size:12px;'>
																					<td align='left'>Idioma</td>
																					<td align='left'>Leitura</td>
																					<td align='left'>Escrita</td>
																					<td align='left'>Conversação</td>
																				</tr>
																				
																				<tr style='font-family: "Trebuchet MS", Helvetica, sans-serif;font-size:12px;'>
																					<td>
																						<?=$nome_idiomaid1;?>
																					</td>
																					
																					<?
																					switch ($leitura1){										
																					case "B":											
																					$leitura1_N = "Básica";
																					break;case "I":											
																					$leitura1_N = "Intermediária";
																					break;case "A":											
																					$leitura1_N = "Avançada";
																					break;case "F":											
																					$leitura1_N = "Fluente";
																					break;
																					}
																					
																					switch ($escrita1){										
																					case "B":											
																					$escrita1_N = "Básica";
																					break;case "I":											
																					$escrita1_N = "Intermediária";
																					break;case "A":											
																					$escrita1_N = "Avançada";
																					break;case "F":											
																					$escrita1_N = "Fluente";
																					break;
																					}
																					
																					switch ($conversacao1){										
																					case "B":											
																					$conversacao1_N = "Básica";
																					break;case "I":											
																					$conversacao1_N = "Intermediária";
																					break;case "A":											
																					$conversacao1_N = "Avançada";
																					break;case "F":											
																					$conversacao1_N = "Fluente";
																					break;
																					}
																					
																					
																					?>
																					<td><?if($leitura1==""){}else{echo $leitura1_N;}?></td>
																					<td><?if($escrita1==""){}else{echo $escrita1_N;}?></td>
																					<td><?if($conversacao1==""){}else{echo $conversacao1_N;}?></td>
																				</tr>
																				
																				
																				<tr style='font-family: "Trebuchet MS", Helvetica, sans-serif;font-size:12px;'>
																					<td>
																						<?=$nome_idiomaid2;?>
																					</td>
																					
																					<?
																					switch ($leitura2){										
																					case "B":											
																					$leitura2_N = "Básica";
																					break;case "I":											
																					$leitura2_N = "Intermediária";
																					break;case "A":											
																					$leitura2_N = "Avançada";
																					break;case "F":											
																					$leitura2_N = "Fluente";
																					break;
																					}
																					
																					switch ($escrita2){										
																					case "B":											
																					$escrita2_N = "Básica";
																					break;case "I":											
																					$escrita2_N = "Intermediária";
																					break;case "A":											
																					$escrita2_N = "Avançada";
																					break;case "F":											
																					$escrita2_N = "Fluente";
																					break;
																					}
																					
																					switch ($conversacao2){										
																					case "B":											
																					$conversacao2_N = "Básica";
																					break;case "I":											
																					$conversacao2_N = "Intermediária";
																					break;case "A":											
																					$conversacao2_N = "Avançada";
																					break;case "F":											
																					$conversacao2_N = "Fluente";
																					break;
																					}
																					
																					
																					?>
																					<td><?if($leitura2==""){}else{echo $leitura2_N;}?></td>
																					<td><?if($escrita2==""){}else{echo $escrita2_N;}?></td>
																					<td><?if($conversacao2==""){}else{echo $conversacao2_N;}?></td>
																				</tr>
																				
																				<tr style='font-family: "Trebuchet MS", Helvetica, sans-serif;font-size:12px;'>
																					<td>
																						<?=$nome_idiomaid3;?>
																					</td>
																					
																					<?
																					switch ($leitura3){										
																					case "B":											
																					$leitura3_N = "Básica";
																					break;case "I":											
																					$leitura3_N = "Intermediária";
																					break;case "A":											
																					$leitura3_N = "Avançada";
																					break;case "F":											
																					$leitura3_N = "Fluente";
																					break;
																					}
																					
																					switch ($escrita3){										
																					case "B":											
																					$escrita3_N = "Básica";
																					break;case "I":											
																					$escrita3_N = "Intermediária";
																					break;case "A":											
																					$escrita3_N = "Avançada";
																					break;case "F":											
																					$escrita3_N = "Fluente";
																					break;
																					}
																					
																					switch ($conversacao3){										
																					case "B":											
																					$conversacao3_N = "Básica";
																					break;case "I":											
																					$conversacao3_N = "Intermediária";
																					break;case "A":											
																					$conversacao3_N = "Avançada";
																					break;case "F":											
																					$conversacao3_N = "Fluente";
																					break;
																					}
																					
																					
																					?>
																					<td><?if($leitura3==""){}else{echo $leitura3_N;}?></td>
																					<td><?if($escrita3==""){}else{echo $escrita3_N;}?></td>
																					<td><?if($conversacao3==""){}else{echo $conversacao3_N;}?></td>
																				</tr>
																				
																				
																				
																				
				</table>
				<?}?>
				<br>
				<br>
				<p style='width:20%;border-bottom:1px solid #cdcdcd;padding:4px;margin-let:10px;margin-top:20px;'><b>&#9679; CURSOS E PALESTRAS</b></p>
				<?
					$query_noticias_hcp = "SELECT * FROM `cursopalestra` WHERE trabalhadorid ='$id'";
					$rs_noticias_hcp    = mysql_query($query_noticias_hcp);
					while($campo_noticias_hcp = mysql_fetch_array($rs_noticias_hcp)){
					$cursos_palestras 	= $campo_noticias_hcp['cursos_palestras']; 		
					$situacaocurso_cp = $campo_noticias_hcp['situacao'];
					$segmentoatuacaoid = $campo_noticias_hcp['segmentoatuacaoid'];
					$curso_cp = $campo_noticias_hcp['curso'];
					$comprovacaocurso = $campo_noticias_hcp['comprovacao'];
					$idcursospalestras = $campo_noticias_hcp['id'];
					if($idcursospalestras > 0){
					?>
					 <div>&#10148; Curso: <?=$curso_cp;?></div> 
					<?
					$query_noticias_hcsa = "SELECT * FROM `segmentoatuacao` where id='$segmentoatuacaoid'";
					$rs_noticias_hcsa    = mysql_query($query_noticias_hcsa);
					while($campo_noticias_hcsa = mysql_fetch_array($rs_noticias_hcsa)){
					$nomeseguimento 	= $campo_noticias_hcsa['nome']; 	
					}
					?>
					
					 <div>&nbsp;&nbsp;&nbsp; Seguimento: <?=$nomeseguimento;?></div> 	
					 
					 <?
						switch ($situacaocurso_cp){										
						case "C":											
						$situacaocurso_cp_N = "Completo";
						break;case "U":											
						$situacaocurso_cp_N = "Cursando";
						break;case "I":											
						$situacaocurso_cp_N = "Incompleto";
						break;
						}
						?>		
					 <div>&nbsp;&nbsp;&nbsp; Situação: <?=$situacaocurso_cp_N;?></div> 	
						
				
				
				<?}}?>
	</div>
	
		<script type='text/javascript'>window.print();</script>	
</div>	
