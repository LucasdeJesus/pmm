<?
include'conf.php';
?>
<html> 
<head>
<?include'head.php';?>
</head>

<body>



<div data-role="page" data-theme="b" id="foo">

	<?include'head_page.php';?>

	
	
	
	<div data-role="content" data-theme="b">	
	<h3>check-in Módulo Turma</h3>
	<p>
	<?
	$id_turma = $_GET['id_turma']; 
	$nome_turma = $_GET['turma'];
	
		$excluir = $_GET ['excluir'];
		$id_modulo = $_GET ['id_modulo'];
		if($excluir == "")
		{}
		else
		{
		$query="DELETE from tb_modulo  where id_modulo ='$id_modulo'";
		$rs= mysql_query($query);
		$query="DELETE from  aluno_modulo  where id_modulo ='$id_modulo'";
		$rs= mysql_query($query);
		
		
		}
			
	?>
	
	
	</p>
	<p>
	<h4>Curso: <font style='color:#ff6600'><?=$nome_turma ;?></font><h4>
	</p>
		<ul data-role="listview" data-autodividers="true" data-filter="true" data-inset="true" data-filter-placeholder="Burcar Módulos" data-theme="e">
			<?
			
			$query_noticias = "select * from tb_modulo  where id_turma =  '$id_turma' ORDER BY `tb_modulo`.`curso` ASC";
			$rs_noticias    = mysql_query($query_noticias);
			while($campo_noticias = mysql_fetch_array($rs_noticias)){
			$id_modulo        = $campo_noticias['id_modulo'];
			$id_turma_3        = $campo_noticias['id_turma'];
			$curso_3      = $campo_noticias['curso'];
			$inicio_curso      = $campo_noticias['inicio_curso'];
			$terminio_curso      = $campo_noticias['terminio_curso'];
			$instrutor_nome      = $campo_noticias['instrutor'];
			$horario      = $campo_noticias['horario'];
			$conteudo_especifico      = $campo_noticias['conteudo_especifico'];
			$conteudo_gerais      = $campo_noticias['conteudo_gerais'];


			?>
			
			
			<li>
			<a href="chekin_cr.php?id_modulo=<?=$id_modulo;?>&nome_turma=<?=$nome_turma ;?>" data-icon="plus" data-rel="dialog" >
			<h3><?=$curso_3;?></h3>
			<p>Instrutor:<?=$instrutor_nome;?></p>
			<p>Inicio:<?=$inicio_curso;?></p>
			<p>Términio:<?=$terminio_curso;?></p>
			<p>Horário:<?=$horario;?></p>
			<p>Conteúdo Programático: <? if(empty($conteudo_especifico)){ echo"<font style='color:red'><b>Faltando</b></font>";} else{ echo"<font style='color:#1E90FF'><b>OK</b></font>";}   ?></p>
			<p>Relatório Final: <? if(empty($conteudo_gerais)) { echo"<font style='color:red'><b>Faltando</b></font>";} else{ echo"<font style='color:#1E90FF'><b>OK</b></font>";}  ?></p>
			</a>
			 <a href="javascript:Abrir_Pagina('detalhe_diario.php?id_modulo=<?=$id_modulo;?>&id_turma=<?=$id_turma;?>&turma=<?=$curso_3;?>','scrollbars=yes,width=700,height=600')"  data-icon="search" data-rel="popup" data-position-to="window" data-transition="pop">Verificar notas</a>
			</li>
		
			
			
		
		<?}?>
</ul>
		</div><!-- /content -->

	

	
	
	
	
<!-- /footer -->
<?include'rodape.php';?>

<!-- /footer -->


</div><!-- /page -->

</body>


