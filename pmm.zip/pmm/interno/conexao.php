<?   
$database="localhost"; // SERVIDOR E PORTA UTILIZADA   
$dbname="cetepcbr_cetep_v2"; // BASE DE DADOS 
$usuario="cetepcbr_root"; // USU�RIO DO MYSQL
$dbsenha="ceteproot2011"; // SENHA DO MYSQL

$conexao=mysql_connect ($database, $usuario, $dbsenha);
if($conexao){
      if (mysql_select_db($dbname, $conexao)){ print "";
      }else{ print "N�o foi poss�vel selecionar o Banco de Dados"; }
}else{ print "Erro ao conectar o MySQL"; }
?>
	<?php
ini_set('default_charset','UTF-8'); // Para o charset das p�ginas e
mysql_set_charset('utf8'); // para a conex�o com o MySQL
?>
