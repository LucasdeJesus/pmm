<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>
<style Onload="carrega();" ></style>
<style Onload="emcaminhamentof();" ></style>

<body>


	<script type="text/javascript">

	top.frememenu.minhaFuncao2('mostra');
		$(document).ready(function(){									
		$("#cadastro").validate();										
		$.validator.setDefaults({
		submitHandler: function() {

		}
		});
		});
</script>

  <script>
            function pop_pesquisaempresacbo1() {
				var input = document.getElementById("cboid1").value;
				var  page='windobuscaempresacbo1.php?nomecbo='+input;
                window.open(page, 'popRelReciboEntregue', 'width=750,height=450,scrollbars');
                //document.cadastro.action = page;
                //document.cadastro.target = 'popRelReciboEntregue';
                //document.cadastro.submit();
            }

        </script>	
		
		 <script>
            function pop_pesquisaempresacbo2() {
				var input = document.getElementById("cboid2").value;
				var  page='windobuscaempresacbo2.php?nomecbo='+input;
                window.open(page, 'popRelReciboEntregue', 'width=750,height=450,scrollbars');
                //document.cadastro.action = page;
                //document.cadastro.target = 'popRelReciboEntregue';
                //document.cadastro.submit();
            }

        </script>	
		
		 <script>
            function pop_pesquisaempresacbo3() {
				var input = document.getElementById("cboid3").value;
				var  page='windobuscaempresacbo3.php?nomecbo='+input;
                window.open(page, 'popRelReciboEntregue', 'width=750,height=450,scrollbars');
                //document.cadastro.action = page;
                //document.cadastro.target = 'popRelReciboEntregue';
                //document.cadastro.submit();
            }

        </script>	
		
		<script>
            function pop_pesquisanometrabalhador() {
				var input = document.getElementById("nomebusca").value;
				var  page='windobuscanometrabalhador.php?nometrabalhador='+input;
                window.open(page, 'popRelReciboEntregue', 'width=750,height=450,scrollbars');
                //document.cadastro.action = page;
                //document.cadastro.target = 'popRelReciboEntregue';
                //document.cadastro.submit();
            }

        </script>	
		
		<script type="text/javascript">
// INICIO FUNÇÃO DE MASCARA MAIUSCULA
function maiuscula(z){
        v = z.value.toUpperCase();
        z.value = v;
    }
//FIM DA FUNÇÃO MASCARA MAIUSCULA

</script>

<div id="content" name='contente' >
<div id="container">


			<div id="bg-container"   class='contener'>
							
					
							<?
							
							
									$deletezeroescolaridade="DELETE from escolaridade WHERE trabalhadorid='0'";
									$deleterscescolaridadezero= mysql_query($deletezeroescolaridade);
									
									$deletezerohistorico="DELETE from historico WHERE trabalhadorid='0'";
									$deleterschistoricozero= mysql_query($deletezerohistorico);
									
				
											$cpf_busca 	= $_GET['cpf_busca']; 
											$idbusca 	= $_GET['idtr']; 
											$buscaform 	= $_GET['buscaform']; 
		
										if($cpf_busca==''){
										
											$query_noticias = "SELECT * FROM `trabalhador` WHERE id = '$idbusca'";
										} else{
										
											$query_noticias = "SELECT * FROM `trabalhador` WHERE `cpf` LIKE '%$cpf_busca%'";
											
										}
												
											$rs_noticias    = mysql_query($query_noticias);																							
											while($campo_noticias = mysql_fetch_array($rs_noticias)){
											$id= $campo_noticias['id']; 											
											$cadbf= $campo_noticias['cadbf']; 
											$nome= $campo_noticias['nome']; 
											$email= $campo_noticias['email']; 
													$cpf 	= $campo_noticias['cpf']; 	 		 			 	
												$nome 	= $campo_noticias['nome']; 
												$mae 	= $campo_noticias['mae'];	 		 			 	
												$pai 	= $campo_noticias['pai'];	 		 			 	
												$datanascimento 	= $campo_noticias['datanascimento']; 	 		 			 	
												$naturalidade 	= $campo_noticias['naturalidade']; 	 		 			 	
												$sexo 	= $campo_noticias['sexo']; 	 		 			 	
												$etnia 	= $campo_noticias['etnia']; 	 		 			 	
												$statusjovem 	= $campo_noticias['statusjovem']; 	 		 			 	
												$estadocivil 	= $campo_noticias['estadocivil']; 												 		 			 	
												$txtfilhosestudantes 	= $campo_noticias['txtfilhosestudantes']; 	 		 			 	
												$txttrabalhando 	= $campo_noticias['txttrabalhando']; 	 		 			 	
												$txtmeres 	= $campo_noticias['txtmeres']; 	 		 			 	
												$txtmenores 	= $campo_noticias['txtmenores']; 	 		 			 	
												$txtmenores 	= $campo_noticias['txtmenores']; 					 	 		 			 	
												$cbolaudo 	= $campo_noticias['cbolaudo']; 	 		 			 	
												$txtlimitacoes 	= $campo_noticias['txtlimitacoes']; 	 		 			 	
												$intencao 	= $campo_noticias['intencao']; 	 		 			 	
												$cboTemporario 	= $campo_noticias['cboTemporario']; 	 		 			 	
												$cboservida 	= $campo_noticias['cboservida']; 	 		 			 	
												$cboNoturno 	= $campo_noticias['cboNoturno']; 	 		 			 	
												$cbotur 	= $campo_noticias['cbotur']; 	 		 			 	
												$cbofeira 	= $campo_noticias['cbofeira']; 	 		 			 	
												$cep 	= $campo_noticias['cep']; 	 		 			 	
												$txtestado 	= $campo_noticias['txtestado']; 	 		 			 	
												$cidadeid 	= $campo_noticias['cidadeid']; 	 		 			 	
												$bairro 	= $campo_noticias['bairro']; 	 		 			 	
												$endereco 	= $campo_noticias['endereco']; 	 		 			 	
												$telres 	= $campo_noticias['telres']; 	 		 			 	
												$telcel 	= $campo_noticias['telcel']; 	 		 			 	
												$telrec 	= $campo_noticias['telrec']; 	 		 			 	
												$nmrecado 	= $campo_noticias['nmrecado']; 	 		 			 	
												$email 	= $campo_noticias['email'];	 		 			 	
												$identidade 	= $campo_noticias['identidade']; 	 		 			 	
												$orgaoexpedidor 	= $campo_noticias['orgaoexpedidor']; 	 		 			 	
												$txttitulo 	= $campo_noticias['txttitulo']; 	 		 			 	
												$txtzona 	= $campo_noticias['txtzona']; 	 		 			 	
												$txtsecao 	= $campo_noticias['txtsecao']; 	 		 			 	
												$tipocnh 	= $campo_noticias['tipocnh']; 	 		 			 	
												$carteiratrabalho 	= $campo_noticias['carteiratrabalho']; 	 		 			 	
												$seriect 	= $campo_noticias['seriect']; 	 		 			 	
												$txtregistroprof 	= $campo_noticias['txtregistroprof']; 	 		 			 	
												$orgaoreg 	= $campo_noticias['orgaoreg']; 	 		 			 	
												$pispasep 	= $campo_noticias['pispasep']; 	 		 			 	
												$passaporte 	= $campo_noticias['passaporte']; 	 		 			 	
												$txtmoracom 	= $campo_noticias['txtmoracom']; 	 		 			 	
												$txtmorapais 	= $campo_noticias['txtmorapais']; 	 		 			 	
												$txtmoracompanheiro 	= $campo_noticias['txtmoracompanheiro']; 	 		 			 	
												$txtmoraoutros 	= $campo_noticias['txtmoraoutros']; 	 		 			 	
												$txtmorafilhos 	= $campo_noticias['txtmorafilhos']; 	 		 			 	
												$txtmorafilhos1 	= $campo_noticias['txtmorafilhos1']; 	 		 			 	
												$txtmorafilhos2 	= $campo_noticias['txtmorafilhos2']; 	 		 			 	
												$txtmorafilhos3 	= $campo_noticias['txtmorafilhos3']; 	 		 			 	
												$txtmorairmaos 	= $campo_noticias['txtmorairmaos']; 	 		 			 	
												$txtmorairmaos1 	= $campo_noticias['txtmorairmaos1']; 	 		 			 	
												$txtmorairmaos2 	= $campo_noticias['txtmorairmaos2']; 	 		 			 	
												$txtmorairmaos22 	= $campo_noticias['txtmorairmaos22']; 	 		 			 	
												$txtmorairmaos3 	= $campo_noticias['txtmorairmaos3']; 	 		 			 	
												$txtrendafamiliar 	= $campo_noticias['txtrendafamiliar']; 	 		 			 	
												$selchefefamilia 	= $campo_noticias['selchefefamilia']; 	 		 			 	
												$programasocialid 	= $campo_noticias['programasocialid']; 	 		 			 	
												$cboprocesso 	= $campo_noticias['cboprocesso']; 	 		 			 	
												$cbosoube_caet 	= $campo_noticias['cbosoube_caet']; 	 		 			 	
												$selcidacaptado 	= $campo_noticias['selcidacaptado']; 	 		 			 	
												$selcidaatraves 	= $campo_noticias['selcidaatraves']; 	 		 			 	
												$selLocalDocs 	= $campo_noticias['selLocalDocs']; 	 		 			 	
												$txthistorico	= $campo_noticias['txthistorico'];
 
												$txthabilidades1 = $campo_noticias['txthabilidades1'];
												$txthabilidades2 = $campo_noticias['txthabilidades2'];
												$txthabilidades3 = $campo_noticias['txthabilidades3'];
												$cboid1 =  $campo_noticias['cboid1'];
												$cboid2 =  $campo_noticias['cboid2'];
												$cboid3 =  $campo_noticias['cboid3'];
												$pretensaosalarial =  $campo_noticias['pretensaosalarial'];
												$ultimosalario =  $campo_noticias['ultimosalario'];
												$escolaridade 	= $campo_noticias['escolaridade']; 
												$senha 	= $campo_noticias['senha']; 
												$situacao 	= $campo_noticias['situacao']; 
												$serie 	= $campo_noticias['serie']; 
												$turno 	= $campo_noticias['turno']; 
												$formacaoacademicaidbusca 	= $campo_noticias['formacaoacademicaidbusca']; 
												$formacaoacademicaid 	= $campo_noticias['formacaoacademicaid']; 
												$outrocurso 	= $campo_noticias['outrocurso']; 
												$instituicao 	= $campo_noticias['instituicao']; 
												$comprovacao 	= $campo_noticias['comprovacao']; 
												$softwareid1 	= $campo_noticias['softwareid1']; 
												$softwareid2 	= $campo_noticias['softwareid2']; 
												$softwareid3 	= $campo_noticias['softwareid3']; 
												$idiomaid1 	= $campo_noticias['idiomaid1']; 
												$idiomaid2 	= $campo_noticias['idiomaid2']; 
												$vagadeficiente 	= $campo_noticias['vagadeficiente']; 
												$idiomaid3 	= $campo_noticias['idiomaid3']; 
												$leitura1 	= $campo_noticias['leitura1']; 
												$leitura2 	= $campo_noticias['leitura2']; 
												$leitura3	= $campo_noticias['leitura3']; 
												$conversacao1	= $campo_noticias['conversacao1']; 
												$conversacao2	= $campo_noticias['conversacao2']; 
												$conversacao3	= $campo_noticias['conversacao3']; 
												$escrita1	= $campo_noticias['escrita1']; 
												$escrita2	= $campo_noticias['escrita2']; 
												$escrita3	= $campo_noticias['escrita3']; 
												
												$cadastrado_por	= $campo_noticias['usuarioid']; 
												$datacadastro	= $campo_noticias['datacadastro']; 
												$dataupdate	= $campo_noticias['dataupdate']; 
												$infotrabalhado	= $campo_noticias['infotrabalhado']; 
											}			

										
											
											?>
											
												<?if($buscaform ==""){ 	?>
																		<form  class="form" method="get" action=""  id="cadastro" name='cadastro' >			

																		<div class="form-row">
																		<div class="label">CPF:</div>
																		<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" onBlur="return validar_cpf()" name="cpf_busca" id='cpf_busca' placeholder="Insira o CPF" type="text"  class="input req-same" maxlength="14"  /></div>
																		</div>
																		
																		
																		<div class="form-row">
																		<div class="label">ID:</div>
																		<div class="input-container"><input  name="idtr" id='idtr' placeholder="Insira o ID" type="text"  class="input req-same" maxlength="14"  /></div>
																		</div>
																		
																		
																			<div class="form-row">
																			<div class="label">Nome</div>
																			<div class="input-container">
																		
																			<table><tr>
																			<td>
																			<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="nomebusca"  placeholder="Nome do trabalhador" id="nomebusca"  class="input req-same" size="60" maxlength="200" onchange="EditandoRegistro2()" tabindex="1"  type="text" style='width:350px;'>
																			</td>
																			<td>
																			<a class="sendBtn" onclick="pop_pesquisanometrabalhador('windobuscanometrabalhador.php')" >...</a>
																			</td></tr></table>
																			</div>
																			</div>

																		
																		<div class="form-row">
																		<div class="label"></div>
																		<div class="input-container" style='width:546px;'>		
																		<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" id="submitBtn2" value="Buscar" type="submit" class="sendBtn"  onclick='return validar_cpf()' />
																		<div id="errorDiv2" class="error-div"></div>
																		</div>
																		</div>
																		<input type='hidden' name='buscaform' value='b'>
																		</form>
			
															<?}

															else


															{
															
															?>
													<form  class="form" method="post"   id="cadastro" name='cadastro' <?if($id ==""){echo" action='script_cadastro.php?acao=cadastro' "; }else{ echo" action='script_cadastro.php?acao=editar' ";}?> >
														
														</style>
														<h1>Cadastro de Currículo</h1>
													<div><font style='font-size:16px;'>&#10144; </font>Atenção, campos com <font class='simbolo'>&#10045;</font> são obrigatorios!</div>
													
														
														<div class="idTabs" id='idTabs'><!--div pagginação-->
													
														<div id="cadastro1" name='cadastro1'>
														
																	<div style='margin:20px;width:100%;' align='center'>
																	<font style='font-size:15px;color:red;font-weight:bold;'><a href="#cadastro1" >PASSO 1</a> &#10132; </font>
																	<font style='font-size:15px;color:#999;font-weight:bold;'><a href="#proficional" >PASSO 2</a> &#10132; </font>
																	<font style='font-size:15px;color:#999;font-weight:bold;'><a  href="#qualificacao"  onclick="carrega_proficional();carrega_escolaridade();" >PASSO 3</a>  </font>

																	</div>
										

															<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" type='hidden' name='id' value='<?=$id;?>'/>
															
														<h2>DADOS PESSOAIS</h2>
														
														<!--<h3>Same fields required example</h3>-->
															<?if($id > 0){?>		
																
																<div class="form-row" >
																<div class="label"></div>
																<div class="input-container" style='width:541px;'>													
																<?
																$query_atendente = "SELECT *  FROM  `usuario` where  id='$cadastrado_por'";	
																$rs_atendente    = mysql_query($query_atendente); 													
																while($campo_atendente = mysql_fetch_array($rs_atendente)){
																$nome_atendente= $campo_atendente['nome']; 
																$perfiluselogado = $campo_atendente['perfil'];
																}														
																
																?>
																
																
																<?
																$query_atendentet = "SELECT senha  FROM  `usuario` where  usuario='$cpf'";	
																$rs_atendentet    = mysql_query($query_atendentet); 													
																while($campo_atendentet = mysql_fetch_array($rs_atendentet)){
																$senhatrabalhador= $campo_atendentet['senha']; 
																}														
																
																?>
																
																
																<a href="javascript:Abrir_Pagina('candidatocurriculum.php?id=<?=$id;?>','scrollbars=yes,width=800,height=500')" title='Imprimir curriculum '  class="sendBtn">Imprimir</a>	
																ID: <input onBlur="maiuscula(this)" onBlur="maiuscula(this)" style='width:170px'  class="input req-same"value='<?=$id;?>'readonly="true"  type="text"   /><br>
																Cadastro: <input onBlur="maiuscula(this)" onBlur="maiuscula(this)" style='width:170px' class="input req-same" value='<?=$datacadastro;?>'readonly="true"  type="text"   /><br>
																Atualizado: <input onBlur="maiuscula(this)" onBlur="maiuscula(this)" style='width:170px'  class="input req-same"value='<?=$dataupdate;?>'readonly="true"  type="text"   /><br>
																Atendente : <input onBlur="maiuscula(this)" onBlur="maiuscula(this)" style='width:170px' class="input req-same" value='<?=$nome_atendente;?>'readonly="true"  type="text"   /><br>
															<?if($perfiluselogado=="W"){?>Senha Trab. : <input onBlur="maiuscula(this)" onBlur="maiuscula(this)" style='width:170px' class="input req-same" value='<?=$senhatrabalhador;?>'readonly="true"  type="text"   /><?}?>
																</div>
																</div>
															<?}?>
														
														<script type="text/javascript">														
																$(document).ready(function(){	
																
																	$('#intencao').change(function() {	
																		var intencao = $("#intencao").val();
																			if(intencao=="1"){
																			$("#statusjovem").prop('disabled', false);
																			}else{	
																			$("#statusjovem").val("");	
//																			$('#statusjovem').remove();																			
																			$("#statusjovem").prop('disabled', true);
																			 
																			}																		
																	});
																
																;});
														</script>
														
														
											<div class="form-row"   >
												<div class="label"></div>
												<div class="input-container" style='width:546px;'  >		

													Cadastro realizado na Brasil Offshore?<font class='simbolo'><font class='simbolo'>&#10045;</font></font>
													<select name="cadbf"  id="cadbf" style="width:88px;" tabindex="15">
														
														<?
																switch ($cadbf){										
																case "N":											
																$cadbf_N = "Não";
																break;case "S":											
																$cadbf_N = "Sim";
																break;
																}
															if($cadbf=="")	{}else{
														?>
														<option value="<?=$cadbf;?>"><?=$cadbf_N;?></option>
														<?}?>
														<option value='N' >Não</option>
														<option value='S' >Sim</option>
													</select>
													
												</div>
											</div >
											
														<div class="form-row">
															<div class="label">Intenção? <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"  style='width:546px;'>
														<select name="intencao" id="intencao" required tabindex="22" style="width:240">
														
														<?
																			switch ($intencao){										
																			case "E":											
																			$intencao_N = "Emprego";
																			break;
																			case "1":											
																			$intencao_N = "1º Emprego(Jovem Aprendiz)";
																			break;
																			case "T":											
																			$intencao_N = "Estágio";
																			break;
																			case "C":											
																			$intencao_N = "Curso";
																			break;
																			case "D":											
																			$intencao_N = "Emissão de Documentos";
																			break;
																			case "G":											
																			$intencao_N = "Emprego/Curso";
																			break;
																			case "M":											
																			$intencao_N = "Emprego/Emissão de Documentoso";
																			break;
																			case "U":											
																			$intencao_N = "Curso/Emissão de Documentos";
																			break;
																			case "S":											
																			$intencao_N = "Todas";
																			break;
																			
																			}
																			?>
																			
																		<option value="<?=$intencao;?>"><?=$intencao_N;?></option>
																		<option value="E" >Emprego</option>
																		<option value="1">1º Emprego(Jovem Aprendiz)</option>
																		<option value="T">Estágio</option>
																		<option value="C">Curso</option>
																		<option value="D">Emissão de Documentos</option>
																		<option value="G">Emprego/Curso</option>
																		<option value="M">Emprego/Emissão de Documentos</option>
																		<option value="U">Curso/Emissão de Documentos</option>
																		<option value="S">Todas</option>
																	</select>
														</div>
														</div>
														
														<div class="form-row">
															<div class="label">Status Jovem  <font class='simbolo'></font> </div>
															<div class="input-container"  style='width:546px;'>
														<select name="statusjovem" id="statusjovem"  tabindex="22" style="width:240">
														
														<?
																			switch ($statusjovem){										
																			case "A":											
																			$statusjovem_N = "Em Andamento";
																			break;
																			case "T":											
																			$statusjovem_N = "Treinado";
																			break;
																			case "E":											
																			$statusjovem_N = "Evadido";
																			break;
																			case "I":											
																			$statusjovem_N = "Inserido";
																			break;
																			case "C":											
																			$statusjovem_N = "Encaminhado";
																			break;
																			}
																			?>
																			
																		<option value="<?=$statusjovem;?>"><?=$statusjovem_N;?></option>
																		<option value="A" >Em Andamento</option>
																		<option value="T">Treinado</option>
																		<option value="E">Evadido</option>
																		<option value="I">Inserido</option>
																		<option value="C">Encaminhado</option>
																		<option value="">--</option>
																		
																		
																	</select>
														</div>
														</div>
														
														
															
														
														
														
														<div class="form-row">
															<div class="label">CPF <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" style='width:200px'  readonly="true" name="cpf" value='<?if($cpf_busca ==""){echo $cpf; } else{ echo $cpf_busca;};?>' onkeypress="formatar_mascara(this, '###.###.###-##')" type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="14"  /></div>
														</div>
														
														
														
														
														<div class="form-row">
															<div class="label">Nome <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="nome" required  value='<?=$nome;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
														</div>
														
															<script> 
															function validarConfirmacao(){ 

															var senha = document.cadastro.senha.value; 
															var csenha = document.cadastro.csenha.value; 
															if(senha != csenha){ 
															alert("Confirmação e senha diferentes") 
															document.cadastro.csenha.focus(); 
															} 
															} 
															</script> 
						
														<!--
														<div class="form-row">
															<div class="label">Senha <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="senha" required  value='<?=$senha;?>'type="password" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="13"  /></div>
														</div>
														
														<div class="form-row">
															<div class="label">Repetir-Senha <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"><input onBlur="validarConfirmacao()"  name="resenha" required  value='<?=$senha;?>'type="password" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="13"  /></div>
														</div>-->
					<script type="text/javascript">

					function deficiente(df){
					$.ajax({
					url: 'deficiente_trabalhador.php?id_trabalhado=<?=$id;?>&escolha='+ df,
					success: function(data) {
					$('#deficiente').html(data);
					}
					});
					}
					</script>									
					<script  type="text/javascript">	
						
					if(<?=$id;?> > 0){deficiente('<?=$vagadeficiente;?>') };
					function deficienter(cidade) {
					
					// Verificando Browser
					if(window.XMLHttpRequest) {
					req = new XMLHttpRequest();
					}
					else if(window.ActiveXObject) {
					req = new ActiveXObject("Microsoft.XMLHTTP");
					}
					   
				
					
					// Arquivo PHP juntamente com o valor digitado no campo (método GET)
					
					
					var url = "deficiente_trabalhador.php?id_trabalhado=<?=$id;?>&escolha="+cidade;				
					
				
						
					// Chamada do método open para processar a requisição
					req.open("Get", url, true); 
					req.setRequestHeader("Cache-Control","no-cache,no-store");
					req.setRequestHeader("Pragma", "no-cache");

					// Quando o objeto recebe o retorno, chamamos a seguinte função;
					req.onreadystatechange = function() {

					// Exibe a mensagem "Buscando Noticias..." enquanto carrega
					if(req.readyState == 1) {
					document.getElementById('deficiente').innerHTML = 'Carregando aguarde...';
					}
							
					// Verifica se o Ajax realizou todas as operações corretamente
					if(req.readyState == 4 && req.status == 200) {

					// Resposta retornada pelo busca.php
					var resposta = req.responseText;

					// Abaixo colocamos a(s) resposta(s) na div resultado
					document.getElementById('deficiente').innerHTML = resposta;
					}
					}
					req.send(null);
					req.setRequestHeader("Cache-Control", "no-cache");
					req.setRequestHeader("Pragma", "no-cache"); 
					
				
					
					}
					
								
						
					</script>
					
					
					
										<div class="form-row"   >
												<div class="label"></div>
												<div class="input-container" style='width:546px;'  >		

													Possui deficiência<font class='simbolo'><font class='simbolo'>&#10045;</font></font>
													<select name="vagadeficiente"  required='' id="vagadeficiente" onchange="deficiente(this.value);"style="width:88px;" tabindex="15">
														
														<?
																switch ($vagadeficiente){										
																case "N":											
																$vagadeficiente_N = "Não";
																break;case "S":											
																$vagadeficiente_N = "Sim";
																break;
																}
															if($vagadeficiente=="")	{}else{
														?>
														<option value="<?=$vagadeficiente;?>"><?=$vagadeficiente_N;?></option>
														<?}?>
														<option value='N' >Não</option>
														<option value='S' >Sim</option>
													</select>
													
												</div>
											</div >
											
											
											
											
											
														<div class="form-row">
															<div class="label">Mãe <font class='simbolo'>&#10045;</font></div>
															<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="mae" required value='<?=$mae;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
														</div>
														<div class="form-row">
															<div class="label">Pai</div>
															<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="pai" value='<?=$pai;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="100"  /></div>
														</div>
														
														<script language="JavaScript">

//VALIDAÇÃO DA DATA 

function VerificaData(digData) 
{
	var bis---to = 0;
	var data = digData; 
	var tam = data.length;
	if (tam == 10) 
	{
		var dia = data.substr(0,2)
		var mes = data.substr(3,2)
		var ano = data.substr(6,4)
		if ((ano > 1900)||(ano < 2100))
		{
			switch (mes) 
			{
				case '01':
				case '03':
				case '05':
				case '07':
				case '08':
				case '10':
				case '12':
					if  (dia <= 31) 
					{
						return true;
					}
					break
				
				case '04':		
				case '06':
				case '09':
				case '11':
					if  (dia <= 30) 
					{
						return true;
					}
					break
				case '02':
					/* Validando ano Bis---to / fevereiro / dia */ 
					if ((ano % 4 == 0) || (ano % 100 == 0) || (ano % 400 == 0)) 
					{ 
						bis---to = 1; 
					} 
					if ((bis---to == 1) && (dia <= 29)) 
					{ 
						return true;				 
					} 
					if ((bis---to != 1) && (dia <= 28)) 
					{ 
						return true; 
					}			
					break						
			}
		}
	}	
	alert("A Data "+data+" é inválida!");
	return false;
}
</script>
														<div class="form-row">
															<div class="label">Data Nascimento <font class='simbolo'>&#10045;</font> </div>
															<?$datanascimento2 = implode('/',array_reverse(explode('-',$datanascimento)));?>
															<div class="input-container"><input onBlur="VerificaData(this.value);" name="datanascimento" id='datanascimento'required  value='<?=$datanascimento2;?>' type="text"    class="input req-same"  /></div>
														</div>
														<div class="form-row">
															<div class="label">Naturalidade <font class='simbolo'>&#10045;</font></div>
															<div class="input-container"><input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="naturalidade" required value='<?=$naturalidade;?>'  type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="40"  /></div>
														</div>
														
														<div class="form-row">
															<div class="label">Gênero <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container"  style='width:546px;'>
															<select name="sexo" id="sexo"  required tabindex="12" width='100px' >
															<?
																			switch ($sexo){										
																			case "F":											
																			$sexo_N = "Feminino";
																			break;

																			case "M":											
																			$sexo_N = "Masculino";
																			break;
																			case "A":											
																			$sexo_N = "Ambos";
																			break;
																			}
																			?>
																			<option value="<?=$sexo;?>"><?=$sexo_N;?></option>																			
																			
																		<option value="M">Masculino</option>
																		<option value="F">Feminino</option>
																	</select></div>
														</div>
														
															<div class="form-row">
															<div class="label">Etnia? <font class='simbolo'></font> </div>
															<div class="input-container"  style='width:546px;'>
														<select name="etnia" id="etnia"  tabindex="22" style="width:240">
														
														<?
																			switch ($etnia){										
																			case "B":											
																			$etnia_N = "Branco";
																			break;
																			case "P":											
																			$etnia_N = "Parda";
																			break;
																			case "N":											
																			$etnia_N = "Negro";
																			break;
																			case "M":											
																			$etnia_N = "Mulato";
																			break;
																			case "C":											
																			$etnia_N = "Caboclos";
																			break;
																			
																			case "":											
																			$etnia_N = "Não Informar";
																			break;
																			
																			}
																			?>
																			
																		<option value="<?=$etnia;?>"><?=$etnia_N;?></option>
																		<option value="B" >Branco</option>
																		<option value="N">Negro</option>
																		<option value="P">Pardo</option>
																		<option value="M">Mulato</option>
																		<option value="C">Caboclos</option>
																		<option value="">Não Informar</option>
																		
																	</select>
														</div>
														</div>
														
														
														
														<div class="form-row">
															<div class="label">Estado Civil  </div>
															<div class="input-container"  style='width:546px;'>
															<select name="estadocivil" id="estadocivil"  tabindex="13" style="width:150px">
																		<?
																			switch ($estadocivil){										
																			case "S":											
																			$estadocivil_N = "Solteiro";
																			break;case "C":											
																			$estadocivil_N = "Casado";
																			break;case "U":											
																			$estadocivil_N = "União Estável";
																			break;case "E":											
																			$estadocivil_N = "Desquitado";
																			break;case "D":											
																			$estadocivil_N = "Divorciado";
																			break;case "V":											
																			$estadocivil_N = "Viúvo";
																			break;case "O":											
																			$estadocivil_N = "Outro";
																			break;

																		
																			}
																			?>
																				<option value="<?=$estadocivil;?>"><?=$estadocivil_N;?></option>
																				<option value="S">Solteiro</option>
																				<option value="C">Casado</option>
																				<option value="U">União Estável</option>
																				<option value="E">Desquitado</option>
																				<option value="D">Divorciado</option>
																				<option value="V">Viúvo</option>
																				<option value="O">Outro</option>
																	</select></div>
														</div>
														
														
														
																	<script type="text/javascript">

																$(document).ready(function(){
																 $('#deficiencia').hide();

																 $('#mostrar').click(function(event){
																 event.preventDefault();
																 $("#deficiencia").show("slow");
																 });

																 $('#ocultar').click(function(event){
																 event.preventDefault();
																 $("#deficiencia").hide("slow");
																 });
																 });

																</script>

																
																
											
											<div id='deficiente' name='deficiente'class="form-row" >
											
											</div>
																
																
																
																
																
																
																
																
																
																
																
																
														
														
															


														<h2>ENDEREÇO</h2>
															<div class="form-row">
															<div class="label">CEP</div>
															<div class="input-container">
															<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="cep" id="cep" style="width:200px "value="<?=$cep;?>" maxlength="8"  class="input req-same"onkeyup="verificaNumero('window.document.Ficha.cep');" tabindex="27"  type="text" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>

													<script  type="text/javascript">
													<?if($id > 0){}else{?>
														
														busca_cidade('19');
													<?}?>
													// FUNÇÃO PARA BUSCA NOTICIA
													function busca_cidade(valor2) {
													// Verificando Browser
													if(window.XMLHttpRequest) {
													req = new XMLHttpRequest();
													}
													else if(window.ActiveXObject) {
													req = new ActiveXObject("Microsoft.XMLHTTP");
													}

													// Arquivo PHP juntamente com o valor digitado no campo (método GET)

													var url = "busca_endereco.php?tipo_busca=cidade&uf="+valor2;

													// Chamada do método open para processar a requisição
													req.open("Get", url, true); 
													req.setRequestHeader("Cache-Control","no-cache,no-store");
													req.setRequestHeader("Pragma", "no-cache");

													// Quando o objeto recebe o retorno, chamamos a seguinte função;
													req.onreadystatechange = function() {

													// Exibe a mensagem "Buscando Noticias..." enquanto carrega
													if(req.readyState == 1) {
													document.getElementById('cidadeid').innerHTML = '<option >buscando</option>';
													}

													// Verifica se o Ajax realizou todas as operações corretamente
													if(req.readyState == 4 && req.status == 200) {

													// Resposta retornada pelo busca.php
													var resposta = req.responseText;

													// Abaixo colocamos a(s) resposta(s) na div resultado
													document.getElementById('cidadeid').innerHTML = resposta;
													}
													}
													req.send(null);
													req.setRequestHeader("Cache-Control", "no-cache");
													req.setRequestHeader("Pragma", "no-cache"); 

													}
													</script>
															
															
															<div class="form-row">
															<div class="label">Estado <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container">	
																<select name="txtestado" required id="txtestado" onchange="busca_cidade(this.value);" >
																
																<?if($id > 0){}else{?>
														
														<option value='19' >RJ</option>
																<?}?>
													
																<?	
												$query_estado_db = "SELECT * FROM `cidade` where id='$cidadeid' ";
												$rs_estado_db     = mysql_query($query_estado_db );
												while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
												$ufid        = $campo_estado_db ['ufid'];

													$query_estado_dbuf = "SELECT * FROM `uf` where id='$ufid' ";
													$rs_estado_dbuf     = mysql_query($query_estado_dbuf );
													while($campo_estado_dbuf  = mysql_fetch_array($rs_estado_dbuf )){
													$uf_nome        = $campo_estado_dbuf ['uf'];
													$id_uf_db        = $campo_estado_dbuf ['id'];
													}
											
												}	
												?>
												<option value='<?=$id_uf_db;?>'><?=$uf_nome ;?></option>
																						
												<?
												$query_noticias_estado = "SELECT *  FROM  `uf` ORDER BY  `uf`.`uf` ASC ";
												$rs_noticias_estado    = mysql_query($query_noticias_estado);
												while($campo_noticias_estado = mysql_fetch_array($rs_noticias_estado)){		
												$iduf 	= $campo_noticias_estado['id']; 
												$nome_uf 	= $campo_noticias_estado['uf']; 
												
												?>
												<option value='<?=$iduf;?>'><?=$nome_uf ;?></option>			
												<?}?>
																</select>	
															
															</div>
															</div>
															



															
															
																	<?	
															$query_noticias_cidadecp = "SELECT * FROM `cidade` where id='$cidadeid' ";
															$rs_noticias_cidadecp    = mysql_query($query_noticias_cidadecp);
															while($campo_noticias_cidadecp = mysql_fetch_array($rs_noticias_cidadecp)){
															$nome_cidade        = $campo_noticias_cidadecp['nome'];	
															$id_cidade        = $campo_noticias_cidadecp['id'];	
															}	
															?>
																	<div class="form-row">
															<div class="label">Cidade <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container">
																<select name="cidadeid" required id="cidadeid" onchange="busca_bairo(this.value);" >
																	<option value='<?=$id_cidade;?>'><?=$nome_cidade;?></option>
																</select>			
															</div>
															</div>
															
														
														<div class="form-row">
															<div class="label">Bairro <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container">
																<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="bairro" required id="bairro" value="<?=$bairro;?>" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();"   class="input req-same"tabindex="33"  type="text" onkeyup="this.value = this.value.toUpperCase();">
																
															</div>
															</div>
																	<script type="text/javascript">
																	$().ready(function() {
																	//var id_bairro_ecolhido = $('#bairro option:selected').val();
																	$("#endereco").autocomplete("autoComplete_endereco.php?id_bairro_ecolhido=", {
																	width: 546,
																	matchContains: true,
																	//mustMatch: true,
																	//minChars: 0,
																	//multiple: true,
																	//highlight: false,
																	//multipleSeparator: ",",
																	selectFirst: false
																	});
																	</script>
														<div class="form-row">
															<div class="label">Endereço <font class='simbolo'>&#10045;</font> </div>
															<div class="input-container">
															<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="endereco" id="endereco" required  value="<?=$endereco;?>" maxlength="400" onchange="Maiuscula(this);EditandoRegistro();"   class="input req-same"tabindex="33"  type="text" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>
														<h2>CONTATOS</h2>
														
														<div class="form-row">
															<div class="label"></div>
															<div class="input-container"   style='width:546px;'>
															Tel.: Residencial
																	<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telres" id="telres" value="<?=$telres;?>" maxlength="12"  class="input req-same"    tabindex="34" style="width:100px;" type="text" /> 
																	&nbsp;Celular <font class='simbolo'>&#10045;</font> 
																	<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telcel" required id="telcel" value="<?=$telcel;?>" maxlength="13" class="input req-same" tabindex="35" style="width:99px;" type="text" />
																	&nbsp;Recado
																	<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="telrec" id="telrec" value="<?=$telrec;?>" maxlength="14"  class="input req-same" tabindex="36" style="width:99px;" type="text" /> 
															</div>
															</div>
															
														<div class="form-row">
															<div class="label">Contato para Recados</div>
															<div class="input-container"   style='width:546px;'>
															<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="nmrecado" id="nmrecado" value="<?=$nmrecado;?>" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" class="input req-same"tabindex="37"  type="text" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>
														<div class="form-row">
															<div class="label">Email</div>
															<div class="input-container"   style='width:546px;'>
																<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="email" id="email" value="<?=$email;?>"  maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" class="input req-same" tabindex="38"  type="email" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>
															
														<h2>DOCUMENTOS</h2>
																<div class="form-row">
																<div class="label"></div>
																<div class="input-container"   style='width:546px;'>
																Identidade <font class='simbolo'>&#10045;</font> 
																<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="identidade" required id="identidade" value="<?=$identidade;?>"class="input req-same" maxlength="15" class="input req-same"tabindex="39" style="width:124px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
																
																Orgão Expedidor <font class='simbolo'>&#10045;</font>
																<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="orgaoexpedidor" required id="orgaoexpedidor" value="<?=$orgaoexpedidor;?>" class="input req-same" maxlength="50" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="40" style="width:179px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
																</div>
																</div>
														
														<div class="form-row">
															<div class="label"></div>
															<div class="input-container"   style='width:546px;'>
																	
																	
																	Possui CNH
																	<select name="tipocnh"  id="tipocnh" onchange="Maiuscula(this);EditandoRegistro();" style="width:63px;" tabindex="44">
																		<option value="<?=$tipocnh;?>"><?=$tipocnh;?></option>
																		<option value="A">A</option>
																		<option value="B">B</option>
																		<option value="C">C</option>
																		<option value="D">D</option>
																		<option value="E">E</option>
																		<option value="AB">AB</option>
																		<option value="AC">AC</option>
																		<option value="AD">AD</option>
																		<option value="AE">AE</option>
																		<option value="NÃO">NÃO</option>
																	</select>
															</div>
															</div>
														
														
														<div class="form-row">
															<div class="label"></div>
															<div class="input-container"   style='width:546px;'>
																	Carteira Trabalho 
																	<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="carteiratrabalho"  value="<?=$carteiratrabalho;?>"id="carteiratrabalho" class="input req-same" maxlength="15" onkeyup="verificaNumero('window.document.Ficha.carteiratrabalho');" tabindex="45" style="width:61px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
																	Série
																	<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="seriect"  value="<?=$seriect;?>"id="seriect" maxlength="10" class="input req-same" onkeyup="VerificaMascara('window.document.Ficha.seriect','####/@@',1)" tabindex="46" style="width:55px;" type="text" onkeyup="this.value = this.value.toUpperCase();">

																	Expedidor 
																	<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="orgaoreg"  value="<?=$orgaoreg;?>"id="orgaoreg" maxlength="10" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="48" style="width:55px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>
														
														<div class="form-row">
															<div class="label"></div>
															<div class="input-container"   style='width:546px;'>
																	PIS/PASEP
																	<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="pispasep" value="<?=$pispasep;?>"id="pispasep" maxlength="20" class="input req-same"tabindex="49" style="width:202px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
																	Passaporte 
																	<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="passaporte" value="<?=$passaporte;?>" id="passaporte" maxlength="10" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="50" style="width:188px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
															</div>
															</div>
																

														
														
															<div class="form-row">
															<div class="label">Informação interna do trabalhado</div>
															<div class="input-container"   style='width:546px;'>
																	  <textarea maxlength="400" name="infotrabalhado"   style='height:63px;' id="infotrabalhado" rows="3" cols="99" tabindex="11" style="font-size: 12px; font-family: Arial;" class="input req-same" onkeyup="funTamanhoCerto('window.document.Ficha.descricao', 500);" onchange="Maiuscula(this);
                                                                        EditandoRegistro();"><?= $infotrabalhado; ?></textarea>
															</div>
															</div>

															
															
															<div class="form-row">
															<div class="label">Alguém na residência está inscrito em algum Programa Social  <font class='simbolo'>&#10045;</font></div>
															<div class="input-container"   style='width:546px;'>
																
																	

																					<select name="programasocialid" required id="programasocialid" >
																			
																			<?	
																			$query_programasocialid_bd = "SELECT *  FROM  `programasocial` where id='$programasocialid'";
																			$rs_programasocialid_bd    = mysql_query($query_programasocialid_bd);
																			while($campo_programasocialid_bd = mysql_fetch_array($rs_programasocialid_bd)){
																			$nome_programasocialid_bd         = $campo_programasocialid_bd['nome'];	
																			$id_programasocialid_bd         = $campo_programasocialid_bd['id'];	
																				
																			?><?}?>
																		<option value="<?=$id_programasocialid_bd;?>"><?=$nome_programasocialid_bd;?></option>
																			
																			
																			
																			<?	
																			$query_programasocialid = "SELECT *  FROM  `programasocial` ORDER BY  `programasocial`.`nome` ASC ";
																			$rs_programasocialid    = mysql_query($query_programasocialid);
																			while($campo_programasocialid = mysql_fetch_array($rs_programasocialid)){
																			$nome_programasocialid         = $campo_programasocialid['nome'];	
																			$id_programasocialid         = $campo_programasocialid['id'];	
																				
																			?>
																			<option value='<?=$id_programasocialid;?>'><?=$nome_programasocialid;?></option>
																			<?}?>
																	
																					</select>
															</div>
															</div>
															
															
															<div class="form-row" >
															<div class="label"></div>
															<div class="input-container" style='width:546px;padding-bottom:162px;'>		
																<a  href="#cadastro1" style='display:none;'> DADOS DA VAGA</a>	
																<a  href="#proficional" class="sendBtn"  onclick='carrega_historico_proficional();'>Próximo &#9658;<a>	

															</div>
															</div >


												</div>
												
												
											



												<div name='proficional' id='proficional'>
												
																<div style='margin:20px;width:100%;' align='center'>
																	<font style='font-size:15px;color:red;font-weight:bold;'><a href="#cadastro1" >PASSO 1</a> &#10132; </font>
																	<font style='font-size:15px;color:red;font-weight:bold;'><a href="#proficional" >PASSO 2</a> &#10132; </font>
																	<font style='font-size:15px;color:#999;font-weight:bold;'><a  href="#qualificacao"  onclick="carrega_proficional();carrega_escolaridade();" >PASSO 3</a>  </font>

																	</div>


																			<script type="text/javascript">
																			$().ready(function() {
																			$("#cboid1").autocomplete("789/autoComplete.php", {
																			width: 546,
																			//matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});


																			$("#cboid2").autocomplete("789/autoComplete.php", {
																			width: 546,
																			//matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});

																			$("#cboid3").autocomplete("789/autoComplete.php", {
																			width: 546,
																			//matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});

																			$("#txtocupacao4").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});
																			
																			
																			
																			$("#cargo").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			//mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			//highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});
																			
																			$("#cboid1").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});
																			$("#cboid2").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});
																			
																			$("#cboid3").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,
																			//minChars: 0,
																			//multiple: true,
																			highlight: false,
																			//multipleSeparator: ",",
																			selectFirst: false
																			});
																			
																			$("#cboid").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});
																			
																			
																			});
																			</script>



																			

																			<script type="text/javascript">
																			$(function(){
																			$("#pretensaosalarial").maskMoney({symbol:'R$ ',showSymbol:true, thousands:'.', decimal:',', symbolStay: true});
																			$("#ultimosalario").maskMoney({symbol:'R$ ',showSymbol:true, thousands:'.', decimal:',', symbolStay: true});
																			})
																			</script>








																			<h2>OBJETIVOS </h2>
																			<h4>Ocupações Pretendidas / CBO</h5>


																			<div class="form-row">
																			<div class="label">1- <font class='simbolo'>&#10045;</font></div>
																			<div class="input-container">
																					
																		<?
																		$query_cboid1 = "SELECT * FROM `cbo` where id='$cboid1' ";
																		$rs_cboid1     = mysql_query($query_cboid1 );
																		while($campo_cboid1  = mysql_fetch_array($rs_cboid1 )){
																		$cbo1        = $campo_cboid1 ['cbo'];
																		}
																		?>

																			
																			
																			
																			<table><tr>
																			<td>
																			<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="cboid1" required placeholder="Escreva sua ocupação pretendida" id="cboid1" value="<?echo $cbo1;?>" class="input req-same" size="60" maxlength="200" onchange="EditandoRegistro2()" tabindex="1"  type="text" style='width:350px;'>
																			</td>
																			<td>
																			<a class="sendBtn" onclick="pop_pesquisaempresacbo1('windobuscaempresacbo1.php')" >...</a>
																			</td></tr></table>
																			</div>
																			</div>


																			<div class="form-row">
																			<div class="label">2- </div>
																			<div class="input-container">	

																				<?
																		$query_cboid2 = "SELECT * FROM `cbo` where id='$cboid2' ";
																		$rs_cboid2     = mysql_query($query_cboid2 );
																		while($campo_cboid2  = mysql_fetch_array($rs_cboid2 )){
																		$cbo2        = $campo_cboid2 ['cbo'];
																		}
																		?>	

																			<table><tr>
																			<td>
																			<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="cboid2"  placeholder="Escreva sua ocupação pretendida" id="cboid2" class="input req-same" value="<?echo $cbo2;?>"size="60" maxlength="200" onchange="EditandoRegistro2()" tabindex="1"   type="text" style='width:350px;'>	
																			</td>
																			<td>
																			<a class="sendBtn" onclick="pop_pesquisaempresacbo2('windobuscaempresacbo.php')" >...</a>
																			</td>
																			</tr></table>
																			
																			</div>
																			</div>


																			<div class="form-row">
																			<div class="label">3- </div>
																			<div class="input-container">		
																			
																			<?
																		$query_cboid3 = "SELECT * FROM `cbo` where id='$cboid3' ";
																		$rs_cboid3     = mysql_query($query_cboid3 );
																		while($campo_cboid3  = mysql_fetch_array($rs_cboid3 )){
																		$cbo3        = $campo_cboid3 ['cbo'];
																		}
																		?>	
																			
																			
																			
																			
																			
																			<table><tr>
																			<td>
																			<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="cboid3"  placeholder="Escreva sua ocupação pretendida" id="cboid3" value="<?echo $cbo3;?>"class="input req-same" size="60" maxlength="200" onchange="EditandoRegistro2()" tabindex="1"  type="text" style='width:350px;'>			
																			</td>
																			
																			<td>
																			<a class="sendBtn" onclick="pop_pesquisaempresacbo3('windobuscaempresacbo.php')" >...</a>
																			</td>
																			</tr></table>
																			
																			</div>
																			</div>



																			<div class="form-row">
																			<div class="label"></div>
																			<div class="input-container" style='width:546px;'>		
																			Pretensão Salarial
																			<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="pretensaosalarial"  id="pretensaosalarial" value=" <?echo '' . number_format($pretensaosalarial, 2, ',', '.');?>"  maxlength="14"  class="input req-same"onchange="EditandoRegistro2();" style="font-family: Tahoma; font-size: 10px;width:100px;" tabindex="17" value="" type="text"/> 
																			Último Salário
																			<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" name="ultimosalario" id="ultimosalario" value="<?echo '' . number_format($ultimosalario, 2, ',', '.');?>"  maxlength="14"  class="input req-same" onchange="EditandoRegistro2();" style="font-family: Tahoma; font-size: 10px;width:100px;" tabindex="18" value="" type="text"/> 
																			</div>
																			</div>

													
																			<? include'proficional.php'; ?> 	
																			<div class="form-row" >
																			<div class="label"></div>
																			<div class="input-container" style='width:546px;padding-bottom:162px;'>		
																			<a  href="#cadastro1"  class="sendBtn2"> &#9668; Anterior</a>	
																			<a  href="#qualificacao" class="sendBtn" onclick="carrega_proficional();carrega_escolaridade();" >Próximo &#9658;</a>	

																			</div>
																			</div >

											
													
													</div>
													
													
													
													
													
													<div name='qualificacao' id='qualificacao'>
													
														<div style='margin:20px;width:100%;' align='center'>
																	<font style='font-size:15px;color:red;font-weight:bold;'><a href="#cadastro1" >PASSO 1</a> &#10132; </font>
																	<font style='font-size:15px;color:red;font-weight:bold;'><a href="#proficional" >PASSO 2</a> &#10132; </font>
																	<font style='font-size:15px;color:red;font-weight:bold;'><a  href="#qualificacao" onclick="carrega_proficional();carrega_escolaridade();" >PASSO 3</a> </font>

																	</div>

													
														<?include'qualificacao.php';?> 
													
													
													<script type="text/javascript">

										var tempo1 = window.setInterval(carrega, 900000);
										function carrega3()
										{
										$('#mensagem').load("menssagem_form.php");

										}
										</script>
															<div class="form-row" style='padding-bottom:160px;'>
													<div class="label"></div>
														<div class="input-container" style='width:546px;'>		
															<a  href="#proficional"  class="sendBtn2"> &#9668; Anterior</a>	
															<!--<a  href="#emcaminhamentodiv" class="sendBtn"  >Próximo &#9658;</a>	-->
																																		
															<?if($id ==""){?>
																<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" id="submitBtn2" value="Concluir" type="submit" onclick='carrega3()' class="sendBtn3" />
															<?}else{?>	
																<input onBlur="maiuscula(this)" onBlur="maiuscula(this)" id="submitBtn2" value="&#10004; Concluir cadastro" onclick='carrega3()' type="submit" class="sendBtn3" />
															<?}?>
																
																<div id='mensagem' name='mensagem'></div>
																
														</div>
													</div >
													
													
							
											
														
													</div>

													



															
															
													</div>	<!--div pagginação-->				
															
										</form>	
												
										<?}?>												
														
												
												
									
											
							
							
							
			</div>
</div>




<!--------------------cria paginações paginas--------------->
<script type="text/javascript" src="jquery.idTabs.min.js"></script>

<script type="text/javascript"> 
$('div.abas').click(function(){
    $('div.abas').removeClass("abas_ative");
    $(this).addClass("abas_ative");
});
</script>
<!--------------------cria paginações paginas--------------->


</body>
</html>
