<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>




<!--
<li  ><a href="#bg-container"  ><img src='img/icone/user_add.gif'/> <br> Trabalhador</a></li>
<li><a href="#tabs-1" onClick="SelecionaMenu2('proficional.php')" > <img src='img/icone/cog_edit.png'/><br> Perfil <br>Profissional </a></li>
<li><a href="#tabs-2" onClick="SelecionaMenu2('qualificacao.php')"><img src='img/icone/plugin_add.gif'/> <br>Qualificação<br> Profissional </a></li>
<li><a href="#tabs-3" onClick="SelecionaMenu2('idiaomas.php')"><img src='img/icone/feed_add.png'/><br> Idiomas</a></li>
<li><a href="#tabs-4" onClick="SelecionaMenu2('socio_economico.php')"><img src='img/icone/information.png'/><br> Perfil <br>Sócio-Econômico </a></li>
<li><a href="#tabs-5" onClick="SelecionaMenu2('carteira_trabalho.php')"><img src='img/icone/book.png'/><br> Emissão <br>de CTPS  </a></li>
<li><a href="#tabs-6" onClick="SelecionaMenu2('conteudo.php')"><img src='img/icone/user_add.gif'/><br> Economia <br>Popular  </a></li>
<li><a href="#tabs-7" onClick="SelecionaMenu2('acompanhamento.php')"><img src='img/icone/application_view_list.png'/><br> Acompanhamento </a></li>
<li><a href="#tabs-8" onClick="SelecionaMenu2('encaminhamento.php')"><img src='img/icone/application_go.png'/><br> Encaminhamento</a></li>
-->


<?
		$cpf_busca 	= $_GET['cpf_busca']; 
		
		if($cpf_busca==''){} else{
		$query_noticias = "SELECT * FROM `trabalhador` WHERE `cpf` LIKE '%$cpf_busca%'";
		$rs_noticias    = mysql_query($query_noticias);
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$id_trabalhador 	= $campo_noticias['id_trabalhador']; 
		$cpf 	= $campo_noticias['cpf']; 	 		 			 	
		$nome 	= $campo_noticias['nome']; 
		$mae 	= $campo_noticias['mae'];	 		 			 	
		$pai 	= $campo_noticias['pai'];	 		 			 	
		$data_nsc 	= $campo_noticias['data_nsc']; 	 		 			 	
		$naturidade 	= $campo_noticias['naturidade']; 	 		 			 	
		$cbosexo 	= $campo_noticias['cbosexo']; 	 		 			 	
		$cboestadocivil 	= $campo_noticias['cboestadocivil']; 	 		 			 	
		$cboetnia 	= $campo_noticias['cboetnia']; 	 		 			 	
		$txtfilhosnr 	= $campo_noticias['txtfilhosnr']; 	 		 			 	
		$txtfilhosestudantes 	= $campo_noticias['txtfilhosestudantes']; 	 		 			 	
		$txttrabalhando 	= $campo_noticias['txttrabalhando']; 	 		 			 	
		$txtmeres 	= $campo_noticias['txtmeres']; 	 		 			 	
		$txtmenores 	= $campo_noticias['txtmenores']; 	 		 			 	
		$txtmenores 	= $campo_noticias['txtmenores']; 	 		 			 	
		$cbodeficiencia 	= $campo_noticias['cbodeficiencia']; 	 		 			 	
		$cbolaudo 	= $campo_noticias['cbolaudo']; 	 		 			 	
		$txtlimitacoes 	= $campo_noticias['txtlimitacoes']; 	 		 			 	
		$cboIntencao 	= $campo_noticias['cboIntencao']; 	 		 			 	
		$cboTemporario 	= $campo_noticias['cboTemporario']; 	 		 			 	
		$cboservida 	= $campo_noticias['cboservida']; 	 		 			 	
		$cboNoturno 	= $campo_noticias['cboNoturno']; 	 		 			 	
		$cbotur 	= $campo_noticias['cbotur']; 	 		 			 	
		$cbofeira 	= $campo_noticias['cbofeira']; 	 		 			 	
		$txtcep 	= $campo_noticias['txtcep']; 	 		 			 	
		$txtestado 	= $campo_noticias['txtestado']; 	 		 			 	
		$txtcidade 	= $campo_noticias['txtcidade']; 	 		 			 	
		$txtbairro 	= $campo_noticias['txtbairro']; 	 		 			 	
		$txtendereco 	= $campo_noticias['txtendereco']; 	 		 			 	
		$txttelres 	= $campo_noticias['txttelres']; 	 		 			 	
		$txttelcel 	= $campo_noticias['txttelcel']; 	 		 			 	
		$txttelrec 	= $campo_noticias['txttelrec']; 	 		 			 	
		$txtnmrecado 	= $campo_noticias['txtnmrecado']; 	 		 			 	
		$txtemail 	= $campo_noticias['txtemail'];	 		 			 	
		$txtidentidade 	= $campo_noticias['txtidentidade']; 	 		 			 	
		$txtorgaoexpedidor 	= $campo_noticias['txtorgaoexpedidor']; 	 		 			 	
		$txttitulo 	= $campo_noticias['txttitulo']; 	 		 			 	
		$txtzona 	= $campo_noticias['txtzona']; 	 		 			 	
		$txtsecao 	= $campo_noticias['txtsecao']; 	 		 			 	
		$seltipocnh 	= $campo_noticias['seltipocnh']; 	 		 			 	
		$txtcarttrabalho 	= $campo_noticias['txtcarttrabalho']; 	 		 			 	
		$txtserie 	= $campo_noticias['txtserie']; 	 		 			 	
		$txtregistroprof 	= $campo_noticias['txtregistroprof']; 	 		 			 	
		$txtorgaoreg 	= $campo_noticias['txtorgaoreg']; 	 		 			 	
		$txtpispasep 	= $campo_noticias['txtpispasep']; 	 		 			 	
		$txtpassaporte 	= $campo_noticias['txtpassaporte']; 	 		 			 	
		$txtmoracom 	= $campo_noticias['txtmoracom']; 	 		 			 	
		$txtmorapais 	= $campo_noticias['txtmorapais']; 	 		 			 	
		$txtmoracompanheiro 	= $campo_noticias['txtmoracompanheiro']; 	 		 			 	
		$txtmoraoutros 	= $campo_noticias['txtmoraoutros']; 	 		 			 	
		$txtmorafilhos 	= $campo_noticias['txtmorafilhos']; 	 		 			 	
		$txtmorafilhos1 	= $campo_noticias['txtmorafilhos1']; 	 		 			 	
		$txtmorafilhos2 	= $campo_noticias['txtmorafilhos2']; 	 		 			 	
		$txtmorafilhos3 	= $campo_noticias['txtmorafilhos3']; 	 		 			 	
		$txtmorairmaos 	= $campo_noticias['txtmorairmaos']; 	 		 			 	
		$txtmorairmaos1 	= $campo_noticias['txtmorairmaos1']; 	 		 			 	
		$txtmorairmaos2 	= $campo_noticias['txtmorairmaos2']; 	 		 			 	
		$txtmorairmaos22 	= $campo_noticias['txtmorairmaos22']; 	 		 			 	
		$txtmorairmaos3 	= $campo_noticias['txtmorairmaos3']; 	 		 			 	
		$txtrendafamiliar 	= $campo_noticias['txtrendafamiliar']; 	 		 			 	
		$selchefefamilia 	= $campo_noticias['selchefefamilia']; 	 		 			 	
		$selprogramassociais 	= $campo_noticias['selprogramassociais']; 	 		 			 	
		$cboprocesso 	= $campo_noticias['cboprocesso']; 	 		 			 	
		$cbosoube_caet 	= $campo_noticias['cbosoube_caet']; 	 		 			 	
		$selcidacaptado 	= $campo_noticias['selcidacaptado']; 	 		 			 	
		$selcidaatraves 	= $campo_noticias['selcidaatraves']; 	 		 			 	
		$selLocalDocs 	= $campo_noticias['selLocalDocs']; 	 		 			 	
		$txthistorico	= $campo_noticias['txthistorico'];
		$id_trabalhador 	= $campo_noticias['id_trabalhador']; 
		$txthabilidades1 = $campo_noticias['txthabilidades1'];
		$txthabilidades2 = $campo_noticias['txthabilidades2'];
		$txthabilidades3 = $campo_noticias['txthabilidades3'];
		$txtocupacao1 =  $campo_noticias['txtocupacao1'];
		$txtocupacao2 =  $campo_noticias['txtocupacao2'];
		$txtocupacao3 =  $campo_noticias['txtocupacao3'];
		$txtPretensaoSalarial =  $campo_noticias['txtPretensaoSalarial'];
		$txtUltimoSalario =  $campo_noticias['txtUltimoSalario'];
		$cboescolaridade 	= $campo_noticias['cboescolaridade']; 
		$cbosituacao 	= $campo_noticias['cbosituacao']; 
		$cboserie 	= $campo_noticias['cboserie']; 
		$cboturno 	= $campo_noticias['cboturno']; 
		$cbopos 	= $campo_noticias['cbopos']; 
		$cbocurso 	= $campo_noticias['cbocurso']; 
		$txtoutrocurso 	= $campo_noticias['txtoutrocurso']; 
		$txtinstituicao 	= $campo_noticias['txtinstituicao']; 
		$selcomprovacao 	= $campo_noticias['selcomprovacao']; 
		$txIdioma 	= $campo_noticias['txIdioma']; 
		$txIdioma2 	= $campo_noticias['txIdioma2']; 
		$txIdioma3 	= $campo_noticias['txIdioma3']; 
		$idioma1 	= $campo_noticias['idioma1']; 
		$idioma2 	= $campo_noticias['idioma2']; 
		$idioma3 	= $campo_noticias['idioma3']; 
		$leitura1 	= $campo_noticias['leitura1']; 
		$leitura2 	= $campo_noticias['leitura2']; 
		$leitura3	= $campo_noticias['leitura3']; 
		$convesacao1	= $campo_noticias['convesacao1']; 
		$convesacao2	= $campo_noticias['convesacao2']; 
		$convesacao3	= $campo_noticias['convesacao3']; 
		$escrita1	= $campo_noticias['escrita1']; 
		$escrita2	= $campo_noticias['escrita2']; 
		$escrita3	= $campo_noticias['escrita3']; 
		$data	= $campo_noticias['data']; 
		$dia	= $campo_noticias['dia']; 
		$mes	= $campo_noticias['mes']; 
		$ano	= $campo_noticias['ano']; 
		$cadastrado_por	= $campo_noticias['cadastrado_por']; 
		}					
	}					


		

?>



<div style='width:100%;float:left;background-color:#157FCC;'align='center' class="idTabs" id='idTabs'>
	<a  href="#cadastro1" ><div   class='abas' style='margin-left:50px;' ><img src='img/icone/user_add.gif'/> <br> Trabalhador</div></a>
	<a  href='#proficional' onclick="carrega_historico_proficional()"> <div   class='abas' <?if($id_trabalhador==""){echo"style='opacity:0.34;	-moz-opacity:0.34;	filter: alpha(opacity=34);'";}else{}?> ><img src='img/icone/cog_edit.png'/><br> Perfil <br>Profissional </div></a>
	<a href="#qualificacao" onClick="carrega_proficional()"><div   class='abas'  <?if($id_trabalhador==""){echo"style='opacity:0.34;	-moz-opacity:0.34;	filter: alpha(opacity=34);'";}else{}?>><img src='img/icone/plugin_add.gif'/> <br>Qualificação<br> Profissional </div></a>
	<!--<a href="#idiaomas" ><div   class='abas'  ><img src='img/icone/feed_add.png'/><br> Idiomas</div></a>-->
	<!--<a href="#socio_economico" ><div   class='abas'  ><img src='img/icone/information.png'/><br> Perfil <br>Sócio-Econômico </div></a>-->
	<!--<a href="#carteira_trabalho" ><div   class='abas'  ><img src='img/icone/book.png'/><br> Emissão <br>de CTPS  </div></a>-->
	<!--<a href="#conteudo" ><div   class='abas'  ><img src='img/icone/user_add.gif'/><br> Economia <br>Popular  </div></a>-->
	<!--<a href="#acompanhamento" ><div   class='abas'  ><img src='img/icone/application_view_list.png'/><br> Acompanhamento </div></a>-->
	<a href="#emcaminhamentodiv" onclick="carrega()"><div   class='abas'  <?if($id_trabalhador==""){echo"style='opacity:0.34;	-moz-opacity:0.34;	filter: alpha(opacity=34);'";}else{}?> ><img src='img/icone/application_go.png'/><br> Encaminhamento</div></a>
</div>


		

<div id="content" name='contente' onload='carrega()'>
<div id="container">


<div id="bg-container"   class='contener'>
				
				
				
				<div id="cadastro1" name='cadastro1'>
				
				<?if($cpf_busca ==""){?>
			<form  class="form" method="get" action=""  id="cadastro" name='cadastro' onSubmit="return validar_cpf()">			
				
				<div class="form-row">
				<div class="label">CPF:</div>
				<div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cpf_busca" id='cpf_busca' placeholder="Insira o CPF" type="text"  class="input req-same" maxlength="14"  /></div>
				</div>
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container" style='width:546px;'>		
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Buscar" type="submit" class="sendBtn"  onclick='return validar_cpf()' />
				<div id="errorDiv2" class="error-div"></div>
				</div>
				</div>
	
			</form>
				
				<?}
				
				else
				
				
				{?>

<form  class="form" method="post"  <?if($id_trabalhador ==""){echo" action='script_cadastro.php?acao=cadastro' "; }else{ echo" action='script_cadastro.php?acao=editar' ";}?>>


		<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type='hidden' name='id_trabalhador' value='<?=$id_trabalhador;?>'/>
		
  	<h2>DADOS PESSOAIS</h2>
	
  	<!--<h3>Same fields required example</h3>-->
  		
	<div class="form-row" >
	    <div class="label"></div>
	    <div class="input-container" style='width:541px;'>
			<?
			$sql3e = "select usuario  from usuarios where id  ='$cadastrado_por'";
			$rsd3e = mysql_query($sql3e);
			while($rs3e = mysql_fetch_array($rsd3e)) {
			$usuario_ajaxe= $rs3e['usuario'];	}
			?>
		ID: <input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" style='width:70px'  class="input req-same"value='<?=$id_trabalhador;?>'readonly="true"  type="text"   /><br>
		Cadastro: <input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" style='width:70px' class="input req-same" value='<?=$data;?>'readonly="true"  type="text"   /><br>
		Atualizado: <input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" style='width:70px'  class="input req-same"value='<?=$dia;?>-<?=$mes;?>-<?=$ano;?>'readonly="true"  type="text"   /><br>
		 Atendente : <input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" style='width:70px' class="input req-same" value='<?=$usuario_ajaxe;?>'readonly="true"  type="text"   />
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">CPF</div>
	    <div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" style='width:200px'  readonly="true" name="cpf" value='<?=$cpf_busca;?>' onkeypress="formatar_mascara(this, '###.###.###-##')" type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="14"  /></div>
	</div>
	<div class="form-row">
	    <div class="label">Nome</div>
	    <div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="nome" required  value='<?=$nome;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="40"  /></div>
	</div>
	<div class="form-row">
	    <div class="label">Mãe</div>
	    <div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="mae" value='<?=$mae;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="40"  /></div>
	</div>
	<div class="form-row">
	    <div class="label">Pai</div>
	    <div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="pai" value='<?=$pai;?>'type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="40"  /></div>
	</div>
	<div class="form-row">
	    <div class="label">Data Nascimento </div>
	    <div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="data_nsc" required  value='<?=$data_nsc;?>' type="text"   onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="10"  /></div>
	</div>
	<div class="form-row">
	    <div class="label">Naturalidade</div>
	    <div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="naturidade" required value='<?=$naturidade;?>'  type="text" onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="40"  /></div>
	</div>
	<div class="form-row">
	    <div class="label">Gênero </div>
	    <div class="input-container">
		<select name="cbosexo" id="cbosexo"  required tabindex="12" >
					<option value="<?=$cbosexo;?>"><?=$cbosexo;?></option>
					<option value="Masculino">Masculino</option>
					<option value="Feminino">Feminino</option>
				</select></div>
	</div>
	<div class="form-row">
	    <div class="label">Estado Civil</div>
	    <div class="input-container">
		<select name="cboestadocivil" id="cboestadocivil" required tabindex="13" style="width:100">
					<option value="<?=$cboestadocivil;?>"><?=$cboestadocivil;?></option>
					<option value="Solteiro(a">Solteiro(a)</option>
					<option value="Casado(a)">Casado(a)</option>
					<option value="União Estável">União Estável</option>
					<option value="Desquitado(a)">Desquitado(a)</option>
					<option value="Divorciado(a">Divorciado(a)</option>
					<option value="Viúvo(a)">Viúvo(a)</option>
					<option value="Outros">Outros</option>
				</select></div>
	</div>
	<div class="form-row">
	    <div class="label">Etnia</div>
	    <div class="input-container">
		<select name="cboetnia" id="cboetnia" required tabindex="14" style="width:110">
					<option value="<?=$cboetnia;?>"><?=$cboetnia;?></option>
					<option value="AMARELA">AMARELA</option>
					<option value="BRANCA">BRANCA</option>
					<option value="INDÍGENA">INDÍGENA</option>
					<option value="NÃO DECLARADA">NÃO DECLARADA</option>
					<option value="NEGRA">NEGRA</option>
					<option value="PARDA">PARDA</option>
						
				</select></div>
	</div>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>
				Filhos
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtfilhosnr" value='<?=$txtfilhosnr;?>' id="txtfilhosnr" maxlength="2"  class="input req-same"onkeyup="verificaNumero('window.document.Ficha.txtfilhosnr');" tabindex="15" style="width:73px;" type="text" onkeyup="this.value = this.value.toUpperCase();"/>
				Estudantes 
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtfilhosestudantes" value='<?=$txtfilhosestudantes;?>'  id="txtfilhosestudantes"  class="input req-same"maxlength="2" onkeyup="verificaNumero('window.document.Ficha.txtfilhosestudantes');" tabindex="16" style="width:73px;" type="text" onkeyup="this.value = this.value.toUpperCase();"/>
				Trabalhando 
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txttrabalhando" value='<?=$txttrabalhando;?>'  id="txttrabalhando" maxlength="2"  class="input req-same"onkeyup="verificaNumero('window.document.Ficha.txttrabalhando');" tabindex="17" style="width:73px;" type="text" onkeyup="this.value = this.value.toUpperCase();"/>
				Menores 
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtmenores" value='<?=$txtmenores;?>'  id="txtmenores" maxlength="2"  class="input req-same"onkeyup="verificaNumero('window.document.Ficha.txtmenores');" tabindex="18" style="width:74px;" type="text" onkeyup="this.value = this.value.toUpperCase();"/>
		</div>
	</div>
	
	
				<script type="text/javascript">

			$(document).ready(function(){
			 $('#deficiencia').hide();

			 $('#mostrar').click(function(event){
			 event.preventDefault();
			 $("#deficiencia").show("slow");
			 });

			 $('#ocultar').click(function(event){
			 event.preventDefault();
			 $("#deficiencia").hide("slow");
			 });
			 });

			</script>

	
	<?if($cbodeficiencia==""){?>
	<div class="form-row">
	    <div class="label"><font style='color:red;'>Possui deficiência:</font> </div>
	    <div class="input-container" style='width:546px;'>
		<font style='color:red;'>
			 Sim<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='tem' id="mostrar" value="S"  type="radio"/>	
			 Não<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='tem' id="ocultar"  value="N"  type="radio"/>	
			</font>	
				<img src='img/deficiente.png'>		
		</div>
	</div>
	<?}else{ }?>
	<div <?if($cbodeficiencia==""){echo"id='deficiencia'";}else{ }?>>
	<div class="form-row">
	    <div class="label">Tipo de deficiência</div>
	    <div class="input-container">
		<select name="cbodeficiencia" id="cbodeficiencia" tabindex="19" style="width:328">
				<option value="<?=$cbodeficiencia;?>"><?=$cbodeficiencia;?></option>
				<option value="AUDITIVA">AUDITIVA</option>
				<option value="FÍSICA">FÍSICA</option>
				<option value="MENTAL">MENTAL</option>
				<option value="OUTRAS">OUTRAS</option>
				<option value="VISUAL">VISUAL</option>

				</select>
	</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Laudo</div>
	    <div class="input-container">
			<select name="cbolaudo" id="cbolaudo" tabindex="20" style="width:42">
			<option value="<?=$cbolaudo;?>"><?=$cbolaudo;?></option>
			<option value="Não" >Não</option>
			<option value="Sim">Sim</option>
			</select>
	</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Nível de Limitação</div>
	    <div class="input-container">
			<textarea name="txtlimitacoes" id="txtlimitacoes"  class="input req-same" rows="2" cols="96" tabindex="21" style="font-size: 12px; font-family: Arial;height:56px;" onkeyup="funTamanhoCerto('window.document.Ficha.txtlimitacoes', 200);" onchange="Maiuscula(this);EditandoRegistro();"><?=$txtlimitacoes;?></textarea>
	</div>
	</div>
</div>	
	
	
	<div class="form-row">
	    <div class="label">Intenção?</div>
	    <div class="input-container">
	<select name="cboIntencao" id="cboIntencao" required tabindex="22" style="width:140">
					<option value="<?=$cboIntencao;?>"><?=$cboIntencao;?></option>
					<option value="Emprego" >Emprego</option>
					<option value="1º Emprego">1º Emprego</option>
					<option value="Estágio">Estágio</option>
					<option value="Curso">Curso</option>
					<option value="Emissão de Documentos">Emissão de Documentos</option>
					<option value="Emprego/Curso">Emprego/Curso</option>
					<option value="Emprego/Emissão de Documentos">Emprego/Emissão de Documentos</option>
					<option value="Curso/Emissão de Documentos">Curso/Emissão de Documentos</option>
					<option value="Todas">Todas</option>
				</select>
	</div>
	</div>
	
	
		
	
	
	
	
		


  	<h2>ENDEREÇO</h2>
		<div class="form-row">
		<div class="label">CEP</div>
		<div class="input-container">
		<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtcep" id="txtcep" value="<?=$txtcep;?>" maxlength="8"  class="input req-same"onkeyup="verificaNumero('window.document.Ficha.txtcep');" tabindex="27"  type="text" onkeyup="this.value = this.value.toUpperCase();">
		</div>
		</div>

<script  type="text/javascript">	
// FUNÇÃO PARA BUSCA NOTICIA
function busca_cidade(valor2) {
// Verificando Browser
if(window.XMLHttpRequest) {
req = new XMLHttpRequest();
}
else if(window.ActiveXObject) {
req = new ActiveXObject("Microsoft.XMLHTTP");
}

// Arquivo PHP juntamente com o valor digitado no campo (método GET)

var url = "busca_endereco.php?tipo_busca=cidade&uf="+valor2;

// Chamada do método open para processar a requisição
req.open("Get", url, true); 
req.setRequestHeader("Cache-Control","no-cache,no-store");
req.setRequestHeader("Pragma", "no-cache");

// Quando o objeto recebe o retorno, chamamos a seguinte função;
req.onreadystatechange = function() {

// Exibe a mensagem "Buscando Noticias..." enquanto carrega
if(req.readyState == 1) {
document.getElementById('txtcidade').innerHTML = '<option >buscando</option>';
}

// Verifica se o Ajax realizou todas as operações corretamente
if(req.readyState == 4 && req.status == 200) {

// Resposta retornada pelo busca.php
var resposta = req.responseText;

// Abaixo colocamos a(s) resposta(s) na div resultado
document.getElementById('txtcidade').innerHTML = resposta;
}
}
req.send(null);
req.setRequestHeader("Cache-Control", "no-cache");
req.setRequestHeader("Pragma", "no-cache"); 

}
</script>
		
		
		<div class="form-row">
		<div class="label">Estado</div>
		<div class="input-container">	
			<select name="txtestado" required id="txtestado" onchange="busca_cidade(this.value);" >
			
			<?	$query_noticias_cidadeuf = "SELECT * FROM `uf`  where cd_uf ='$txtestado'";
			$rs_noticias_cidadeuf    = mysql_query($query_noticias_cidadeuf);
			while($campo_noticias_cidadeuf = mysql_fetch_array($rs_noticias_cidadeuf)){
			$ds_uf_nome        = $campo_noticias_cidadeuf['ds_uf_nome'];	
			$cd_uf        = $campo_noticias_cidadeuf['cd_uf'];	
			}
			?>
	
	
					<option value='<?=$cd_uf;?>'><?=$ds_uf_nome;?></option>
				<?
					$query_noticias_estado = "SELECT * FROM `uf` ORDER BY `uf`.`ds_uf_nome` ASC";
					$rs_noticias_estado    = mysql_query($query_noticias_estado);
					while($campo_noticias_estado = mysql_fetch_array($rs_noticias_estado)){		
					$ds_uf_sigla 	= $campo_noticias_estado['cd_uf']; 
					$ds_uf_nome 	= $campo_noticias_estado['ds_uf_nome']; 
				?>
				<option value='<?=$ds_uf_sigla;?>'><?=$ds_uf_nome ;?></option>			
				<?}?>
			</select>	
		
		</div>
		</div>
		



					<script  type="text/javascript">	
					// FUNÇÃO PARA BUSCA NOTICIA
					function busca_bairo(cidade) {
					// Verificando Browser
					if(window.XMLHttpRequest) {
					req = new XMLHttpRequest();
					}
					else if(window.ActiveXObject) {
					req = new ActiveXObject("Microsoft.XMLHTTP");
					}

					// Arquivo PHP juntamente com o valor digitado no campo (método GET)

					var url = "busca_endereco.php?tipo_busca=bairro&cidade="+cidade;

					// Chamada do método open para processar a requisição
					req.open("Get", url, true); 
					req.setRequestHeader("Cache-Control","no-cache,no-store");
					req.setRequestHeader("Pragma", "no-cache");

					// Quando o objeto recebe o retorno, chamamos a seguinte função;
					req.onreadystatechange = function() {

					// Exibe a mensagem "Buscando Noticias..." enquanto carrega
					if(req.readyState == 1) {
					document.getElementById('txtbairro').innerHTML = '<option >buscando</option>';
					}

					// Verifica se o Ajax realizou todas as operações corretamente
					if(req.readyState == 4 && req.status == 200) {

					// Resposta retornada pelo busca.php
					var resposta = req.responseText;

					// Abaixo colocamos a(s) resposta(s) na div resultado
					document.getElementById('txtbairro').innerHTML = resposta;
					}
					}
					req.send(null);
					req.setRequestHeader("Cache-Control", "no-cache");
					req.setRequestHeader("Pragma", "no-cache"); 

					}
					</script>
		
		
	<?	
	$query_noticias_cidadecp = "SELECT * FROM `cidades` where cd_cidade='$txtcidade' ";
	$rs_noticias_cidadecp    = mysql_query($query_noticias_cidadecp);
	while($campo_noticias_cidadecp = mysql_fetch_array($rs_noticias_cidadecp)){
	$ds_cidade_nome        = $campo_noticias_cidadecp['ds_cidade_nome'];	
	$cd_cidade        = $campo_noticias_cidadecp['cd_cidade'];	
	}	
	?>
				<div class="form-row">
		<div class="label">Cidade</div>
		<div class="input-container">
			<select name="txtcidade" required id="txtcidade" onchange="busca_bairo(this.value);" >
				<option value='<?=$cd_cidade;?>'><?=$ds_cidade_nome;?></option>
			</select>			
		</div>
		</div>
		
	<?	
	$query_noticias_cidadebp = "SELECT * FROM `bairros` WHERE cd_bairro = '$txtbairro'"; 
	$rs_noticias_cidadebp    = mysql_query($query_noticias_cidadebp);
	while($campo_noticias_cidadebp = mysql_fetch_array($rs_noticias_cidadebp)){
	$cd_bairro        = $campo_noticias_cidadebp['cd_bairro'];	
	$ds_bairro_nome         = $campo_noticias_cidadebp['ds_bairro_nome'];	
	}
	?>
	<div class="form-row">
		<div class="label">Bairro</div>
		<div class="input-container">
			<!--<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtbairro" required id="txtbairro" value="<?//=$txtbairro;?>" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();"   class="input req-same"tabindex="33"  type="text" onkeyup="this.value = this.value.toUpperCase();">-->
			<select name="txtbairro" required id="txtbairro">
			<option value='<?=$cd_bairro;?>'><?=$ds_bairro_nome ;?></option>
			
			</select>	
			
		</div>
		</div>
				<script type="text/javascript">
				$().ready(function() {
				//var id_bairro_ecolhido = $('#txtbairro option:selected').val();
				$("#txtendereco").autocomplete("autoComplete_endereco.php?id_bairro_ecolhido=", {
				width: 546,
				matchContains: true,
				//mustMatch: true,
				//minChars: 0,
				//multiple: true,
				//highlight: false,
				//multipleSeparator: ",",
				selectFirst: false
				});
				</script>
	<div class="form-row">
		<div class="label">Endereço</div>
		<div class="input-container">
		<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtendereco" id="txtendereco" required  value="<?=$txtendereco;?>" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();"   class="input req-same"tabindex="33"  type="text" onkeyup="this.value = this.value.toUpperCase();">
		</div>
		</div>
  	<h2>CONTATOS</h2>
	
	<div class="form-row">
		<div class="label"></div>
		<div class="input-container"   style='width:546px;'>
		Telefones: Residencial
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txttelres" id="txttelres" value="<?=$txttelres;?>" maxlength="12"  class="input req-same" onkeypress="formatar_mascara(this, '##.####-####')"   tabindex="34" style="width:100px;" type="text" onkeyup="this.value = this.value.toUpperCase();"> 
				&nbsp;Celular
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txttelcel" required id="txttelcel" value="<?=$txttelcel;?>" maxlength="13" class="input req-same" onkeypress="formatar_mascara(this, '##.#####-####')"tabindex="35" style="width:99px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
				&nbsp;Recado
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txttelrec" id="txttelrec" value="<?=$txttelrec;?>" maxlength="14"  class="input req-same" tabindex="36" style="width:99px;" type="text" onkeyup="this.value = this.value.toUpperCase();"> 
		</div>
		</div>
		
	<div class="form-row">
		<div class="label">Dados para Recados</div>
		<div class="input-container"   style='width:546px;'>
		<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtnmrecado" id="txtnmrecado" value="<?=$txtnmrecado;?>" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" class="input req-same"tabindex="37"  type="text" onkeyup="this.value = this.value.toUpperCase();">
		</div>
		</div>
	<div class="form-row">
		<div class="label">Email</div>
		<div class="input-container"   style='width:546px;'>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtemail" required id="txtemail" value="<?=$txtemail;?>"  maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" class="input req-same" tabindex="38"  type="text" onkeyup="this.value = this.value.toUpperCase();">
		</div>
		</div>
		
	<h2>DOCUMENTOS</h2>
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container"   style='width:546px;'>
			Identidade
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtidentidade" required id="txtidentidade" value="<?=$txtidentidade;?>"class="input req-same" maxlength="20" class="input req-same"tabindex="39" style="width:124px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
			Orgão Expedidor
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtorgaoexpedidor" required id="txtorgaoexpedidor" value="<?=$txtorgaoexpedidor;?>" class="input req-same" maxlength="10" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="40" style="width:254px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
			</div>
			</div>
	
	<div class="form-row">
		<div class="label"></div>
		<div class="input-container"   style='width:546px;'>
				
				
				Categoria da CNH
				<select name="seltipocnh" required id="seltipocnh" onchange="Maiuscula(this);EditandoRegistro();" style="width:63px;" tabindex="44">
					<option value="<?=$seltipocnh;?>"><?=$seltipocnh;?></option>
					<option value="A">A</option>
					<option value="B">B</option>
					<option value="C">C</option>
					<option value="D">D</option>
					<option value="E">E</option>
					<option value="AB">AB</option>
					<option value="AC">AC</option>
					<option value="AD">AD</option>
					<option value="AE">AE</option>
					<option value="não tem">Não tem</option>
				</select>
		</div>
		</div>
	
	
	<div class="form-row">
		<div class="label"></div>
		<div class="input-container"   style='width:546px;'>
				Carteira Trabalho
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtcarttrabalho" value="<?=$txtcarttrabalho;?>"id="txtcarttrabalho" class="input req-same" maxlength="18" onkeyup="verificaNumero('window.document.Ficha.txtcarttrabalho');" tabindex="45" style="width:61px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
				Série
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtserie" value="<?=$txtserie;?>"id="txtserie" maxlength="9" class="input req-same" onkeyup="VerificaMascara('window.document.Ficha.txtserie','####/@@',1)" tabindex="46" style="width:55px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
				Reg. Prof.
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtregistroprof" value="<?=$txtregistroprof;?>"id="txtregistroprof" class="input req-same" maxlength="20" onchange="Maiuscula(this);EditandoRegistro();" tabindex="47" style="width:104px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
				Expedidor
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtorgaoreg" value="<?=$txtorgaoreg;?>"id="txtorgaoreg" maxlength="10" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="48" style="width:55px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
		</div>
		</div>
	
	<div class="form-row">
		<div class="label"></div>
		<div class="input-container"   style='width:546px;'>
				PIS/PASEP
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtpispasep" value="<?=$txtpispasep;?>"id="txtpispasep" maxlength="20" class="input req-same"tabindex="49" style="width:217px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
				Passaporte 
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtpassaporte" value="<?=$txtpassaporte;?>" id="txtpassaporte" maxlength="10" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="50" style="width:188px;" type="text" onkeyup="this.value = this.value.toUpperCase();">
		</div>
		</div>
			

	
	<div class="form-row">
		<div class="label">
		</div>
		<div class="input-container"   style='width:546px;'>
				<script type="text/javascript">
		$(function(){
			$("#txtrendafamiliar").maskMoney({symbol:'R$ ',showSymbol:true, thousands:'.', decimal:',', symbolStay: true});
					})
		</script>
				<b>Renda Familiar</b>
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtrendafamiliar" id="txtrendafamiliar" value="<?=$txtrendafamiliar;?>"  class="input req-same"  maxlength="20" onkeyup="VerificaMascara('window.document.Ficha.txtrendafamiliar','###.###.###,##',0)" tabindex="63" style="width:293px" type="text" onkeyup="this.value = this.value.toUpperCase();">
				<b>Chefe de Família</b>
				<select name="selchefefamilia" id="selchefefamilia" onchange="Maiuscula(this);EditandoRegistro();" style="width:63px;" tabindex="64">
					<option value="<?=$selchefefamilia;?>"><?=$selchefefamilia;?></option>
					<option value="Sim">Sim</option>
					<option value="Não">Não</option>
				</select>
		</div>
		</div>
		
		
		<div class="form-row">
		<div class="label">Alguém na residência está inscrito em algum Programa Social</div>
		<div class="input-container"   style='width:546px;'>
			
				

								<select name="selprogramassociais" id="selprogramassociais" >
				<option value="<?=$selprogramassociais;?>"><?=$selprogramassociais;?></option>
				<option value="APOSENTADORIA - IDADE">APOSENTADORIA - IDADE</option>
				<option value="APOSENTADORIA - INVALIDEZ">APOSENTADORIA - INVALIDEZ</option>
				<option value="AUXILIO DOENÇA">AUXILIO DOENÇA</option>
				<option value="BOLSA FAMILIA">BOLSA FAMILIA</option>
				<option value="CESTA BÁSICA">CESTA BÁSICA</option>
				<option value="JOVEM APRENDIZ">JOVEM APRENDIZ</option>
				<option value="OUTROS">OUTROS</option>
				<option value="PETI">PETI</option>
				<option value="SEGURO DESEMPREGO">SEGURO DESEMPREGO</option>
					
								</select>
		</div>
		</div>
		
		
		<h2>CTM</h2>
		
		<div class="form-row">
		<div class="label"></div>
		<div class="input-container"   style='width:546px;'>
				
				<b>Como soube da CTM</b>
				<select name="cbosoube_caet" required id="cbosoube_caet" tabindex="76" style="width:229px">
					<option value="<?=$cbosoube_caet;?>"><?=$cbosoube_caet;?></option>
					<option value="AMIGOS">AMIGOS</option>
					<option value="INTERNET">INTERNET</option>
					<option value="JORNAIS">JORNAIS</option>
					<option value="OUTROS">OUTROS</option>
					<option value="RADIO">RADIO</option>
					<option value="REVISTAS">REVISTAS</option>
					<option value="TELEVISÃO">TELEVISÃO</option>
					</select>
		</div>
		</div>
		
		
		<div class="form-row">
		<div class="label">
		</div>
		<div class="input-container"   style='width:546px;'>
		Responsável pelo Cadastro 
		<select name="selcidacaptado" id="selcidacaptado" onchange="EditandoRegistro()" tabindex="77" style="width:157px;">
		<option value="<?=$selcidacaptado;?>"><?=$selcidacaptado;?></option>
		<option value="134">AFFONSO LUIZ DE ANDRADE CARNEIRO</option>&lt;<option value="57">ALESSANDRO FRANCO DOS SANTOS</option>&lt;<option value="121">ALEX VIEIRA DE MATOS</option>&lt;<option value="135">ANA LUCIA DA ROCHA CARNEIRO</option>&lt;<option value="114">ANA SUELLEN SCHUELER GOMES</option>&lt;<option value="130">ANDERSON MONTEIRO DA SILVA</option>&lt;<option value="115">ANNA LUISA LORENZ CUNHA</option>&lt;<option value="60">ANNE TOLISSANO DE CORDOVA</option>&lt;<option value="125">CARLA BEATRIZ LIMA KLEM FONTANA</option>&lt;<option value="58">CARLOS EDUARDO MARQUES DE MELO DOS SANTOS</option>&lt;<option value="110">CAROLINA CARINO MUSSI</option>&lt;<option value="15">CYNTHIA LOBO</option>&lt;<option value="122">DARLENE GOMES DE ATAYDE</option>&lt;<option value="131">DOUGLAS P. GUIMARAES</option>&lt;<option value="127">ELVIS PINTO DO AMARAL</option>&lt;<option value="117">EUZINEIA SANTUCHI ROCHA</option>&lt;<option value="109">FREDERICO MOTTA</option>&lt;<option value="129">GERLAINE FIGUEIREDO ALVES</option>&lt;<option value="137">GISELE DAUDT</option>&lt;<option value="69">IVANETE PEREIRA ALVES</option>&lt;<option value="64">JANAINA DOS SANTOS CARVALHO</option>&lt;<option value="136">JÉSSICA GOMES JORGE</option>&lt;<option value="123">JULIANA DOS SANTOS PEIXOTO NUNES</option>&lt;<option value="118">JULIO CEZAR DE LIMA</option>&lt;<option value="128">LAERTE RAMOS DE GOUVEA</option>&lt;<option value="111">LEANDRO TAVARES FIGUEIRA</option>&lt;<option value="119">MARCOS FERREIRA LOPES</option>&lt;<option value="78">MARIANA CARVALHO PAIXÃO EMERIK</option>&lt;<option value="126">MARTA REGINA DOS SANTOS CUNHA</option>&lt;<option value="88">MICHELLE AMARAL DIAS</option>&lt;<option value="124">MILENA LIMA DE JESUS</option>&lt;<option value="59">NATHALIA ERASMI DE SOUZA PEREIRA</option>&lt;<option value="120">NATIELE DE FREITAS SOUZA</option>&lt;<option value="22">PAULO ROBERTO NORONHA</option>&lt;<option value="132">SUELI TENORIO</option>&lt;<option value="133">VERA LUCIA VIEIRA MARTINS</option>&lt;<option value="89">VOGNER DE LIMA MOREIRA</option>&lt;	
		</select>
		Referência
		<select name="selcidaatraves" id="selcidaatraves" onchange="EditandoRegistro()" tabindex="78" style="width:144px;">
		<option value="<?=$selcidaatraves;?>"><?=$selcidaatraves;?></option>
		
		<option value="5">COORD DE VAGAS</option>&lt;<option value="3">COORDENADORIA JOVEM</option>&lt;<option value="4">CTM</option>&lt;<option value="2">EQUIPE MULTIDISCIPLINAR</option>&lt;	
		</select>
		</div>
		</div>
		
		
		
		
		<div class="form-row">
		<div class="label">Histórico</div>
		<div class="input-container"   style='width:546px;'>
		<textarea name="txthistorico" style='width:100%;' id="txthistorico" rows="3" cols="96" tabindex="80" style="font-size: 12px; font-family: Arial;" onkeyup="funTamanhoCerto('window.document.Ficha.txthistorico', 2000);" onchange="Maiuscula(this);EditandoRegistro();"><?=$txthistorico;?></textarea>
		</div>
		</div>

		
		
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
		
		<?if($id_trabalhador ==""){?>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar" type="submit" class="sendBtn" />
		<?}else{?>	
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Alterar" type="submit" class="sendBtn" />
		<?}?>
			
			
		<div id="errorDiv2" class="error-div"></div>
		</div>
	</div>
	







		
		<?//include"proficional.php";?>			
		<?//include"qualificacao.php";?>
		<?//include"socio_economico.php";?>
		
		
</form>	
<?}?>
</div>



<script type="text/javascript">

var tempo1 = window.setInterval(carrega, 900000);
function carrega()
{
$('#id_vaga_e').load("lista_vaga_disponivel.php");
//$('#cursos_palestra_lista').load("curso_palestras.php?id_trabalhador=<?=$id_trabalhador;?>&nome=<?=$nome;?>&cpf=<?=$cpf;?>");
//$('#ReloadThis').load("historico.php?id_trabalhafo_get=<?=$id_trabalhador;?>&nome=<?=$nome;?>&cpf=<?=$cpf;?>");
}
</script>



	<div name='proficional' id='proficional'>
	
		<? if($id_trabalhador=="") { echo"<h2>Nenhum Trabalhador Selecionado...!</h2>";} else {include'proficional.php'; };?> 
	
	</div>
	
	
	<div name='qualificacao' id='qualificacao'>
	
		<? if($id_trabalhador=="") { echo"<h2>Nenhum Trabalhador Selecionado...!</h2>";} else {include'qualificacao.php';};?> 
	
	</div>
	
	<div name='emcaminhamentodiv' id='emcaminhamentodiv'>
	
		<? if($id_trabalhador=="") { echo"<h2>Nenhum Trabalhador Selecionado...!</h2>";} else {include'emcaminhamento.php';};?> 
	
	</div>
	
	
	
	
</div>
</div>












<script type="text/javascript" src="jquery.idTabs.min.js"></script>

<script type="text/javascript"> 
$('div.abas').click(function(){
    $('div.abas').removeClass("abas_ative");
    $(this).addClass("abas_ative");
});
</script>



</body>
</html>
