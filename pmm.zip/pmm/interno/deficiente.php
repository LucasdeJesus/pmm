<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
	$escolha = $_GET['escolha'];
	$id_vaga33 = $_GET['id'];
	
	if($escolha =="S")
	
		{
	
		
		
		
		if($id_vaga33> 0)
		{
		$query_noticias2df = "SELECT * FROM `vaga` WHERE `id` ='$id_vaga33'";	
		$rs_noticias2df    = mysql_query($query_noticias2df); 													
		while($campo_noticias2df = mysql_fetch_array($rs_noticias2df)){
		 
		$necEspAuditiva =$campo_noticias2df['necEspAuditiva']; 
		$necEspFala =$campo_noticias2df['necEspFala']; 
		$necEspFisica =$campo_noticias2df['necEspFisica']; 
		$necEspMental =$campo_noticias2df['necEspMental']; 
		$necEspVisual =$campo_noticias2df['necEspVisual']; 
		$necEspAuditivaTipo =$campo_noticias2df['necEspAuditivaTipo']; 
		$necEspAuditivaUniBi =$campo_noticias2df['necEspAuditivaUniBi']; 
		$necEspFalaTipo =$campo_noticias2df['necEspFalaTipo']; 
		$necEspFisicaTipo =$campo_noticias2df['necEspFisicaTipo']; 
		$necEspFisicaInfSup =$campo_noticias2df['necEspFisicaInfSup']; 
		$necEspVisualTipo =$campo_noticias2df['necEspVisualTipo']; 
		$necEspVisualUniBi =$campo_noticias2df['necEspVisualUniBi']; 
		$necEspComunic =$campo_noticias2df['necEspComunic']; 
		$necEspHabSocial =$campo_noticias2df['necEspHabSocial']; 
		$necEspSaudeSeg =$campo_noticias2df['necEspSaudeSeg']; 
		$necEspComunic =$campo_noticias2df['necEspComunic']; 
		$necEspHabSocial =$campo_noticias2df['necEspHabSocial'];  
		$necEspLazer =$campo_noticias2df['necEspLazer']; 
		$necEspCuidadoPess =$campo_noticias2df['necEspCuidadoPess']; 
		$necEspRecursosCom =$campo_noticias2df['necEspRecursosCom']; 
		$necEspHabAcad =$campo_noticias2df['necEspHabAcad']; 
		$necEspTrabalho =$campo_noticias2df['necEspTrabalho']; 
		$codigo_cid =$campo_noticias2df['codigo_cid']; 
		}
		}
		?>
		
							
		
			  <table border="0" cellspacing="0" cellpadding="0"><tr><td colspan="2">
			    <tr><td colspan="3"><font  ID=PrTn><h2>Selecione o tipo de defici&ecirc;ncia:</h2></font></td></tr>
			    <tr><td width="5%">&nbsp;</td>
				    <td width="20%"><font  ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox"  id="necEspAuditiva" <?if($necEspAuditiva=="S"){echo"checked=''";}else{}?> name="necEspAuditiva" value="S"  >Auditiva</font></td>
		            <td><div name="necEspAuditi2va" id="necEspAuditiv2a"><font  ID=PrTn>
					
					
					<select id='necEspAuditivaTipo' name="necEspAuditivaTipo"  style=" width: 300px">
					
							<?
							switch ($necEspAuditivaTipo){										
							case "M":											
							$necEspAuditivaTipo_N = "de 41 a 55 dB – Surdez Moderada";
							break;
							case "A":											
							$necEspAuditivaTipo_N = "de 56 a 70 dB – Surdez Acentuada";
							break;
							case "S":											
							$necEspAuditivaTipo_N = "de 71 a 90 dB – Surdez Severa";
							break;
							case "P":											
							$necEspAuditivaTipo_N = "Acima de 91 dB – Surdez Profunda";
							break;
							case "N":											
							$necEspAuditivaTipo_N = "Anacusia";
							break;
							}
							?>
							<option value="<?=$necEspAuditivaTipo;?>"><?=$necEspAuditivaTipo_N;?></option>
							<option  value="M">de 41 a 55 dB – Surdez Moderada</option>
							<option  value="A">de 56 a 70 dB – Surdez Acentuada</option>							
							<option  value="S">de 71 a 90 dB – Surdez Severa</option>
							<option  value="P">Acima de 91 dB – Surdez Profunda</option>							
							<option  value="N">Anacusia</option>
						</select>&nbsp;
						
						
						<select name="necEspAuditivaUniBi" style=" width: 200px">
						<?
							switch ($necEspAuditivaUniBi){										
							case "U":											
							$necEspAuditivaUniBi_N = "unilateral";
							break;case "B":											
							$necEspAuditivaUniBi_N = "bilateral";
							break;
							}
						?>
							<option selected value="<?=$necEspAuditivaUniBi;?>"><?=$necEspAuditivaUniBi_N;?></option>
							<option  value="U">unilateral</option>
							<option  value="B">bilateral</option>							
						</select></font></div></td></tr>
						
						
			    <tr><td width="5%">&nbsp;</td>
				    <td><font  ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspFala" value="S"  <?if($necEspFala=="S"){echo"checked=''";}else{}?> >Fala</font></td>
		            <td><div name="necEspFala" id="necEspFala"><font  ID=PrTn>
					
					
					<select name="necEspFalaTipo" style=" width: 300px">
					<?
							switch ($necEspFalaTipo){										
							case "G":											
							$necEspFalaTipo_N = "Grandes altera&ccedil;&otilde;es na fala";
							break;case "M":											
							$necEspFalaTipo_N = "Mudez";
							break;
							}
						?>
						
							<option value="<?=$necEspFalaTipo;?>"><?=$necEspFalaTipo_N;?></option>
							<option  value="G">Grandes altera&ccedil;&otilde;es na fala</option>
							<option  value="M">Mudez</option>
						</select></font></div></td></tr>
						
						
						
			    <tr><td width="5%">&nbsp;</td>
				    <td><font  ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspFisica" <?if($necEspFisica=="S"){echo"checked=''";}else{}?> value="S" " >F&iacute;sica</font></td>
		            <td><div name="necEspFisica" id="necEspFisica"><font  ID=PrTn>
					
					
					<select name="necEspFisicaTipo"  style=" width: 300px">
					<?
							switch ($necEspFisicaTipo){										
							case "M":											
							$necEspFisicaTipo_N = "Monoparesia";
							break;case "E":											
							$necEspFisicaTipo_N = "Monoplegia";
							break;
							case "H":											
							$necEspFisicaTipo_N = "Hemiparesia";
							break;case "G":											
							$necEspFisicaTipo_N = "Hemiplegia";
							break;case "P":											
							$necEspFisicaTipo_N = "Paraparesia";
							break;case "A":											
							$necEspFisicaTipo_N = "Paraplegia";
							break;case "T":											
							$necEspFisicaTipo_N = "Triparesia";
							break;case "I":											
							$necEspFisicaTipo_N = "Triplegia";
							break;case "L":											
							$necEspFisicaTipo_N = "Tetraparesia";
							break;case "R":											
							$necEspFisicaTipo_N = "Tetraplegia";
							break;case "U":											
							$necEspFisicaTipo_N = "Amputa&ccedil;&atilde;o ou aus&ecirc;ncia de membro";
							break;case "S":											
							$necEspFisicaTipo_N = "Membros com deformidade cong&ecirc;nita ou adquirida";
							break;case "N":											
							$necEspFisicaTipo_N = "Nanismo";
							break;case "O":											
							$necEspFisicaTipo_N = "Ostomia";
							break;
							}
						?>
						
							<option  value="<?=$necEspFisicaTipo;?>"><?=$necEspFisicaTipo_N;?></option>
							<option  value="M">Monoparesia</option>
							<option  value="E">Monoplegia</option>
							<option  value="H">Hemiparesia</option>
							<option  value="G">Hemiplegia</option>
							<option  value="P">Paraparesia</option>
							<option  value="A">Paraplegia</option>
							<option  value="T">Triparesia</option>
							<option  value="I">Triplegia</option>
							<option  value="L">Tetraparesia</option>
							<option  value="R">Tetraplegia</option>
							<option  value="U">Amputa&ccedil;&atilde;o ou aus&ecirc;ncia de membro</option>
							<option  value="S">Membros com deformidade cong&ecirc;nita ou adquirida</option>
							<option  value="N">Nanismo</option>
							<option  value="O">Ostomia</option>	
						</select>&nbsp;
						
						
						
						<select name="necEspFisicaInfSup" style=" width: 200px">
						<?
						switch ($necEspFisicaInfSup){										
							case "I":											
							$necEspFisicaInfSup_N = "membro(s) inferior(es)";
							break;case "S":											
							$necEspFisicaInfSup_N = "membro(s) superior(es)";
							break;case "A":											
							$necEspFisicaInfSup_N = "membros superior(es) e inferior(es)";
							break;
							}
						?>
							<option value="<?=$necEspFisicaInfSup;?>"><?=$necEspFisicaInfSup_N;?></option>
							<option  value="I">membro(s) inferior(es)</option>
							<option  value="S">membro(s) superior(es)</option>
							<option  value="A">membros superior(es) e inferior(es)</option></select></font></div></td></tr>
			    
				
				<tr><td width="5%">&nbsp;</td>
				    <td valign="top"><font  ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspMental" value="S"  <?if($necEspMental=="S"){echo"checked=''";}else{}?>>Mental</font></td>
		            <td><div name="LimnecEspMental" id="LimnecEspMental"><font face="Verdana, Arial" size="1" ID=PrTn>
						Limita&ccedil;&otilde;es associadas a duas ou mais &aacute;reas de habilidades adaptativas, tais como:<br>
					    <table border="0" cellspacing="0" cellpadding="0">
							<tr><td><font face="Verdana, Arial" size="1" ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspComunic" <?if($necEspComunic=="S"){echo"checked=''";}else{}?> value="S"   >Comunica&ccedil;&atilde;o</font></td>
							    <td><font face="Verdana, Arial" size="1" ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspCuidadoPess" <?if($necEspCuidadoPess=="S"){echo"checked=''";}else{}?>  value="S"   >Cuidado pessoal</font></td></tr>
							<tr><td><font face="Verdana, Arial" size="1" ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspHabSocial"  <?if($necEspHabSocial=="S"){echo"checked=''";}else{}?>  value="S"   >Habilidade social</font></td>
							    <td><font face="Verdana, Arial" size="1" ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspRecursosCom" <?if($necEspRecursosCom=="S"){echo"checked=''";}else{}?>  value="S"   >Utiliza&ccedil;&atilde;o de recursos da comunidade</font></td></tr>
							<tr><td><font face="Verdana, Arial" size="1" ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspSaudeSeg"  <?if($necEspSaudeSeg=="S"){echo"checked=''";}else{}?> value="S"   >Sa&uacute;de e seguran&ccedil;a</font></td>
							    <td><font face="Verdana, Arial" size="1" ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspHabAcad"  <?if($necEspHabAcad=="S"){echo"checked=''";}else{}?>  value="S"   >Habilidade acad&ecirc;mica</font></td></tr>
							<tr><td><font face="Verdana, Arial" size="1" ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspLazer"  <?if($necEspLazer=="S"){echo"checked=''";}else{}?> value="S"   >Lazer</font></td>
							    <td><font face="Verdana, Arial" size="1" ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspTrabalho" <?if($necEspTrabalho=="S"){echo"checked=''";}else{}?> value="S"   >Trabalho</font></td></tr>
						</table>
						</font></div></td></tr>
						
						
			    <tr><td width="5%">&nbsp;</td>
				    <td><font  ID=PrTn><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="checkbox" name="necEspVisual" <?if($necEspVisual=="S"){echo"checked=''";}else{}?> value="S" " >Visual</font></td>
		            <td><div name="necEspVisual" id="necEspVisual"><font  ID=PrTn>
					
					
					<select name="necEspVisualTipo"  style=" width: 300px">
					<?
					switch ($necEspVisualTipo){										
							case "B":											
							$necEspVisualTipo_N = "Vis&atilde;o Subnormal ou Baixa Vis&atilde;o";
							break;case "C":											
							$necEspVisualTipo_N = "Cegueira";
							break;
							}
					?>
							<option selected value="<?=$necEspVisualTipo;?>"><?=$necEspVisualTipo_N;?></option>
							<option  value="B">Vis&atilde;o Subnormal ou Baixa Vis&atilde;o</option>
							<option  value="C">Cegueira</option>
						</select>&nbsp;
						
						
						<select name="necEspVisualUniBi"  style=" width: 200px">
						<?
					switch ($necEspVisualUniBi){										
							case "B":											
							$necEspVisualUniBi_N = "bilateral";
							break;case "U":											
							$necEspVisualUniBi_N = "unilateral/monocular";
							break;
							}
					?>
					
							<option selected value="<?=$necEspVisualUniBi;?>"><?=$necEspVisualUniBi_N;?></option>
							<option  value="U">unilateral/monocular</option>
							<option  value="B">bilateral</option>							
						</select></font></div></td></tr>
						
						
			    
			  </table>
			  <br>
			  <br>
		<div class="form-row" >
		<div class="label">Código CID: <font class='simbolo'><font class='simbolo'></font></font> </div>
		<div class="input-container" style='width:536px;'>		
		<input onChange="javascript:this.value=this.value.toUpperCase();"  onChange="javascript:this.value=this.value.toUpperCase();" name="codigo_cid" value='<?=$codigo_cid;?>'id="codigoId" maxlength="8" class="input req-same"onchange="Maiuscula(this);EditandoRegistro();" tabindex="2" style="font-family: Tahoma; font-size: 10px; width:142px;" type="text">
		</div>
		</div >
            
         
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<?
		}

?>
