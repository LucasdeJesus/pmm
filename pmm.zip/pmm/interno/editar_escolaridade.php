﻿<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);

		$id = $_GET['id'];
		$nome = $_GET['nome'];
		$cpf = $_GET['cpf'];
		$acao = $_GET['acao'];
		
		
		
		if($acao==1)
		
		{
		

			$escolaridadep 	= $_POST['escolaridade']; 		
			$situacaop	= $_POST['situacao']; 
			$seriep 	= $_POST['serie']; 
			$turnop 	= $_POST['turno']; 			
			$formacaoacademicaidp 	= $_POST['formacaoacademicaid']; 
			$outrocursop 	= $_POST['outrocurso']; 
			$instituicaop 	= $_POST['instituicao']; 
			$comprovacaop 	= $_POST['comprovacao']; 
			
			$query2 =" update escolaridade set escolaridade='$escolaridadep',situacao='$situacaop',	serie='$seriep',turno='$turnop',formacaoacademicaid='$formacaoacademicaidp',outrocurso='$outrocursop',instituicao='$instituicaop',comprovacao='$comprovacaop'	where id='$id' ";
			$rs2 = mysql_query($query2);

			
			?>
			<SCRIPT language="JavaScript">alert("Salvo com sucesso !");</SCRIPT>
			<?	
		}
		else
		{
				if($acao==2)
				
				{
				$query ="DELETE FROM  `escolaridade` where id='$id' ";
				$rs = mysql_query($query);
					
				?>
				<SCRIPT language="JavaScript">setTimeout("self.close();",5);</SCRIPT>
				<?	
			}
			else{}
			
		}
		
		
		
		$query_noticias_h = "SELECT * FROM `escolaridade` WHERE id ='$id'";
		$rs_noticias_h    = mysql_query($query_noticias_h);
		while($campo_noticias = mysql_fetch_array($rs_noticias_h)){		
		
			$escolaridade 	= $campo_noticias['escolaridade']; 
			$senha 	= $campo_noticias['senha']; 
			$situacao 	= $campo_noticias['situacao']; 
			$serie 	= $campo_noticias['serie']; 
			$turno 	= $campo_noticias['turno']; 
			$formacaoacademicaidbusca 	= $campo_noticias['formacaoacademicaidbusca']; 
			$formacaoacademicaid 	= $campo_noticias['formacaoacademicaid']; 
			$outrocurso 	= $campo_noticias['outrocurso']; 
			$instituicao 	= $campo_noticias['instituicao']; 
			$comprovacao 	= $campo_noticias['comprovacao']; 
		
		}
		
		
		
?>
<head>
	
			<link rel="stylesheet" type="text/css" href="assets/reset.css" />
			<link rel="stylesheet" type="text/css" href="assets/styles.css" />
  
			<script type="text/javascript">
			function formatar_mascara(src, mascara) {
			var campo = src.value.length;
			var saida = mascara.substring(0,1);
			var texto = mascara.substring(campo);
			if(texto.substring(0,1) != saida) {
			src.value += texto.substring(0,1);
			}
			}
			</script>
			
		
</head>

			<script type="text/javascript">

				function acao1() {
				 document.curso_palesta.action = "editar_escolaridade.php?nome=<?=$nome;?>&cpf=<?=$cpf;?>&id=<?=$id;?>&acao=1";
				}
				function acao2() {
				
					var name= confirm("Deseja excluir?")
					if (name==true)
					{
						document.curso_palesta.action = "editar_escolaridade.php?nome=<?=$nome;?>&cpf=<?=$cpf;?>&id=<?=$id;?>&acao=2";
					 }
					 else
					 {}
				}
			</script>
				
<form class="form" name='curso_palesta' id='curso_palesta' method="Post" action="" >
				
				
				
			<h2>TRABALHADOR</h2>

			<div class="form-row">
			<div class="label">CPF</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  value="<?echo $cpf;?>" size="60" maxlength="60"  disabled=""class="input req-same" tabindex="22" type="text"/> 
			
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Nome</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?echo $nome;?>" tabindex="23"type="text"/>
			
			</div>
			</div>
			
<div class="form-row">
		<h2>ESCOLARIDADE</h2>
		
		
		
		
		
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			
			<b>Escolaridade <font class='simbolo'>&#10045;</font> </b>			
			<select name="escolaridade" required id="escolaridade" tabindex="1" style="width:213px" onchange="escolaridade(this.value);" >
			<?
				switch ($escolaridade){										
				case "N":											
				$escolaridade_N = "Analfabeto";
				break;
				case "A":											
				$escolaridade_N = "Alfabetizado";
				break;
				case "F":											
				$escolaridade_N = "Fundamental";
				break;
				case "M":											
				$escolaridade_N = "Médio";
				break;
				case "P":											
				$escolaridade_N = "Pós-Médio";
				break;
				case "S":											
				$escolaridade_N = "Superior";
				break;
				case "G":											
				$escolaridade_N = "Pós-Graduação";
				break;
				case "E":											
				$escolaridade_N = "Mestrado";
				break;
				case "D":											
				$escolaridade_N = "Doutorado";
				break;
				}
			?>
				<option value="<?=$escolaridade;?>"  ><?=$escolaridade_N;?></option>
				<option value="N">Analfabeto</option>
				<option value="A">Alfabetizado</option>
				<option value="F">Fundamental</option>
				<option value="M">Médio</option>
				<option value="P">Pós-Médio</option>
				<option value="S">Superior</option>
				<option value="G">Pós-Graduação</option>
				<option value="E">Mestrado</option>	
				<option value="D">Doutorado</option>
			</select>
			<b>Situação <font class='simbolo'>&#10045;</font> </b>
			<select name="situacao" id="situacao" required onchange="fun_escolaridade();EditandoRegistroEsc();" tabindex="2" style="width:133px">
				<?
				switch ($situacao){										
				case "C":											
				$situacao_N = "Completo";
				break;case "I":											
				$situacao_N = "Incompleto";
				break;case "U":											
				$situacao_N = "Cursando";
				break;
				}
				?>
			
				<option value="<?=$situacao;?>"  ><?=$situacao_N;?></option>
				<option value="C">Completo</option>
				<option value="I">Incompleto</option>	
				<option value="U">Cursando</option>	
			</select>
			
			
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>	<b>Série </b>	
<select name="serie" id="serie" tabindex="3" style="width:208px" onchange="EditandoRegistroEsc();">

		<?
		switch ($serie){		
		case"1":$serie_N="1º ANO";break;
		case"2":$serie_N="2º ANO";break;
		case"3":$serie_N="3º ANO";break;
		case"4":$serie_N="4º ANO";break;
		case"5":$serie_N="5º ANO";break;
		case"6":$serie_N="6º ANO";break;
		case"7":$serie_N="7º ANO";break;
		case"8":$serie_N="8º ANO";break;
		case"9":$serie_N="9º ANO";break;
		case"C1":$serie_N="CICLO I - ALFA";break;
		case"C2":$serie_N="CICLO II - 1ª E 2ª";break;
		case"C3":$serie_N="CICLO III - 3ª E 4ª";break;
		case"C4":$serie_N="CICLO IV - 5ª E 6ª";break;
		case"C5":$serie_N="CICLO V - 7ª E 8ª";break;
		case"F":$serie_N="ED. ESP. ENS. FUND.";break;
		case"I":$serie_N="ED. ESP. ENS. INF.";break;
		case"J1":$serie_N="EJA - ENS.MED - 1ª ANO";break;
		case"J2":$serie_N="EJA - ENS.MED - 2º ANO";break;
		case"J3":$serie_N="EJA - ENS.MED - 3º ANO";break;
		case"M1":$serie_N="ENS.MED - 1º ANO";break;
		case"M2":$serie_N="ENS.MED - 2º ANO";break;
		case"M3":$serie_N="ENS.MED - 3º ANO";break;
		case"A1":$serie_N="MATERNAL I";break;
		case"A2":$serie_N="MATERNAL II";break;
		case"P1":$serie_N="PRÉ I";break;
		case"P2":$serie_N="PRÉ II";break;
 
 }
		
		?>
			<option value="<?=$serie;?>"  ><?=$serie_N;?></option>
							<option value="1">1º ANO</option>
							<option value="2">2º ANO</option>
							<option value="3">3º ANO</option>
							<option value="4">4º ANO</option>
							<option value="5">5º ANO</option>
							<option value="6">6º ANO</option>
							<option value="7">7º ANO</option>
							<option value="8">8º ANO</option>
							<option value="9">9º ANO</option>
							<option value="C1">CICLO I - ALFA</option>
							<option value="C2">CICLO II - 1ª E 2ª</option>
							<option value="C3">CICLO III - 3ª E 4ª</option>
							<option value="C4">CICLO IV - 5ª E 6ª</option>
							<option value="C5">CICLO V - 7ª E 8ª</option>
							<option value="F">ED. ESP. ENS. FUND.</option>
							<option value="I">ED. ESP. ENS. INF.</option>
							<option value="J1">EJA - ENS.MED - 1ª ANO</option>
							<option value="J2">EJA - ENS.MED - 2º ANO</option>
							<option value="J3">EJA - ENS.MED - 3º ANO</option>
							<option value="M1">ENS.MED - 1º ANO</option>
							<option value="M2">ENS.MED - 2º ANO</option>
							<option value="M3">ENS.MED - 3º ANO</option>
							<option value="A1">MATERNAL I</option>
							<option value="A2">MATERNAL II</option>
							<option value="P1">PRÉ I</option>
							<option value="P2">PRÉ II</option>
								
			</select>
		</div>
	</div>
	
	

	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<b>Turno</b>
			<select name="turno" id="turno" tabindex="4" style="width:68px" onchange="EditandoRegistroEsc();">
			
			<?
			switch ($turno){										
				case "M":											
				$turno_N = "Manhã";
				break;case "T":											
				$turno_N = "Tarde";
				break;case "N":											
				$turno_N = "Noite";
				break;
				}
			
			?>
					<option value="<?=$turno;?>"  ><?=$turno_N;?></option>
				<option value="M">Manhã</option>
				<option value="T">Tarde</option>	
				<option value="N">Noite</option>	
			</select>				   
<!--
			<b>Pós Graduação </b>
-->
			
			
			<b>Curso</b>
			<select name="formacaoacademicaid" id="formacaoacademicaid" tabindex="6" style="width:380px" onchange="EditandoRegistroEsc();">
			
				
				<?
				$query_formacaoacademica_db = "SELECT * FROM `formacaoacademica` WHERE id='$formacaoacademicaid'";
				$rs_formacaoacademica_db    = mysql_query($query_formacaoacademica_db);
				while($campo_formacaoacademica_db = mysql_fetch_array($rs_formacaoacademica_db)){
				$nome_formacaoacademica_db 	= $campo_formacaoacademica_db['nome']; 	
				$id_formacaoacademica_db 	= $campo_formacaoacademica_db['id']; 	
				?><?}?>
					<option value="<?=$id_formacaoacademica_db;?>"  ><?=$nome_formacaoacademica_db;?></option>
				
				
								<?
				$query_formacaoacademica = "SELECT * FROM `formacaoacademica` ORDER BY `formacaoacademica`.`nome` ASC";
				$rs_formacaoacademica    = mysql_query($query_formacaoacademica);
				while($campo_formacaoacademica = mysql_fetch_array($rs_formacaoacademica)){
				$nome_formacaoacademica 	= $campo_formacaoacademica['nome']; 	
				$id_formacaoacademica 	= $campo_formacaoacademica['id']; 	
				?>
				<option value="<?=$id_formacaoacademica;?>"><?=$nome_formacaoacademica;?></option>
				<?}?>

			</select>
			
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Outro Curso</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="outrocurso" id="outrocurso" value="<?=$outrocurso;?>" class="input req-same"maxlength="300" onchange="Maiuscula(this);EditandoRegistroEsc();" tabindex="7" style="width:453" type="text">
				
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Última Instituição</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="instituicao" value="<?=$instituicao;?>" id="instituicao" class="input req-same" maxlength="300" onchange="Maiuscula(this);EditandoRegistroEsc();" tabindex="8" style="width:421" type="text">
				
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Tem Comprovação <font class='simbolo'>&#10045;</font>  </div>
	    <div class="input-container" style='width:546px;'>		
			<select name="comprovacao" id="comprovacao" required tabindex="9"  onchange="EditandoRegistroEsc();">
			
			<?
																switch ($comprovacao){										
																case "N":											
																$comprovacao_N = "Não";
																break;case "S":											
																$comprovacao_N = "Sim";
																break;
																}
														?>
					<option value="<?=$comprovacao;?>"  ><?=$comprovacao_N;?></option>
				<option value='N' >Não</option>
				<option value='S'>Sim</option>
			</select>
				
		</div>
	</div>
	
	
		<div class="form-row">
		<div class="label"></div>
		<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Excluir" onClick="acao2();"type="submit" class="sendBtn" />
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar" onClick="acao1();"type="submit" class="sendBtn" />		
		</div>
		</div>
			
		
		
</form>
<!---------------------------------------------------------empresa 1------------------------------------------------->






