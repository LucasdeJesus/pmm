<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<style Onload="carrega();" ></style>
<style Onload="emcaminhamentof();" ></style>
<script language="Javascript">
parent.test();
</script>
<body >

<script>

	top.frememenu.minhaFuncao2('ocuta');
	
</script> 
<div id="bg-container" class='contener' align='center' style="margin:10%;">



				<?
				
				$cpf_busca = $_GET['cpf_busca'];
				$query_noticias = "SELECT id,cpf,nome,datacadastro,dataupdate FROM `trabalhador` WHERE `cpf` LIKE '%$cpf_busca%'";
				$rs_noticias    = mysql_query($query_noticias);																							
				while($campo_noticias = mysql_fetch_array($rs_noticias)){
				$id= $campo_noticias['id']; 
				$cpf= $campo_noticias['cpf']; 
				$cpf_busca= $campo_noticias['cpf']; 
				$nome= $campo_noticias['nome']; 
				
				$datacadastro= $campo_noticias['datacadastro']; 
				$dataupdate= $campo_noticias['dataupdate']; 
				}
				
				
				
				
				?>

										<script type="text/javascript">
											jQuery(document).ready(function(){												
												jQuery('#emcaminhamentof').submit(function(){
													
													 jQuery("#load").css("display","block");
													var dados = jQuery( this ).serialize();

													jQuery.ajax({
														type: "POST",
														url: "script_emcaminhamento.php?acao=cadastro",
														data: dados,
														success: function(data)
														{
																													
															  
															 var id_trabalhador_form =  $("#id_trabalhadore_e").val();
															 var id_vaga_e = $("#id_vaga_e").val();
															  var dados2 = $.trim(data) ;
															  if(dados2  < 2){
																window.open("imprimi_emcaminhamento.php?vagaid="+id_vaga_e+"&id_trabalhafo_get="+id_trabalhador_form,"","width=500,height=500");
																}else{ 
																window.open("imprimi_emcaminhamento.php?vagaid="+id_vaga_e+"&id_trabalhafo_get="+id_trabalhador_form,"","width=500,height=500");
																//alert("Tarabalhado já encaminhado para referida vaga!");
																
																}
																
																
																$("#obs").val("");
																$("#id_vaga_e").val("");
																$("#atendimento").val("");
																 jQuery("#load").css("display","none");
														}
													});
													
													

													return false;
													
												});
												
												
											
												
												
												
												
												
												
											});
											
											
											</script>
	






<script type="text/javascript">


function emcaminhamentof(){

var xmlHttp;
try{    
xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
}
catch (e){
try{
xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
}
catch (e){
try{
xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
}
catch (e){
alert("No AJAX!?");
return false;
}
}
}

xmlHttp.onreadystatechange=function(){
if(xmlHttp.readyState==4){
document.getElementById('tr_lista_emcaminhamento').innerHTML=xmlHttp.responseText;
setTimeout('emcaminhamentof()',3000);
}
}
xmlHttp.open("GET","lista_emcaminhamento.php?id=<?=$id;?>",true); // aqui configuramos o arquivo
xmlHttp.send(null);
}

window.onload=function(){
setTimeout('emcaminhamentof()',3000); // aqui o tempo entre uma atualização e outra
}

</script>

				

				 <script>
				function pop_pesquisaempresa(page) {
					window.open('', 'popRelReciboEntregue', 'width=750,height=450,scrollbars');
					document.emcaminhamentof.action = page;
					document.emcaminhamentof.target = 'popRelReciboEntregue';
					document.emcaminhamentof.submit();
				}

				</script>


	<form id="emcaminhamentof"  name='emcaminhamentof' class="form" method="Post" action="" >	
			<h2>TRABALHADOR</h2>
			<a href="javascript:Abrir_Pagina('candidatocurriculum.php?id=<?=$id;?>','scrollbars=yes,width=800,height=500')" title='Imprimir curriculum '  class="sendBtn">Imprimir</a>	
			<div class="form-row">
			<div class="label">CPF</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  value="<?echo $cpf;?>" size="60" maxlength="60"  disabled=""class="input req-same" tabindex="22" type="text"/> 

			</div>
			</div>

			<div class="form-row">
			<div class="label">Nome</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?echo $nome;?>" tabindex="23"type="text"/>

			</div>
			</div>
			
			<div class="form-row">
			<div class="label">ID</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?=$id;?>" tabindex="23"type="text"/>

			</div>
			</div>
			
			
			
	
			<h2>ENCAMINHAMENTOS</h2>

			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_trabalhadore_e' id='id_trabalhadore_e'type='hidden' value='<?=$id;?>'/>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_emcaminhamento_e' type='hidden' value='<?=$id_emcaminhamento;?>'/>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='cpf3' type='hidden' value='<?=$cpf_busca;?>'/>
			
			
			<div id='load' name='load' style='display:none;'><img src='img/carregamento-da-pagina-com-loading.gif'/></div>
			

			
						<div class="label">Vaga ( Clique no botão ao lado, e na janela clique na vaga)</div>
						<div class="input-container" style='width:546px;'>	
						
						<a class="sendBtn" onclick="pop_pesquisaempresa('interno/index.php?lista=vagas_disponivel_trabalhador&cpf=<?=$cpf;?>')"  title="Listar vagas prefil"><img src='img/novo_item.png'/></a>
						<select required name='id_vaga_e' id='id_vaga_e' style='width:449px;'>
						
						<?
						/*
						$query_noticiasj = "SELECT id,cboid,quantidadeencaminhar FROM `vaga` where status IN ('A') ORDER BY `vaga`.`id` ASC  limit 1";			
						$rs_noticiasj    = mysql_query($query_noticiasj);				
						while($campo_noticiasj = mysql_fetch_array($rs_noticiasj)){

						$id_vagam= $campo_noticiasj['id']; 			
						$cboid = $campo_noticiasj['cboid'];	
						$txEncaminhar = $campo_noticiasj['quantidadeencaminhar'];	
						
							$query_ocupacao = "SELECT cbo FROM `cbo` where id='$cboid' ";
							$rs_ocupacao     = mysql_query($query_ocupacao );
							while($campo_ocupacao  = mysql_fetch_array($rs_ocupacao )){
							$txcbonome        = $campo_ocupacao ['cbo'];
							}
							$query_noticias_total_emca = "SELECT id FROM  encaminhamento  WHERE vagaid ='$id_vagam'";	
							$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
							$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
							
							if($total_total_emca > $txEncaminhar )
							
							{
							}
							else{
							?>
							<option value='<?=$id_vagam;?>'><?=$id_vagam;?> - <?=$txcbonome;?></option>
							<?}	}*/?>
						</select>
						
						 <a class="sendBtn" onclick="pop_pesquisaempresa('interno/index.php?lista=encaminhamento')"  title="Listar vagas mural"><img src='img/busca.png'/></a>
						 
						</div>
					
	
	

				<div class="form-row">
				<div class="label">Observações</div>
				<div class="input-container" style='width:546px;'>		
				<textarea name='obs' id='obs' class="input req-same" rows="2" cols="96" tabindex="21" style="font-size: 12px; font-family: Arial;height:56px;"></textarea>				
				</div>
				</div>

				<div class="form-row">
				<div class="label"></div>
				<div class="input-container" style='width:546px;'>	
				<input type='hidden' name='status' id='status' value='E'/>				

				</div>
				</div>
				
				
	
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container" style='width:546px;'>	
				 <a href="conteudo.php?idtr=<?=$id;?>&buscaform=id"  class="sendBtn2"> &#9668; Anterior</a>				
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar"  type="submit" class="sendBtn" />

				</div>
				</div>
				
				
				
				
				<table>
					<tr>
						<td class='td1' width='15px' >N°</td>
						<td class='td1' width='63px'  >Data</td>
						<td class='td1'width='214px'  >IDS </td>
						<td class='td1'width='214px'  >Vaga </td>
						<td class='td1'width='210px'  >OBS: </td>
						<td class='td1' width='110px' >Atendimento</td>
						<td class='td1'width='110px' >Status</td>
						<td class='td1'width='' >IMPr.</td>
					</tr>
					
				</table>
					
				<table name='tr_lista_emcaminhamento'id='tr_lista_emcaminhamento' >
					
					
				</table>
							
				<p><a class="sendBtn2"  onclick="minhaFuncao2();"href="finalizarantendimento.php?idtrabalhador=<?=$id;?>" id='element_to_pop_up' name='element_to_pop_up'  ><img src='img/inserir_curso.png'/>Finalizar Atendimento</a></p>
				<p style='color:red;'> <b>Atenção </b>Finalize o atendimento para mostrar o menu! </p>
						
</form>	
				
			




</div>




</body>
</html>
