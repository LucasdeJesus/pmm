
<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('#emcaminhamentof').submit(function(){
			var dados = jQuery( this ).serialize();

			jQuery.ajax({
				type: "POST",
				url: "script_emcaminhamento.php?acao=cadastro",
				data: dados,
				success: function( data )
				{
					alert( data );
				}
			});

			return false;
		});
		
		
	});
	
	
	</script>
	






<script type="text/javascript">


function emcaminhamentof(){

var xmlHttp;
try{    
xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
}
catch (e){
try{
xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
}
catch (e){
try{
xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
}
catch (e){
alert("No AJAX!?");
return false;
}
}
}

xmlHttp.onreadystatechange=function(){
if(xmlHttp.readyState==4){
document.getElementById('tr_lista_emcaminhamento').innerHTML=xmlHttp.responseText;
setTimeout('emcaminhamentof()',100);
}
}
xmlHttp.open("GET","lista_emcaminhamento.php?id_trabalhador=<?=$id_trabalhador;?>",true); // aqui configuramos o arquivo
xmlHttp.send(null);
}

window.onload=function(){
setTimeout('emcaminhamentof()',100); // aqui o tempo entre uma atualização e outra
}

</script>

				<script>
				function openWin()
				{
				
				var id_trabalhador_form = document.getElementById("id_trabalhadore_e").value;
				var myWindow = window.open("imprimi_emcaminhamento.php?id_trabalhafo_get="+id_trabalhador_form,"","width=500,height=500");
				//document.emcaminhamentof.reset();
				}
				</script>




	<form id="emcaminhamentof"  onsubmit="openWin()" name='emcaminhamentof'class="form" method="Post" action="" >	
			<h2>TRABALHADOR</h2>

			<div class="form-row">
			<div class="label">CPF</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  value="<?echo $cpf;?>" size="60" maxlength="60"  disabled=""class="input req-same" tabindex="22" type="text"/> 

			</div>
			</div>

			<div class="form-row">
			<div class="label">Nome</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?echo $nome;?>" tabindex="23"type="text"/>

			</div>
			</div>
			
	
			<h2>ENCAMINHAMENTOS</h2>

			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_trabalhadore_e' id='id_trabalhadore_e'type='hidden' value='<?=$id_trabalhador;?>'/>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_emcaminhamento_e' type='hidden' value='<?=$id_emcaminhamento;?>'/>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='cpf3' type='hidden' value='<?=$cpf_busca;?>'/>
			
			
			

			<div class="form-row">
			<div class="label">Vaga</div>
			<div class="input-container" style='width:546px;'>		
			<select required name='id_vaga_e' id='id_vaga_e'>
			<option value=''>Selecione<option>
			
			</select>
			</div>
			</div>
	
	

				<div class="form-row">
				<div class="label">Observações</div>
				<div class="input-container" style='width:546px;'>		
				<textarea name='obs' id='obs' class="input req-same" rows="2" cols="96" tabindex="21" style="font-size: 12px; font-family: Arial;height:56px;"></textarea>				
				</div>
				</div>

				<div class="form-row">
				<div class="label">Status</div>
				<div class="input-container" style='width:546px;'>	

				<select name='estatus'  id='estatus' required>
				
					<option value=''>Selecione</option>
					<option value='E'>Encaminhado</option>
					<option value='I'>Inserido</option>
					<option value='N'>Não Inserido</option>
				</select>	

				</div>
				</div>
				
				

				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container" style='width:546px;'>		
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar"  type="submit" class="sendBtn" />

				</div>
				</div>
				
				<table>
					<tr>
						<td class='td1' width='15px' >N°</td>
						<td class='td1' width='63px'  >Data</td>
						<td class='td1'width='214px'  >Vaga </td>
						<td class='td1'width='210px'  >OBS: </td>
						<td class='td1' width='110px' >Atendimento</td>
						<td class='td1'width='110px' >Status</td>
					</tr>
					
				</table>
					
				<table name='tr_lista_emcaminhamento'id='tr_lista_emcaminhamento' >
					
					
				</table>
				
			
</form>