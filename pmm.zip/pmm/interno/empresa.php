
<frameset frameborder="0" framespacing="0" rows="30%,*">
<frame scrolling="No" framespacing="0" marginheight="0" marginwidth="0" noresize="" frameborder="0" name="FrmMenu" src="cadastro_empresa.php">
<frame framespacing="0" marginheight="0" marginwidth="5" frameborder="0" name="FrmDados" id='FrmDados'src="lista_empresa.php">
</frameset>