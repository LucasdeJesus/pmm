<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);


		$busca = $_GET['busca'];
		$id = $_GET['id'];
		$id_empresa = $_GET['idempresa'];
		
		if($id==""){				


						$query_noticias = "SELECT * FROM `empresa` WHERE id='$id_empresa'";
								$rs_noticias    = mysql_query($query_noticias);
								while($campo_noticias = mysql_fetch_array($rs_noticias)){		
															
								$enderecoentrevista1	= $campo_noticias['enderecoentrevista']; 
										if($enderecoentrevista1==""){
										
												$enderecolocal	= $campo_noticias['endereco']; 	 		 			 	
												$bairrolocal	= $campo_noticias['bairro']; 	 		 			 	
												$cidadelocalid	= $campo_noticias['cidadeid'];	 			 	
												$ceplocal	= $campo_noticias['cep'];		 		 			 	
												$falarcom	= $campo_noticias['responsavel'];									
												$emailentrevista	= $campo_noticias['email']; 	 		 			 	
												$proximodelocal	= $campo_noticias['referenciaend']; 
												$numerolocal	= $campo_noticias['numero']; 
												
												
												
										
										}else{
												$enderecolocal	= $campo_noticias['enderecoentrevista']; 
												$bairrolocal	= $campo_noticias['bairroentrevista']; 	 		 			 	
												$cidadelocalid	= $campo_noticias['cidadeentrevistaid'];	 			 	
												$ceplocal	= $campo_noticias['cepentrevista'];		 		 			 	
												$falarcom	= $campo_noticias['falarcom'];									
												$emailentrevista	= $campo_noticias['email']; 
												$proximodelocal	= $campo_noticias['proximode'];
												$numerolocal	= $campo_noticias['numeroentrevista'];

												
												
										
										}
		 	}	 
		}
		else
		{
					$query_noticias = "SELECT * FROM `vaga` WHERE id ='$id'";
					$rs_noticias    = mysql_query($query_noticias);
					while($campo_noticias = mysql_fetch_array($rs_noticias)){												
					$enderecolocal	= $campo_noticias['enderecolocal']; 	 		 			 	
					
											
						}	 
						
						if($enderecolocal=="")
						{
								$query_noticias = "SELECT * FROM `empresa` WHERE id='$id_empresa'";
								$rs_noticias    = mysql_query($query_noticias);
								while($campo_noticias = mysql_fetch_array($rs_noticias)){		

								$enderecolocal	= $campo_noticias['endereco']; 	 		 			 	
								$bairrolocal	= $campo_noticias['bairro']; 	 		 			 	
								$cidadelocalid	= $campo_noticias['cidadeid'];	 			 	
								$ceplocal	= $campo_noticias['cep'];		 		 			 	
								$falarcom	= $campo_noticias['responsavel']; 			 	
								$numerolocal	= $campo_noticias['numero']; 			 	
								
								$emailentrevista	= $campo_noticias['email']; 	 		 			 	
								$proximodelocal	= $campo_noticias['referenciaend']; 
								}
						}
						
						else{						
						
							$query_noticias = "SELECT * FROM `vaga` WHERE id ='$id'";
							$rs_noticias    = mysql_query($query_noticias);
							while($campo_noticias = mysql_fetch_array($rs_noticias)){
														
							$enderecolocal	= $campo_noticias['enderecolocal']; 	 		 			 	
							$bairrolocal	= $campo_noticias['bairrolocal']; 	 		 			 	
							$cidadelocalid	= $campo_noticias['cidadelocalid'];		 	
							$ceplocal	= $campo_noticias['ceplocal']; 			 	
							$falarcom	= $campo_noticias['falarcom']; 	 		 			 	
							$emailentrevista	= $campo_noticias['emailentrevista']; 	 		 			 	
							$proximodelocal	= $campo_noticias['proximodelocal']; 	 		 			 	
							$onoffshore	= $campo_noticias['onoffshore']; 
							$numerolocal	= $campo_noticias['numerolocal']; 			 	
							$numeroentrevista	= $campo_noticias['numeroentrevista']; 	
							$local	= $campo_noticias['local']; }
											
						}	 
						
						
						
		}
											
												?>	
													<div class="form-row" >
																	<div class="label"></div>
																	<div class="input-container" style='width:546px;'>		
																	<b>CEP</b>
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="ceplocal" id="ceplocal" value='<?=$ceplocal;?>'  maxlength="8" onchange="EditandoRegistro();" class="input req-same" onkeyup="verificaNumero('window.document.Ficha.ceplocal');" tabindex="24" style="width:65px;" type="text">
																		<b>Estado <font class='simbolo'><font class='simbolo'>&#10045;</font></font></b>
																		
																			<select name="txtestado_local" required id="txtestado_local" onchange="busca_cidadel(this.value);" style='width:59px;'>

																				<?	
																				$query_estado_dben = "SELECT * FROM `cidade` where id='$cidadelocalid' ";
																				$rs_estado_dben     = mysql_query($query_estado_dben );
																				while($campo_estado_dben  = mysql_fetch_array($rs_estado_dben )){
																				$ufiden        = $campo_estado_dben ['ufid'];

																				$query_estado_dbufen = "SELECT * FROM `uf` where id='$ufiden' ";
																				$rs_estado_dbufen     = mysql_query($query_estado_dbufen );
																				while($campo_estado_dbufen  = mysql_fetch_array($rs_estado_dbufen )){
																				$uf_nomeen        = $campo_estado_dbufen ['uf'];
																				$id_uf_dben        = $campo_estado_dbufen ['id'];
																				}

																				}	
																				?>
																				<option value='<?=$id_uf_dben;?>'><?=$uf_nomeen ;?></option>
																						
																				<?
																				$query_noticias_estadoen = "SELECT *  FROM  `uf` ORDER BY  `uf`.`uf` ASC ";
																				$rs_noticias_estadoen    = mysql_query($query_noticias_estadoen);
																				while($campo_noticias_estadoen = mysql_fetch_array($rs_noticias_estadoen)){		
																				$idufen 	= $campo_noticias_estadoen['id']; 
																				$nome_ufen 	= $campo_noticias_estadoen['uf']; 

																				?>
																				<option value='<?=$idufen;?>'><?=$nome_ufen ;?></option>			
																				<?}?>	
																		
																		</select>
																		
																		


										<?	
												$query_noticias_cidadecpen = "SELECT * FROM `cidade` where id='$cidadelocalid' ";
												$rs_noticias_cidadecpen    = mysql_query($query_noticias_cidadecpen);
												while($campo_noticias_cidadecpen = mysql_fetch_array($rs_noticias_cidadecpen)){
												$local_cidadeen        = $campo_noticias_cidadecpen['nome'];	
												$cidadelocaliden        = $campo_noticias_cidadecpen['id'];	
												}	
												?>
																		<b>Cidade <font class='simbolo'><font class='simbolo'>&#10045;</font></font></b>
															<select name="cidadelocalid" required id="cidadelocalid" onchange="busca_bairol(this.value);"style='width:220px;' >
															<option value='<?=$cidadelocaliden;?>'><?=$local_cidadeen;?></option>
															<?	
													$query_noticias_cidadecp2 = "SELECT * FROM `cidade` where ufid='$ufiden' ";
													$rs_noticias_cidadecp2    = mysql_query($query_noticias_cidadecp2);
													while($campo_noticias_cidadecp2 = mysql_fetch_array($rs_noticias_cidadecp2)){
													$nome_cidade2        = $campo_noticias_cidadecp2['nome'];	
													$id_cidade2        = $campo_noticias_cidadecp2['id'];	

													?>
													<option value='<?=$id_cidade2;?>'><?=$nome_cidade2;?></option>

													<?}?>
													
															</select>

																	
																	</div>
																</div >
																
																
																
																<div class="form-row">
																	<div class="label">Bairro <font class='simbolo'><font class='simbolo'>&#10045;</font></font></div>
																	<div class="input-container" style='width:546px;'>		
																		
																			
																			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="bairrolocal" required=''  value="<?=$bairrolocal;?>"  id="bairrolocal"  maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="28" class="input req-same" type="text">
																	</div>
																</div>
																
																<div class="form-row">
																	<div class="label">Endereço <font class='simbolo'><font class='simbolo'>&#10045;</font></font></div>
																	<div class="input-container" style='width:546px;'>		
																		<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="enderecolocal" required=''  value="<?=$enderecolocal;?>"  id="enderecolocal"  maxlength="400" onchange="Maiuscula(this);EditandoRegistro();" tabindex="28" class="input req-same" type="text">
																	</div>
																</div>
																
															<div class="form-row">
																<div class="label">Numero <font class='simbolo'>&#10045;</font></div>
																<div class="input-container" style='width:546px;'>	
																	<i>Favor informa apenas numero</i>	
																	<input  style='width:146px;' onChange="javascript:this.value=this.value.toUpperCase();" required onChange="javascript:this.value=this.value.toUpperCase();" name="numerolocal"   value="<?echo $numerolocal;?>"  id="numerolocal"  class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="79" type="numbre">
																		
																</div>
															</div>
									
																<div class="form-row">
																	<div class="label"></div>
																	<div class="input-container" style='width:546px;'>		
																		<b>Próximo de</b>
																		<i>Ex: loja A, perto de,...</i>	
																		<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="proximodelocal" value="<?=$proximodelocal;?>"  id="proximodelocal" class="input req-same" maxlength="100" onchange="Maiuscula(this);EditandoRegistro();" tabindex="29" style="width:373px;" type="text">

																		
																	</div>
																</div>
																
																
																<div class="form-row">
																	<div class="label">Local da Vaga</div>
																	<div class="input-container" style='width:546px;'>		
																		
																		<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="local" id="local"  value="<?=$local;?>"  maxlength="100" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" class="input req-same" tabindex="31" type="text">
																	</div>
																</div>
																
															
																												
											
									