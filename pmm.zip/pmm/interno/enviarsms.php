﻿<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);

	include("topo.php");
?>
	<link rel="stylesheet" type="text/css" href="assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="assets/styles.css" />
	


							<?

							$palestra = $_POST['palestra'];
							$texto = $_POST['texto'];
							
							if($palestra==""){}else{
								
											$numero="";
											if($palestra=="0"){
												$query_noticias = "SELECT * FROM `palestra` ";
											}else{
												$query_noticias = "SELECT * FROM `palestra`WHERE  `palestra` LIKE '%$palestra%' ";
											}							
												
													
											$rs_noticias    = mysql_query($query_noticias); 
											$total = mysql_num_rows($rs_noticias);	
											while($campo_noticias = mysql_fetch_array($rs_noticias)){
											$celular 	= $campo_noticias['celular']; 	 		 			 	
											
											
											$vowels = array("(", ")", ".", "-");
											$numerocelular = str_replace($vowels, "", $celular);
											$celularesbanco = "55".$numerocelular.",";
											$numero.=	$celularesbanco;
											}	
								
								
										?>
										<script>
										
										
										
										$.ajax({
										url: 'http://app.smsconecta.com.br/SendAPI/Send.aspx?usr=cetep&pwd=cetep357&number=<?=$numero;?>&sender=AGETRAB&msg=<?=$texto;?>',
										success: function(data) {				
											if($.trim(data)  > 2){
													//document.getElementById("sms").innerHTML = "<h3>SMS envida com sucesso para <?=$total;?> numeros</h3>";		
													alert("SMS envida com sucesso para <?=$total;?> numeros ");
											}else{
												alert(data);
												//document.getElementById("sms").innerHTML = "Erro, o limite é de 140 caracteres";	
													alert("Erro, o limite é de 140 caracteres ");												
											}
										}
										
										

										});


										</script>
										
										<?
								
							}
							

							?>
	<form class="form" method="post">
	<h2>Envia SMS</h2>
	
	<p>
	<b>Total:</b>
	<?=$total;?></p>
	<p>
	
	<p>
	<b>Enviado para:</b>
	<?=$numero;?></p>
	<p>
	<b>Texto</b><br>
	<?=$texto;?><br><br><br></p>
	
	
	
		<div name="sms" id="sms"></div>
		<div class="form-row">
				<div class="label">SELECIONE PALESTRA</div>
				<div class="input-container" style='width:546px;'>		
					<select name="palestra">
						<option value="0">Todos</option>
						<option value="1">1 - RH nos Momentos de Adversidades e o Fator Humano na Gestão de Empresas de Energia</option>
						<option value="2">2 - Planejamento de Carreira</option>
						<option value="3">3 - Como posso agregar valor à empresa e para meu desenvolvimento</option>
						<option value="4">4 - Dando a volta por cima</option>
						<option value="5">5 - Qualificação Profissional alavancando a carreira</option>
					</select>
				</div>
			</div>
			
			<div class="form-row">
				<div class="label">TEXTO SMS (Maximo 140 caracteres) </div>
				<div class="input-container" style='width:546px;'>		
					<textarea name='texto'style="width:100%;height:200px"></textarea>
				</div>
			</div>
			
			<div class="input-container" style='width:546px;'>		
			
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Enviar" type="submit" class="sendBtn" />
			</div>
			
			
	</table>		
	<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>
	<form>