<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);

		
		$id_trabalhafo_get = $_GET['id'];
		$nomeg = $_GET['nome'];
		$cpfg = $_GET['cpf'];
		
		//$query_noticias_hcp = "SELECT * FROM `escolaridade` WHERE trabalhadorid ='$id_trabalhafo_get' ";
		$query_noticias_hcp ="SELECT DISTINCT * FROM escolaridade where trabalhadorid ='$id_trabalhafo_get' ";
		$rs_noticias_hcp    = mysql_query($query_noticias_hcp);
		while($campo_noticias_hcp = mysql_fetch_array($rs_noticias_hcp)){
		
		$escolaridade 	= $campo_noticias_hcp['escolaridade']; 		
		$serie = $campo_noticias_hcp['serie'];
		$formacaoacademicaid = $campo_noticias_hcp['formacaoacademicaid'];
		$comprovacao	 = $campo_noticias_hcp['comprovacao'];
		$id = $campo_noticias_hcp['id'];
		$situacao = $campo_noticias_hcp['situacao'];
		
?>


<?
		switch ($serie){		
		case"1":$serie_N="1º ANO";break;
		case"2":$serie_N="2º ANO";break;
		case"3":$serie_N="3º ANO";break;
		case"4":$serie_N="4º ANO";break;
		case"5":$serie_N="5º ANO";break;
		case"6":$serie_N="6º ANO";break;
		case"7":$serie_N="7º ANO";break;
		case"8":$serie_N="8º ANO";break;
		case"9":$serie_N="9º ANO";break;
		case"C1":$serie_N="CICLO I - ALFA";break;
		case"C2":$serie_N="CICLO II - 1ª E 2ª";break;
		case"C3":$serie_N="CICLO III - 3ª E 4ª";break;
		case"C4":$serie_N="CICLO IV - 5ª E 6ª";break;
		case"C5":$serie_N="CICLO V - 7ª E 8ª";break;
		case"F":$serie_N="ED. ESP. ENS. FUND.";break;
		case"I":$serie_N="ED. ESP. ENS. INF.";break;
		case"J1":$serie_N="EJA - ENS.MED - 1ª ANO";break;
		case"J2":$serie_N="EJA - ENS.MED - 2º ANO";break;
		case"J3":$serie_N="EJA - ENS.MED - 3º ANO";break;
		case"M1":$serie_N="ENS.MED - 1º ANO";break;
		case"M2":$serie_N="ENS.MED - 2º ANO";break;
		case"M3":$serie_N="ENS.MED - 3º ANO";break;
		case"A1":$serie_N="MATERNAL I";break;
		case"A2":$serie_N="MATERNAL II";break;
		case"P1":$serie_N="PRÉ I";break;
		case"P2":$serie_N="PRÉ II";break;
 
 }
		
		?>
<?
				switch ($escolaridade){										
				case "N":											
				$escolaridade_N = "Analfabeto";
				break;
				case "A":											
				$escolaridade_N = "Alfabetizado";
				break;
				case "F":											
				$escolaridade_N = "Fundamental";
				break;
				case "M":											
				$escolaridade_N = "Médio";
				break;
				case "P":											
				$escolaridade_N = "Pós-Médio";
				break;
				case "S":											
				$escolaridade_N = "Superior";
				break;
				case "G":											
				$escolaridade_N = "Pós-Graduação";
				break;
				case "E":											
				$escolaridade_N = "Mestrado";
				break;
				case "D":											
				$escolaridade_N = "Doutorado";
				break;
				}
			?>

	<tr class='tr_tb' >
					
		<td class='td2' width='205px'> <?=$escolaridade_N;?> </td>
		<td class='td2' width='221px'> <?=$serie_N;?> </td>
		<?
				$query_formacaoacademica_db = "SELECT * FROM `formacaoacademica` WHERE id='$formacaoacademicaid'";
				$rs_formacaoacademica_db    = mysql_query($query_formacaoacademica_db);
				while($campo_formacaoacademica_db = mysql_fetch_array($rs_formacaoacademica_db)){
				$nome_formacaoacademica_db 	= $campo_formacaoacademica_db['nome']; 	
				$id_formacaoacademica_db 	= $campo_formacaoacademica_db['id']; 	
				?><?}?>
		<td class='td2' width='221px'> <?=$nome_formacaoacademica_db;?> </td>
		
					<?
			switch ($situacao){										
			case "C":											
			$situacaocurso_cp_N = "Completo";
			break;case "U":											
			$situacaocurso_cp_N = "Cursando";
			break;case "I":											
			$situacaocurso_cp_N = "Incompleto";
			break;
			}
			?>		

			
		<td class='td2' width='83px'>  <?=$situacaocurso_cp_N;?></td>		
			<?
			switch ($comprovacao){										
			case "N":											
			$comprovacaocurso_N = "Não";
			break;case "S":											
			$comprovacaocurso_N = "Sim";
			break;
			}
			?>		
		<td class='td2' width='83px'>  <?=$comprovacaocurso_N;?></td>				
		<td class='td2' width=''><a href="javascript:Abrir_Pagina('editar_escolaridade.php?id=<?=$id;?>&nome=<?=$nomeg;?>&cpf=<?=$cpfg;?>','scrollbars=yes,width=600,height=500');" title='Saiba mais'><img src='img/busca.png'/></a> </td>
		
	</tr>

<?}?>