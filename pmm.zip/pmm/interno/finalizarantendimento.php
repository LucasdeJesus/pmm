<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<style Onload="carrega();" ></style>
<style Onload="emcaminhamentof();" ></style>
<body >


<div id="bg-container" class='contener' align='center' style="margin:10%;">



				<?
				
				$idtrabalhador = $_GET['idtrabalhador'];
				$query_noticias = "SELECT * FROM `trabalhador` WHERE `id`='$idtrabalhador'";
				$rs_noticias    = mysql_query($query_noticias);																							
				while($campo_noticias = mysql_fetch_array($rs_noticias)){
				$id= $campo_noticias['id']; 
				$cpf_busca= $campo_noticias['cpf']; 
				$nome= $campo_noticias['nome']; 
				$cpf= $campo_noticias['cpf']; 
				$datacadastro= $campo_noticias['datacadastro']; 
				$dataupdate= $campo_noticias['dataupdate']; 
				}
				
				
				
				
				?>

										<script type="text/javascript">
											jQuery(document).ready(function(){
												jQuery('#emcaminhamentof').submit(function(){
													var dados = jQuery( this ).serialize();
												
													var atendimento =  $("#atendimento").val();
													var id_trabalhador_form =  $("#id_trabalhadore_e").val();	
													
													jQuery.ajax({
														type: "GET",
														url: "script_emcaminhamento.php?acao=atendimento&atendimento="+atendimento+"&id_trabalhadore_e=<?=$idtrabalhador;?>",
														data: dados,
														success: function(data)
														{																												
															  
															
															  if($.trim(data)=="S"){																
																alert("Atendimento Informado e Finalizado!");
																location.href="conteudo.php";
																}else{ 	
																	  if($.trim(data)=="N"){
																		alert("Tipo de atendimento não salvo!");																
																		}
																}
																
																if(atendimento==""){
																document.getElementById("ocutar").style.display = "none"; 																
																}else{ document.getElementById("ocutar").style.display = "block";  }
																
														}
														 
													});
													
													

													return false;
													
												});
												
												
												
												
											});
											
											
											</script>
	






				


	<form id="emcaminhamentof2"  name='emcaminhamentof2' class="form" method="POST" action="script_emcaminhamento.php?acao=atendimento" >	
			<h2>TRABALHADOR</h2>

			<div class="form-row">
			<div class="label">CPF</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  value="<?echo $cpf;?>" size="60" maxlength="60"  disabled=""class="input req-same" tabindex="22" type="text"/> 

			</div>
			</div>

			<div class="form-row">
			<div class="label">Nome</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?echo $nome;?>" tabindex="23"type="text"/>

			</div>
			</div>
			
			<div class="form-row">
			<div class="label">ID</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?=$id;?>" tabindex="23"type="text"/>

			</div>
			</div>
			
			
			<h2>ATENDIMENTO</h2>
			
			
		
			<div class="form-row">
				<div class="label">Tipo de Atendimento</div>
				<div class="input-container" style='width:546px;'>	

				<select name='atendimento'  id='atendimento' required>				
					<option value=''>Selecione</option>
					<option value='T'>Atendimento</option>
					<option value='C'>Cadastro</option>
					<option value='A'>Atualização</option>
					<option value='E'>Encaminhamento</option>
					<option value='N'>Cadastro / Encaminhamento</option>
					<option value='Z'>Atualização / Encaminhamento</option>
				</select>	

				</div>
				</div>
	
		

			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_trabalhadore_e' id='id_trabalhadore_e'type='hidden' value='<?=$id;?>'/>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_emcaminhamento_e' type='hidden' value='<?=$id_emcaminhamento;?>'/>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='cpf3' type='hidden' value='<?=$cpf_busca;?>'/>
			
			
			

			
				
				<div class="form-row">
				<div class="label"></div>
				<div class="input-container" style='width:546px;'>	
				 <a href="javascript:window.history.back()"  class="sendBtn2"> &#9668; Anterior</a>				
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar"  type="submit" class="sendBtn" />

				</div>
				</div>
				
				
				
			
</form>


</div>




</body>
</html>
