<?php
include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

        
<body>
<div id="content">
<div id="bg-container" class='contener'>



<form id="form-22" class="form" method="get" action="?formno=2">

<h2>TRABALHADORS</h2>
	
  	<!--<h3>Same fields required example</h3>-->
  	<?
	$cpf = $_GET['cpf '];
	$txnome= $_GET['cpf '];
	$txtocupacao1= $_GET['cpf '];
	$txtocupacao2= $_GET['cpf '];
	$txtocupacao3= $_GET['cpf '];
	$txtocupacao4= $_GET['cpf '];
	
	$txthabilidades1= $_GET['cpf '];
	$txthabilidades2= $_GET['cpf '];
	$txthabilidades3= $_GET['cpf '];
	$txthabilidades4= $_GET['cpf '];
	$txtPretensaoSalarial= $_GET['cpf' ];
	$txtUltimoSalario= $_GET['cpf '];
	
	?>
	<div class="form-row">
	    <div class="label">CPF</div>
	    <div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txCPF" id="txCPF" class="input req-same" maxlength="18" onchange="Maiuscula(this)"  value="<?echo $cpf;?>" disabled="" type="text"/></div>
	</div>
	<div class="form-row">
	    <div class="label">Nome</div>
	    <div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txnome" id="txnome" class="input req-same" maxlength="50" onchange="Maiuscula(this)"  value="<?echo $txnome;?>" disabled="" type="text"/></div>
	</div>
	

<h2>IDIOMAS</h2>
<div class="form-row">		

	    <div class="label">Idioma</div>
	    <div class="input-container" style='width:546px;'>		
					<select name="txIdioma" id="txIdioma" onchange="EditandoRegistro1()" tabindex="3" style="width:477px;">
					<option value="">Selecione</option>
					<option value="4">ALEMÃO</option>
					<option value="10">CHINES</option>
					<option value="2">ESPANHOL</option>
					<option value="3">FRANCES</option>
					<option value="6">GREGO</option>
					<option value="8">HOLANDES</option>
					<option value="1">INGLÊS</option>
					<option value="5">ITALIANO</option>
					<option value="9">JAPONES</option>
					<option value="7">LATIM</option>

					</select>	
				
		</div>
	</div>
	
	<div class="form-row">
			    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
					Lê 
			<select name="selLe" id="selLe" onchange="EditandoRegistro2()" tabindex="4" style="width:42px;">
				<option value="N" selected="">Não</option>
				<option value="S">Sim</option>
			</select>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txle" id="txle" type="hidden">

			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			Fala
			<select name="selFala" id="selFala" onchange="EditandoRegistro2()" tabindex="5" style="width:42px;">
				<option value="N" selected="">Não</option>
				<option value="S">Sim</option>
			</select>			
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txfala" id="txfala" type="hidden">

			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			Escreve
			<select name="selEscreve" id="selEscreve" onchange="EditandoRegistro2()" tabindex="6" style="width:42px;">
				<option value="N" selected="">Não</option>
				<option value="S">Sim</option>
			</select>			
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txescreve" id="txescreve" type="hidden">

			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			Nível
			<select name="selNivel" id="selNivel" onchange="EditandoRegistro2()" tabindex="7" style="width:100px;">
				<option value="">Selecione</option>
				<option value="B">Básico</option>
				<option value="I">Intermediário</option>
				<option value="A">Avançado</option>
			</select>	
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar" type="submit" class="sendBtn" />
				<div id="errorDiv2" class="error-div"></div>
		</div>
	</div>
	
</form>





</div>

</body>
</html>
