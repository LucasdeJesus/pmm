﻿<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);
		
		
?>
		<style>
		td{vertical-align: top;}
		body {
    font-family: Arial,Helvetica,sans-serif;
    font-size: 11px;}
	table{ font-size: 11px;}
		</style>
<body>
		<?
			$id_trabalhafo_get = $_GET['id_trabalhafo_get'];
			$vagaid = $_GET['vagaid'];
		$query_noticias_hcpj = "SELECT * FROM `encaminhamento`  WHERE trabalhadorid ='$id_trabalhafo_get' and vagaid='$vagaid' ORDER BY `encaminhamento`.`id` DESC limit 1";
		$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
		while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
		$id_vaga_ajax  = $campo_noticias_hcpj['vagaid'];
		$selStatus_ajax  = $campo_noticias_hcpj['status'];
		$id_usuario_ajax  = $campo_noticias_hcpj['usuarioid'];
		$dia_ajax  = $campo_noticias_hcpj['dia'];
		$mes_ajax  = $campo_noticias_hcpj['mes'];
		$ano_ajax  = $campo_noticias_hcpj['ano'];
		$obs  = $campo_noticias_hcpj['observacao'];
		$id_emcaminhamento  = $campo_noticias_hcpj['id'];
		$id_trabalhandor  = $campo_noticias_hcpj['trabalhadorid'];
		$datacadastro  = $campo_noticias_hcpj['datacadastro'];
		
		
					$query_noticias_hcpjvg = "SELECT * FROM `vaga` where id='$id_vaga_ajax'";
					$rs_noticias_hcpjvg    = mysql_query($query_noticias_hcpjvg);
					while($campo_noticias_hcpjvg = mysql_fetch_array($rs_noticias_hcpjvg)){			
					$id_vaga  = $campo_noticias_hcpjvg['id'];
					$id_empresa  = $campo_noticias_hcpjvg['empresaid'];
					$txcargo  = $campo_noticias_hcpjvg['cargo'];
					$txcbonome  = $campo_noticias_hcpjvg['cboid'];
					$txtfalarcom  = $campo_noticias_hcpjvg['falarcom'];
					$viaencaminhamento  = $campo_noticias_hcpjvg['viaencaminhamento'];
					$enderecoentrevista  = $campo_noticias_hcpjvg['enderecoentrevista'];
					$bairroentrevista  = $campo_noticias_hcpjvg['bairroentrevista'];
					$numeroentrevista  = $campo_noticias_hcpjvg['numeroentrevista'];
					$cidadeentrevista  = $campo_noticias_hcpjvg['cidadeentrevistaid'];
					$proximode  = $campo_noticias_hcpjvg['proximode'];
					$cepentrevista  = $campo_noticias_hcpjvg['cepentrevista'];
					$tel1  = $campo_noticias_hcpjvg['tel1'];
					$tel2  = $campo_noticias_hcpjvg['tel2'];
					$tel3  = $campo_noticias_hcpjvg['tel3'];					
					$emailcontato  = $campo_noticias_hcpjvg['emailcontato'];
					$emailentrevista  = $campo_noticias_hcpjvg['emailentrevista'];
					$horarioatendimento  = $campo_noticias_hcpjvg['horarioatendimento'];
					$falarcom  = $campo_noticias_hcpjvg['falarcom'];
					$horariotrabalho  = $campo_noticias_hcpjvg['horariotrabalho'];
					$sigilosa  = $campo_noticias_hcpjvg['sigilosa'];
					
					}
					
		
		?>
		
<?
									
						$query_noticias_hcpjvget = "SELECT * FROM `trabalhador` where id='$id_trabalhandor' ";
						$rs_noticias_hcpjvget    = mysql_query($query_noticias_hcpjvget);
						while($campo_noticias_hcpjvget = mysql_fetch_array($rs_noticias_hcpjvget)){			
						$nome  = $campo_noticias_hcpjvget['nome'];
						$txttelcel  = $campo_noticias_hcpjvget['telcel'];
						$txttelrec  = $campo_noticias_hcpjvget['telrec'];
						$telres  = $campo_noticias_hcpjvget['telres'];
						
						}
							
							?>
		
		
		<table border='1' width='100%'>
			<tr >
				
				<td style='vertical-align: top;padding:2px'>
			<div style='padding:30px;'>				
						<div style='100%' align='center'>
						<img src='img/logo.jpg'/>
						<img src="http://chart.googleapis.com/chart?cht=qr&chs=120x120&choe=UTF-8&chld=H&chl=SEMTRE, Vaga:<?=$id_vaga_ajax;?>,Candidato: <?=$nome;?>"/> <img src="http://macae.rj.gov.br/midia/destaque/1484053334.jpg" width="120px"/>
						</div>	

						<div>
						<br>
						<br>
						<br>
							<table width='100%'>
								<tr>
									<td width='50%' align='left'>
										<h2>Carta de Encaminhamento</h2>
									</td>
									
									<td align='right'>
										<h4><?=$id_emcaminhamento;?></h4>
										<?
										//$data = implode("/",array_reverse(explode("-",$datacadastro)));

										//$datacadastro = implode("-",array_reverse(echo explode("/",$datacadastro)));
										$data = date("d-m-Y H:i:s", strtotime($datacadastro));
										?>
										<div style='font-size:10px'>Data do Encaminhamento: <br> <?=$data;?></div>
										
									</td>
									
								</tr>	
								</table>
								
							<table width='100%'>	
								<tr>
									<td align='left' >
										<div><b>ID da Vaga: </b><?=$id_vaga_ajax;?></div>
										
										<?
									
										$query_noticias_hcpjvge = "SELECT * FROM `empresa` where id='$id_empresa'";
										$rs_noticias_hcpjvge    = mysql_query($query_noticias_hcpjvge);
										while($campo_noticias_hcpjvge = mysql_fetch_array($rs_noticias_hcpjvge)){			
										$txnome  = $campo_noticias_hcpjvge['nome'];
										$txtendereco  = $campo_noticias_hcpjvge['endereco'];
										$txtbairro  = $campo_noticias_hcpjvge['bairro'];
										$cidadeid  = $campo_noticias_hcpjvge['cidadeid'];
										$txtestado  = $campo_noticias_hcpjvge['txtestado'];
										$txtcep  = $campo_noticias_hcpjvge['cep'];
										$numero  = $campo_noticias_hcpjvge['numero'];
									
										
										}
							
								?>

							<p>
							<br>
						<br>
						
								<div style='font-size:10px;'>EMPRESA / INSTITUIÇÃO:</div>
								<?if($sigilosa=="S"){echo"Não Informar";}else{?>
										<?=$txnome;?>
								<?}?>
							<br>
						<br>
						
							</p>
							
							
								<?
							switch ($viaencaminhamento){										
							case "I":											
							$viaencaminhamento_N = "Ir ao Endereço";
							break;case "L":											
							$viaencaminhamento_N = "Ligar Antes";
							break;case "E":											
							$viaencaminhamento_N = "Email (Currículo)";
							break;case "D":
							$viaencaminhamento_N = "Deixar (Currículo) Semtre";
							break;
							}
							?>
			
			<?if($viaencaminhamento=="I"){?>
							<div><span class='text_azul'><b>Endereço: </b></span><?=$enderecoentrevista;?>, <?=$numeroentrevista;?> </div>							
							<div><span class='text_azul'><b>Bairro: </b></span> <?=$bairroentrevista;?> </div>							
							
											<?	
											$query_estado_dben = "SELECT * FROM `cidade` where id='$cidadeentrevista' ";
											$rs_estado_dben     = mysql_query($query_estado_dben );
											while($campo_estado_dben  = mysql_fetch_array($rs_estado_dben )){
											$ufiden        = $campo_estado_dben ['ufid'];

											$query_estado_dbufen = "SELECT * FROM `uf` where id='$ufiden' ";
											$rs_estado_dbufen     = mysql_query($query_estado_dbufen );
											while($campo_estado_dbufen  = mysql_fetch_array($rs_estado_dbufen )){
											$uf_nomeen        = $campo_estado_dbufen ['uf'];
											$id_uf_dben        = $campo_estado_dbufen ['id'];
											}

											}	
											?>
											
											<?	
												$query_noticias_cidadecpen = "SELECT * FROM `cidade` where id='$cidadeentrevista' ";
												$rs_noticias_cidadecpen    = mysql_query($query_noticias_cidadecpen);
												while($campo_noticias_cidadecpen = mysql_fetch_array($rs_noticias_cidadecpen)){
												$local_cidadeen        = $campo_noticias_cidadecpen['nome'];	
												$cidadelocaliden        = $campo_noticias_cidadecpen['id'];	
												}	
												?>
							<div><span class='text_azul'><b>Cidade: </b></span><?=$local_cidadeen;?>/ <?=$uf_nomeen;?> / <?=$cepentrevista;?></div>							
							<div><span class='text_azul'><b>Próximo de: </b> </span> <?=$proximode;?></div>							
							
							<?}else{
							
											if($viaencaminhamento=="L"){
													?>
							
							
											<b>Telefone de Contato:</b> <div>	<?=$tel1?> /	<?=$tel2?> /	<?=$tel3?></div>							
							
											<?}else{
							
												if($viaencaminhamento=="E"){
												?>
												<div><span class='text_azul'><b>Email: </b> </span><?=$emailentrevista;?> </div>							
												
												<?}else{
												
														if($viaencaminhamento=="V"){
														?>
														<h5>Entrevista na SECRETÁRIO MUNICIPAL ADJUNTO DE TRABALHO E RENDA</h5>
														<div><span class='text_azul'><b>Endereço: </b></span>Rua Alfredo Backer, 363   </div>							
														<div><span class='text_azul'><b>Bairro: </b></span> Centro </div>	
														<div><span class='text_azul'><b>Cidade: </b></span> Macaé - RJ </div>	
														<div><span class='text_azul'><b></b></span> Próximo ao Corpo de Bombeiro  </div>	
														
														
														
														<?
														}					
												
												}
											}
									}		
											?>
							
							
							<div><span class='text_azul'><b>Horário: </b></span> <?=$horarioatendimento;?></div>							
							<div><span class='text_azul'><b>Procurar: </b></span> <?=$falarcom;?></div>							
							
							<?
							switch ($viaencaminhamento){										
							case "I":											
							$viaencaminhamento_N = "Ir ao Endereço";
							break;case "L":											
							$viaencaminhamento_N = "Ligar Antes";
							break;case "E":											
							$viaencaminhamento_N = "Email (Currículo)";
							break;case "D":
							$viaencaminhamento_N = "Deixar (Currículo) Semtre";
							break;
							;case "V":
							$viaencaminhamento_N = "Entrevista CTM";
							break;
							}
							?>
							
							<!--<div><span class='text_azul'>Horário:</span><?=$horariotrabalho;?></div>-->
			
							
							
									</td>
									
									
								</tr>									
							</table>
							
							
							
							
								
							
							
							<div style='font-size:10px;margin-top:10px;'>	Solicitamos o atendimento ao candidato, indicado abaixo, conforme descrição:				</div>
							
							
							
							
							<div style='font-size:10px;margin-top:10px;'><b>ID do Trabalhador:</b> <?=$id_trabalhandor;?></div>
							<div><b>Nome: </b><?=$nome;?></div>
							<div><b>Tel.: </b><?=$telres;?> / <?=$txttelcel;?> / <?=$txttelrec;?></div>
							
							
							<?
									
								$query_noticias_hcpjvgetc = "SELECT * FROM `cbo` where id='$txcbonome' ";
								$rs_noticias_hcpjvgetc    = mysql_query($query_noticias_hcpjvgetc);
								while($campo_noticias_hcpjvgetc = mysql_fetch_array($rs_noticias_hcpjvgetc)){			
								$cbo  = $campo_noticias_hcpjvgetc['cbo'];
								
								
								}
							
							?>
							<p>
							<div>Cargo pretendido: 
							
							<?=$txcargo;?>
							</div>
							</p>
							
							
							
							
							<p style='margin-top:20px;'>
							<table style='font-size:10px;' width='100%'>
								<tr>
									<td  align='left'>
										<b>Cordialmente, <br>Leonardo Pessanha da Rocha</b><br>
										(SECRETÁRIO MUNICIPAL ADJUNTO DE TRABALHO E RENDA  - Mat.404103)
									</td>
									
									<td align='center'>
										________________________________<br>
										Servidor Responsável<br>
										<?
										$sql3 = "select nome  from usuario where id  ='$id_usuario_ajax'";
										$rsd3 = mysql_query($sql3);
										while($rs3 = mysql_fetch_array($rsd3)) {
										$usuario_ajax = $rs3['nome'];
										}

										?>
										(<?=$usuario_ajax;?>)
										
									</td>
									
								</tr>	
								
																
							</table>
							</p>
							<br>
						<br>
						
							<p style='font-size:10px;'><b>Importante:</b> O Candidato acima foi submetido a uma análise de compatibilidade com a vaga oferecida.Contudo, o processo de seleção completo
							deverá ser efetuado pelo contratante. Não será permitido qualquer tipo de rasura ou alteração nos dados constantes neste documento, sendo passível
							a perda de fidelidade do mesmo junto aos órgãos competentes.
							
							</p>
							<br>
						<br>
						
							
							<div style='100%' align='center' style='font-size:12px;'>
							<p>
								<b>SECRETÁRIO MUNICIPAL ADJUNTO DE TRABALHO E RENDA - Novo Endereço:<br>
								Rodovia Amaral Paixoto, S/n<br>
								Macaé -  RJ<br>
								Ponto de Referência: Em frente ao Estádio Cláudio Moacyr  <br>
								www.macae.rj.gov.br/TRABALHOERENDA
								</b>
							</p>	
							</div>
							
							
							
						</div>
						
					</div>	
				</td>
			
			</tr>
		</table>
		
		
		
		
		
		
		

<?}?>

<script type='text/javascript'>window.print();</script>

</body>