<HTML>
<HEAD>
	<title>Secretaria Municipal de Trabalho e Renda de Macaé</title>
</HEAD>
<frameset rows="10,*,25" framespacing="0" frameborder="0"> 
	<FRAME src="topo.php" name="treeTitle" frameborder="0" scrolling="No" noresize marginwidth="0" marginheight="0" framespacing="0">
	<FRAMESET cols="193,*"> 
		<FRAME src="menu.php" name="treeFrame" frameborder="0"  marginwidth="5" marginheight="0" framespacing="0"> 
		<FRAME SRC="conteudo.php" name="mainFrame" frameborder="0"  marginwidth="0" marginheight="0" framespacing="0">
	</FRAMESET>
	<FRAME src="rodape.php" name="TimerFrame" frameborder="0" scrolling="No" noresize marginwidth="0" marginheight="0" framespacing="0"> 
</FRAMESET> 

</HTML>
</HTML>