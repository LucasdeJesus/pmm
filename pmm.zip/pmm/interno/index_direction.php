
<?
$actual_link = $_SERVER['HTTP_REFERER'];
	if($actual_link=="http://sistemas.macae.rj.gov.br:84/catalogo/semtre/index/mural"){
	?>
	<SCRIPT language="JavaScript">
		//window.location='http://www.cetepmacae.rj.gov.br/semtre/interno/interno/muralexterno.php'
		window.location='http://institutocoimbra.com.br/semtre/interno/interno/muralexterno.php';
	</script><?
	}
	
	else{?>
	<SCRIPT language="JavaScript">
	window.location='http://institutocoimbra.com.br/semtre/';
	</script>
	<?}
exit;
?>
<html>
<?include'topo.php';?>

<body>
	<?include"topo_logo.php";
	
	?>


	
									
<script language="JavaScript">
function cpf_loginfun(){
var cpf_login = document.cpf_loginF.cpf_login.value;
var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
if(!filtro.test(cpf_login)){
window.alert("CPF inválido. Tente novamente.");
return false;
}

cpf_login = remove(cpf_login, ".");
cpf_login = remove(cpf_login, "-");

if(cpf_login.length != 11 || cpf_login == "00000000000" || cpf_login == "11111111111" ||
cpf_login == "22222222222" || cpf_login == "33333333333" || cpf_login == "44444444444" ||
cpf_login == "55555555555" || cpf_login == "66666666666" || cpf_login == "77777777777" ||
cpf_login == "88888888888" || cpf_login == "99999999999"){
window.alert("cpf inválido. Tente novamente.");
return false;
}

soma = 0;
for(i = 0; i < 9; i++)
soma += parseInt(cpf_login.charAt(i)) * (10 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_login.charAt(9))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
soma = 0;
for(i = 0; i < 10; i ++)
soma += parseInt(cpf_login.charAt(i)) * (11 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_login.charAt(10))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
return true;
}

function remove(str, sub) {
i = str.indexOf(sub);
r = "";
if (i == -1) return str;
r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
return r;
}
</script>	

		
									
<script language="JavaScript">
function cpf_trabalhadorfun(){
var cpf_trabalhador = document.cpf_trabalhadorF.cpf_trabalhador.value;
var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
if(!filtro.test(cpf_trabalhador)){
window.alert("CPF inválido. Tente novamente.");
return false;
}

cpf_trabalhador = remove(cpf_trabalhador, ".");
cpf_trabalhador = remove(cpf_trabalhador, "-");

if(cpf_trabalhador.length != 11 || cpf_trabalhador == "00000000000" || cpf_trabalhador == "11111111111" ||
cpf_trabalhador == "22222222222" || cpf_trabalhador == "33333333333" || cpf_trabalhador == "44444444444" ||
cpf_trabalhador == "55555555555" || cpf_trabalhador == "66666666666" || cpf_trabalhador == "77777777777" ||
cpf_trabalhador == "88888888888" || cpf_trabalhador == "99999999999"){
window.alert("cpf inválido. Tente novamente.");
return false;
}

soma = 0;
for(i = 0; i < 9; i++)
soma += parseInt(cpf_trabalhador.charAt(i)) * (10 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_trabalhador.charAt(9))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
soma = 0;
for(i = 0; i < 10; i ++)
soma += parseInt(cpf_trabalhador.charAt(i)) * (11 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_trabalhador.charAt(10))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
return true;
}

function remove(str, sub) {
i = str.indexOf(sub);
r = "";
if (i == -1) return str;
r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
return r;
}



</script>	

		
		<div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);height:500px;margin-top:50px;' align='center' >
		
				
			<table width='960px'>
					<tr>
					
					
						<td width='460'>
							<div style='height:225px;border: 3px dotted  #00B8AD;margin:10px;border-radius: 5px;margin-top:10px;color:#00B8AD;padding:15px;'>
							<h3><img src='img/traba.png'> Trabalhador</h3>
							<h2>
								Procurando uma oportunidade de emprego?
								</h2>
								
							<p>Inscreva-se e participe do processo de intermediação de emprego. Acesse as vagas disponíveis na SEMTRE. Elabore e imprima seu currículo.</p>
								
								
								
								
								
							
								
								
								<form  class="form">
								<a href="#"  class="sendBtn2" data-reveal-id="myModal">
								acessar...
								</a>	
								
								<a href="#"  class="sendBtn" data-reveal-id="cadastro_trabalhador">
								Cadastre-se
								</a>
								
								</form>
								
																
								
								<div id="myModal" class="reveal-modal">
								
										<script type="text/javascript">
										function exibe(id) {
										if(document.getElementById(id).style.display=="none") {
										document.getElementById(id).style.display = "inline";
										}
										else {
										document.getElementById(id).style.display = "none";
										}
										}
										</script>
								
								
										<h2>Acesso área do Trabalhador</h2>
										<form  class="form" method="POST" action="valida_trabalhado.php"  id="cpf_loginF" name='cpf_loginF' onSubmit="return cpf_loginfun()">
												
												
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container">
													<input name="cpf_login" id='cpf_login' required   onkeypress='mascaraMutuario(this,cpfCnpj)'  placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  />
												</div>
												</div>
												
												
												<div class="form-row">
												<div class="label">Senha</div>
												<div class="input-container"><input name="senha" id='senha' required  placeholder="senha" type="password"  style='width:130px;'class="input req-same"   /></div>
												</div>

												
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn" value='acessar'  /></div>
												</div>
												
												<p> Se você esqueceu sua senha, <a href='#' onclick="javascript: exibe('conteudo');">clique aqui</a></p>			
												
												
										
										</form>
										
										<!-----envia senha email ---->
										<div id="conteudo" style="display: none;">
										
										<form  class="form">
										<h2>Informa seu CPF Cadastrado</h2>
										<p>Você recebara um email com a senha!</p>
												
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container"><input name="cpf_trabalhador" id='cpf_trabalhador_cadastro'  onkeypress='mascaraMutuario(this,cpfCnpj)'  required  placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  /></div>
												</div>
												
												
												<div class="form-row">
											<div class="label"></div>
											<div class="input-container" style='width:246px;'>		
												
											
												<input id="submitBtn2" value="Enviar" type="submit" class="sendBtn" />
													<div id="errorDiv2" class="error-div"></div>
											</div>
										</div>
										
													
										</form>
										
										
										</div>
										
										<!------------envia senha email -------------->
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
								
								<div id="cadastro_trabalhador" class="reveal-modal">
								
								
										<h2>Cadastro do Trabalhador</h2>
										<form  class="form" method="POST" action="cadatro_trabalhador_1.php"  id="cpf_trabalhadorF" name='cpf_trabalhadorF' onSubmit="return cpf_trabalhadorfun()">
												
												
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container"><input name="cpf_trabalhador" id='cpf_trabalhador' required  onkeypress='mascaraMutuario(this,cpfCnpj)' placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  /></div>
												</div>
												
												
												
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn"  value='Avançar'  /></div>
												</div>
												
											
										
										</form>
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
								
								
								
								
								
		
		
							</div>							
						</td>	

						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
							<td width='460'>
							<div style='height:225px;border: 3px dotted #F36C34;margin:10px;border-radius: 5px;margin-top:10px;color:#F36C34;padding:15px'>
								<h3><img src='img/empregador.png'> Empregador</h3>
								<h2>
								A SEMTRE ajuda você a encontrar e selecionar as pessoas certas
								</h2>
								<p>
								Cadastre-se e disponibilize vagas para os trabalhadores inscritos na SEMTRE .
								</p>
								
								
								
								<form  class="form">
								<a href="#"  class="sendBtn2" data-reveal-id="myModal2">
								acessar...
								</a>	
								
								<a href="#"  class="sendBtn" data-reveal-id="cadastro_empresa">
								Cadastre-se
								</a>
									
								 <a href="#" class="sendBtn" data-reveal-id="ajuda" >Ajuda</a>
							
								</form>
								
								<div id="myModal2" class="reveal-modal">
								
								
								
								
										<h2>Acesso área do Empregador</h2>
										<form  class="form" method="post" action="valida_empresa.php"  id="cadastroem" name='cadastroem' onSubmit=" return ValidarCNPJ(cadastroem.txCNPJ);">
												
												
												<div class="form-row">
												<div class="label">CNPJ</div>
												<div class="input-container">
													<input name="txCNPJ" id="txCNPJ" required value=''maxlength="18" placeholder="Insira o CNPJ" tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)' onBlur="ValidarCNPJ(cadastroem.txCNPJ);" style="width:194px;" type="text" class="input req-same">
												</div>
												</div>
												
												
												<div class="form-row">
												<div class="label">Senha</div>
												<div class="input-container"><input name="senha" required  id='senha' placeholder="senha" type="password"  style='width:130px;'class="input req-same"   /></div>
												</div>
												
												<input type='hidden' name="enviado" value="posted">
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn" onclick='return validar_cpf()' value='acessar'  /></div>
												</div>
						
													<p> Se você esqueceu sua senha, <a href='#' onclick="javascript: exibe('conteudo_empresa');">clique aqui</a></p>
													
													
													
													
										</form>
										
										<?
										$pass= $_GET['pass'];
										$txCNPJ_POST= $_POST['txCNPJ'];
										
										if($pass > 0){
											$query_user = "SELECT * FROM `usuario` WHERE usuario = '$txCNPJ_POST'";										
											$rs_user   = mysql_query($query_user);
											while($campo_user = mysql_fetch_array($rs_user)){
											$iduser 	= $campo_user['id']; 											
											$senhauser 	= $campo_user['senha']; 											
											$usuariouser 	= $campo_user['usuario']; 											
											}	
											
											if($iduser > 0){											
													
													$query_dadoslembrete = "SELECT * FROM `empresa` WHERE cnpj = '$txCNPJ_POST'";										
													$rs_dadoslembrete   = mysql_query($query_dadoslembrete);
													while($campo_dadoslembrete = mysql_fetch_array($rs_dadoslembrete)){
													$idsecao 	= $campo_dadoslembrete['id']; 
													$nomeempresa 	= $campo_dadoslembrete['nome']; 
													$email 	= $campo_dadoslembrete['email']; 
													$emailresponsavel 	= $campo_dadoslembrete['emailresponsavel']; 
													
													}	
													

													$assunto	= "Solicitação de Senha";
													global $email;
													$data      = date("d/m/y");                     
													$ip        = $_SERVER['REMOTE_ADDR'];          
													$navegador = $_SERVER['HTTP_USER_AGENT'];       
													$hora      = date("H:i");                       
													$remetente      = "semtrevagas@macae.rj.gov.br"  ;                     
													$destinatario      = "$email,$emailresponsavel"  ;                     

													
												$headers = "MIME-Version: 1.0\r\n";
												$headers .= "Content-type: text/html; charset=".$charset."\r\n";
												//$headers .= "Cc: semtrevagas@macae.rj.gov.br\r\n";
												$headers .= "Bcc: $email\r\n"; 
												$headers .= "From: ".$remetente."\r\n";
												$corpo="Dados de  Acesso sistema SEMTRE: <br><br> LOGIN: $usuariouser <br>SENHA: $senhauser\n <br>LINK<br>http://sistemas.macae.rj.gov.br:84/catalogo/semtre ";
													
													
													
													if(mail($destinatario, $assunto, $corpo, $headers)) {
														echo "<script>alert('Dados de Acesso enviado para email $email')</script>";
														}
														else {
														echo "<script>alert('Erro: tente novamente')</script>";
														}
														
											}
										}
										?>
										
										<!-----envia senha email ---->
										<div id="conteudo_empresa" style="display: none;">
										
										<form  class="form"   action="?pass=1"id='lembrasenha' method="post"name='lembrasenha' onSubmit=" return  ValidarCNPJ(lembrasenha.txCNPJ);">
										<h2>Informa seu CPF/CNPJ Cadastrado</h2>
										<p>Você recebara um email com a senha!</p>
												
												<div class="form-row">
												<div class="label">CNPJ</div>
												<div class="input-container">
													<input name="txCNPJ" id="txCNPJ" required value=''maxlength="18" placeholder="Insira o CNPJ" tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)' onBlur="ValidarCNPJ(lembrasenha.txCNPJ);" style="width:194px;" type="text" class="input req-same">
												</div>
												</div>
												
												<div class="form-row">
											<div class="label"></div>
											<div class="input-container" style='width:246px;'>		
												
											
												<input id="submitBtn2" value="Enviar" type="submit" class="sendBtn" />
													<div id="errorDiv2" class="error-div"></div>
											</div>
										</div>
										
													
										</form>
										
										
										</div>
										
										<!------------envia senha email -------------->
										
										
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
								
								
								<div id="cadastro_empresa" class="reveal-modal">
								
								
										<h2>Cadastro do Empregador</h2>
										<form  class="form" method="GET" onSubmit="return  ValidarCNPJ(cadastroem2.txCNPJ);" action="cadatro_empresa_1.php"  id="cadastroem2" name='cadastroem2' >
												
												
												<div class="form-row">
												<div class="label">CNPJ</div>
												<div class="input-container">
													<input name="txCNPJ" id="txCNPJ" required value=''maxlength="18" placeholder="Insira o CNPJ" tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)' onkeypress='mascaraMutuario(this,cpfCnpj)' onBlur="ValidarCNPJ(cadastroem2.txCNPJ);"style="width:194px;" type="text" class="input req-same">
												</div>
												</div>
												
																								
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn" onclick='return validar_cpf()' value='próximo &#10132;'  /></div>
												</div>
						
													
										</form>
										
										
										
										
										
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
								
								<div id="ajuda" class="reveal-modal">
								
								
										
										
										
										<img src='img/cadastrosemtre.jpg' width="500px">
										
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
							
							</div>
							
						</td>	
						
						
						
						

						
					</tr>
				</table>
				
		</div>
		
		
		
			<?include"rodape_novo.php";?>
	
</body>
</html>