<?php
include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>	
<HTML>
<HEAD>
	<title>Secretaria Municipal de Trabalho e Renda de Macaé</title>
		<script type="text/javascript">
		function test() { alert('teste de mensagem'); };
		</script>
</HEAD>
<frameset rows="*,25" framespacing="0" frameborder="0"> 
	
	<FRAMESET cols="257,*" id='framecontenhe' name='framecontenhe'> 
		<FRAME src="menu.php"  id='frememenu' name='frememenu' style='overflow-y: hidden;border-right:2px solid #157FCC'frameborder="0"  style='' marginwidth="5" marginheight="0" framespacing="0"> 
		<FRAME SRC="principal.php" name="mainFrame"  id='mainFrame'frameborder="0"  marginwidth="0" marginheight="0" style="background-color:#F0F0F0;"framespacing="0">
	</FRAMESET>
	
	<FRAME src="rodape.php" name="TimerFrame" frameborder="0" scrolling="No" noresize marginwidth="0" marginheight="0" framespacing="0"> 
</FRAMESET> 

</HTML>
</HTML>