<?php
include"../../input_banco.php";

	
ini_set('default_charset','UTF-8'); // Para o charset das páginas e
mysql_set_charset('utf8'); // para a conexão com o MySQL
error_reporting(0);
$q = strtolower($_GET["q"]);
if (!$q) return;

		$query_noticias = "select DISTINCT cargo from vaga where cargo LIKE '%$q%'";	
		$rs_noticias    = mysql_query($query_noticias); 		
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		
		$cargo= $campo_noticias['cargo']; 
		 
	
	echo "$cargo\n";
}

		
?>