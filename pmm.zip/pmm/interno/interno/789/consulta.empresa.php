<?php
$host="localhost"; // Host name
$username="root"; // Mysql username
$password="web"; // Mysql password
$db_name="semtre"; // Database name


	$con = mysql_connect($host,$username,$password)   or die(mysql_error());
	mysql_select_db($db_name, $con)  or die(mysql_error());

$q = strtolower($_GET["q"]);
if (!$q) return;

$sql = "select DISTINCT txnome,id_empresa from empresa where txnome LIKE '%$q%'";
$rsd = mysql_query($sql);
while($rs = mysql_fetch_array($rsd)) {
	$txnome = $rs['txnome'];
	$id_empresa = $rs['id_empresa'];
	
	echo "ID: $id_empresa $txnome\n";
}
?>