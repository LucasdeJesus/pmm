<?
include"../input_banco.php";
		
		
		$acao = $_GET['acao'];
		switch ($acao) {

			case vagafechada:
			
				$horaagora =  date("Y-m-d H:i");
				//$horaagora = "2015-11-18 01:21";
				$arr = array();
				
				
					$rs = mysql_query("SELECT * FROM  `vaga` WHERE  `status` IN ( 'S',  'P',  'O',  'C',  'E',  'R')AND  `dataupdate` >=  '$horaagora'");
					$totaldata  = mysql_num_rows($rs);				
					while($obj = mysql_fetch_object($rs)) {
					
					
						$arr[] = $obj;
					}
			
					
					if($totaldata==0){$obj->databr = "0";$arr[] = $obj;}
					
				
				echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				

			break;
			
			
			case chamaatendimento:
			
				$horaagora =  date("Y-m-d");
				//$horaagora = "2015-11-18 01:21";
				$arr = array();
				
				
					$rs = mysql_query("SELECT * FROM  `chamanome` ");
					$totaldata  = mysql_num_rows($rs);				
					while($obj = mysql_fetch_object($rs)) {
					
					
						$arr[] = $obj;
					}
			
					
					if($totaldata==0){$obj->databr = "0";$arr[] = $obj;}
					
				
				echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				

			break;
			
			
			
			case deletnome:
			header('Access-Control-Allow-Origin: *');
				$horaagora =  date("Y-m-d");
				//$horaagora = "2015-11-18 01:21";
				$arr = array();
				$totaldata=0;
				
				$query="DELETE FROM `chamanome` WHERE `chamanome`.`id` > '0' ";
				$rs= mysql_query($query);
			
					
					if($totaldata==0){$obj->databr = "0";$arr[] = $obj;}
					
				
				echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
				

			break;
			
		}