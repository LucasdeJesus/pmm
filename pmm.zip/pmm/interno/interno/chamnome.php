<?
include"../input_banco.php";
?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Vagas TV</title>
	<style>
	.text_azul{color:blue;}
	span{line-height:130%;}
	html{overflow-y:hidden;}
	body{overflow-y:hidden;}
	</style>
	
	   
    <!-- Bootstrap -->
   <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css" integrity="sha384-aUGj/X2zp5rLCbBxumKTCw2Z50WgIr1vs/PFN4praOTvYXWlVyh2UtNUU0KAUhAX" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" integrity="sha512-K1qjQ+NcF2TYO/eI3M6v8EiNYZfA95pQumfvcVrTHtwQVDG+aHRqLi/ETn2uB+1JqwYqVG3LIvdm9lj6imS/pQ==" crossorigin="anonymous"></script>
   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" integrity="sha256-Sk3nkD6mLTMOF0EOpNtsIry+s1CsaqQC1rVLTAy+0yc= sha512-K1qjQ+NcF2TYO/eI3M6v8EiNYZfA95pQumfvcVrTHtwQVDG+aHRqLi/ETn2uB+1JqwYqVG3LIvdm9lj6imS/pQ==" crossorigin="anonymous"></script>
 
 
 

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body bgcolor="">

	
	
		
		<table style="width:100%;height:99%;background-color:#01569F">
			<tr>
				<td style="height:20%">
					<div id="nomeprincipal"   >
	
    
					</div>
						
				</td>
			</tr>
			
			
			<tr style="width:100%;background-color:#71A7D6">
				<td>
				er
				</td>
			</tr>
			
			
			
			<tr>
				<td>
				er
				</td>
			</tr>
			
			
		</table>
		
		
		
		
	
		
		
	


	
<!-- Modal -->
<div class="modal fade" id="myModalnome" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content" >
      <div class="modal-header"  style="background-color:#f2dede">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title" id="myModalLabel">Atendimento</h3>
      </div>
      <div class="modal-body">
			<div id="fechanome">
			
			</div>
      </div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>	
		
	<script type="text/javascript">

					</script>	
		
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 <script>
    
		
		
		
		function chamanome(){
			
			$('#nomeprincipal').empty();
				$.ajax({
				url: 'acoesmuraltv.php?acao=chamaatendimento' ,	
				dataType: 'jsonp',
				jsonp: 'jsoncallback',
				timeout: 5000,
				success: function(data, status){
					
					$.each(data, function(i,item){
					
						if(item.databr=="0"){}else{
						
						var divmodalvaga = '<div style="color:#fff" ><b>'+item.nome+' </b> atendimento  <b>'+item.tipo+'</b> </div>';
						$("#nomeprincipal").append(divmodalvaga);
						//$('#myModalnome').modal('show') ;
						
						
						
						setTimeout(function() {		
						
						
						//$('#myModalnome').modal('hide') ;
						
						$.ajax({
							type: "GET",
							url: "acoesmuraltv.php?acao=deletnome",
							success: function(data) {
							//manipula os dados
							
							},
							error: function() {
							}
							});
						
						
						}, 5000);
						
						
						
						
						}
					
					});
						
				},
				error: function(){
								
				}
				});
		
		setTimeout("chamanome()", 10000);	
		}
		
		
		
		 chamanome(); 
 
	</script>
	
	
	
	
	
	
	

 </body>
</html>