	<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=filtropcd".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	
	
	
	?>
	

<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

td{padding:5px;}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>
	<style>
	.text_azul{color:blue;}
	span{line-height:130%;}
	</style>
	
	
	<div id="getexcel">
	
	<?
	
				//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
				//if($usuario==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='$post_status'  ";}
				if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
				if($post_contapcd==""){}else{$sqlcontacpd="and `vagadeficiente` = '$post_contapcd' ";}				
				if($post_statusescolaridade==""){}else{$sqlstatusescolaridade="and `situacao` = '$post_statusescolaridade' ";}				
				
				
				if($post_escolaridade==""){}else{
				
					$idtrabalhadoreesclaridades="";
					
					$query_escolaridade = "SELECT * FROM `escolaridade` WHERE `escolaridade` = '$post_escolaridade'".$post_statusescolaridade." ";
					$rs_escolaridade    = mysql_query($query_escolaridade);
					while($campo_escolaridade = mysql_fetch_array($rs_escolaridade)){
					$trabalhadorid_escolaridade= $campo_escolaridade['trabalhadorid']; 
					$idtrabalhadoreesclaridades.="$trabalhadorid_escolaridade ,"; 
					}
					
					
					$sqloescolaridade="and `id` IN ($idtrabalhadoreesclaridades 0)";
				
				}
				
				if($post_pcd_status==""){}else{
				
					$idtrabalhadoreesclaridades2="";
					
					$query_escolaridade2 = "SELECT status  FROM `trabalhadorpcd` where status = '$post_pcd_status' ";
					$rs_escolaridade2    = mysql_query($query_escolaridade2);
					while($campo_escolaridade2 = mysql_fetch_array($rs_escolaridade2)){
					$trabalhadorid_escolaridade2= $campo_escolaridade2['trabalhadorid']; 
					$idtrabalhadoreesclaridades2.="$trabalhadorid_escolaridade2 ,"; 
					}
					
					
					$sqlopcd_status="and `id` IN ($idtrabalhadoreesclaridades2 0)";
				
				}
				
				
				if($post_intencao==""){}else{$sqlintencao="and intencao='$post_intencao' ";}
				if($post_sexo==""){}else{$sqlsexo="and sexo='$post_sexo' ";}
				if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
				
				
				 //$post_datainicio1 = date("Y-m-d", strtotime($post_datainicio));
				//$post_datafinal1 = date("Y-m-d", strtotime($post_datafinal));
				
				$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
				$post_datafinal1 = implode("-",array_reverse(explode("/",$post_datafinal)));
				
				
						$post_datainicio1 = date("Y-n-j", strtotime($post_datainicio1));
				
				if(($post_datainicio=="") || ($post_datafinal==""))
				{
					
					//$post_datainicio1 = date("Y-n-j", strtotime($post_datainicio));
					//$post_datafinal1 = date("Y-n-j", strtotime($post_datafinal));
					
					
					if($post_datainicio==""){}else{
						
						//$post_datainicio1 = date("Y-n-j", strtotime($post_datainicio1));
						$sql2data="and `data` = '$post_datainicio1' ";
					}
					if($post_datafinal1==""){}else{
						$post_datafinal1 = date("Y-n-j", strtotime($post_datafinal1));
						$sql2data="and `data` ='$post_datafinal1' ";}
					
				
				}
				else{
				$post_datafinal1 = date('Y-n-j', strtotime("+1 days",strtotime($post_datafinal1))); // 15/03/2006
				$sql2data= "and `data` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
				}
				if($tipo==""){
					$sqltipo= "and tipo IN ( 'D','V','C')";
					
				}else{
				$sqltipo= "and tipo='$tipo'";
				}
				
				
					switch ($tipo) {
				case "C" :
					$tipoatendimento = "Atendimento CTPS";
					break;
				case "D":
					$tipoatendimento =  "Atendimento DETRAN";
					break;
				case "V":
					$tipoatendimento =  "Atendimento Vagas ";
					break;
					case "P":
					$tipoatendimento =  "Pendência";
					break;
					
					 default:
					$tipoatendimento =  "Todos Atendimento";
					break;
				}
		$mesbuscadata = $_POST['mesbuscadata'];		
		$anobuscadata = $_POST['anobuscadata'];		
	$sqltipopordia = "AND data IN (
	'$anobuscadata-$mesbuscadata-1',  '$anobuscadata-$mesbuscadata-2',  '$anobuscadata-$mesbuscadata-3',  '$anobuscadata-$mesbuscadata-4', '$anobuscadata-$mesbuscadata-5', '$anobuscadata-$mesbuscadata-6', '$anobuscadata-$mesbuscadata-7', '$anobuscadata-$mesbuscadata-8', '$anobuscadata-$mesbuscadata-9' , '$anobuscadata-$mesbuscadata-10',
	'$anobuscadata-$mesbuscadata-11',  '$anobuscadata-$mesbuscadata-12',  '$anobuscadata-$mesbuscadata-13',  '$anobuscadata-$mesbuscadata-14', '$anobuscadata-$mesbuscadata-15', '$anobuscadata-$mesbuscadata-16', '$anobuscadata-$mesbuscadata-17', '$anobuscadata-$mesbuscadata-18', '$anobuscadata-$mesbuscadata-19' , '$anobuscadata-$mesbuscadata-20',
	'$anobuscadata-$mesbuscadata-21',  '$anobuscadata-$mesbuscadata-22',  '$anobuscadata-$mesbuscadata-23',  '$anobuscadata-$mesbuscadata-24', '$anobuscadata-$mesbuscadata-25', '$anobuscadata-$mesbuscadata-26', '$anobuscadata-$mesbuscadata-27', '$anobuscadata-$mesbuscadata-28', '$anobuscadata-$mesbuscadata-29' , '$anobuscadata-$mesbuscadata-30', '$anobuscadata-$mesbuscadata-31'
	)
	GROUP BY data";
	?>
	
	
	<table  border="1" bordercolor="#000000" style="border-collapse: collapse" cellpadding="2" class="sortable" style='font-size:11px;'  font="11" class="sortable">
		
		
		
		
		
			
					<tr>
		
		
		
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b>Data</b></font>
						</td>
						
						
					
				

					
				
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b>Tipo</b></font>
						</td>
						
						
						
					

					
					
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b>Aguardando</b></font>
						</td>
						
						
					
					
					
					
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b>Atendido</b></font>
						</td>
						
					
				
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b>1º via</b></font>
						</td>
						
					
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b>2º via</b></font>
						</td>
						
						
					
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b>Não Compareçeu</b></font>
						</td>
						
					
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b>Atendimento Pendência</b></font>
						</td>
						
					
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b>Cancelado</b></font>
						</td>
						
					
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b> Encaixe </b></font>
						</td>
						
					
						<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
							<font color="#ffffff" face="Tahoma"><b>TOTAL</b></font>
						</td>
						
						
						
						
					</tr>
				<?
				$totalperidadoguardando = 0;
				$totalperiado =0;
				$totalperidadoatendido =0;
				$totalperiadoprimeiravia =0;
				$totalperiadosegundavia =0;
				$totalperiadonaocompareceu =0;
				$totalperiadopendencia =0;
				$totalperiadocancelado =0;
				$totalperiadoencaixe =0;
				$query_noticias_aguardando = "SELECT *  FROM `agendamentoctps` where id > '0'
				".$sqltipo."
				".$sqltipopordia."	
				";

				//echo$query_noticias_aguardando ; 
				$rs_noticias_aguardando    = mysql_query($query_noticias_aguardando);	
				while($campo_noticias = mysql_fetch_array($rs_noticias_aguardando)){
				$databanco 	= $campo_noticias['data']; 
				$sql2databanco="and `data` ='$databanco'";

				$newDate = date("Y-m-d", strtotime($databanco));

				?>
				<tr>
						<td bgcolor="" align="center" >
							<font color="#000" face="Tahoma"><b><?=$newDate;?> </b></font>
						</td>
						
						<td bgcolor="" align="center" >
							<font color="#000" face="Tahoma"><b><?=$tipoatendimento;?> </b></font>
						</td>

						<td bgcolor="" align="center" >
							<?
							$query_noticias_aguardando1 = "SELECT *  FROM `agendamentoctps` where  status='A'   
							".$sqltipo."
							".$sql2databanco."
							ORDER BY  `nome` ASC ";
									
							//echo$query_noticias ; 
							$rs_noticias_aguardando1    = mysql_query($query_noticias_aguardando1);
							$total_aguardando = mysql_num_rows($rs_noticias_aguardando1);
							$totalperidadoguardando +=$total_aguardando ;
							?>
							<font color="#000" face="Tahoma"><b><?=$total_aguardando;?> </b></font>
						</td>
						
						
						<td bgcolor="" align="center" >
							<?
							$query_noticias_atendido = "SELECT *  FROM `agendamentoctps` where  status IN ( 'A1','A2','AT')  
							".$sqltipo."
							".$sql2databanco."
							ORDER BY  `nome` ASC ";
									
							//echo$query_noticias ; 
							$rs_noticias_atendido    = mysql_query($query_noticias_atendido);
							$total_atendido = mysql_num_rows($rs_noticias_atendido);
							$totalperidadoatendido+=$total_atendido;							
							?>
						
							<font color="#000" face="Tahoma"><b><?=$total_atendido;?> </b></font>
						</td>
						
						<td bgcolor="" align="center" >
							<?
							$query_noticias_atendido1 = "SELECT *  FROM `agendamentoctps` where status IN ( 'A1')  
							".$sqltipo."
							".$sql2databanco."
							ORDER BY  `nome` ASC ";
									
							//echo$query_noticias ; 
							$rs_noticias_atendido1    = mysql_query($query_noticias_atendido1);
							$total_atendido1 = mysql_num_rows($rs_noticias_atendido1);	
							$totalperiadoprimeiravia+=$total_atendido1
							?>
						
							<font color="#000" face="Tahoma"><b><?=$total_atendido1;?> </b></font>
						</td>
						
						
						
						
						<td bgcolor="" align="center" >
							
							<?
							$query_noticias_atendido2 = "SELECT *  FROM `agendamentoctps` where  status IN ('A2')  
							".$sqltipo."
							".$sql2databanco."
							ORDER BY  `nome` ASC ";
									
							//echo$query_noticias ; 
							$rs_noticias_atendido2    = mysql_query($query_noticias_atendido2);
							$total_atendido2 = mysql_num_rows($rs_noticias_atendido2);
							$totalperiadosegundavia+=$total_atendido2							
							?>
						
							<font color="#000" face="Tahoma"><b><?=$total_atendido2;?> </b></font>
						</td>
						
						
						
						<td bgcolor="" align="center" >
							
							<?
							$query_noticias_nao = "SELECT *  FROM `agendamentoctps` where 	 status ='N'	 	
							".$sqltipo."
							".$sql2databanco."
							ORDER BY  `nome` ASC ";
									
							//echo$query_noticias ; 
							$rs_noticias_nao    = mysql_query($query_noticias_nao);
							$total_nao = mysql_num_rows($rs_noticias_nao);	
							$totalperiadonaocompareceu +=$total_nao;
							?>
						
							<font color="#000" face="Tahoma"><b><?=$total_nao;?> </b></font>
						</td>
						
						
						
						<td bgcolor="" align="center" >
							
							<?
							$query_noticias_p = "SELECT *  FROM `agendamentoctps` where  status ='P'	
							".$sqltipo."
							".$sql2databanco."
							ORDER BY  `nome` ASC ";
									
							//echo$query_noticias ; 
							$rs_noticias_p    = mysql_query($query_noticias_p);
							$total_pendencia = mysql_num_rows($rs_noticias_p);	
							$totalperiadopendencia+=$total_pendencia;
							?>
						
							<font color="#000" face="Tahoma"><b><?=$total_pendencia;?> </b></font>
						</td>
						
						
						<td bgcolor="" align="center" >
							
							<?
							$query_noticias_c = "SELECT *  FROM `agendamentoctps` where status ='C'	
							".$sqltipo."
							".$sql2databanco."
							ORDER BY  `nome` ASC ";
									
							//echo$query_noticias ; 
							$rs_noticias_c    = mysql_query($query_noticias_c);
							$total_cancelado = mysql_num_rows($rs_noticias_c);	
							$totalperiadocancelado+=$total_cancelado;
							?>
						
							<font color="#000" face="Tahoma"><b><?=$total_cancelado;?> </b></font>
						</td>
						
						
						
						<td bgcolor="" align="center" >
							
							<?
							$query_noticias_ca = "SELECT *  FROM `agendamentoctps` where avulso='S'	
							".$sqltipo."
							".$sql2databanco."
							ORDER BY  `nome` ASC ";
									
							//echo$query_noticias ; 
							$rs_noticias_ca    = mysql_query($query_noticias_ca);
							$total_vulso = mysql_num_rows($rs_noticias_ca);	
							$totalperiadoencaixe+=$total_vulso;
							?>
							<font color="#000" face="Tahoma"><b><?=$total_vulso;?> </b></font>
						</td>
						
						
						
						
						<td bgcolor="" align="center" >
							
							<? $somatudo= $total_cancelado+ $total_pendencia+$total_nao+$total_atendido+$total_aguardando;
						$totalperiado += $somatudo;
						?>
							<font color="#000" face="Tahoma"><b><?=$somatudo;?> </b></font>
						</td>
					</tr>	
				<?}?>
				
				
				
<tr>
						<td bgcolor="" align="center" >
							<font color="#000" face="Tahoma"><b>TOTAL</b></font>
						</td>
						
						<td bgcolor="" align="center" >
							<font color="#000" face="Tahoma"><b>--</b></font>
						</td>

						<td bgcolor="" align="center" >
							
							<font color="#000" face="Tahoma"><b><?=$totalperidadoguardando;?></b></font>
						</td>
						
						
						<td bgcolor="" align="center" >
												<font color="#000" face="Tahoma"><b><?=$totalperidadoatendido;?></b></font>
						</td>
						
						<td bgcolor="" align="center" >
						
						
							<font color="#000" face="Tahoma"><b><?=$totalperiadoprimeiravia;?> </b></font>
						</td>
						
						
						
						
						<td bgcolor="" align="center" >
							
							
						
							<font color="#000" face="Tahoma"><b><?=$totalperiadosegundavia;?> </b></font>
						</td>
						
						
						
						<td bgcolor="" align="center" >
							
						
						
							<font color="#000" face="Tahoma"><b><?=$totalperiadonaocompareceu;?>  </b></font>
						</td>
						
						
						
						<td bgcolor="" align="center" >
							
						
						
							<font color="#000" face="Tahoma"><b><?=$totalperiadopendencia;?> </b></font>
						</td>
						
						
						<td bgcolor="" align="center" >
							
							
							<font color="#000" face="Tahoma"><b><?=$totalperiadocancelado;?> </b></font>
						</td>
						
						
						
						<td bgcolor="" align="center" >
							
							
							<font color="#000" face="Tahoma"><b><?=$totalperiadoencaixe;?></b></font>
						</td>
						
						
						
						
						<td bgcolor="" align="center" >
							
						
							<font color="#000" face="Tahoma"><b><?=$totalperiado;?> </b></font>
						</td>
					</tr>					
		
	</table>
	
	
	<h2>TOTAL do período : <?=$totalperiado;?> </h2>	
	</div>