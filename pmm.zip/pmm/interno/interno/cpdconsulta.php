	<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=filtropcd".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	
	
	include"topopcd.php";
	?>
	

<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

td{padding:5px;}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>
	<style>
	.text_azul{color:blue;}
	span{line-height:130%;}
	</style>
	
	
	<div id="getexcel">
	
	<table  border="1" bordercolor="#000000" style="border-collapse: collapse" cellpadding="2" class="sortable" style='font-size:11px;'  font="11" class="sortable">
	<tr>
		<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
			<font color="#ffffff" face="Tahoma"><b>ID</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
			<font color="#ffffff" face="Tahoma"><b>NOME</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab3" onMouseOver="MouseSobreCab('3')" onMouseOut="MouseSaiCab('3')" onClick="SelecionaCab('3')">
			<font color="#ffffff" face="Tahoma"><b>CPF</b></font>
		</td>
		
		<td bgcolor="#000080" align="center" id="trCab3" onMouseOver="MouseSobreCab('3')" onMouseOut="MouseSaiCab('3')" onClick="SelecionaCab('3')">
			<font color="#ffffff" face="Tahoma"><b>Status</b></font>
		</td>

		
		<td bgcolor="#000080" align="center" id="trCab5" onMouseOver="MouseSobreCab('5')" onMouseOut="MouseSaiCab('5')" onClick="SelecionaCab('5')">
			<font color="#ffffff" face="Tahoma"><b>RG</b></font>
		</td>
		
		<td bgcolor="#000080" align="center" id="trCab5" onMouseOver="MouseSobreCab('5')" onMouseOut="MouseSaiCab('5')" onClick="SelecionaCab('5')">
			<font color="#ffffff" face="Tahoma"><b>GÊNERO</b></font>
		</td>
		
		<td bgcolor="#000080" align="center" id="trCab5" onMouseOver="MouseSobreCab('5')" onMouseOut="MouseSaiCab('5')" onClick="SelecionaCab('5')">
			<font color="#ffffff" face="Tahoma"><b>IDADE</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>ENDEREÇO</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab7" onMouseOver="MouseSobreCab('7')" onMouseOut="MouseSaiCab('7')" onClick="SelecionaCab('7')">
			<font color="#ffffff" face="Tahoma"><b>CONTATO</b></font>
		</td>

		<td bgcolor="#000080" align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')">
			<font color="#ffffff" face="Tahoma"><b>EMAIL</b></font>
		</td>

		<td bgcolor="#000080" align="center" id="trCab9">
			<font color="#ffffff" face="Tahoma"><b>ESCOLARIDADE</b></font>
		</td>
		<td bgcolor="#000080" align="center" width='100px' id="trCab10">
			<font color="#ffffff" face="Tahoma" ><b>PCD</b></font>
		</td>
		<td bgcolor="#000080" align="center" width='100px' id="trCab10">
			<font color="#ffffff" face="Tahoma" ><b>INTENÇÃO</b></font>
		</td>
		

	</tr>
	
	<script>
function inseristatuspcd(id)
{
	
	 
   var  value =  document.getElementById("status_pcd_"+id+"").value;
	
	
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("rep_div_"+id+"").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("POST","script_statuspcd.php?id="+id+"&value="+value+"",true);
xmlhttp.send();
}
</script>

		
					<?
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			$numero=1;
			
			
			
		function calcula_idade($data_nascimento, $data_calcula)
		{
		// as datas devem ser no formato aaaa-mm-dd

		//conversão das datas para o formato de tempo linux
		$data_nascimento = strtotime($data_nascimento." 00:00:00");
		$data_calcula = strtotime($data_calcula." 00:00:00");

		//cálculo da idade fazendo a diferença entre as duas datas
		$idade = floor(abs($data_calcula-$data_nascimento)/60/60/24/365);

		return($idade);
		}


				if($get_acao==""){
				$query_noticias = "SELECT *  FROM `trabalhador`   ORDER BY  `id` DESC limit 20  ";
				}
				else
				{
				//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
				//if($usuario==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='$post_status'  ";}
				if($post_pcd_cidade==""){}else{$sqlcidadeid="and `cidadeid`='$post_pcd_cidade' ";}
				if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
				if($post_contapcd==""){}else{$sqlcontacpd="and `vagadeficiente` = '$post_contapcd' ";}				
				if($post_statusescolaridade==""){}else{$sqlstatusescolaridade="and `situacao` = '$post_statusescolaridade' ";}				
				if($post_pcd_turno==""){}else{$sqlturno="and `turno` = '$post_pcd_turno' ";}				
				
				
				if($post_escolaridade==""){}else{
				
					$idtrabalhadoreesclaridades="";
					/*S
					$query_escolaridade = "SELECT * FROM `escolaridade` WHERE `escolaridade` = '$post_escolaridade' $post_statusescolaridade $sqlturno ";
					$rs_escolaridade    = mysql_query($query_escolaridade);
					while($campo_escolaridade = mysql_fetch_array($rs_escolaridade)){
					$trabalhadorid_escolaridade= $campo_escolaridade['trabalhadorid']; 
					$idtrabalhadoreesclaridades.="$trabalhadorid_escolaridade ,"; 
					}*/
					
					
					//$sqloescolaridade="and `id` IN ($idtrabalhadoreesclaridades 0)";
					$sqloescolaridade="";
				
				}
				
				if($post_pcd_status==""){}else{
					$sqlopcd_status ="and statusjovem ='$post_pcd_status'";				
				}
				
				
				if($post_intencao==""){}else{$sqlintencao="and intencao='$post_intencao' ";}
				if($post_sexo==""){}else{$sqlsexo="and sexo='$post_sexo' ";}
				if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
				
				
				
				$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
				$post_datafinal1 = implode("-",array_reverse(explode("/",$post_datafinal)));
						
				
				if(($post_datainicio=="") || ($post_datafinal==""))
				{
					if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
					if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
					
				
				}
				else{
				$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1))); // 15/03/2006
				$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
				}
				
				
				if($post_pcd_idade==""){}else{
					$anoatual = date("Y");
					$anodenascimento = $anoatual - $post_pcd_idade;
					$sql2anodenascimento= "and `datanascimento` LIKE  '%$anodenascimento%'";
					
				}
				
				
				
				$query_noticias = "SELECT *  FROM `trabalhador` where id > '0'  
					
				".$sqlcontacpd."
				".$sqlsexo."
				".$sqloescolaridade."
				".$sqlopcd_status."
				".$sqlintencao."
				".$sql2data."
				".$sqlcidadeid."
				".$sql2anodenascimento."
				ORDER BY  `nome` ASC ";
				}

				
		
				
		$rs_noticias    = mysql_query($query_noticias); 
			
		$total = mysql_num_rows($rs_noticias);	
	
																								
											while($campo_noticias = mysql_fetch_array($rs_noticias)){
											$id= $campo_noticias['id']; 											
											$nome= $campo_noticias['nome']; 
											$email= $campo_noticias['email']; 
													$cpf 	= $campo_noticias['cpf']; 	 		 			 	
												$nome 	= $campo_noticias['nome']; 
												$mae 	= $campo_noticias['mae'];	 		 			 	
												$pai 	= $campo_noticias['pai'];	 		 			 	
												$datanascimento 	= $campo_noticias['datanascimento']; 	 		 			 	
												$naturalidade 	= $campo_noticias['naturalidade']; 	 		 			 	
												$sexo 	= $campo_noticias['sexo']; 	 		 			 	
												$estadocivil 	= $campo_noticias['estadocivil']; 												 		 			 	
												$txtfilhosestudantes 	= $campo_noticias['txtfilhosestudantes']; 	 		 			 	
												$txttrabalhando 	= $campo_noticias['txttrabalhando']; 	 		 			 	
												$txtmeres 	= $campo_noticias['txtmeres']; 	 		 			 	
												$txtmenores 	= $campo_noticias['txtmenores']; 	 		 			 	
												$txtmenores 	= $campo_noticias['txtmenores']; 					 	 		 			 	
												$cbolaudo 	= $campo_noticias['cbolaudo']; 	 		 			 	
												$txtlimitacoes 	= $campo_noticias['txtlimitacoes']; 	 		 			 	
												$intencao 	= $campo_noticias['intencao']; 	 		 			 	
												$cboTemporario 	= $campo_noticias['cboTemporario']; 	 		 			 	
												$cboservida 	= $campo_noticias['cboservida']; 	 		 			 	
												$cboNoturno 	= $campo_noticias['cboNoturno']; 	 		 			 	
												$cbotur 	= $campo_noticias['cbotur']; 	 		 			 	
												$cbofeira 	= $campo_noticias['cbofeira']; 	 		 			 	
												$cep 	= $campo_noticias['cep']; 	 		 			 	
												$txtestado 	= $campo_noticias['txtestado']; 	 		 			 	
												$cidadeid 	= $campo_noticias['cidadeid']; 	 

												
												
												$bairro 	= $campo_noticias['bairro']; 	 		 			 	
												$endereco 	= $campo_noticias['endereco']; 	 		 			 	
												$telres 	= $campo_noticias['telres']; 	 		 			 	
												$telcel 	= $campo_noticias['telcel']; 	 		 			 	
												$telrec 	= $campo_noticias['telrec']; 	 		 			 	
												$nmrecado 	= $campo_noticias['nmrecado']; 	 		 			 	
												$email 	= $campo_noticias['email'];	 		 			 	
												$identidade 	= $campo_noticias['identidade']; 	 		 			 	
												$orgaoexpedidor 	= $campo_noticias['orgaoexpedidor']; 	 		 			 	
												$txttitulo 	= $campo_noticias['txttitulo']; 	 		 			 	
												$txtzona 	= $campo_noticias['txtzona']; 	 		 			 	
												$txtsecao 	= $campo_noticias['txtsecao']; 	 		 			 	
												$tipocnh 	= $campo_noticias['tipocnh']; 	 		 			 	
												$carteiratrabalho 	= $campo_noticias['carteiratrabalho']; 	 		 			 	
												$seriect 	= $campo_noticias['seriect']; 	 		 			 	
												$txtregistroprof 	= $campo_noticias['txtregistroprof']; 	 		 			 	
												$orgaoreg 	= $campo_noticias['orgaoreg']; 	 		 			 	
												$pispasep 	= $campo_noticias['pispasep']; 	 		 			 	
												$passaporte 	= $campo_noticias['passaporte']; 	 		 			 	
												$txtmoracom 	= $campo_noticias['txtmoracom']; 	 		 			 	
												$txtmorapais 	= $campo_noticias['txtmorapais']; 	 		 			 	
												$txtmoracompanheiro 	= $campo_noticias['txtmoracompanheiro']; 	 		 			 	
												$txtmoraoutros 	= $campo_noticias['txtmoraoutros']; 	 		 			 	
												$txtmorafilhos 	= $campo_noticias['txtmorafilhos']; 	 		 			 	
												$txtmorafilhos1 	= $campo_noticias['txtmorafilhos1']; 	 		 			 	
												$txtmorafilhos2 	= $campo_noticias['txtmorafilhos2']; 	 		 			 	
												$txtmorafilhos3 	= $campo_noticias['txtmorafilhos3']; 	 		 			 	
												$txtmorairmaos 	= $campo_noticias['txtmorairmaos']; 	 		 			 	
												$txtmorairmaos1 	= $campo_noticias['txtmorairmaos1']; 	 		 			 	
												$txtmorairmaos2 	= $campo_noticias['txtmorairmaos2']; 	 		 			 	
												$txtmorairmaos22 	= $campo_noticias['txtmorairmaos22']; 	 		 			 	
												$txtmorairmaos3 	= $campo_noticias['txtmorairmaos3']; 	 		 			 	
												$txtrendafamiliar 	= $campo_noticias['txtrendafamiliar']; 	 		 			 	
												$selchefefamilia 	= $campo_noticias['selchefefamilia']; 	 		 			 	
												$programasocialid 	= $campo_noticias['programasocialid']; 	 		 			 	
												$cboprocesso 	= $campo_noticias['cboprocesso']; 	 		 			 	
												$cbosoube_caet 	= $campo_noticias['cbosoube_caet']; 	 		 			 	
												$selcidacaptado 	= $campo_noticias['selcidacaptado']; 	 		 			 	
												$selcidaatraves 	= $campo_noticias['selcidaatraves']; 	 		 			 	
												$selLocalDocs 	= $campo_noticias['selLocalDocs']; 	 		 			 	
												$txthistorico	= $campo_noticias['txthistorico'];
 
												$txthabilidades1 = $campo_noticias['txthabilidades1'];
												$txthabilidades2 = $campo_noticias['txthabilidades2'];
												$txthabilidades3 = $campo_noticias['txthabilidades3'];
												$cboid1 =  $campo_noticias['cboid1'];
												$cboid2 =  $campo_noticias['cboid2'];
												$cboid3 =  $campo_noticias['cboid3'];
												$pretensaosalarial =  $campo_noticias['pretensaosalarial'];
												$ultimosalario =  $campo_noticias['ultimosalario'];
												
												$senha 	= $campo_noticias['senha']; 
												$situacao 	= $campo_noticias['situacao']; 
												$serie 	= $campo_noticias['serie']; 
												$turno 	= $campo_noticias['turno']; 
												$formacaoacademicaidbusca 	= $campo_noticias['formacaoacademicaidbusca']; 
												$formacaoacademicaid 	= $campo_noticias['formacaoacademicaid']; 
												$outrocurso 	= $campo_noticias['outrocurso']; 
												$instituicao 	= $campo_noticias['instituicao']; 
												$comprovacao 	= $campo_noticias['comprovacao']; 
												$softwareid1 	= $campo_noticias['softwareid1']; 
												$softwareid2 	= $campo_noticias['softwareid2']; 
												$softwareid3 	= $campo_noticias['softwareid3']; 
												$idiomaid1 	= $campo_noticias['idiomaid1']; 
												$idiomaid2 	= $campo_noticias['idiomaid2']; 
												$vagadeficiente 	= $campo_noticias['vagadeficiente']; 
												$idiomaid3 	= $campo_noticias['idiomaid3']; 
												$leitura1 	= $campo_noticias['leitura1']; 
												$leitura2 	= $campo_noticias['leitura2']; 
												$leitura3	= $campo_noticias['leitura3']; 
												$conversacao1	= $campo_noticias['conversacao1']; 
												$conversacao2	= $campo_noticias['conversacao2']; 
												$conversacao3	= $campo_noticias['conversacao3']; 
												$escrita1	= $campo_noticias['escrita1']; 
												$escrita2	= $campo_noticias['escrita2']; 
												$escrita3	= $campo_noticias['escrita3']; 
												
												$cadastrado_por	= $campo_noticias['usuarioid']; 
												$datacadastro	= $campo_noticias['datacadastro']; 
												$dataupdate	= $campo_noticias['dataupdate']; 
												$infotrabalhado	= $campo_noticias['infotrabalhado']; 									
												$intencao	= $campo_noticias['intencao']; 									
												$datanascimento	= $campo_noticias['datanascimento']; 									
									
		
				
				if($post_escolaridade==""){
					
					$totalescola= 1;
				}
				else{
					$query_escolaridade = "SELECT * FROM `escolaridade` WHERE  trabalhadorid='$id' and  `escolaridade` = '$post_escolaridade' $sqlstatusescolaridade $sqlturno ";
					$rs_escolaridade    = mysql_query($query_escolaridade);
					$totalescola = mysql_num_rows($rs_escolaridade);
				}
					
				if($totalescola > 0){
			
				
				
		
			?>
	
	
	
	<tr  class='tr_tb'>
		<td  align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
			<font color="#000000" face="Tahoma"><b><?=$id;?> </b></font>
		</td>
		<td  align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
			<font color="#000000" face="Tahoma"><b><a href="javascript:Abrir_Pagina('../conteudo.php?idtr=<?=$id;?>&buscaform=N','scrollbars=yes,width=800,height=500')"><?=$nome;?></a></b></font>
		</td>
		<td  align="center" id="trCab3" onMouseOver="MouseSobreCab('3')" onMouseOut="MouseSaiCab('3')" onClick="SelecionaCab('3')">
			<font color="#000000" face="Tahoma"><b><?=$cpf;?></b></font>
		</td>
		
			<?
			$query_status_pcd = "SELECT status  FROM `trabalhadorpcd` where trabalhadorid = '$id' ";
			$rs_status_pcd   = mysql_query($query_status_pcd);							
			while($campo_status_pcd = mysql_fetch_array($rs_status_pcd)){
			$status_pcd  	= $campo_status_pcd['status'];
			
			
			switch ($status_pcd){										
			case "A":											
			$status_pcd_N = "Aguardando Treinamneto";
			break;
			
			case "T":											
			$status_pcd_N = "Treinado";
			break;
			
			case "I":											
			$status_pcd_N = "Inserido";
			break;
			
			case " ":											
			$status_pcd_N = "";
			break;
			
			}
			}
			if($status_pcd==""){
				
			$option="<option value='N'>--</option>";	
			}else{
			$option="<option value='$status_pcd'>$status_pcd_N</option>";
			}
		
			
			?>		
		
		<td  align="center" id="trCab3">
			<?=$status_pcd_N;?>
			<select name="status_pcd_<?=$id?>"  id="status_pcd_<?=$id?>" onchange="inseristatuspcd('<?=$id;?>');">
				<?=$option;?>
				<option value="I">Inserido</option>
				<option value="A">Aguardando Treinamento</option>
				<option value="T">Treinado</option>
			</select><font id="rep_div_<?=$id;?>" name="rep_div_<?=$id;?>"></font>
			
		</td>
		

		
		<td  align="center" id="trCab5" onMouseOver="MouseSobreCab('5')" onMouseOut="MouseSaiCab('5')" onClick="SelecionaCab('5')">
			<font color="#000000" face="Tahoma"><b><?=$identidade;?></b></font>
		</td>
		
		<td  align="center" id="trCab5" onMouseOver="MouseSobreCab('5')" onMouseOut="MouseSaiCab('5')" onClick="SelecionaCab('5')">
		
		<?
		switch ($sexo){										
																			case "M":											
																			$sexo_N = "Masculino";
																			break;

																			case "F":											
																			$sexo_N = "Feminino";
																			break;
																			
																			}
		?>
			<font color="#000000" face="Tahoma"><b><?=$sexo_N;?></b></font>
		</td>
		<td  align="center" id="trCab5" onMouseOver="MouseSobreCab('5')" onMouseOut="MouseSaiCab('5')" onClick="SelecionaCab('5')">
			<font color="#000000" face="Tahoma"><b><?echo calcula_idade("$datanascimento",date("Y-m-d"))." anos";?></b></font>
		</td>
		
		<?
		
												$query_noticias_cidadecp = "SELECT nome FROM `cidade` where id='$cidadeid' ";
												$rs_noticias_cidadecp    = mysql_query($query_noticias_cidadecp);
												while($campo_noticias_cidadecp = mysql_fetch_array($rs_noticias_cidadecp)){
												$nome_cidade        = $campo_noticias_cidadecp['nome'];												
												}	
		?>
		<td  align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#000000" face="Tahoma"><b><?=$endereco;?> - <?=$nome_cidade;?></b></font>
		</td>
		<td  align="center" id="trCab7" onMouseOver="MouseSobreCab('7')" onMouseOut="MouseSaiCab('7')" onClick="SelecionaCab('7')">
			<font color="#000000" face="Tahoma"><b><?=$telres;?> | <?=$telcel;?> | <?=$telrec;?></b></font>
		</td>

		<td  align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')">
			<font color="#000000" face="Tahoma"><b><?=$email;?></b></font>
		</td>
		

		<td  align="center" id="trCab9">
		
						<?


				$query_atendente = "SELECT * FROM `escolaridade` where  trabalhadorid='$id' group by escolaridade";	
				$rs_atendente    = mysql_query($query_atendente); 													
				while($campo_atendente = mysql_fetch_array($rs_atendente)){
				$escolaridade= $campo_atendente['escolaridade']; 
				$turnoescolaridade= $campo_atendente['turno']; 
															

				switch ($turnoescolaridade){										
				case "M":											
					$turnoescolaridade_N = "Manhã";
				break;

				case "T":											
					$turnoescolaridade_N = "Tarde";
				break;

				case "N":											
					$turnoescolaridade_N = "Noite";
				break;

				}

				switch ($escolaridade){										
				case "F":											
				$escolaridade_N = "Fundamental";
				break;

				case "M":											
				$escolaridade_N = "Médio";
				break;

				case "P":											
				$escolaridade_N = "Pós-Médio";
				break;

				case "S":											
				$escolaridade_N = "Superior";
				break;
				}
				?>


			<div color="#000000" face="Tahoma"><b><?=$escolaridade_N;?><br> <?=$turnoescolaridade_N;?></b></div>
			
			<?}?>
		</td>
		<td  align="center" width='100px' id="trCab10">
			<font color="#000000" face="Tahoma" ><b><?if($vagadeficiente=="S"){echo"<a href=\"javascript:Abrir_Pagina('../deficiente_trabalhador.php?id_trabalhado=$id&escolha=S','scrollbars=yes,width=800,height=500')\">Sim</a>";}else{echo"Não";};?></b></font>
		</td>
		<?
																			switch ($intencao){										
																			case "E":											
																			$intencao_N = "Emprego";
																			break;
																			case "1":											
																			$intencao_N = "Jovem Aprendiz";
																			break;
																			case "T":											
																			$intencao_N = "Estágio";
																			break;
																			case "C":											
																			$intencao_N = "Curso";
																			break;
																			case "D":											
																			$intencao_N = "Emissão de Documentos";
																			break;
																			case "G":											
																			$intencao_N = "Emprego/Curso";
																			break;
																			case "M":											
																			$intencao_N = "Emprego/Emissão de Documentoso";
																			break;
																			case "U":											
																			$intencao_N = "Curso/Emissão de Documentos";
																			break;
																			case "S":											
																			$intencao_N = "Todas";
																			break;
																			
																			}
																			?>
		
		<td  align="center" width='100px' id="trCab10">
			<font color="#000000" face="Tahoma" ><b><?=$intencao_N;?></b></font>
		</td>
		

	</tr>

	
	<?
	
			}
		}
	
			
	
	?>
	
	</table>
	
	<?//=$query_noticias ; ?>
	
	<h2>Total da pesquisa :<?=$total;?></h2>
	</div>