	<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	include"../input_banco.php"
	
	
	?>
	
	
	<div id="getexcel">
	<table border="1" width="100%"  class="sortable">
	<tr>
		<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;N°&nbsp;</b></font>
		</td>
		
		<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;CNPJ/CPF&nbsp;</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Razão Social&nbsp;</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab3" onMouseOver="MouseSobreCab('3')" onMouseOut="MouseSaiCab('3')" onClick="SelecionaCab('3')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Nome&nbsp;</b></font>
		</td>

		
		<td bgcolor="#000080" align="center" id="trCab5" onMouseOver="MouseSobreCab('5')" onMouseOut="MouseSaiCab('5')" onClick="SelecionaCab('5')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Seg.Atuação&nbsp;</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Ins. Municipal&nbsp;</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab7" onMouseOver="MouseSobreCab('7')" onMouseOut="MouseSaiCab('7')" onClick="SelecionaCab('7')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Ins. Estadual&nbsp;</b></font>
		</td>
<td bgcolor="#000080" align="center" id="trCab7" onMouseOver="MouseSobreCab('7')" onMouseOut="MouseSaiCab('7')" onClick="SelecionaCab('7')">
			<font color="#ffffff" face="Tahoma"><b>&nbsp;Cadastro&nbsp;</b></font>
		</td>

		
	</tr>
		
					<?
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			$numero=1;
			
							
		
		
		
				if($get_acao==""){
				$query_noticias = "SELECT *  FROM `empresa` ORDER BY `empresa`.`nome` DESC ";
				}
				else
				{
					//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
					if($post_status==""){$sqlostatus="";}else{$sqlostatus=" status='$post_status'  ";}				
					if($post_segmentoatuacao==""){}else{$sqlsegmentoatuacao="and segmentoatuacaoid='$post_segmentoatuacao' ";}
					if($post_jovemaprendiz==""){}else{$sqljovemaprendiz="and jovemaprendiz='$post_jovemaprendiz'";}
					if($post_estagios==""){}else{$sqlestagios="and estagios='$post_estagios' ";}
					if($post_contapcd==""){}else{$sqlcontapcd="and contapcd='$post_contapcd' ";}
					
					
					$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
					$post_datafinal1s = implode("-",array_reverse(explode("/",$post_datafinal)));
					
					if($post_datafinal==""){}else{
					 $post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1s))); // 15/03/2006
					}
					
					
					if(($post_datainicio=="") || ($post_datafinal==""))
					{
						if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
						if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
						
					
					}
					else{
					$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
					}
					
					
					
					$query_noticias = "SELECT *  FROM `empresa` where id > '0'
					".$sqlostatus."
					".$sql2data."
					".$sqlsegmentoatuacao."
					".$sqljovemaprendiz."
					".$sqlestagios."
					".$sqlcontapcd."
					 ORDER BY `empresa`.`nome` DESC ";
					
				}
			
		
		//echo $query_noticias;
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$cnpj 	= $campo_noticias['cnpj']; 	 		 			 	
		$selTipo	= $campo_noticias['selTipo']; 	 		 			 	
		$razaosocial	= $campo_noticias['razaosocial']; 	 		 			 	
		$nome	= $campo_noticias['nome']; 	 		 			 	
		$segmentoatuacaoid	= $campo_noticias['segmentoatuacaoid']; 	 		 			 	
		$inscmunicipal	= $campo_noticias['inscmunicipal']; 	 		 			 	
		$inscestadual	= $campo_noticias['inscestadual']; 	 		 			 	
		$endereco	= $campo_noticias['endereco']; 	 		 			 	
		$bairro	= $campo_noticias['bairro']; 	 		 			 	
		$cidadeid	= $campo_noticias['cidadeid']; 			 			 	
		$cep	= $campo_noticias['cep']; 
		$emailresponsavel	= $campo_noticias['emailresponsavel']; 	 		 			 	
		$tel1= $campo_noticias['tel1']; 	 		 			 	
		$tel2= $campo_noticias['tel2']; 	 		 			 	
		$tel3= $campo_noticias['tel3']; 	 		 			 	
		$email= $campo_noticias['email']; 	 		 			 	
		$homepage= $campo_noticias['homepage']; 	 		 			 	
		$responsavel= $campo_noticias['responsavel']; 	 		 			 	
		$cargoresponsavel= $campo_noticias['cargoresponsavel']; 	 		 			 	
		$contato= $campo_noticias['contato']; 	 		 			 	
		$cargocontato= $campo_noticias['cargocontato']; 	 		 			 	
		$emailcontato= $campo_noticias['emailcontato']; 	 		 			 	
		$captadorid= $campo_noticias['captadorid']; 	 		 			 	
		$localcaptacaoid= $campo_noticias['localcaptacaoid']; 	 		 			 	
		$status= $campo_noticias['status']; 	 		 			 	
		$observacao= $campo_noticias['observacao']; 	 
		$id= $campo_noticias['id']; 	 
		$txtestadoentrevista= $campo_noticias['txtestadoentrevista']; 	 
		$cepentrevista= $campo_noticias['cepentrevista']; 	 
		$senha= $campo_noticias['senha']; 	 
		$jovemaprendiz= $campo_noticias['jovemaprendiz']; 	 
		$estagios= $campo_noticias['estagios']; 	 
		$contapcd= $campo_noticias['contapcd']; 	 
		$quantempregados= $campo_noticias['quantempregados']; 	 
		$referenciaend= $campo_noticias['referenciaend']; 	 
		$datacadastro= $campo_noticias['datacadastro']; 	 
		
		
			?>
	
	
	<tr class='tr_tb' >		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$cnpj ;?> </td>
				<td class='td2' >  <?=$razaosocial;?></td>				
				<td class='td2' >  <?=$nome;?></td>		
							<?
													$query_seguimentoatuacao_db = "SELECT * FROM  `segmentoatuacao` where id='$segmentoatuacaoid' ";
													$rs_seguimentoatuacao_db    = mysql_query($query_seguimentoatuacao_db);
													while($campo_seguimentoatuacao_db = mysql_fetch_array($rs_seguimentoatuacao_db)){		
													$seguimento_id_db 	= $campo_seguimentoatuacao_db['id']; 
													$seguimento_nome_db 	= $campo_seguimentoatuacao_db['nome']; 
													}
													?>
													
													
				<td class='td2' >  <?=$seguimento_nome_db;?></td>				
				<td class='td2' >  <?=$inscmunicipal;?></td>				
				<td class='td2' >  <?=$inscestadual;?></td>				
				<td class='td2' ><?=$datacadastro;?></td>	
				
	</tr>

	
	<?}?>
	
	</table>
	
	</div>