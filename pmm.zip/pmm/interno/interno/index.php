<?include("../seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'../topo.php';?>


<link rel="stylesheet" type="text/css" href="../assets/reset.css" />
<link rel="stylesheet" type="text/css" href="../assets/styles.css" />

<body  onload="listavaga('oi');">
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script src="../js/sorttable.js"></script>
<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>

<div id="bg-container" class='contener'>

<script language="JavaScript"> 


function Abrir_Pagina(URL,Configuracao) {
window.open(URL,'',Configuracao);      
} 

function Impressao( preVisualizar ) 
{
	var CorpoMensagem = document.body.innerHTML;
	document.body.innerHTML = ImprimirConteudo.innerHTML;
	if( preVisualizar ) 
	{
		PreVisualizar();
	} 
	else 
	{
		window.print();
	}
	document.body.innerHTML = CorpoMensagem;
}
 
function PreVisualizar() 
{
	try 
	{
		 //Utilizando o componente WebBrowser1 registrado no MS Windows Server 2000/2003 ou XP/Vista
		 var WebBrowser = '<OBJECT ID="WebBrowser1" WIDTH=0 HEIGHT=0 CLASSID="CLSID:8856F961-340A-11D0-A96B-00C04FD705A2"></OBJECT>'; 
		 document.body.insertAdjacentHTML('beforeEnd', WebBrowser); 
		 WebBrowser1.ExecWB( 7, 1 ); 
		 WebBrowser1.outerHTML = ""; 
	} 
	catch(e) 
	{
		alert("Para visualizar a impressão você precisa habilitar o uso de controles ActiveX na página.");
		return;
	}
}
</script>	
   
			

			

		
						<?include"topo.php";?>
						
						
						<?include"$url";?>
						
						
							<div name='listavaga1' id='listavaga1'></div>
						<?include"rodape.php";?>
					
		
		

			
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
	
	$(document).ready(function () {					
							
								// var conteudo = $('#getexcel:first').html();
								 var conteudo  = $("#getexcel").html();
								 $("#htmlform").val(conteudo);
								 //alert(conteudo);
								 //window.open('exporta_excel.php?html='+conteudo,'GoogleWindow', 'width=800, height=600');
							
						});		
						
</script>
	

</body>
</html>
