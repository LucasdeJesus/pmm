	<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	
	
	
	?>
	
	
		
					<?
						
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			
			
						if($get_acao==""){$limit="limit 100";}else{$limit="";};
						
						//if($post_status==""){$sqlostatus="`status` IN ('A','S','C','P','E','N','I','R','O')";}else{$sqlostatus=" status='$post_status'  ";}
						if($post_status==""){$sqlostatus="`id` > 0";}else{$sqlostatus="id > 0 ";}
						if($post_statusencaminhamento==""){$sqlpost_statusencaminhamento="`status` IN ('E','I','N')";}else{$sqlpost_statusencaminhamento=" status='$post_statusencaminhamento'  ";}
						if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
						if($post_descricao==""){}else{$sqldescricao="and `descricao` LIKE '%$post_descricao%' ";}				
						if($post_escolaridade==""){}else{$sqloescolaridade="and escolaridade='$post_escolaridade' ";}
						if($post_sexo==""){}else{$sqlsexo="and sexo IN ('$post_sexo','A') ";}
						if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
						if($post_id==""){}else{$sqlid="and id='$post_id' ";}
						if($post_atendente==""){}else{$sqlatendente="and usuarioid='$post_atendente' ";}
						if($empresaid==""){}else{$sqlempresaid="and empresaid='$empresaid' ";}
						
						
							if($_POST['acao']==""){$post_datainicio= date('d/m/Y');}else{};
						
						$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
						$post_datafinal1 = implode("-",array_reverse(explode("/",$post_datafinal)));
						
						
					if($post_statusencaminhamento=="I")					
					{
						if(($post_datainicio=="") || ($post_datafinal==""))
						{
							if($post_datainicio==""){}else{$sql2data="and `dataupdate` LIKE '%$post_datainicio1%' ";}
							if($post_datafinal1==""){}else{$sql2data="and `dataupdate` LIKE '%$post_datafinal1%' ";}
							
						
						}
						else
						
						{
								$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1))); // 15/03/2006
								$sql2data= "and `dataupdate` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
						}
						
					
					
					}else{
					
				
						
						
						if(($post_datainicio=="") || ($post_datafinal==""))
						{
							if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
							if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
							
						
						}
						else
						
						{
								$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1))); // 15/03/2006
								$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
						}
							
							
					
					}
						
							
					
																		
													
						
										if($sql2data==""){
											$query_noticias = "SELECT *  FROM `vaga` where  
										".$sqlostatus."				
										".$sqlcargo."				
										".$sqldescricao."				
										".$sqloescolaridade."				
										".$sqlsexo."				
										".$sqlaceitasemexperiencia."				
										".$sqlid."				
										".$sqlempresaid."	
										".$sql2data."
										
										ORDER BY  `vaga`.`cargo` ASC ".$limit."";
										}else{
										
												$whileencamaninha ="";
												$query_noticiase1 = "SELECT * FROM `encaminhamento` WHERE ".$sqlpost_statusencaminhamento." ".$sql2data." ".$sqlatendente."";
												$rs_noticiase1    = mysql_query($query_noticiase1);	
												
												while($campo_noticiase1= mysql_fetch_array($rs_noticiase1)){
												
												$idvagaem	= $campo_noticiase1['vagaid'];
												$whileencamaninha.="'$idvagaem',"; 
												}
												
												$query_noticias = "SELECT *  FROM `vaga` where  
												".$sqlostatus."				
												".$sqlcargo."				
												".$sqldescricao."				
												".$sqloescolaridade."				
												".$sqlsexo."				
												".$sqlaceitasemexperiencia."				
												".$sqlid."				
												".$sqlempresaid."	
												and `id` IN ($whileencamaninha '0')
												ORDER BY  `vaga`.`cargo` ASC  ".$limit."";
												
											
										}
										
										
										
										$totalencaminhados=0;
										$rs_noticias    = mysql_query($query_noticias);			
											
										$total = mysql_num_rows($rs_noticias);	
										echo"$query_noticiase1";
										$iddasvagas ="";
										while($campo_noticias = mysql_fetch_array($rs_noticias)){	
										$id_vaga= $campo_noticias['id'];										
										$iddasvagas.="'$id_vaga',"; 									
										 }
										 
																				 
										$query_noticiase1 = "SELECT * FROM `encaminhamento` WHERE ".$sqlpost_statusencaminhamento."  and `vagaid`IN ($iddasvagas '0') ".$sql2data." ".$sqlatendente." group by usuarioid ";
										$rs_noticiase1    = mysql_query($query_noticiase1);										
										//echo $query_noticiase1;
										$totalencaminhamento1 = mysql_num_rows($rs_noticiase1);
										while($campo_noticiase1= mysql_fetch_array($rs_noticiase1)){																			
										$usuarioid11	= $campo_noticiase1['usuarioid'];										
																			
													
													$query_noticiasceu1 = "SELECT * FROM `usuario`  WHERE id='$usuarioid11' ";
													$rs_noticiasceu1    = mysql_query($query_noticiasceu1);
													while($campo_noticiasceu1 = mysql_fetch_array($rs_noticiasceu1)){	
													$usuarioa1	= $campo_noticiasceu1['usuario']; 												
													$nomeat	= $campo_noticiasceu1['nome']; 												

													}
													?>
													
													
													<div style=';width:100%;margin:10px;' align='center'><h2>Atendente <?=$nomeat;?> </h2></div>
													<?=$post_datainicio;?>
													<table border="1" width="100%"  class="sortable">
													
														
														<tr>
															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;N°&nbsp;</b></font>
															</td>

															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;ID Taabalhador&nbsp;</b></font>
															</td>
															
															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;ID Vaga&nbsp;</b></font>
															</td>

															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;ID Enc.&nbsp;</b></font>
															</td>
															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Candidato&nbsp;</b></font>
															</td>
															
															
															<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;CPF&nbsp;</b></font>
															</td>
															<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Sexo&nbsp;</b></font>
															</td>

															<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Status&nbsp;</b></font>
															</td>

															<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Tel.&nbsp;</b></font>
															</td>

															<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Cargo&nbsp;</b></font>
															</td>

															<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Empresa&nbsp;</b></font>
															</td>

															<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Encaminhado&nbsp;</b></font>
															</td>
															
															<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Cadastro&nbsp;</b></font>
															</td>
															
															<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Atendente&nbsp;</b></font>
															</td>


													</tr>
												
												<?
											
												$numero=1;
													$query_noticiase = "SELECT * FROM `encaminhamento` WHERE  ".$sqlpost_statusencaminhamento."  and `vagaid`IN ($iddasvagas '0') ".$sql2data."  and usuarioid='$usuarioid11'";
													$rs_noticiase    = mysql_query($query_noticiase);										
													
													$totalencaminhamento = mysql_num_rows($rs_noticiase);
													$totalencaminhados+="$totalencaminhamento";
													while($campo_noticiase= mysql_fetch_array($rs_noticiase)){	
													$trabalhadorid	= $campo_noticiase['trabalhadorid']; 
													$vagaid	= $campo_noticiase['vagaid'];										
													$status	= $campo_noticiase['status'];										
													$datacadastrem	= $campo_noticiase['datacadastro'];	
														
													$idencaminhamento	= $campo_noticiase['id'];														
																						
													///	dados da vaga
													
													$query_noticiasceu1vaga = "SELECT * FROM `vaga`  WHERE id='$vagaid' ";
													$rs_noticiasceu1vaga    = mysql_query($query_noticiasceu1vaga);
													while($campo_noticiasceu1vaga = mysql_fetch_array($rs_noticiasceu1vaga)){	
													$empresaid 	= $campo_noticiasceu1vaga['empresaid'];
													$cargo= $campo_noticiasceu1vaga['cargo'];	
																	
													}
													
													///dados da vaga
													
																
													?>
													
				
														<?
																$query_noticiasc = "SELECT * FROM `trabalhador`  WHERE id='$trabalhadorid' ".$sqlsexo." ORDER BY  `nome` ASC";
																$rs_noticiasc    = mysql_query($query_noticiasc);																
																while($campo_noticiasc = mysql_fetch_array($rs_noticiasc)){	
																$idcandidato	= $campo_noticiasc['id']; 
																$candidato	= $campo_noticiasc['nome']; 
																$cpf	= $campo_noticiasc['cpf']; 
																$sexo	= $campo_noticiasc['sexo']; 
																$email	= $campo_noticiasc['email']; 
																$telres	= $campo_noticiasc['telres']; 
																$telcel	= $campo_noticiasc['telcel']; 
																$telrec	= $campo_noticiasc['telrec']; 
																$dataupdate	= $campo_noticiasc['dataupdate'];
																$datacadastret	= $campo_noticiasc['datacadastro']; 
																}
																
														
														?>
														
													<tr class='tr_tb' >		
																<td class='td2' > <?=$numero++;?> </td>													
																<td class='td2' > <?=$idcandidato ;?> </td>
																<td class='td2' > <?=$vagaid ;?> </td>
																<td class='td2' > <?=$idencaminhamento ;?> </td>
																<td class='td2' > <?=$candidato ;?> </td>
																<td class='td2' >  <?=$cpf;?></td>
																	<?
																	switch ($sexo){										
																	case "F":											
																	$sexo_N = "Feminino";
																	break;

																	case "M":											
																	$sexo_N = "Masculino";
																	break;
																	case "A":											
																	$sexo_N = "Ambos";
																	break;
																	}
																	?>
																<td class='td2' >  <?=$sexo_N;?></td>
																	<?
																	switch ($status){										

																	case "E":											
																	$status_N = "Encaminhado";
																	break;

																	case "I":											
																	$status_N = "Inserido";
																	break;
																	case "N":											
																	$status_N = "Não Inserido";
																	break;
																	}
																	?>
															
																<td class='td2' >  <?=$status_N;?></td>		
																		
																<td class='td2' >  <?=$telres;?> / <?=$telcel;?> / <?=$telrec;?></td>	
																<td class='td2' >  <?=$cargo;?></td>
																<?
																$query_noticiasce = "SELECT * FROM `empresa`  WHERE id='$empresaid' ";
																$rs_noticiasce    = mysql_query($query_noticiasce);
																while($campo_noticiasce = mysql_fetch_array($rs_noticiasce)){	
																$empresa	= $campo_noticiasce['nome']; 												
																
																}													
																
																?>
																<td class='td2' >  <?=$empresa;?></td>															
																<td class='td2' >  <?=date("d-m-Y H:i:s", strtotime($datacadastrem));?> /  	
																 <?if($dataupdate="0000-00-00 00:00:00"){}else{echo"Atualizado:";?><?=date("d-m-Y H:i:s", strtotime($dataupdate));}?> </td>		
																<td class='td2' >  <?=date("d-m-Y H:i:s", strtotime($datacadastret));?></td>		
																<td class='td2' >  <?=$usuarioa1;?></td>		
																		
													</tr>	
											<? } // ecaminhamento do usuario?>
											</table>

							<? }?>
						<h2> Total = <?=$totalencaminhados;?>
						</h2>
	
