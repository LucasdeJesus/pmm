	<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	
	
	
	?>
	

<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>
	<style>
	.text_azul{color:blue;}
	span{line-height:130%;}
	</style>
	<div id="getexcel">
	<div id="ImprimirConteudo">
	<table border="1" width="100%" class="sortable">
	<tr>
		<td bgcolor="#000080" align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')">
			<font color="#ffffff" face="Tahoma"><b>Código da vaga</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
			<font color="#ffffff" face="Tahoma"><b>VAGA</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
			<font color="#ffffff" face="Tahoma"><b>DESCRIÇÃO</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab3" onMouseOver="MouseSobreCab('3')" onMouseOut="MouseSaiCab('3')" onClick="SelecionaCab('3')">
			<font color="#ffffff" face="Tahoma"><b>QTD</b></font>
		</td>

		
		<td bgcolor="#000080" align="center" id="trCab5" onMouseOver="MouseSobreCab('5')" onMouseOut="MouseSaiCab('5')" onClick="SelecionaCab('5')">
			<font color="#ffffff" face="Tahoma"><b>GÊNERO</b></font>
		</td>
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>ESCOLARIDADE</b></font>
		</td>
		
		

		

	</tr>
		
					<?
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			$numero=1;
			
			
			
				if($get_acao==""){
				$query_noticias = "SELECT *  FROM `vaga` WHERE  `status` ='A' ORDER BY  `vaga`.`cargo` ASC  ";
				}
				else
				{
				//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
				if($post_status==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='$post_status'  ";}
				if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
				if($post_descricao==""){}else{$sqldescricao="and `descricao` LIKE '%$post_descricao%' ";}				
				if($post_escolaridade==""){}else{$sqloescolaridade="and escolaridade='$post_escolaridade' ";}
				if($post_sexo==""){}else{$sqlsexo="and sexo='$post_sexo' ";}
				if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
				if($post_id==""){}else{$sqlid="and id='$post_id' ";}
				if($empresaid==""){}else{$sqlempresaid="and empresaid='$empresaid' ";}
				
				
				$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
				$post_datafinal1s = implode("-",array_reverse(explode("/",$post_datafinal)));
						$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1s))); // 15/03/2006
				
				if(($post_datainicio=="") || ($post_datafinal==""))
				{
					if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
					if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
					
				
				}
				else{
				$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
				}
				
				
				$query_noticias = "SELECT *  FROM `vaga` where  
				".$sqlostatus."				
				".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."				
				".$sqlempresaid."	
				".$sql2data."
				ORDER BY  `vaga`.`cargo` ASC ";
				}
			
		
		$rs_noticias    = mysql_query($query_noticias); 
			
		$total = mysql_num_rows($rs_noticias);	
	
		while($campo_noticias = mysql_fetch_array($rs_noticias)){



									
									$id= $campo_noticias['id']; 	 
									$empresaid= $campo_noticias['empresaid']; 	 
									$selvagasigilosa = $campo_noticias['selvagasigilosa'];
									
									$cboid = $campo_noticias['cboid'];
									$descricao = $campo_noticias['descricao'];
									$cargo = $campo_noticias['cargo']; 
									$txvagadata = $campo_noticias['txvagadata'];
									$horariotrabalho = $campo_noticias['horariotrabalho'];
									$vagadeficiente = $campo_noticias['vagadeficiente'];
									$quantidadedisponivel = $campo_noticias['quantidadedisponivel'];
									$txvagapreenchidaCTM = $campo_noticias['txvagapreenchidaCTM']; 
									$txvagapreenchidaOutros = $campo_noticias['txvagapreenchidaOutros'];
									$txvagaCancelada = $campo_noticias['txvagaCancelada']; 
									$txvagasativas = $campo_noticias['txvagasativas']; 
									$quantidadeencaminhar = $campo_noticias['quantidadeencaminhar'];
									$datalimiteencaminhar = $campo_noticias['datalimiteencaminhar'];
									$chktemporaria = $campo_noticias['chktemporaria'];
									$ceplocal = $campo_noticias['ceplocal'];
									$txtestado_local = $campo_noticias['txtestado_local'];
									$cidadelocalid = $campo_noticias['cidadelocalid'];
									$bairrolocal = $campo_noticias['bairrolocal'];
									$enderecolocal = $campo_noticias['enderecolocal']; 
									$proximodelocal = $campo_noticias['proximodelocal']; 
									$onoffshore = $campo_noticias['onoffshore']; 
									$local = $campo_noticias['local'];
									$salario = $campo_noticias['salario'];
									$comissao = $campo_noticias['comissao'];
									$prospeccao = $campo_noticias['prospeccao'];
									$cartaoalimentacao = $campo_noticias['cartaoalimentacao']; 
									$alimentacaolocal = $campo_noticias['alimentacaolocal']; 
									$lanche = $campo_noticias['lanche'];
									$cestabasica = $campo_noticias['cestabasica']; 
									$planosaude = $campo_noticias['planosaude']; 
									$planoodonto = $campo_noticias['planoodonto'];
									$segurovida = $campo_noticias['segurovida'];
									$carteiraassinada = $campo_noticias['carteiraassinada']; 
									$valetransporte= $campo_noticias['valetransporte'];
									$premiacao = $campo_noticias['premiacao']; 
									$outrosbeneficios = $campo_noticias['outrosbeneficios'];
									$tempoano = $campo_noticias['tempoano']; 
									$tempomes = $campo_noticias['tempomes']; 
									$comprovada = $campo_noticias['comprovada'];
									$idademinima = $campo_noticias['idademinima']; 
									$idademaxima = $campo_noticias['idademaxima']; 
									$escolaridade = $campo_noticias['escolaridade'];
									$escolaridadesituacao = $campo_noticias['escolaridadesituacao'];
									$cnh= $campo_noticias['cnh']; 
									$sexo = $campo_noticias['sexo'];
									$estadocivil = $campo_noticias['estadocivil']; 
									$txvagafilhos = $campo_noticias['txvagafilhos'];
									$importanciatempo = $campo_noticias['importanciatempo']; 
									$importanciaidade = $campo_noticias['importanciaidade']; 
									$importanciaescolaridade = $campo_noticias['importanciaescolaridade']; 
									$importanciacnh = $campo_noticias['importanciacnh'];
									$importanciasexo = $campo_noticias['importanciasexo']; 
									$importanciaestadocivil = $campo_noticias['importanciaestadocivil'];
									$selvagafilhos_niv = $campo_noticias['selvagafilhos_niv'];
									$txvagaregiao = $campo_noticias['txvagaregiao'];
									$txvagahabilidades = $campo_noticias['txvagahabilidades']; 
									$txvagarestricoes = $campo_noticias['txvagarestricoes'];
									$importanciaestadocivil = $campo_noticias['importanciaestadocivil']; 
									$selvagaidiomas_niv = $campo_noticias['selvagaidiomas_niv'];
									$selvagainformatica_niv = $campo_noticias['selvagainformatica_niv'];
									$aceitasemexperiencia = $campo_noticias['aceitasemexperiencia'];
									$txtcep = $campo_noticias['txtcep'];
									$txtestado = $campo_noticias['txtestado'];
									$txtcidade = $campo_noticias['txtcidade'];
									$txtbairro = $campo_noticias['txtbairro'];
									$txtendereco = $campo_noticias['txtendereco']; 
									$txtproximode = $campo_noticias['txtproximode'];
									$txtfalarcom = $campo_noticias['txtfalarcom']; 
									$txtEmailEntrevista = $campo_noticias['txtEmailEntrevista']; 
									$horarioatendimento = $campo_noticias['horarioatendimento'];
									$viaencaminhamento = $campo_noticias['viaencaminhamento'];
									$observacao = $campo_noticias['observacao']; 
									$status = $campo_noticias['status']; 
									$formacaptacaoid = $campo_noticias['formacaptacaoid'];
									$localcaptacaoid = $campo_noticias['localcaptacaoid']; 
									$selpublicar = $campo_noticias['selpublicar']; 
									$dia = $campo_noticias['dia']; 
									$mes = $campo_noticias['mes']; 
									$ano = $campo_noticias['ano']; 
									$sigilosa = $campo_noticias['sigilosa']; 
									
									 $softwareid1 = $campo_noticias['softwareid1']; 
									 $softwareid2 = $campo_noticias['softwareid2']; 
									 $softwareid3 = $campo_noticias['softwareid3'];
									 
									 $idiomaid1 = $campo_noticias['idiomaid1']; 
									 $leitura1 = $campo_noticias['leitura1']; 
									 $escrita1 = $campo_noticias['escrita1']; 
									 $conversacao1 = $campo_noticias['conversacao1']; 
									 
									  $idiomaid2 = $campo_noticias['idiomaid2']; 
									 $leitura2 = $campo_noticias['leitura2']; 
									 $escrita2 = $campo_noticias['escrita2']; 
									 $conversacao2 = $campo_noticias['conversacao2']; 
									 
									  $idiomaid3 = $campo_noticias['idiomaid3']; 
									 $leitura3 = $campo_noticias['leitura3']; 
									 $escrita3 = $campo_noticias['escrita3']; 
									 $conversacao3 = $campo_noticias['conversacao3']; 
									 $cadastrado_por = $campo_noticias['usuarioid']; 
									 $datacadastro = $campo_noticias['datacadastro'];

									$enderecolocal	= $campo_noticias['enderecolocal']; 	 		 			 	
									$bairrolocal	= $campo_noticias['bairrolocal']; 	 		 			 	
									$cidadelocalid	= $campo_noticias['cidadelocalid'];		 	
									$ceplocal	= $campo_noticias['ceplocal']; 			 	
									$falarcom	= $campo_noticias['falarcom']; 	 		 			 	
									$emailentrevista	= $campo_noticias['emailentrevista']; 	 		 			 	
									$proximodelocal	= $campo_noticias['proximodelocal']; 	 		 			 	
									$onoffshore	= $campo_noticias['onoffshore']; 	 		 			 	
									$local	= $campo_noticias['local']; 										 
									$enderecoentrevista	= $campo_noticias['enderecoentrevista']; 	 		 			 	
									$bairroentrevista	= $campo_noticias['bairroentrevista']; 	 		 			 	
									$cidadeentrevista	= $campo_noticias['cidadeentrevistaid'];		 	
									$cepentrevista	= $campo_noticias['cepentrevista']; 			 	
									$falarcom	= $campo_noticias['falarcom']; 	 		 			 	
									$emailentrevista	= $campo_noticias['emailentrevista']; 	 		 			 	
									$proximode	= $campo_noticias['proximode']; 										 
									
		
			?>
	

	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >
	
	<td  align="center" id="trCab8" class='td2' >
			<span color="#000" face="Tahoma"><b><?=$id;?></b></span>
		</td>
		<td  align="center"  class='td2'  id="trCab1">
										<?
										$query_ocupacao = "SELECT * FROM `cbo` where id='$cboid' ";
										$rs_ocupacao     = mysql_query($query_ocupacao );
										while($campo_ocupacao  = mysql_fetch_array($rs_ocupacao )){
										$cbo        = $campo_ocupacao ['cbo'];
										};
										
										if($vagadeficiente=="N"){$vagaparadeficiente='';}else{$vagaparadeficiente="PESSOA COM DEFICIÊNCIA";};
										$d=explode("-",$datalimiteencaminhar);
										$data=$d[2]."/".$d[1]."/".$d[0];
										
										?>
			<span color="#000" face="Tahoma"><b><?=$vagaparadeficiente;?><br>  <?=$cargo;?></span>
				
				<?switch ($onoffshore){										
				case "O":											
				$onoffshore_N = "";
				break;

				case "F":											
				$onoffshore_N = "OFFSHORE";
				break;
				}
				echo"$onoffshore_N";
				?>
				</b>
		</td>
		<!---td decricaço--->
		<td   class='td2' id="trCab2" >
			<span color="#000" face="Tahoma"><b>
			
			<div><?=$descricao;?></div>
			<div><?if($comprovada=="S"){echo"<span class='text_azul'>Experiência: </span>Comprovada";}?></div>
			<div><?if($aceitasemexperiencia=="S"){echo"Aceita Sem Experiência";}?></div>			
			<div><span class='text_azul'>Hs de trabalho: </span><?=$horariotrabalho;?></div>
			<?
				$query_software1 = "SELECT * FROM `software`where id='$softwareid1'";
				$rs_software1    = mysql_query($query_software1);
				while($campo_software1 = mysql_fetch_array($rs_software1)){																						
				$nome_soft1 	= $campo_software1['nome']; 	
				if($nome_soft1=="--"){}else{
				?>
				<div> <span class='text_azul'>Informática: </span><?=$nome_soft1;?> -
				<?}}
				$query_software2 = "SELECT * FROM `software`where id='$softwareid2'";
				$rs_software2    = mysql_query($query_software2);
				while($campo_software2 = mysql_fetch_array($rs_software2)){																						
				$nome_soft2 	= $campo_software2['nome']; 	
				if($nome_soft2=="--"){}else{
				?>
				<?=$nome_soft2;?> -
				<?}}
				$query_software3 = "SELECT * FROM `software`where id='$softwareid3'";
				$rs_software3    = mysql_query($query_software3);
				while($campo_software3 = mysql_fetch_array($rs_software3)){																						
				$nome_soft3 	= $campo_software3['nome']; 	
				if($nome_soft3=="--"){}else{				
				?>				
				- <?=$nome_soft3;?>
				<?}}?>
				
				
				
				<!----idiomas----------------------------->
					<?
					$query_idiomaid1 = "SELECT * FROM `idioma` where id='$idiomaid1'";
					$rs_idiomaid1    = mysql_query($query_idiomaid1);
					while($campo_idiomaid1 = mysql_fetch_array($rs_idiomaid1)){																						
					$nome_idiomaid1 	= $campo_idiomaid1['nome'];
					}
				if($nome_idiomaid1=="--"){}else{						
					
					?>
					<?
					switch ($leitura1){										
					case "B":											
					$leitura1_N = "Básica";
					break;case "I":											
					$leitura1_N = "Intermediária";
					break;case "A":											
					$leitura1_N = "Avançada";
					break;case "F":											
					$leitura1_N = "Fluente";
					break;
					}

					switch ($escrita1){										
					case "B":											
					$escrita1_N = "Básica";
					break;case "I":											
					$escrita1_N = "Intermediária";
					break;case "A":											
					$escrita1_N = "Avançada";
					break;case "F":											
					$escrita1_N = "Fluente";
					break;
					}

					switch ($conversacao1){										
					case "B":											
					$conversacao1_N = "Básica";
					break;case "I":											
					$conversacao1_N = "Intermediária";
					break;case "A":											
					$conversacao1_N = "Avançada";
					break;case "F":											
					$conversacao1_N = "Fluente";
					break;
					}
				
					?>					
					<span class='text_azul'>Idiomas</span>
					<div><?=$nome_idiomaid1;?> -
					<span class='text_azul'>Leitura: </span><?= $leitura1_N; ?> -
					<span class='text_azul'>Escrita: </span><?= $escrita1_N; ?> -
					<span class='text_azul'>Conversação: </span><?= $conversacao1_N; ?>
					</div>
					
				<?}?>
				
				<?
					$query_idiomaid2 = "SELECT * FROM `idioma` where id='$idiomaid2'";
					$rs_idiomaid2    = mysql_query($query_idiomaid2);
					while($campo_idiomaid2 = mysql_fetch_array($rs_idiomaid2)){																						
					$nome_idiomaid2 	= $campo_idiomaid2['nome'];
					}
				if($nome_idiomaid2=="--"){}else{						
					
					?>
					<?
					switch ($leitura2){										
					case "B":											
					$leitura2_N = "Básica";
					break;case "I":											
					$leitura2_N = "Intermediária";
					break;case "A":											
					$leitura2_N = "Avançada";
					break;case "F":											
					$leitura2_N = "Fluente";
					break;
					}

					switch ($escrita2){										
					case "B":											
					$escrita2_N = "Básica";
					break;case "I":											
					$escrita2_N = "Intermediária";
					break;case "A":											
					$escrita2_N = "Avançada";
					break;case "F":											
					$escrita2_N = "Fluente";
					break;
					}

					switch ($conversacao2){										
					case "B":											
					$conversacao2_N = "Básica";
					break;case "I":											
					$conversacao2_N = "Intermediária";
					break;case "A":											
					$conversacao2_N = "Avançada";
					break;case "F":											
					$conversacao2_N = "Fluente";
					break;
					}
				
					?>					
					<span class='text_azul'>Idiomas</span>
					<div><?=$nome_idiomaid2;?> -
					<span class='text_azul'>Leitura: </span><?= $leitura2_N; ?> -
					<span class='text_azul'>Escrita: </span><?= $escrita2_N; ?> -
					<span class='text_azul'>Conversação: </span><?= $conversacao2_N; ?>
					</div>
					
				<?}?>
				
				
				<?
					$query_idiomaid3 = "SELECT * FROM `idioma` where id='$idiomaid3'";
					$rs_idiomaid3    = mysql_query($query_idiomaid3);
					while($campo_idiomaid3 = mysql_fetch_array($rs_idiomaid3)){																						
					$nome_idiomaid3 	= $campo_idiomaid3['nome'];
					}
				if($nome_idiomaid3=="--"){}else{						
					
					?>
					<?
					switch ($leitura3){										
					case "B":											
					$leitura3_N = "Básica";
					break;case "I":											
					$leitura3_N = "Intermediária";
					break;case "A":											
					$leitura3_N = "Avançada";
					break;case "F":											
					$leitura3_N = "Fluente";
					break;
					}

					switch ($escrita3){										
					case "B":											
					$escrita3_N = "Básica";
					break;case "I":											
					$escrita3_N = "Intermediária";
					break;case "A":											
					$escrita3_N = "Avançada";
					break;case "F":											
					$escrita3_N = "Fluente";
					break;
					}

					switch ($conversacao3){										
					case "B":											
					$conversacao3_N = "Básica";
					break;case "I":											
					$conversacao3_N = "Intermediária";
					break;case "A":											
					$conversacao3_N = "Avançada";
					break;case "F":											
					$conversacao3_N = "Fluente";
					break;
					}
				
					?>					
					<span class='text_azul'>Idiomas</span>
					<div><?=$nome_idiomaid3;?> -
					<span class='text_azul'>Leitura: </span><?= $leitura3_N; ?> -
					<span class='text_azul'>Escrita: </span><?= $escrita3_N; ?> -
					<span class='text_azul'>Conversação: </span><?= $conversacao3_N; ?>
					</div>
					
				<?}?>
			
			
			<?
			if($tempoano < 1 && $tempomes < 1)
				{}else{
				echo"Tempo de Experiência $tempoano ano /$tempomes meses <br>";				
				}				
				if($cnh==""){}else{
				
					switch ($importanciacnh){										
					case "D":											
					$importanciacnh_N = "Desejável";
					break;

					case "I":											
					$importanciacnh_N = "Imprescindível";
					break;
					}
																				
				echo"Categoria CNH $cnh - $importanciacnh_N ";
				}
				
			?>
			
			</b></span>
		</td>
		<!--fim td descrição-->
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$quantidadedisponivel;?></b></span>
		</td>

	
		<td  align="center" class='td2' id="trCab5" >
		<?
																			switch ($sexo){										
																			case "M":											
																			$sexo_N = "Masculino";
																			break;

																			case "F":											
																			$sexo_N = "Feminino";
																			break;
																			case "A":											
																			$sexo_N = "Ambos";
																			break;
																			}
																			?>
																			
																			<?
																			switch ($importanciasexo){										
																			case "D":											
																			$importanciasexo_N = "Desejável";
																			break;

																			case "I":											
																			$importanciasexo_N = "Imprescindível";
																			break;


																			}
																			?>
			<span color="#000" face="Tahoma"><b><?=$sexo_N;?> <?if($importanciasexo=="D"){echo "$importanciasexo_N"; };?></b></span>
		</td>
		<td  align="center" id="trCab6" class='td2'>
		
													<?
													switch ($escolaridade){										
													case "F":											
													$escolaridade_N = "Fundamental";
													break;

													case "M":											
													$escolaridade_N = "Médio";
													break;

													case "P":											
													$escolaridade_N = "Pós-Médio";
													break;

													case "S":											
													$escolaridade_N = "Superior";
													break;
													}
													?>
													
													<?
													switch ($escolaridadesituacao){										
													case "I":											
													$escolaridadesituacao_N = "Incompleto";
													break;

													case "U":											
													$escolaridadesituacaoe_N = "Cursando";
													break;

													case "C":											
													$escolaridadesituacao_N = "Completo";
													break;


													}
													?>
													
													
													<?
													switch ($importanciaescolaridade){										
													case "D":											
													$importanciaescolaridade_N = "Desejável";
													break;

													case "I":											
													$importanciaescolaridade_N = "Imprescindível";
													break;

													
													}
													?>
																			
			<span color="#000" face="Tahoma"><b><?=$escolaridade_N;?> <?=$escolaridadesituacao_N;?> <?if($importanciaescolaridade=="D"){echo $importanciaescolaridade_N; };?></b></span>
		</td>
		

		
		
	

	</tr>

	
	<?}?>
	
	</table>
	</div>
	</div>