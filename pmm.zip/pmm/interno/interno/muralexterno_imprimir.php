<?
	include"../input_banco.php";
error_reporting(1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'../topo.php';?>


<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	$tipo= $_GET ['tipo'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".$tipo");
    header("Pragma: no-cache");
	}else{}
	

	
	
	?>
	

<style>

td{padding:3px;}
.sortable{font-size:13px;}


</style>
	<style>
	.text_azul{color:blue;}
	span{line-height:130%;}
	</style>

<body  onload="listavaga('oi');" rightmargin="5" bottommargin="0" >
<style>

	
.clTab {cursor:hand;background:transparent;font:13pt Arial;padding-left:3px;padding-right:3px;text-align:center;}

</style>

<div id="bg-container" class='contener'>

<script language="JavaScript"> 
function Abrir_Pagina(URL,Configuracao) {
window.open(URL,'',Configuracao);      
} 

function Impressao( preVisualizar ) 
{
	var CorpoMensagem = document.body.innerHTML;
	document.body.innerHTML = ImprimirConteudo.innerHTML;
	if( preVisualizar ) 
	{
		PreVisualizar();
	} 
	else 
	{
		window.print();
	}
	document.body.innerHTML = CorpoMensagem;
}
 
function PreVisualizar() 
{
	try 
	{
		 //Utilizando o componente WebBrowser1 registrado no MS Windows Server 2000/2003 ou XP/Vista
		 var WebBrowser = '<OBJECT ID="WebBrowser1" WIDTH=0 font=13 HEIGHT=0 CLASSID="CLSID:8856F961-340A-11D0-A96B-00C04FD705A2"></OBJECT>'; 
		 document.body.insertAdjacentHTML('beforeEnd', WebBrowser); 
		 WebBrowser1.ExecWB( 7, 1 ); 
		 WebBrowser1.outerHTML = ""; 
	} 
	catch(e) 
	{
		//alert("Para visualizar a impressão você precisa habilitar o uso de controles ActiveX na página.");
		//return;
	}
}
</script>	
   
			

			

		
			<div id="getexcel">		
		<table width="100%" style='background-color:#fff;'>
			<tr >
				<td><img src='../img/LogoSecretaria.png' width='200px'></td>
				<td>DIVULGAÇÃO DE VAGAS<br>
				
				<form action="" method="post" onsubmit="target_popup(this)">
							<?$datahoje = date('d/m/Y');?>
							<input type='text' name="sqlpcd" style='display:none;'value="and vagadeficiente='S' and aceitadeficiente='S'" id="sqlpcd"style="width:55px; "/>
							
							<input type="submit" value='PCD'/> 
				</form>
				<input type="button" name="imprimir" value="Imprimir" onclick="window.print();"/>	
				</td>

				
 
			</tr>
						
			
			
		</table>
		

		<table width="100%"  style='background-color:#002db2;color:#fff;'> 		
			<tr width='200px'>
				<td><?echo date("d/m/Y");?></td>
				<td></td>
				
				<td align='right'></td>
			</tr>
			
		
		</table>
		
		
		
		<?
				$get_acao= $_POST['acao'];
				$post_status= $_POST['status'];			
				$post_escolaridade= $_POST['escolaridade'];
				$post_sexo= $_POST['sexo'];
				$post_datainicio= $_POST['datainicio'];
				$post_datafinal= $_POST['datafinal'];
				$post_semexperiencia= $_POST['semexperiencia'];
				$post_descricao= $_POST['descricao'];
				$post_ocupacao= $_POST['ocupacao'];
				$post_id= $_POST['id'];
				$post_atendente= $_POST['atendente'];
				$empresaid= $_POST['empresaid'];
				
				
				$post_segmentoatuacao= $_POST['segmentoatuacao'];
				$post_jovemaprendiz= $_POST['jovemaprendiz'];
				$post_estagios= $_POST['estagios'];
				$post_contapcd= $_POST['contapcd'];
				$post_sqlpcd= $_POST['sqlpcd'];
				if($post_sqlpcd==""){$post_sqlpcd="and `vagadeficiente` NOT IN ('S') AND  `aceitadeficiente` NOT IN ('S')";}
				
				
				
		
		?>
	
	
	<div id="ImprimirConteudo"  style="font-size:16px;" >
	<table  border="1" bordercolor="#000000" style="border-collapse: collapse;font-size:16px;" cellpadding="2" class="sortable" style="font-size:13px;" >
	<tr>
		<td bgcolor="#000080"  style="width:2;"align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')">
			<font color="#ffffff" face="Tahoma"><b>ID</b></font>
		</td>
		<td bgcolor="#000080" " align="center" id="trCab1" >
			<font color="#ffffff" face="Tahoma"><b>VAGA</b></font>
		</td>
		<td bgcolor="#000080" "align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
			<font color="#ffffff" face="Tahoma"><b>DESCRIÇÃO</b></font>
		</td>
		<td bgcolor="#000080" align="center"   id="trCab3" onMouseOver="MouseSobreCab('3')" onMouseOut="MouseSaiCab('3')" onClick="SelecionaCab('3')">
			<font color="#ffffff" font="Tahoma"><b>QTD</b></font>
		</td>

		
		
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>ESCOLARIDADE</b></font>
		</td>
		
		<!--<td bgcolor="#000080" align="center" id="trCab11">
			<font color="#ffffff" face="Tahoma"><b>Benefícios</b></font>
		</td>-->

		

	</tr>
		
					<?
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			$numero=1;
			
			
			
				if($get_acao==""){
				$query_noticias = "SELECT *  FROM `vaga` WHERE  `status` ='A' ".$post_sqlpcd." ORDER BY  `vaga`.`cargo` ASC  ";
				}
				else
				{
				//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
				if($post_status==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='A'  ";}
				if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
				if($post_descricao==""){}else{$sqldescricao="and `descricao` LIKE '%$post_descricao%' ";}				
				if($post_escolaridade==""){}else{$sqloescolaridade="and escolaridade='$post_escolaridade' ";}
				if($post_sexo==""){}else{$sqlsexo="and sexo='$post_sexo' ";}
				if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
				if($post_id==""){}else{$sqlid="and id='$post_id' ";}
				if($empresaid==""){}else{$sqlempresaid="and empresaid='$empresaid' ";}
				
				
				$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
				$post_datafinal1s = implode("-",array_reverse(explode("/",$post_datafinal)));
						$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1s))); // 15/03/2006
				
				if(($post_datainicio=="") || ($post_datafinal==""))
				{
					if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
					if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
					
				
				}
				else{
				$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
				}
				
				
				$query_noticias = "SELECT *  FROM `vaga` where  
				".$sqlostatus."	
				".$post_sqlpcd."				
				".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."				
				".$sqlempresaid."	
				".$sql2data."
				ORDER BY  `vaga`.`cargo` ASC ";
				}
			
		//echo $query_noticias;
		$rs_noticias    = mysql_query($query_noticias); 
			
		$total = mysql_num_rows($rs_noticias);	
	
		while($campo_noticias = mysql_fetch_array($rs_noticias)){



									
									$id= $campo_noticias['id']; 	 
									$empresaid= $campo_noticias['empresaid']; 	 
									$selvagasigilosa = $campo_noticias['selvagasigilosa'];
									
									$cboid = $campo_noticias['cboid'];
									$descricao = $campo_noticias['descricao'];
									$cargo = $campo_noticias['cargo']; 
									$txvagadata = $campo_noticias['txvagadata'];
									$horariotrabalho = $campo_noticias['horariotrabalho'];
									$vagadeficiente = $campo_noticias['vagadeficiente'];
									$quantidadedisponivel = $campo_noticias['quantidadedisponivel'];
									$txvagapreenchidaCTM = $campo_noticias['txvagapreenchidaCTM']; 
									$txvagapreenchidaOutros = $campo_noticias['txvagapreenchidaOutros'];
									$txvagaCancelada = $campo_noticias['txvagaCancelada']; 
									$txvagasativas = $campo_noticias['txvagasativas']; 
									$quantidadeencaminhar = $campo_noticias['quantidadeencaminhar'];
									$datalimiteencaminhar = $campo_noticias['datalimiteencaminhar'];
									$chktemporaria = $campo_noticias['chktemporaria'];
									$ceplocal = $campo_noticias['ceplocal'];
									$txtestado_local = $campo_noticias['txtestado_local'];
									$cidadelocalid = $campo_noticias['cidadelocalid'];
									$bairrolocal = $campo_noticias['bairrolocal'];
									$enderecolocal = $campo_noticias['enderecolocal']; 
									$proximodelocal = $campo_noticias['proximodelocal']; 
									$onoffshore = $campo_noticias['onoffshore']; 
									$local = $campo_noticias['local'];
									$salario = $campo_noticias['salario'];
									$comissao = $campo_noticias['comissao'];
									$prospeccao = $campo_noticias['prospeccao'];
									$cartaoalimentacao = $campo_noticias['cartaoalimentacao']; 
									$alimentacaolocal = $campo_noticias['alimentacaolocal']; 
									$lanche = $campo_noticias['lanche'];
									$cestabasica = $campo_noticias['cestabasica']; 
									$planosaude = $campo_noticias['planosaude']; 
									$planoodonto = $campo_noticias['planoodonto'];
									$segurovida = $campo_noticias['segurovida'];
									$carteiraassinada = $campo_noticias['carteiraassinada']; 
									$valetransporte= $campo_noticias['valetransporte'];
									$premiacao = $campo_noticias['premiacao']; 
									$outrosbeneficios = $campo_noticias['outrosbeneficios'];
									$tempoano = $campo_noticias['tempoano']; 
									$tempomes = $campo_noticias['tempomes']; 
									$comprovada = $campo_noticias['comprovada'];
									$idademinima = $campo_noticias['idademinima']; 
									$idademaxima = $campo_noticias['idademaxima']; 
									$escolaridade = $campo_noticias['escolaridade'];
									$escolaridadesituacao = $campo_noticias['escolaridadesituacao'];
									$cnh= $campo_noticias['cnh']; 
									$sexo = $campo_noticias['sexo'];
									$estadocivil = $campo_noticias['estadocivil']; 
									$txvagafilhos = $campo_noticias['txvagafilhos'];
									$importanciatempo = $campo_noticias['importanciatempo']; 
									$importanciaidade = $campo_noticias['importanciaidade']; 
									$importanciaescolaridade = $campo_noticias['importanciaescolaridade']; 
									$importanciacnh = $campo_noticias['importanciacnh'];
									$importanciasexo = $campo_noticias['importanciasexo']; 
									$importanciaestadocivil = $campo_noticias['importanciaestadocivil'];
									$selvagafilhos_niv = $campo_noticias['selvagafilhos_niv'];
									$txvagaregiao = $campo_noticias['txvagaregiao'];
									$txvagahabilidades = $campo_noticias['txvagahabilidades']; 
									$txvagarestricoes = $campo_noticias['txvagarestricoes'];
									$importanciaestadocivil = $campo_noticias['importanciaestadocivil']; 
									$selvagaIDIOMAS_niv = $campo_noticias['selvagaIDIOMAS_niv'];
									$selvagainformatica_niv = $campo_noticias['selvagainformatica_niv'];
									$aceitasemexperiencia = $campo_noticias['aceitasemexperiencia'];
									$txtcep = $campo_noticias['txtcep'];
									$txtestado = $campo_noticias['txtestado'];
									$txtcidade = $campo_noticias['txtcidade'];
									$txtbairro = $campo_noticias['txtbairro'];
									$txtendereco = $campo_noticias['txtendereco']; 
									$txtproximode = $campo_noticias['txtproximode'];
									$txtfalarcom = $campo_noticias['txtfalarcom']; 
									$txtEmailEntrevista = $campo_noticias['txtEmailEntrevista']; 
									$horarioatendimento = $campo_noticias['horarioatendimento'];
									$viaencaminhamento = $campo_noticias['viaencaminhamento'];
									$observacao = $campo_noticias['observacao']; 
									$status = $campo_noticias['status']; 
									$formacaptacaoid = $campo_noticias['formacaptacaoid'];
									$localcaptacaoid = $campo_noticias['localcaptacaoid']; 
									$selpublicar = $campo_noticias['selpublicar']; 
									$dia = $campo_noticias['dia']; 
									$mes = $campo_noticias['mes']; 
									$ano = $campo_noticias['ano']; 
									$sigilosa = $campo_noticias['sigilosa']; 
									
									 $softwareid1 = $campo_noticias['softwareid1']; 
									 $softwareid2 = $campo_noticias['softwareid2']; 
									 $softwareid3 = $campo_noticias['softwareid3'];
									 
									 $idiomaid1 = $campo_noticias['idiomaid1']; 
									 $LEITURA1 = $campo_noticias['LEITURA1']; 
									 $ESCRITA1 = $campo_noticias['ESCRITA1']; 
									 $conversacao1 = $campo_noticias['conversacao1']; 
									 
									  $idiomaid2 = $campo_noticias['idiomaid2']; 
									 $LEITURA2 = $campo_noticias['LEITURA2']; 
									 $ESCRITA2 = $campo_noticias['ESCRITA2']; 
									 $conversacao2 = $campo_noticias['conversacao2']; 
									 
									  $idiomaid3 = $campo_noticias['idiomaid3']; 
									 $LEITURA3 = $campo_noticias['LEITURA3']; 
									 $ESCRITA3 = $campo_noticias['ESCRITA3']; 
									 $conversacao3 = $campo_noticias['conversacao3']; 
									 $cadastrado_por = $campo_noticias['usuarioid']; 
									 $datacadastro = $campo_noticias['datacadastro'];

									$enderecolocal	= $campo_noticias['enderecolocal']; 	 		 			 	
									$bairrolocal	= $campo_noticias['bairrolocal']; 	 		 			 	
									$cidadelocalid	= $campo_noticias['cidadelocalid'];		 	
									$ceplocal	= $campo_noticias['ceplocal']; 			 	
									$falarcom	= $campo_noticias['falarcom']; 	 		 			 	
									$emailentrevista	= $campo_noticias['emailentrevista']; 	 		 			 	
									$proximodelocal	= $campo_noticias['proximodelocal']; 	 		 			 	
									$onoffshore	= $campo_noticias['onoffshore']; 	 		 			 	
									$local	= $campo_noticias['local']; 										 
									$enderecoentrevista	= $campo_noticias['enderecoentrevista']; 	 		 			 	
									$bairroentrevista	= $campo_noticias['bairroentrevista']; 	 		 			 	
									$cidadeentrevista	= $campo_noticias['cidadeentrevistaid'];		 	
									$cepentrevista	= $campo_noticias['cepentrevista']; 			 	
									$falarcom	= $campo_noticias['falarcom']; 	 		 			 	
									$emailentrevista	= $campo_noticias['emailentrevista']; 	 		 			 	
									$proximode	= $campo_noticias['proximode']; 										 
									
		
			?>
	

	<tr title="ATENÇÂO Documentos Necessários: CPF, RG Carteira de Trabalho" style="font-size:13px;" >
	
		<td width="50px"align="center" id="trCab8" style="font-size:13px;">
			<span   color="#000" face="Tahoma" style="font-size:13px;"><b><?=$id;?></b></span>
		</td>
		
		
		<td align="center"   id="trCab1" style="font-size:13px;">
			<?
			$query_ocupacao = "SELECT * FROM `cbo` where id='$cboid' ";
			$rs_ocupacao     = mysql_query($query_ocupacao );
			while($campo_ocupacao  = mysql_fetch_array($rs_ocupacao )){
			$cbo        = $campo_ocupacao ['cbo'];
			};
			
			if($vagadeficiente=="N"){$vagaparadeficiente='';}else{$vagaparadeficiente="PESSOA COM DEFICIÊNCIA";};
			$d=explode("-",$datalimiteencaminhar);
			$data=$d[2]."/".$d[1]."/".$d[0];
			
			?>
			<span   color="#000" face="Tahoma" style="font-size:13px;" ><b><?=$vagaparadeficiente;?><br>  <?=$cargo;?></span>
				
				<?switch ($onoffshore){										
				case "O":											
				$onoffshore_N = "";
				break;

				case "F":											
				$onoffshore_N = "OFFSHORE";
				break;
				}
				echo"$onoffshore_N";
				?>
				</b>
		</td>
		
		
		
		<!---td decricaço--->
		<td     id="trCab2"  style="font-size:13px;">
			<span   color="#000" face="Tahoma" style="font-size:13px;"><b>
			
			<div><?=$descricao;?></div>
			<div><?if($comprovada=="S"){echo"<span  class='text_azul'>EXPERIÊNCIA: </span>COMPROVADA";
			
			
			}?></div>
			<div><?if($aceitasemexperiencia=="S"){echo"ACEITA SEM EXPERIÊNCIA";
			
                                                                                
                                                                                
			
			}?></div>			
			<div><span   class='text_azul'>HORÁRIO DE TRABALHO: </span><?=$horariotrabalho;?></div>
			<?
			
			if(($idademinima > 0)||($idademaxima > 0 )){
				
				if($idademinima > 1){$idademinimaedit = " apartir de   $idademinima anos"; }
				if($idademaxima > 1){$idademaximamaedit = " até $idademaxima anos"; }
				
				
				}
				if($tempoano =="0"){$tempoano = ""; $anot="";} else{$anot="ano ";}
			if($tempomes =="0"){$tempomes = "   "; $mest=""; }else{$mest="meses";}
			if(($tempoano > 0) && ($tempomes > 0 )){$separador ="e";}else{ $separador =""; }
			if(($tempoano > 0)||($tempomes > 0 )){echo"<div><span class='text_azul'> TEMPO DE EXPERIÊNCIA </span> $tempoano $anot  $separador  $tempomes $mest </div>";}
				
			
				
				$query_software1 = "SELECT * FROM `software`where id='$softwareid1'";
				$rs_software1    = mysql_query($query_software1);
				while($campo_software1 = mysql_fetch_array($rs_software1)){																						
				$nome_soft1 	= $campo_software1['nome']; 	
				if($nome_soft1=="--"){}else{
				?>
				<div> <span   class='text_azul'>INFORMÁTICA: </span><?=$nome_soft1;?> -
				<?}}
				$query_software2 = "SELECT * FROM `software`where id='$softwareid2'";
				$rs_software2    = mysql_query($query_software2);
				while($campo_software2 = mysql_fetch_array($rs_software2)){																						
				$nome_soft2 	= $campo_software2['nome']; 	
				if($nome_soft2=="--"){}else{
				?>
				<?=$nome_soft2;?> -
				<?}}
				$query_software3 = "SELECT * FROM `software`where id='$softwareid3'";
				$rs_software3    = mysql_query($query_software3);
				while($campo_software3 = mysql_fetch_array($rs_software3)){																						
				$nome_soft3 	= $campo_software3['nome']; 	
				if($nome_soft3=="--"){}else{				
				?>				
				- <?=$nome_soft3;?>
				<?}}?>
				
				
				
				<!----IDIOMAS----------------------------->
					<?
					$query_idiomaid1 = "SELECT * FROM `idioma` where id='$idiomaid1'";
					$rs_idiomaid1    = mysql_query($query_idiomaid1);
					while($campo_idiomaid1 = mysql_fetch_array($rs_idiomaid1)){																						
					$nome_idiomaid1 	= $campo_idiomaid1['nome'];
					}
				if($nome_idiomaid1=="--"){}else{						
					
					?>
					<?
					switch ($LEITURA1){										
					case "B":											
					$LEITURA1_N = "BÁSICA";
					break;case "I":											
					$LEITURA1_N = "INTERMEDIÁRIA";
					break;case "A":											
					$LEITURA1_N = "AVANÇADA";
					break;case "F":											
					$LEITURA1_N = "FLUENTE";
					break;
					}

					switch ($ESCRITA1){										
					case "B":											
					$ESCRITA1_N = "BÁSICA";
					break;case "I":											
					$ESCRITA1_N = "INTERMEDIÁRIA";
					break;case "A":											
					$ESCRITA1_N = "AVANÇADA";
					break;case "F":											
					$ESCRITA1_N = "FLUENTE";
					break;
					}

					switch ($conversacao1){										
					case "B":											
					$conversacao1_N = "BÁSICA";
					break;case "I":											
					$conversacao1_N = "INTERMEDIÁRIA";
					break;case "A":											
					$conversacao1_N = "AVANÇADA";
					break;case "F":											
					$conversacao1_N = "FLUENTE";
					break;
					}
				
					?>					
					<span   class='text_azul'>IDIOMAS</span>
					<div><?=$nome_idiomaid1;?> -
					<span   class='text_azul'>LEITURA: </span><?= $LEITURA1_N; ?> -
					<span   class='text_azul'>ESCRITA: </span><?= $ESCRITA1_N; ?> -
					<span   class='text_azul'>CONVERSAÇÃO: </span><?= $conversacao1_N; ?>
					</div>
					
				<?}?>
				
				<?
					$query_idiomaid2 = "SELECT * FROM `idioma` where id='$idiomaid2'";
					$rs_idiomaid2    = mysql_query($query_idiomaid2);
					while($campo_idiomaid2 = mysql_fetch_array($rs_idiomaid2)){																						
					$nome_idiomaid2 	= $campo_idiomaid2['nome'];
					}
				if($nome_idiomaid2=="--"){}else{						
					
					?>
					<?
					switch ($LEITURA2){										
					case "B":											
					$LEITURA2_N = "BÁSICA";
					break;case "I":											
					$LEITURA2_N = "INTERMEDIÁRIA";
					break;case "A":											
					$LEITURA2_N = "AVANÇADA";
					break;case "F":											
					$LEITURA2_N = "FLUENTE";
					break;
					}

					switch ($ESCRITA2){										
					case "B":											
					$ESCRITA2_N = "BÁSICA";
					break;case "I":											
					$ESCRITA2_N = "INTERMEDIÁRIA";
					break;case "A":											
					$ESCRITA2_N = "AVANÇADA";
					break;case "F":											
					$ESCRITA2_N = "FLUENTE";
					break;
					}

					switch ($conversacao2){										
					case "B":											
					$conversacao2_N = "BÁSICA";
					break;case "I":											
					$conversacao2_N = "INTERMEDIÁRIA";
					break;case "A":											
					$conversacao2_N = "AVANÇADA";
					break;case "F":											
					$conversacao2_N = "FLUENTE";
					break;
					}
				
					?>					
					<span   class='text_azul'>IDIOMAS</span>
					<div><?=$nome_idiomaid2;?> -
					<span   class='text_azul'>LEITURA: </span><?= $LEITURA2_N; ?> -
					<span   class='text_azul'>ESCRITA: </span><?= $ESCRITA2_N; ?> -
					<span   class='text_azul'>CONVERSAÇÃO: </span><?= $conversacao2_N; ?>
					</div>
					
				<?}?>
				
				
				<?
					$query_idiomaid3 = "SELECT * FROM `idioma` where id='$idiomaid3'";
					$rs_idiomaid3    = mysql_query($query_idiomaid3);
					while($campo_idiomaid3 = mysql_fetch_array($rs_idiomaid3)){																						
					$nome_idiomaid3 	= $campo_idiomaid3['nome'];
					}
				if($nome_idiomaid3=="--"){}else{						
					
					?>
					<?
					switch ($LEITURA3){										
					case "B":											
					$LEITURA3_N = "BÁSICA";
					break;case "I":											
					$LEITURA3_N = "INTERMEDIÁRIA";
					break;case "A":											
					$LEITURA3_N = "AVANÇADA";
					break;case "F":											
					$LEITURA3_N = "FLUENTE";
					break;
					}

					switch ($ESCRITA3){										
					case "B":											
					$ESCRITA3_N = "BÁSICA";
					break;case "I":											
					$ESCRITA3_N = "INTERMEDIÁRIA";
					break;case "A":											
					$ESCRITA3_N = "AVANÇADA";
					break;case "F":											
					$ESCRITA3_N = "FLUENTE";
					break;
					}

					switch ($conversacao3){										
					case "B":											
					$conversacao3_N = "BÁSICA";
					break;case "I":											
					$conversacao3_N = "INTERMEDIÁRIA";
					break;case "A":											
					$conversacao3_N = "AVANÇADA";
					break;case "F":											
					$conversacao3_N = "FLUENTE";
					break;
					}
				
					?>					
					<span   class='text_azul'>IDIOMAS</span>
					<div><?=$nome_idiomaid3;?> -
					<span   class='text_azul'>LEITURA: </span><?= $LEITURA3_N; ?> -
					<span   class='text_azul'>ESCRITA: </span><?= $ESCRITA3_N; ?> -
					<span   class='text_azul'>CONVERSAÇÃO: </span><?= $conversacao3_N; ?>
					</div>
					
				<?}?>
			
			
			<?
							
				if($cnh==""){}else{
				
					switch ($importanciacnh){										
					case "D":											
					$importanciacnh_N = "Desejável";
					break;

					case "I":											
					$importanciacnh_N = "Imprescindível";
					break;
					}
																				
				echo"Categoria CNH $cnh - $importanciacnh_N ";
				}
				
			?>
			
			</b></span>
		</td>
		<!--fim td descrição-->
		<td     align="center" id="trCab3" >
			<span   style="font-size:13px;" color="#000" face="Tahoma"><b><?=$quantidadedisponivel;?></b></span>
		</td>

	
		
		<td     align="center" id="trCab6">
		
													<?
													switch ($escolaridade){										
													case "F":											
													$escolaridade_N = "Fundamental";
													break;

													case "M":											
													$escolaridade_N = "Médio";
													break;

													case "P":											
													$escolaridade_N = "Pós-Médio";
													break;

													case "S":											
													$escolaridade_N = "Superior";
													break;
													}
													?>
													
													<?
													switch ($escolaridadesituacao){										
													case "I":											
													$escolaridadesituacao_N = "Incompleto";
													break;

													case "U":											
													$escolaridadesituacao_N = "Cursando";
													break;

													case "C":											
													$escolaridadesituacao_N = "Completo";
													break;


													}
													?>
													
													
													<?
													switch ($importanciaescolaridade){										
													case "D":											
													$importanciaescolaridade_N = "Desejável";
													break;

													case "I":											
													$importanciaescolaridade_N = "Imprescindível";
													break;

													
													}
													?>
																			
			<span   color="#000" face="Tahoma" style="font-size:13px;"><b>&nbsp;<?=$escolaridade_N;?> <?=$escolaridadesituacao_N;?> <?echo $importanciaescolaridade_N; ;?>&nbsp;</b></span>
		</td>
		

		<!--<td  align="left"  class='td2' style="font-size:13px;" id="trCab11">
			<span color="blue" face="Tahoma" style="font-size:13px;"><b>
			
			 <?if($cartaoalimentacao=="S"){echo"Cartão Alimentação <br>";}else{}?>
			 <?if($planosaude=="S"){echo"Plano Saúde <br>";}else{}?> 
			 <?if($carteiraassinada=="S"){echo"Carteira assinada <br>";}else{}?>
			 <?if($alimentacaolocal=="S"){echo"Alimentação no local <br>";}else{}?> 
			 <?if($planoodonto=="S"){echo"Plano Odonto <br>";}else{}?><br>
			 <?if($valetransporte=="S"){echo"V. Transporte<br> ";}else{}?>
			 <?if($lanche=="S"){echo"Lanches <br>";}else{}?> 
			 <?if($segurovida=="S"){echo"Seguro de Vida<br> ";}else{}?>
			 <?if($premiacao=="S"){echo"Premiação <br>";}else{}?>
			 <?if($cestabasica=="S"){echo"Cesta Básica <br>";}else{}?> 
			 <?=$outrosbeneficios;?>
			</b></span>
		</td>-->
		
	

	</tr>

	
	<?}?>
	
	</table>
	</div>
	</div>
						
							<div name='listavaga1' id='listavaga1'></div>
						<?include"rodape.php";?>
					
		
		

			
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
