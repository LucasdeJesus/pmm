<?
include"../input_banco.php";
?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Vagas TV</title>
	<style>
	.text_azul{color:blue;}
	span{line-height:130%;}
	html{overflow-y:hidden;}
	body{overflow-y:hidden;}
	</style>
	
	   
    <!-- Bootstrap -->
   <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css" integrity="sha384-aUGj/X2zp5rLCbBxumKTCw2Z50WgIr1vs/PFN4praOTvYXWlVyh2UtNUU0KAUhAX" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" integrity="sha512-K1qjQ+NcF2TYO/eI3M6v8EiNYZfA95pQumfvcVrTHtwQVDG+aHRqLi/ETn2uB+1JqwYqVG3LIvdm9lj6imS/pQ==" crossorigin="anonymous"></script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  	

  <audio id="audio" src="beep.wav" autostart="false" ></audio>
    
    <script>
    function PlaySound() {
          var sound = document.getElementById("audio");
          sound.play()
      }
    </script>  
   
   
   				
<table  width="100%" border="0"  style="border-collapse: collapse;font-size:16px;" cellpadding="2" class="sortable" style="font-size:13px;" >

	<tr style=''>
		<td bgcolor="#000080"  width="5%"  align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')">
			<font color="#ffffff" face="Tahoma"><b><a href="chamnome.php" style="color:#fff">ID</a></b></font>
		</td>
		<td bgcolor="#000080" width="10%"  align="center" id="trCab1" >
			<font color="#ffffff" face="Tahoma"><b>VAGA</b></font>
		</td>
		<td bgcolor="#000080" width="40%"  align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
			<font color="#ffffff" face="Tahoma"><b>DESCRIÇÃO</b></font>
		</td>
		<td bgcolor="#000080" width="5%"  align="center"   id="trCab3" onMouseOver="MouseSobreCab('3')" onMouseOut="MouseSaiCab('3')" onClick="SelecionaCab('3')">
			<font color="#ffffff" font="Tahoma"><b>QTD</b></font>
		</td>

		
		
		<td bgcolor="#000080" width="20%"  align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>ESCOLARIDADE</b></font>
		</td>
		
		<td bgcolor="#000080" width="20%"  align="center" id="trCab11">
			<font color="#ffffff" face="Tahoma"><b>Benefícios</b></font>
		</td>

		

	</tr>
	<table>
			
		
   <div id="fechanome" style="font-size:50px;">
			
	</div>
   		
		<div id="painel" style="cursor: default; height: 98%; width: 100%; overflow: auto; padding-left: 10px;  padding-right: 10px;padding-top: 20px;"  >
	
    
    </div>

		
		
		
		
	
		
		
		
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content" >
      <div class="modal-header"  style="background-color:#f2dede">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title" id="myModalLabel">Atenção</h3>
      </div>
      <div class="modal-body">
			<div id="vagafechada">
			
			</div>
      </div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>		


	

			
     
		
	<script type="text/javascript">

					carrega_historico_proficional();
					
					
					function carrega_historico_proficional(){
						
						
					var xmlHttp;
					try{    
					xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					catch (e){
					alert("No AJAX!?");
					return false;
					}
					}
					}

					xmlHttp.onreadystatechange=function(){
					if(xmlHttp.readyState==4){
					document.getElementById('painel').innerHTML=xmlHttp.responseText;
					//setTimeout('carrega_historico_proficional()',1000);
					
					}
					}
					xmlHttp.open("GET","minha_pagina_acesso_banco.php?limit=limit 0,2000",true); // aqui configuramos o arquivo
					xmlHttp.send(null);
					
					}

					window.onload=function(){
					setTimeout('carrega_historico_proficional()',1000000); // aqui o tempo entre uma atualização e outra
					
					}
					
				
	
					  i = 0;
					  tempo =5;
					  tamanho = 826; // tamanho da barra de rolagem  >> Ver arquivo Leiame.txt
												
					  function Rolar() {
							var objDiv = document.getElementById("painel");
							var fim = objDiv.scrollTop = objDiv.scrollHeight;
							var fimdiv = fim - 500;


							document.getElementById('painel').scrollTop = i;
							i++;
							t = setTimeout("Rolar()", tempo);
							if (i == fimdiv) {
							i = 0;
							}
							}
							function Parar() {
							clearTimeout(t);
							}
					  Rolar();
					  
						
					</script>	
		
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" integrity="sha256-Sk3nkD6mLTMOF0EOpNtsIry+s1CsaqQC1rVLTAy+0yc= sha512-K1qjQ+NcF2TYO/eI3M6v8EiNYZfA95pQumfvcVrTHtwQVDG+aHRqLi/ETn2uB+1JqwYqVG3LIvdm9lj6imS/pQ==" crossorigin="anonymous"></script>
 
 <script>
     
		function verificavagaencerada(){
			
				
		}
		
		
		
		
		
		function chamanome(){
			
			
				$.ajax({
				url: 'acoesmuraltv.php?acao=chamaatendimento' ,	
				dataType: 'jsonp',
				jsonp: 'jsoncallback',
				timeout: 5000,
				success: function(data, status){
					
					$.each(data, function(i,item){
					
						if(item.databr=="0"){}else{
						
						var divmodalvaga = '<div align="center" style="width:100%"><b style="color:#ff9900">'+item.nome+' </b> <hr> Atendimento: <b>'+item.tipo+'</b> </div>';
						PlaySound();
						$("#fechanome").append(divmodalvaga);
						//$('#painel').hide() ;
						$("#fechanome").show();
						
						
						setTimeout(function() {		
						
						$('#fechanome').empty();
						$("#fechanome").hide();
						$('#painel').show();
						//$('#myModalnome').modal('hide') ;
						
						$.ajax({
							type: "GET",
							url: "acoesmuraltv.php?acao=deletnome",
							success: function(data) {
							//manipula os dados
									
							},
							error: function() {
							}
							});
						
						
						}, 8000);
						
						
						
						
						}
					
					});
						
				},
				error: function(){
								
				}
				});
		
		setTimeout("chamanome()", 15000);	
		}
		
		
		
		 chamanome1(); 
 
	</script>

 </body>
</html>