<?include("../seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'../topo.php';?>




<body  onload="listavaga('oi');">
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script src="../js/sorttable.js"></script>
<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>

<div id="bg-container" class='contener'>

<script language="JavaScript"> 
function Abrir_Pagina(URL,Configuracao) {
window.open(URL,'',Configuracao);      
} 
</script>	
   
			

			

		
						
						<?include"cpdconsulta.php";?>
						
							<div name='listavaga1' id='listavaga1'></div>
						<?include"rodape.php";?>
					
		
		

			
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
