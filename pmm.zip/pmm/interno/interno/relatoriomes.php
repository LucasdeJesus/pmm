	<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	
	
	
	?>
	

					
		
					<?
						
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			
			
						$diaatual = date("d");
						$mestual = date("m");
						$anoatual = date("Y");
						
						if($get_acao==""){
						$sql2data="$anoatual-$mestual";						
						}
						else
						{
						//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
						if($post_status==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='$post_status'  ";}
						if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
						if($post_descricao==""){}else{$sqldescricao="and `descricao` LIKE '%$post_descricao%' ";}				
						if($post_escolaridade==""){}else{$sqloescolaridade="and escolaridade='$post_escolaridade' ";}
						if($post_sexo==""){}else{$sqlsexo="and sexo='$post_sexo' ";}
						if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
						if($post_id==""){}else{$sqlid="and id='$post_id' ";}
						if($empresaid==""){}else{$sqlempresaid="and empresaid='$empresaid' ";}


						$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));						;


						if($post_datainicio==""){}else{
						
						$sql2data="$post_datainicio1";
						
						}
						
						
					}
					
					$pieces = explode("-", $sql2data);
					$anogetdata=  $pieces[0]; // piece1
					$mesgetdata=  $pieces[1]; // piece1
					$totalgeralctpmm=0;
					$nomeusuarioarrei = ""; 
					echo"<div style='width:100%;' align='center'><h5>Busca referente: $anogetdata-$mesgetdata</h5></div>";
					$dataatual="$anogetdata-$mesgetdata";
					?>
						<script  type="text/javascript">	
						
				
					function salvaatendimento(atividade,dia) {
					
											
					switch(dia) {
							case 1:
								var dia1= "01";
								break;
							case 2:
								var dia1= "02";
								break;
						 case 3:
								var dia1= "03";
								break;
						 case 4:
								var dia1= "04";
								break;
						 case 5:
								var dia1= "05";
								break;
						 case 6:
								var dia1= "06";
								break;
						 case 7:
								var dia1= "07";
								break;
						 case 8:
								var dia1= "08";
								break;
						 case 9:
								var dia1= "09";
								break;
						default:		
								var dia1= dia;
						}
						   
						   
					valor_input = document.getElementById(atividade+'carteira_'+dia1).value;
					 
					// Verificando Browser
					if(window.XMLHttpRequest) {
					req = new XMLHttpRequest();
					}
					else if(window.ActiveXObject) {
					req = new ActiveXObject("Microsoft.XMLHTTP");
					}
					   
					// Arquivo PHP juntamente com o valor digitado no campo (método GET)
					var url = "script.php?atividade="+atividade+"&valorinput="+valor_input+"&data=<?=$dataatual;?>-"+dia1;
					//alert(url);
					// Chamada do método open para processar a requisição
					req.open("Get", url, true); 
					req.setRequestHeader("Cache-Control","no-cache,no-store");
					req.setRequestHeader("Pragma", "no-cache");

					// Quando o objeto recebe o retorno, chamamos a seguinte função;
					req.onreadystatechange = function() {

					// Exibe a mensagem "Buscando Noticias..." enquanto carrega
					if(req.readyState == 1) {
					document.getElementById('salvadados').innerHTML = 'Carregando aguarde...';
					}
							
					// Verifica se o Ajax realizou todas as operações corretamente
					if(req.readyState == 4 && req.status == 200) {

					// Resposta retornada pelo busca.php
					var resposta = req.responseText;

					// Abaixo colocamos a(s) resposta(s) na div resultado
					document.getElementById('salvadados').innerHTML = resposta;
					}
					}
					req.send(null);
					req.setRequestHeader("Cache-Control", "no-cache");
					req.setRequestHeader("Pragma", "no-cache"); 
					
					}
					
					</script>
					<?	
					
					$query_atendimento  = "SELECT usuarioID  FROM `atendimento` where  `data` LIKE '%$anogetdata-$mesgetdata%'   group by usuarioID Desc";					
					$rs_atendimento    = mysql_query($query_atendimento);
					
					while($campo_atendimento = mysql_fetch_array($rs_atendimento)){	
					$usuarioaidtodos	= $campo_atendimento['usuarioID']; 												
																


													
													$query_noticiasceu1 = "SELECT usuario,id,nome FROM `usuario` where id='$usuarioaidtodos' ";
													$rs_noticiasceu1    = mysql_query($query_noticiasceu1);
													while($campo_noticiasceu1 = mysql_fetch_array($rs_noticiasceu1)){	
													$usuarioa1	= $campo_noticiasceu1['usuario']; 												
													$usuarioaid1	= $campo_noticiasceu1['id']; 												
													$nomeat	= $campo_noticiasceu1['nome']; 												
													
												
													?>
													
													
													
													
														<?																
														
														
														?>
																
																
													<div id="getexcel">
													<table border="1" width=""  >													
														
														
														
														
														<tr width=''>
															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;<?=$nomeat;?>&nbsp;</b></font>
														    </td>
																
																
																<td width='40px' class="td2"><b> &nbsp;01&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;02&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;03&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;04&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;05&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;06&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;07&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;08&nbsp; </b></td>																	
																<td width='40px' class="td2"><b> &nbsp;09&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;10&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;11&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;12&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;13&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;14&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;15&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;16&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;17&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;18&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;19&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;20&nbsp; </b></td>
																<td width='40px' class="td2"><b> &nbsp;21&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;22&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;23&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;24&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;25&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;26&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;27&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;28&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;29&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;30&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;31&nbsp; </b></td>																
																<td width='40px' class="td2"><b> &nbsp;T&nbsp;</b> </td>																
														</tr>
														
														<!-----------------------------------------------------------------------atendimento --------------------------------->
														<tr width='' bgcolor="#8FB98" >
															<td  align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font  face="Tahoma"><b>&nbsp;Atendimento&nbsp;</b></font>
														    </td>
															
																
																<?php
															
																$arrat = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
																$iat = 0;
																$totalat = 0;
																while ($iat < count($arrat)) {
																   $at = $arrat[$iat];
																   
																   $query_C1a = "SELECT id FROM `atendimento` WHERE  atividade='T' and `data` LIKE '%$anogetdata-$mesgetdata-$at%'  and usuarioID='$usuarioaid1'";
																	$rs_C1a    = mysql_query($query_C1a);
																	$diaC1a = mysql_num_rows($rs_C1a);
																	if($diaC1a==""){$diaC1a="0";}
																	
																	
																	//$query_C1ae = "SELECT * FROM `encaminhamento` WHERE `datacadastro` LIKE '%$anogetdata-$mesgetdata-$at%'  and usuarioid='$usuarioaid1'";
																	$query_C1ae = "SELECT id FROM `atendimento` WHERE  atividade='E' and `data` LIKE '%$anogetdata-$mesgetdata-$at%'  and usuarioID='$usuarioaid1'";
																	$rs_C1ae    = mysql_query($query_C1ae);
																	$diaC1ae = mysql_num_rows($rs_C1ae);
																	if($diaC1ae==""){$diaC1ae="0";}
																	
																	$query_N1a = "SELECT id FROM `atendimento` WHERE  atividade='N' and `data` LIKE '%$anogetdata-$mesgetdata-$at%'  and usuarioID='$usuarioaid1'";
																	$rs_N1a    = mysql_query($query_N1a);
																	$diaN1a = mysql_num_rows($rs_N1a);
																	if($diaN1a==""){$diaN1a="0";}
																	
																	 $query_C1aez= "SELECT id FROM `atendimento` WHERE  atividade='Z' and `data` LIKE '%$anogetdata-$mesgetdata-$at%'  and usuarioID='$usuarioaid1'";
																	$rs_C1aez    = mysql_query($query_C1aez);
																	$diaC1aez = mysql_num_rows($rs_C1aez);
																	if($diaC1aez==""){$diaC1aez="0";}
																	
																	//$query_C1aeza= "SELECT * FROM `trabalhador` WHERE   `dataupdate` LIKE '%$anogetdata-$mesgetdata-$at%'  and usuarioid='$usuarioaid1'";
																	$query_C1aeza= "SELECT id FROM `atendimento` WHERE  atividade='A' and `data` LIKE '%$anogetdata-$mesgetdata-$at%'  and usuarioID='$usuarioaid1'";
																	$rs_C1aeza    = mysql_query($query_C1aeza);
																	$diaC1aeza = mysql_num_rows($rs_C1aeza);
																	if($diaC1aeza==""){$diaC1aeza="0";}
																	
																	
																	$cadastro_CEa =$diaC1a+$diaN1a+$diaC1ae+$diaC1aez+$diaC1aeza;
																	$totalat +=$cadastro_CEa; 
																  ?>
																	<td width='40px' class="td2" title="Atendimento = <?=$diaC1a;?> ,Cadastro / Encaminhamento=<?=$diaN1a;?>, Encaminhamento=<?=$diaC1ae;?>, Atualização / Encaminhamento=<?=$diaC1aez;?>, Atualização=<?=$diaC1aeza;?>"> &nbsp;<?=$cadastro_CEa ;?>&nbsp; </td>																		
																  <?
																   $iat++;
																   
															}?>	
																<td width='40px' class="td2"  bgcolor="#fff" > &nbsp;<?=$totalat ;?>&nbsp; </td>	
																
																
																
																
														</tr>
														
														
														
														
														
														<!-----------------------------------------------------------------------Encaminhamento --------------------------------->
														<tr width='' bgcolor="#EEDD82">
															<td  align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#000" face="Tahoma"><b>&nbsp;Encaminhamento&nbsp;</b></font>
														    </td>
															
															<?php
															
																$arrE = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
																$iE = 0;
																$totalE = 0;
																while ($iE < count($arrE)) {
																   $E = $arrE[$iE];
																   
																   $query_E1 = "SELECT id FROM `encaminhamento` WHERE `datacadastro` LIKE '%$anogetdata-$mesgetdata-$E%'  and usuarioid='$usuarioaid1'";
																   //$query_E1= "SELECT * FROM `atendimento` WHERE  atividade='E' and `data` LIKE '%$anogetdata-$mesgetdata-$at%'  and usuarioID='$usuarioaid1'";
																	$rs_E1    = mysql_query($query_E1);
																	$diaE1 = mysql_num_rows($rs_E1);
																	if($diaE1==""){$diaE1="0";}
																	$totalE +=$diaE1; 
																  ?>
																	<td width='40px' class="td2" title="Encaminhamento=<?=$diaE1;?>"> &nbsp;<?=$diaE1;?>&nbsp; </td>																		
																  <?
																   $iE++;
															}?>	
																
																
																<td width='40px' class="td2"  bgcolor="#fff" > &nbsp;<?=$totalE;?>&nbsp; </td>	
														</tr>
														
														
														
														
														<!-----------------------------------------------------------------------Cadastro --------------------------------->
														<tr width='' bgcolor="#87CEEB">
															<td  align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#000" face="Tahoma"><b>&nbsp;Cadastro&nbsp;</b></font>
														    </td>
																
															<?php
															
																$arrC = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
																$iC = 0;
																$totalC = 0;
																while ($iC < count($arrC)) {
																   $C = $arrC[$iC];
																   
																   $query_C1 = "SELECT id FROM `trabalhador` WHERE   `datacadastro` LIKE '%$anogetdata-$mesgetdata-$C%'  and usuarioid='$usuarioaid1'";
																   //$query_C1 = "SELECT * FROM `atendimento` WHERE  atividade='C' and `data` LIKE '%$anogetdata-$mesgetdata-$C%'  and usuarioID='$usuarioaid1'";
																	$rs_C1    = mysql_query($query_C1);
																	$diaC1 = mysql_num_rows($rs_C1);
																	if($diaC1==""){$diaC1="0";}
																	
																	$query_N1 = "SELECT id  FROM `atendimento` WHERE  atividade='N' and `data` LIKE '%$anogetdata-$mesgetdata-$C%'  and usuarioID='$usuarioaid1'";
																	$rs_N1    = mysql_query($query_N1);
																	$diaN1 = mysql_num_rows($rs_N1);
																	if($diaN1==""){$diaN1="0";}
																	
																	$cadastro_CE =$diaC1+$diaN1;
																	$totalC +=$cadastro_CE; 
																  ?>
																	<td width='40px' class="td2" title="Cadastro vindo sistema  =<?=$diaC1;?> , Encaminhamento vindo finalizar=<?=$diaN1;?>"> &nbsp;<?=$cadastro_CE ;?>&nbsp; </td>																		
																  <?
																   $iC++;
															}?>	
																
																
																<td width='40px' class="td2"  bgcolor="#fff" > &nbsp;<?=$totalC;?>&nbsp; </td>	
														</tr>
														
														
														
														
														
														
														
														
														
														
														<!-----------------------------------------------------------------------total --------------------------------->
														
														<tr width='100px' bgcolor="#fff"  >
															<td align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#000" face="Tahoma"><b>&nbsp;Vagas de Emp.&nbsp;</b></font>
														    </td>
																
															<?
															$arratgeral = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
															$iatgeral = 0;
															$totalatgeral = 0;
															while ($iatgeral < count($arratgeral)) {
																	$atgeral = $arratgeral[$iatgeral];

																	$query_C1ag = "SELECT id FROM `atendimento` WHERE  atividade='T' and `data` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioID='$usuarioaid1'";
																	$rs_C1ag    = mysql_query($query_C1ag);
																	$diaC1ag = mysql_num_rows($rs_C1ag);
																	if($diaC1ag==""){$diaC1ag="0";}


																	//$query_C1aeg = "SELECT * FROM `encaminhamento` WHERE `datacadastro` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioid='$usuarioaid1'";
																	$query_C1aeg = "SELECT id FROM `atendimento` WHERE  atividade='E' and `data` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioID='$usuarioaid1'";
																	$rs_C1aeg    = mysql_query($query_C1aeg);
																	$diaC1aeg = mysql_num_rows($rs_C1aeg);
																	if($diaC1aeg==""){$diaC1aeg="0";}

																	$query_N1ag = "SELECT id FROM `atendimento` WHERE  atividade='N' and `data` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioID='$usuarioaid1'";
																	$rs_N1ag    = mysql_query($query_N1ag);
																	$diaN1ag = mysql_num_rows($rs_N1ag);
																	if($diaN1ag==""){$diaN1ag="0";}

																	$query_C1aezg= "SELECT id FROM `atendimento` WHERE  atividade='Z' and `data` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioID='$usuarioaid1'";
																	$rs_C1aezg    = mysql_query($query_C1aezg);
																	$diaC1aezg = mysql_num_rows($rs_C1aezg);
																	if($diaC1aezg==""){$diaC1aezg="0";}

																	$query_C1aezag= "SELECT id FROM `atendimento` WHERE  atividade='A' and `data` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioID='$usuarioaid1'";
																	$rs_C1aezag    = mysql_query($query_C1aezag);
																	$diaC1aezag = mysql_num_rows($rs_C1aezag);
																	if($diaC1aezag==""){$diaC1aezag="0";}

																	/// r11
																	$cadastro_CEag =$diaC1ag+$diaN1ag+$diaC1aeg+$diaC1aezg+$diaC1aezag;

																	////////////////////////////////////////////////////////////----- encaminha ------------------////////////////////////////////
																	$query_E1g = "SELECT id FROM `encaminhamento` WHERE `datacadastro` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioid='$usuarioaid1'";
																	$rs_E1g    = mysql_query($query_E1g);
																	$diaE1g = mysql_num_rows($rs_E1g);
																	if($diaE1g==""){$diaE1g="0";}
																	/// r11
																	$diaE1g; 

																	////////////////////////////////////////////////////////////-------------cadastro----------////////////////////////////////

																	$query_C1g = "SELECT id FROM `trabalhador` WHERE   `datacadastro` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioid='$usuarioaid1'";
																	$rs_C1g    = mysql_query($query_C1g);
																	$diaC1g = mysql_num_rows($rs_C1g);
																	if($diaC1g==""){$diaC1g="0";}
																	
																	$query_N1g = "SELECT id FROM `atendimento` WHERE  atividade='N' and `data` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioID='$usuarioaid1'";
																	$rs_N1g    = mysql_query($query_N1g);
																	$diaN1g = mysql_num_rows($rs_N1g);
																	if($diaN1g==""){$diaN1g="0";}
																	/// r11
																	$cadastro_CEg =$diaC1g+$diaN1g;


															
																	//$somadiaria= $cadastro_CEg+$diaE1g;
																	$somadiaria= $cadastro_CEg+$cadastro_CEag;
																	$totalatgeral+=$somadiaria;
															?>	
																<td width='40px' class="td2" Title="soma cadastro <?=$cadastro_CEg;?> + Atendimento.<?=$cadastro_CEag;?> ||  Fora=<?=$diaE1g;?>"> &nbsp;<?=$somadiaria;?>&nbsp; </td>
																<?
																$iatgeral++;
																}?>		
														<td width='40px' class="td2"><b> &nbsp;<?=$totalatgeral;?>&nbsp; </b></td>																
														</tr>
														
													</table>
	
							<?							
							$totalgeralctpmm+=$totalatgeral;
							$nomeusuarioarrei.="['$nomeat' , $totalat , $totalE , $totalC ],";
							
							?>
							
					<? 
					
					}}?>
							
							
							
								<!-------------------carteira- de trabalho---------------------------->
								
								<div style="margin-top:5px;">
									<h2> Atendimentos DETRAN</h2>
								<table border="1" width="">
										
										
										<tr width=''>
															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Atendimentos RG&nbsp;</b></font>
														    </td>
																
																
																<td width='40px' class="td2"><b> &nbsp;01&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;02&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;03&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;04&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;05&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;06&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;07&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;08&nbsp; </b></td>																	
																<td width='40px' class="td2"><b> &nbsp;09&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;10&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;11&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;12&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;13&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;14&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;15&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;16&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;17&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;18&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;19&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;20&nbsp; </b></td>
																<td width='40px' class="td2"><b> &nbsp;21&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;22&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;23&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;24&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;25&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;26&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;27&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;28&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;29&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;30&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;31&nbsp; </b></td>																
																<td width='40px' class="td2"><b> &nbsp;T&nbsp;</b> </td>																
														</tr>
														<tr width='' bgcolor="#006400"><!---1 via---->
															<td  align="center" id="trCab1" onMouseOver="MouseSobreCab('1')"  onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#000" face="Tahoma" style="width:100px;padding:3px;"><b>&nbsp;1ª_Via_RG </b></font>
														    </td>
																
															<?php
															
																$arrCa = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
																$iCa = 0;
																$totalCa = 0;																
																while ($iCa < count($arrCa)) {
																   $Ca = $arrCa[$iCa];
																   
																  
																	$query_noticias_hcpj1 = "SELECT id,quantidade FROM `atendimentorg` WHERE  `dia` = '$anogetdata-$mesgetdata-$Ca'  and via='1' ";
																	$rs_noticias_hcpj1    = mysql_query($query_noticias_hcpj1);
																	$totaldia1 = mysql_num_rows($rs_noticias_hcpj1);
																	
																	if($totaldia1 > 0){
																		
																		while($campo_noticias_hcpj1 = mysql_fetch_array($rs_noticias_hcpj1)){			
																		$quantidade1  = $campo_noticias_hcpj1['quantidade'];	
																		$totalCa+=$quantidade1;	
																			
																		?>	<td width='40px' class="td2" title="" style="padding:0px;"><input type='text' id="1carteira_<?=$Ca;?>" onkeyup="salvaatendimento(1,<?=$Ca;?>)" name="1carteira_<?=$Ca;?>" value="<?=$quantidade1;?>" style="width:25px;height:17px;"/></td><?																		
																		}	
																	
																	}
																	else{
																		?><td width='40px' class="td2" title="" style="padding:0px;"><input type='text' id="1carteira_<?=$Ca;?>" onkeyup="salvaatendimento(1,<?=$Ca;?>)" name="1carteira_<?=$Ca;?>" value="" style="width:25px;height:17px;"/></td><?																		
																	}
																  ?>
																	
																  <?
																   $iCa++;
															}?>	
																
																
																<td width='40px' class="td2"  bgcolor="#fff" > &nbsp;<?=$totalCa;?>&nbsp; </td>	
														</tr><!---1 via---->
														
														<tr width='' bgcolor="#FFFF00"><!---2 via---->
															<td  align="center" id="trCab1" onMouseOver="MouseSobreCab('1')"  onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#000" face="Tahoma" style="width:100px;padding:3px;"><b>&nbsp;2ª_Via_RG </b></font>
														    </td>
																
															<?php
															
																$arrCa2 = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
																$iCa2 = 0;
																$totalCa2 = 0;
																while ($iCa2 < count($arrCa2)) {
																   $Ca2 = $arrCa2[$iCa2];
																   
																  
																	$query_noticias_hcpj2 = "SELECT id,quantidade FROM `atendimentorg` WHERE  `dia` = '$anogetdata-$mesgetdata-$Ca2' and via='2'";
																	$rs_noticias_hcpj2    = mysql_query($query_noticias_hcpj2);
																	$totaldia2 = mysql_num_rows($rs_noticias_hcpj2);
																	
																	if($totaldia2 > 0)
																	{
																		while($campo_noticias_hcpj2 = mysql_fetch_array($rs_noticias_hcpj2)){			
																		$quantidade2  = $campo_noticias_hcpj2['quantidade'];
																		$totalCa2+=$quantidade2;
																			
																			?><td width='40px' class="td2" title="" style="padding:0px;"><input type='text' id="2carteira_<?=$Ca2;?>" onkeyup="salvaatendimento(2,<?=$Ca2;?>)" name="2carteira_<?=$Ca2;?>" value="<?=$quantidade2;?>" style="width:25px;height:17px;"/></td><?													
																		}
																	}
																	
																	else
																	{
																		?><td width='40px' class="td2" title="" style="padding:0px;"><input type='text' id="2carteira_<?=$Ca2;?>" onkeyup="salvaatendimento(2,<?=$Ca2;?>)" name="2carteira_<?=$Ca2;?>" value="" style="width:25px;height:17px;"/></td><?																															
																	}
																  ?>
																	
																  <?
																   $iCa2++;
															}?>	
																
																
																<td width='40px' class="td2"  bgcolor="#fff" > &nbsp;<?=$totalCa2;?>&nbsp; </td>	
														</tr><!---2 via---->
														
														
														<tr width='' bgcolor="#0000FF"><!---dic  via---->
															<td  align="center" id="trCab1" onMouseOver="MouseSobreCab('1')"  onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#000" face="Tahoma" style="width:100px;padding:3px;"><b>&nbsp;DIC_Entregues </b></font>
														    </td>
																
															<?php
															
																$arrCadic  = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
																$iCadic = 0;
																$totalCadic  = 0;
																while ($iCadic  < count($arrCadic)) {
																   $Cadic  = $arrCadic [$iCadic ];
																   
																  
																	$query_noticias_hcpjdic  = "SELECT id ,quantidade FROM `atendimentorg` WHERE  `dia` ='$anogetdata-$mesgetdata-$Cadic'  and via='3'";
																	$rs_noticias_hcpjdic     = mysql_query($query_noticias_hcpjdic );
																	$totaldiadic = mysql_num_rows($rs_noticias_hcpjdic);
																	
																	if($totaldiadic > 0)
																	{
																		while($campo_noticias_hcpjdic  = mysql_fetch_array($rs_noticias_hcpjdic )){			
																		$quantidadedic   = $campo_noticias_hcpjdic ['quantidade'];
																		$totalCadic+=$quantidadedic ;
																		
																			?><td width='40px' class="td2" title="" style="padding:0px;"><input type='text' id="3carteira_<?=$Cadic ;?>" onkeyup="salvaatendimento(3,<?=$Cadic ;?>)" name="3carteira_<?=$Cadic ;?>" value="<?=$quantidadedic;?>" style="width:25px;height:17px;"/></td><?
																		}
																	}
																	else{
																		?><td width='40px' class="td2" title="" style="padding:0px;"><input type='text' id="3carteira_<?=$Cadic ;?>" onkeyup="salvaatendimento(3,<?=$Cadic ;?>)" name="3carteira_<?=$Cadic ;?>" value="" style="width:25px;height:17px;"/></td><?																		
																	
																	}
																  ?>
																	
																  <?
																   $iCadic ++;
															}?>	
																
																
																<td width='40px' class="td2"  bgcolor="#fff" > &nbsp;<?=$totalCadic;?>&nbsp; </td>	
														</tr><!---dic via---->
														
														
														<tr width='' bgcolor="#fff"><!---dic  via---->
															<td  align="center" id="trCab1" onMouseOver="MouseSobreCab('1')"  onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#000" face="Tahoma" style="width:100px;padding:3px;"><b>&nbsp;Total DETRAN </b></font>
														    </td>
																
															<?php
																$totalgeral = 0;
																$arrCadict  = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
																$iCadict = 0;
																$totalfinalrg = 0;
																												
																while ($iCadict  < count($arrCadict)) {
																$Cadict  = $arrCadict [$iCadict ];
																
																
																////1
																	$totalCat =0;
																	$query_noticias_hcpj1t = "SELECT id,quantidade FROM `atendimentorg` WHERE  `dia` = '$anogetdata-$mesgetdata-$Cadict'  and via='1' ";
																	$rs_noticias_hcpj1t    = mysql_query($query_noticias_hcpj1t);
																	$totaldia1t = mysql_num_rows($rs_noticias_hcpj1t);
																	
																	if($totaldia1t > 0){
																		
																		while($campo_noticias_hcpj1t = mysql_fetch_array($rs_noticias_hcpj1t)){			
																		$quantidade1t  = $campo_noticias_hcpj1t['quantidade'];
																		$totalCat+=$quantidade1t;																			
																		}																		
																	}else{$totalCat+=$quantidade1t=0;}
																////2
																	$totalCa2t =0;	
																	$query_noticias_hcpj2t = "SELECT id,quantidade FROM `atendimentorg` WHERE  `dia` = '$anogetdata-$mesgetdata-$Cadict' and via='2'";
																	$rs_noticias_hcpj2t    = mysql_query($query_noticias_hcpj2t);
																	$totaldia2t = mysql_num_rows($rs_noticias_hcpj2t);
																	
																	if($totaldia2t > 0)
																	{
																		while($campo_noticias_hcpj2t = mysql_fetch_array($rs_noticias_hcpj2t)){			
																		$quantidade2t  = $campo_noticias_hcpj2t['quantidade'];
																		$totalCa2t+=$quantidade2t;																			
																		}
																	}else{$totalCa2t+=$quantidade2t=0;}
																////3
																	$totalCadict  = 0;
																	$query_noticias_hcpjdict = "SELECT id,quantidade  FROM `atendimentorg` WHERE  `dia` ='$anogetdata-$mesgetdata-$Cadict'  and via='3'";
																	$rs_noticias_hcpjdict     = mysql_query($query_noticias_hcpjdict );
																	$totaldiadict = mysql_num_rows($rs_noticias_hcpjdict);																	
																	if($totaldiadict > 0)
																	{
																		while($campo_noticias_hcpjdict  = mysql_fetch_array($rs_noticias_hcpjdict )){			
																		$quantidadedict   = $campo_noticias_hcpjdict ['quantidade'];
																		$totalCadict+=$quantidadedict ;
																		}
																	}else{$totalCadict+=$quantidadedict=0;}
																
																	$totalgeral= $totalCat+$totalCa2t+$totalCadict;
																	$totalfinalrg+=$totalgeral;
																 ?>
																 
																 <td width='40px' class="td2" title="" style="padding:0px;"><?=$totalgeral;?></td>																		
																
																  <?
																   $iCadict ++;
															}?>	
																
																
																<td width='40px' class="td2"  bgcolor="#fff" > &nbsp;<?=$totalfinalrg;?>&nbsp; </td>	
														</tr><!---dic via---->
														
								</table>	
								</div>	
	<div name='salvadados' id='salvadados'></div>	
				<!-------------------carteira- de trabalho---------------------------->
				
				
						<div style="margin-top:5px;">
						<h2> Totais de Atendimentos</h2>
					<table>

														<tr width=''>
															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;Total_Geral&nbsp;</b></font>
														    </td>
																
																
																<td width='40px' class="td2"><b> &nbsp;01&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;02&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;03&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;04&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;05&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;06&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;07&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;08&nbsp; </b></td>																	
																<td width='40px' class="td2"><b> &nbsp;09&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;10&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;11&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;12&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;13&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;14&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;15&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;16&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;17&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;18&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;19&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;20&nbsp; </b></td>
																<td width='40px' class="td2"><b> &nbsp;21&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;22&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;23&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;24&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;25&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;26&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;27&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;28&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;29&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;30&nbsp; </b></td>	
																<td width='40px' class="td2"><b> &nbsp;31&nbsp; </b></td>																
																<td width='40px' class="td2"><b> &nbsp;T&nbsp;</b> </td>																
														</tr>
<tr bgcolor="#cdcdcd">
<td  align="center"  style="width:279px"id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
<font color="#00" face="Tahoma"><b>&nbsp;Total_Geral&nbsp;</b></font>
</td>

<?
	$arratgerald = array("01", "02", "03", "04","05","06", "07", "08", "09","10","11", "12", "13", "14","15","16", "17", "18", "19","20","21","22", "23", "24", "25","26","27", "28", "29", "30","31");
	$iatgerald = 0;
	$totalatgerald = 0;
	while ($iatgerald < count($arratgerald)) {
	$atgerald = $arratgerald[$iatgerald];

	$query_C1agd = "SELECT id FROM `atendimento` WHERE  atividade='T' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%' ";
	$rs_C1agd    = mysql_query($query_C1agd);
	$diaC1agd = mysql_num_rows($rs_C1agd);
	if($diaC1agd==""){$diaC1agd="0";}


	//$query_C1aegd = "SELECT * FROM `encaminhamento` WHERE `datacadastro` LIKE '%$anogetdata-$mesgetdata-$atgeral%'  and usuarioid='$usuarioaid1'";
	$query_C1aegd = "SELECT id FROM `atendimento` WHERE  atividade='E' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%'  ";
	$rs_C1aegd    = mysql_query($query_C1aegd);
	$diaC1aegd = mysql_num_rows($rs_C1aegd);
	if($diaC1aegd==""){$diaC1aegd="0";}

	$query_N1agd = "SELECT id FROM `atendimento` WHERE  atividade='N' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%'  ";
	$rs_N1agd    = mysql_query($query_N1agd);
	$diaN1agd = mysql_num_rows($rs_N1agd);
	if($diaN1agd==""){$diaN1agd="0";}

	$query_C1aezgd= "SELECT id FROM `atendimento` WHERE  atividade='Z' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%' ";
	$rs_C1aezgd    = mysql_query($query_C1aezgd);
	$diaC1aezgd = mysql_num_rows($rs_C1aezgd);
	if($diaC1aezgd==""){$diaC1aezgd="0";}

	$query_C1aezagd= "SELECT id FROM `atendimento` WHERE  atividade='A' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%'  ";
	$rs_C1aezagd    = mysql_query($query_C1aezagd);
	$diaC1aezagd = mysql_num_rows($rs_C1aezagd);
	if($diaC1aezagd==""){$diaC1aezagd="0";}

	/// r11
	$cadastro_CEagd =$diaC1agd+$diaN1agd+$diaC1aegd+$diaC1aezgd+$diaC1aezagd;

	////////////////////////////////////////////////////////////----- encaminha ------------------////////////////////////////////
	$query_E1gd = "SELECT id FROM `encaminhamento` WHERE `datacadastro` LIKE '%$anogetdata-$mesgetdata-$atgerald%'  ";
	$rs_E1gd    = mysql_query($query_E1gd);
	$diaE1gd = mysql_num_rows($rs_E1gd);
	if($diaE1gd==""){$diaE1gd="0";}
	/// r11
	$diaE1gd; 

	////////////////////////////////////////////////////////////-------------cadastro----------////////////////////////////////

	$query_C1gd = "SELECT id FROM `trabalhador` WHERE   `datacadastro` LIKE '%$anogetdata-$mesgetdata-$atgerald%' ";
	$rs_C1gd    = mysql_query($query_C1gd);
	$diaC1gd = mysql_num_rows($rs_C1gd);
	if($diaC1gd==""){$diaC1gd="0";}

	$query_N1gd = "SELECT id FROM `atendimento` WHERE  atividade='N' and `data` LIKE '%$anogetdata-$mesgetdata-$atgerald%'  ";
	$rs_N1gd    = mysql_query($query_N1gd);
	$diaN1gd = mysql_num_rows($rs_N1gd);
	if($diaN1gd==""){$diaN1gd="0";}
	/// r11
	$cadastro_CEgd =$diaC1gd+$diaN1gd;



	$somadiariad= $cadastro_CEgd+$cadastro_CEagd;
	$totalatgerald+=$somadiariad;
	?>	
	<td width='40px' class="td2" Title="soma cadastro <?=$cadastro_CEgd;?> / Atend.<?=$cadastro_CEagd;?> / "> &nbsp;<?=$somadiariad;?>&nbsp; </td>
	<?
	$iatgerald++;
	}?>															
<td width='40px' class="td2"><b> &nbsp;<?=$totalatgerald;?>&nbsp;</b> </td>																
</tr>
</table>
</div>	
	
	
	 <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawChart);
function drawChart() {

  var data = google.visualization.arrayToDataTable([
    ['Usuario', 'Atendimento', 'Encaminhamento','Cadastro'],
    <?echo $nomeusuarioarrei;?>
    ['',  0,      0,0]
  ]);

  var options = {
    title: 'Relatório Mês',
    hAxis: {title: '<?echo"$anogetdata-$mesgetdata";?>', titleTextStyle: {color: 'red'}}
  };

  var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));

  chart.draw(data, options);

}
    </script>
	
	 <div id="chart_div" style="width: 900px; height: 500px;"></div>
	 
	 </div>
	
	
