
	
	<div width="100%" style='' align='center'>
	<table width="100%" style='background-color:#002db2;color:#fff;'> 		
			<tr>
				<td>Endereço: Rua Doutor Télio Barreto, 28 - CENTRO</td>
				
			</tr>
			
		</table>
		</div>
		
