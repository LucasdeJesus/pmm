<?php
include"../input_banco.php";

$via = $_GET['atividade'];
$quantidade = $_GET['valorinput'];
$dia = $_GET['data'];



				$query_noticias_hcpj = "SELECT * FROM `atendimentorg` WHERE  `dia` LIKE '%$dia%' and  via='$via' ";
				$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
				while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){				
				$id_atendimentorg  = $campo_noticias_hcpj['id'];
				}
																	
		if($id_atendimentorg > 0)
		{
		$query="UPDATE `atendimentorg` set  quantidade='$quantidade', via='$via' where id='$id_atendimentorg '";									  
		$rs= mysql_query($query);
		}
		else
		{
		$query="insert INTO `atendimentorg` (`quantidade`,`via`,`dia`) VALUES ('$quantidade','$via','$dia')";									  
		$rs= mysql_query($query);
		}
		
		
?>