<?
include("../seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(1);

$trabalhadorid= $_GET['id'];
$value= $_GET['value'];



$query_noticiasw = "SELECT id FROM `trabalhadorpcd` WHERE trabalhadorid='$trabalhadorid'";
$rs_noticiasw    = mysql_query($query_noticiasw);
$total = mysql_num_rows($rs_noticiasw);
	
	if($total > 0)
	{
		
			$query="UPDATE `trabalhadorpcd` SET  status='$value', data = CURRENT_TIMESTAMP where trabalhadorid='$trabalhadorid' ";
			$rs= mysql_query($query);
		
	}
	else
	{
		
			$query="INSERT INTO `trabalhadorpcd` (`trabalhadorid` ,`status` ,`data`)VALUES (  '$trabalhadorid',  '$value', CURRENT_TIMESTAMP)";
			$rs= mysql_query($query);
		
	}
	

	if ($rs) 
			{?>			
				OK
			<?
			}else
			{
			?>
			Erro
			<?}

?>