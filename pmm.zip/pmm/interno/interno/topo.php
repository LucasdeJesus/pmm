<?php
$exporta= $_POST['acao'];
if($exporta=="post"){
$arquivo = "relatorio.xls";
header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header ("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
header ("Cache-Control: no-cache, must-revalidate");
header ("Pragma: no-cache");
 header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
header ("Content-type: application/x-m---cel");
header ("Content-Disposition: attachment; filename=\"{$arquivo}\"" );
header ("Content-Description: PHP Generated Data" );
}
?>

<?
					$lista = $_GET['lista'];
					$anofinaldata = date('Y');
						
					switch ($lista) {
					case 'interno':
					$url="consulta.php";
					break;
					case 'mural':
					$url= "mural.php";
					break;
					case 'empresa':
					$url="empresa.php";
					break;
					
					case 'listavaga':
					$url="listavaga.php";
					break;
					
					case 'encaminhamento':
					$url="emcaminhamento.php";
					break;
					
					case 'vagas_disponivel_trabalhador':
					$url="vagas_disponivel_trabalhador.php";
					break;
					
					case 'contatoempresa':
					$url="contatoempresa.php";
					break;
					
					case 'vagasdaempresa':
					$url="vagasdaempresa.php";
					break;
					
					case 'vagastotal':
					$url="vagastotal.php";
					break;
					case 'mapaempresa':
					$url="mapaempresa.php";
					break;
					case 'listaencaminhamento':
					$url="listaencaminhamento.php";
					break;
					
					case 'totalempresa':
					$url="totalempresa.php";
					break;
					
					case 'totalemcaminhamento':
					$url="totalemcaminhamento.php";
					break;
					
					case 'listapararadio':
					$url="listapararadio.php";
					break;
					case 'relatoriomes':
					$url="relatoriomes.php";
					break;	
					case 'atendimentosalao':
					$url="atendimentosalao.php";
					break;
					case 'totalcadastro':
					$url="totalcadastro.php";
					break;
					
					case 'vagastotal_seguimento':
					$url="vagastotal_seguimento.php";
					break;
					
					case 'totalcadastro_ocupacao':
					$url="totalcadastro_ocupacao.php";
					break;
					
					
					
					}


						?>
		<table width="100%" style='background-color:#fff;'>
			<tr >
				<td><img src='../img/LogoSecretaria.png' width='200px'></td>
				<td>DIVULGAÇÃO DE VAGAS<br>
				
				
						<script type="text/javascript">  
							
						
						function target_popup(form) {
						window.open('', 'formpopup', 'width=400,height=400,resizeable,scrollbars');
							form.target = 'formpopup';
						}
					</script>
					
					<script  type="text/javascript">
												
													// FUNÇÃO PARA BUSCA NOTICIA
													function busca_cidade(valor2) {
													// Verificando Browser
													if(window.XMLHttpRequest) {
													req = new XMLHttpRequest();
													}
													else if(window.ActiveXObject) {
													req = new ActiveXObject("Microsoft.XMLHTTP");
													}

													// Arquivo PHP juntamente com o valor digitado no campo (método GET)

													var url = "../busca_endereco.php?tipo_busca=cidade&uf="+valor2;

													// Chamada do método open para processar a requisição
													req.open("Get", url, true); 
													req.setRequestHeader("Cache-Control","no-cache,no-store");
													req.setRequestHeader("Pragma", "no-cache");

													// Quando o objeto recebe o retorno, chamamos a seguinte função;
													req.onreadystatechange = function() {

													// Exibe a mensagem "Buscando Noticias..." enquanto carrega
													if(req.readyState == 1) {
													document.getElementById('cidade').innerHTML = '<option >buscando</option>';
													}

													// Verifica se o Ajax realizou todas as operações corretamente
													if(req.readyState == 4 && req.status == 200) {

													// Resposta retornada pelo busca.php
													var resposta = req.responseText;

													// Abaixo colocamos a(s) resposta(s) na div resultado
													document.getElementById('cidade').innerHTML = resposta;
													}
													}
													req.send(null);
													req.setRequestHeader("Cache-Control", "no-cache");
													req.setRequestHeader("Pragma", "no-cache"); 

													}
													</script>
													
													
													
													<script  type="text/javascript">
												
													// FUNÇÃO PARA BUSCA NOTICIA
													function busca_bairro(valor2) {
													// Verificando Browser
													if(window.XMLHttpRequest) {
													req = new XMLHttpRequest();
													}
													else if(window.ActiveXObject) {
													req = new ActiveXObject("Microsoft.XMLHTTP");
													}

													// Arquivo PHP juntamente com o valor digitado no campo (método GET)

													var url = "../busca_endereco.php?tipo_busca=bairro&cidade="+valor2;

													// Chamada do método open para processar a requisição
													req.open("Get", url, true); 
													req.setRequestHeader("Cache-Control","no-cache,no-store");
													req.setRequestHeader("Pragma", "no-cache");

													// Quando o objeto recebe o retorno, chamamos a seguinte função;
													req.onreadystatechange = function() {

													// Exibe a mensagem "Buscando Noticias..." enquanto carrega
													if(req.readyState == 1) {
													document.getElementById('bairro').innerHTML = '<option >buscando</option>';
													}

													// Verifica se o Ajax realizou todas as operações corretamente
													if(req.readyState == 4 && req.status == 200) {

													// Resposta retornada pelo busca.php
													var resposta = req.responseText;

													// Abaixo colocamos a(s) resposta(s) na div resultado
													document.getElementById('bairro').innerHTML = resposta;
													}
													}
													req.send(null);
													req.setRequestHeader("Cache-Control", "no-cache");
													req.setRequestHeader("Pragma", "no-cache"); 

													}
													</script>
					
						<div style='width:100%;' align='right'>
						<form action="exporta_excel.php" method="post" onsubmit="target_popup(this)">
							<?$datahoje = date('d/m/Y');?>
							<input type='text' name="htmlform" style='display:none;'value=''id="htmlform"style="width:55px; "/>
							
							<input type="submit" value='Exportar Excel'/> 
						</form>
						
				</td>
				<td><input type='Button' name='filtro' value='&#9778; Filtro'  onclick="toggle('maisinfo');" style='padding:2px ;' /></td>
				<a href="javascript:Impressao( false );">Imprimir</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="javascript:Impressao( true );">Visualizar Impressão</a><br>
 
			</tr>
						
			
			
		</table>
		
		
	<script type="text/javascript">
	<!--
	function toggle(obj) {
		var el = document.getElementById(obj);
		if ( el.style.display != "none" ) {
			el.style.display = 'none';
		}
		else {
			el.style.display = '';
		}
	}
	-->
	
	 $(function() {


                $("#datainicio").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1970:<?= $anofinaldata; ?>',
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'],
                    dayNamesMin: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
                    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
                    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
                    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
                });
				
				 $("#datafinal").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1970:<?= $anofinaldata; ?>',
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'],
                    dayNamesMin: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
                    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
                    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
                    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
                });


            });
			
			 $().ready(function() {
                $("#ocupacao").autocomplete("789/autoComplete.php", {
                    matchContains: true,
                    mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
			});
			
	</script>
		<table width="100%" style='background-color:#002db2;color:#fff;'> 		
			<tr width='200px'>
				<td><?echo date("d/m/Y");?></td>
				<td></td>
				
				<td align='right'><?echo date("H:i:s");?></td>
			</tr>
			
		
		</table>
		
		<div id="maisinfo" style="display:none;width:100%;" align='center'>
		<?if(($lista=="empresa") or ($lista=="totalempresa")){?>
		
		<form action='?lista=<?=$lista;?>' method='post'>
							<table border="1">
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Segmento de atuação&nbsp;</b></font>
										</td>
										<td>
											<select name='segmentoatuacao' style='width:100%' >	
										<option value=''>--</option>											
										
										<?
										$query_noticias_lista_vaga = "SELECT id,nome FROM `segmentoatuacao` ORDER BY `segmentoatuacao`.`nome` ASC ";
										$rs_noticias_lista_vaga    = mysql_query($query_noticias_lista_vaga);							
										while($campo_noticias_lista_vaga = mysql_fetch_array($rs_noticias_lista_vaga)){
										$idseg  	= $campo_noticias_lista_vaga['id'];
										$nomeseg  	= $campo_noticias_lista_vaga['nome'];

										?>							
										
											<option value='<?=$idseg;?>'><?=$nomeseg ;?></option>
										<?}?>


									
									
								</select>
										</td>
									</tr>
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Data de Abertura&nbsp;</b></font>
										</td>
										<td>
											<input type=text name="datainicio" id="datainicio" maxlength=10 onBlur="verificaData('window.document.Ficha.flt_Data_ini');" onKeyUp="VerificaMascara('window.document.Ficha.flt_Data_ini','##/##/####',1)" style="width:55px;" value="">
											&nbsp;até&nbsp;
											<input type=text name="datafinal" id="datafinal" maxlength=10 onBlur="verificaData('window.document.Ficha.flt_Data_fim');" onKeyUp="VerificaMascara('window.document.Ficha.flt_Data_fim','##/##/####',1)" style="width:55px;" value="">
										</td>
									</tr>
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Jovem Aprendiz&nbsp;</b></font>
										</td>
										<td>
											<select name="jovemaprendiz" style="width:90px;">
												<option value="">-X-</option>
												<option value="N">Não</option>
												<option value="S">Sim</option>
											</select>
										</td>
									</tr>
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Estágio&nbsp;</b></font>
										</td>
										<td>
											<select name="estagios" style="width:90px;">
												<option value="">-X-</option>
												<option value="N">Não</option>
												<option value="S">Sim</option>
											</select>
										</td>
									</tr>
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Conta CPD&nbsp;</b></font>
										</td>
										<td>
											<select name="contapcd" style="width:90px;">
												<option value="">-X-</option>
												<option value="N">Não</option>
												<option value="S">Sim</option>
											</select>
										</td>
									</tr>
									
									
									
									<tr>
										<td bgcolor="#000080" colspan="2" align="center">
											<input type="submit" name="btBuscar"  value=" Buscar ">											
										</td>
									</tr>
								</table>
								<input type="hidden" name="acao"  value="post">
				<form>
		
		<?}else{?>
				<form action='?lista=<?=$lista;?>' method='post'>
							<table border="1">
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Id&nbsp;</b></font>
										</td>
										<td>
											<input type="Text" name="id" style="width:200px;" value="">
										</td>
									</tr>
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Cargo&nbsp;</b></font>
										</td>
										<td>
											<input type="Text" name="ocupacao" id="ocupacao"style="width:200px;" value="">
										</td>
									</tr>
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Descrição&nbsp;</b></font>
										</td>
										<td>
											<input type="Text" name="descricao" style="width:200px;" value="">
										</td>
									</tr>
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Data de Abertura&nbsp;</b></font>
										</td>
										<td>
											<input type=text name="datainicio" id="datainicio" maxlength=10 onBlur="verificaData('window.document.Ficha.flt_Data_ini');" onKeyUp="VerificaMascara('window.document.Ficha.flt_Data_ini','##/##/####',1)" style="width:55px;" value="">
											&nbsp;até&nbsp;
											<input type=text name="datafinal" id="datafinal" maxlength=10 onBlur="verificaData('window.document.Ficha.flt_Data_fim');" onKeyUp="VerificaMascara('window.document.Ficha.flt_Data_fim','##/##/####',1)" style="width:55px;" value="">
										</td>
									</tr>
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Aceita SEM Experiência&nbsp;</b></font>
										</td>
										<td>
											<select name="semexperiencia" style="width:90px;">
												<option value="">-X-</option>
												<option value="N">Não</option>
												<option value="S">Sim</option>
											</select>
										</td>
									</tr>
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Empresa&nbsp;</b></font>
										</td>
										<td>
										<select name='empresaid' style='width:100%' >	
										<option value="">Selecione</option>
										<?
										$query_noticias_lista_vaga_empresa = "SELECT empresaid  FROM `vaga` GROUP BY  empresaid ASC ";
										$rs_noticias_lista_vaga_empresa      = mysql_query($query_noticias_lista_vaga_empresa );							
										while($campo_noticias_lista_vaga_empresa  = mysql_fetch_array($rs_noticias_lista_vaga_empresa )){
										$empresaid_empresavaga  	= $campo_noticias_lista_vaga_empresa ['empresaid'];										
									
												$query_noticiasempresavaga= "SELECT nome,id FROM `empresa` where id='$empresaid_empresavaga'";	
												$rs_noticias2e_empresavaga     = mysql_query($query_noticiasempresavaga); 													
												while($campo_noticias2e_empresavaga = mysql_fetch_array($rs_noticias2e_empresavaga )){
												$nome_empresa_bd_empresavaga = $campo_noticias2e_empresavaga ['nome']; 	
												$id_empresa_bd_empresavaga = $campo_noticias2e_empresavaga ['id']; 	
										?>
									
										<option value='<?=$id_empresa_bd_empresavaga;?>'><?=$nome_empresa_bd_empresavaga ;?></option>
										<?}}?>
									
								</select>
										</td>
									</tr>
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Segmento de atuação&nbsp;</b></font>
										</td>
										<td>
											<select name='segmentoatuacao' style='width:100%' >	
										<option value=''>--</option>											
										
										<?
										$query_noticias_lista_vaga = "SELECT id,nome FROM `segmentoatuacao` ORDER BY `segmentoatuacao`.`nome` ASC ";
										$rs_noticias_lista_vaga    = mysql_query($query_noticias_lista_vaga);							
										while($campo_noticias_lista_vaga = mysql_fetch_array($rs_noticias_lista_vaga)){
										$idseg  	= $campo_noticias_lista_vaga['id'];
										$nomeseg  	= $campo_noticias_lista_vaga['nome'];

										?>							
										
											<option value='<?=$idseg;?>'><?=$nomeseg ;?></option>
										<?}?>


									
									
								</select>
										</td>
									</tr>
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Gênero&nbsp;</b></font>
										</td>
										<td>
											<select name="sexo" style="width:90px;">
												<option value="">Selecione</option>
												<option value="A">Ambos</option>
												<option value="M">Masculino</option>
												<option value="F">Feminino</option>
											</select>
										</td>
									</tr>
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Escolaridade&nbsp;</b></font>
										</td>
										<td>
											<select name="escolaridade" style="width:90px;">
												<option value="">Selecione</option>
												<option value="F">Fundamental</option>
												<option value="M">Médio</option>
												<option value="P">Pós-Médio</option>
												<option value="S">Superior</option>
											</select>
										</td>
									</tr>
									<?if(($lista=="listaencaminhamento") or ($lista=="totalemcaminhamento") or ($lista=="totalcadastro")){?>
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Atendente&nbsp;</b></font>
										</td>
										<td>
										<select name='atendente' style='width:100%' >	
										<option value="">Selecione</option>
										<option value=''>Todos</option>
										<?
										$query_noticias_lista_vaga_empresap = "SELECT usuarioid  FROM `encaminhamento` GROUP BY  usuarioid ASC ";
										$rs_noticias_lista_vaga_empresap      = mysql_query($query_noticias_lista_vaga_empresap );							
										while($campo_noticias_lista_vaga_empresap  = mysql_fetch_array($rs_noticias_lista_vaga_empresap )){
										$usuarioidform  	= $campo_noticias_lista_vaga_empresap ['usuarioid'];										
									
												$query_noticiasempresavagau= "SELECT id,nome FROM `usuario` where id='$usuarioidform'";	
												$rs_noticias2e_empresavagau     = mysql_query($query_noticiasempresavagau); 													
												while($campo_noticias2e_empresavagau = mysql_fetch_array($rs_noticias2e_empresavagau )){
												$usuarioformenome = $campo_noticias2e_empresavagau ['nome']; 	
												$idusuarioform = $campo_noticias2e_empresavagau ['id']; 	
										?>
									
										<option value='<?=$idusuarioform;?>'><?=$usuarioformenome ;?></option>
										<?}}?>
									
								</select>
										</td>
									</tr>
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Estado&nbsp;</b></font>
										</td>
										<td>
											<select name="estado" style="width:90px;" onchange="busca_cidade(this.value);">
												<option value="">-X-</option>
												<?
												$query_noticias_estado = "SELECT *  FROM  `uf` ORDER BY  `uf`.`uf` ASC ";
												$rs_noticias_estado    = mysql_query($query_noticias_estado);
												while($campo_noticias_estado = mysql_fetch_array($rs_noticias_estado)){		
												$iduf 	= $campo_noticias_estado['id']; 
												$nome_uf 	= $campo_noticias_estado['uf']; 
												
												?>
												<option value='<?=$iduf;?>'><?=$nome_uf ;?></option>			
												<?}?>
											</select>
										</td>
									</tr>
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Cidade&nbsp;</b></font>
										</td>
										<td>
											<select name="cidade"  id="cidade"  onchange="busca_bairro(this.value);" >
													<option value="">-X-</option>
											</select>
										</td>
									</tr>
									
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Bairro&nbsp;</b></font>
										</td>
										<td>
											<select name="bairro"  id="bairro"  >
													<option value="">-X-</option>
											</select>
										</td>
									</tr>


									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Conta PCD&nbsp;</b></font>
										</td>
										<td>
											<select name="contapcd" style="width:90px;">
												<option value="">-X-</option>
												<option value="N">Não</option>
												<option value="S">Sim</option>
											</select>
										</td>
									</tr>
									
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Idade&nbsp;</b></font>
										</td>
										<td>
											<select name="idade" style="width:90px;" >
											
											
												<option value="">-X-</option>
												<?
												$query_noticias_idade = "SELECT datanascimento FROM  `trabalhador` GROUP BY YEAR( datanascimento ) DESC ";
												$rs_noticias_idade    = mysql_query($query_noticias_idade);
												while($campo_noticias_idade = mysql_fetch_array($rs_noticias_idade)){		
												$datanascimentosql	= $campo_noticias_idade['datanascimento']; 
												// Aqui você separa esta em um Array
												$arrayData = explode("-",$datanascimentosql);

												// Imprimindo os dados:
												//echo "ano".$arrayData[0];
												//echo "<br>mes: ".$arrayData[1];
												//echo "<br>dia: ".$arrayData[2];												
										
												$datahjna= date("Y");
												$idadetrabalhado= $datahjna - $arrayData[0] ;
										

										 // 110 Anos, 2 Meses e 2 Dias
																			
												if(($idadetrabalhado > 11) && ($idadetrabalhado < 99)){
												?>
												<option value='<?=$arrayData[0];?>'><?=$idadetrabalhado;?></option>			
									<?}}?>
									
											</select>
										</td>
									</tr>
									
									
										<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Status&nbsp;</b></font>
										</td>
										<td>
										<select name='statusencaminhamento' style='width:100%' >	
										<option value="">Selecione</option>
										<option value=''>Todos</option>
										<?
										$query_noticias_lista_vaga_empresapstatus = "SELECT status from `encaminhamento` GROUP BY  status ASC ";
										$rs_noticias_lista_vaga_empresapstatus      = mysql_query($query_noticias_lista_vaga_empresapstatus );							
										while($campo_noticias_lista_vaga_empresapstatus  = mysql_fetch_array($rs_noticias_lista_vaga_empresapstatus )){
										$status_encaminhamento  	= $campo_noticias_lista_vaga_empresapstatus ['status'];										
										
										
										switch ($status_encaminhamento){										
												case "E":											
												$status_encaminhamento_N = "Encaminhado";
												break;

												case "I":											
												$status_encaminhamento_N = "Inserido";
												break;
												
												case "N":											
												$status_encaminhamento_N = "Não Inserido";
												break;
												
												}
										?>
										
											
									
										<option value='<?=$status_encaminhamento;?>'><?=$status_encaminhamento_N ;?></option>
										<?}?>
									
								</select>
										</td>
									</tr>
									
									
									<?}if(($lista=="interno") or ($lista=="vagastotal") or($lista="vagastotal_seguimento")){?>
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Conta CPD&nbsp;</b></font>
										</td>
										<td>
											<select name="contapcd" style="width:90px;">
												<option value="">-X-</option>
												<option value="N">Não</option>
												<option value="S">Sim</option>
											</select>
										</td>
									</tr>
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Status&nbsp;</b></font>
										</td>
										<td>
											<select name='status' style='width:100%' >										
										
										<?
										$query_noticias_lista_vaga = "SELECT status  FROM `vaga` GROUP BY  status ASC ";
										$rs_noticias_lista_vaga    = mysql_query($query_noticias_lista_vaga);							
										while($campo_noticias_lista_vaga = mysql_fetch_array($rs_noticias_lista_vaga)){
										$status_lista_vaga  	= $campo_noticias_lista_vaga['status'];

										?>							
										<?
										switch ($status_lista_vaga){										
												case "A":											
												$status_N = "Ativa";
												break;case "S":											
												$status_N = "Suspensa";
												break;case "P":											
												$status_N = "Preenchida pelo CTM";
												break;case "O":											
												$status_N = "Preenchida pelo Solicitante";
												break;case "C":											
												$status_N = "Cancelada";
												break;case "E":											
												$status_N = "Encerrada";
												break;case "R":											
												$status_N = "Aguardando Resposta";
												break;case "N":											
												$status_N = "Sem retorno ";						
												break;case "G":											
												$status_N = "Sigilosa";
												break;
												}
												?>
											<option value='<?=$status_lista_vaga;?>'><?=$status_N ;?></option>
										<?}?>
											<option value=''>Todos Status</option>

									
									
								</select>
										</td>
									</tr>
									<?}?>
									<input type="hidden" name="acao"  value="post"/>
									<tr>
										<td bgcolor="#000080" colspan="2" align="center">
											<input type="submit" name="btBuscar"  value=" Buscar ">											
										</td>
									</tr>
								</table>
								
				<form>				
				<?}?>
		</div>
		
		
		<?
				$get_acao= $_POST['acao'];
				$post_status= $_POST['status'];			
				$post_escolaridade= $_POST['escolaridade'];
				$post_sexo= $_POST['sexo'];				
				$post_datainicio= $_POST['datainicio'];
				$post_datafinal= $_POST['datafinal'];
				$post_semexperiencia= $_POST['semexperiencia'];
				$post_descricao= $_POST['descricao'];
				$post_ocupacao= $_POST['ocupacao'];
				$post_id= $_POST['id'];
				$post_atendente= $_POST['atendente'];
				$empresaid= $_POST['empresaid'];
				
				
				$post_segmentoatuacao= $_POST['segmentoatuacao'];
				$post_jovemaprendiz= $_POST['jovemaprendiz'];
				$post_estagios= $_POST['estagios'];
				$post_contapcd= $_POST['contapcd'];
				$post_estado= $_POST['estado'];
				$post_cidade= $_POST['cidade'];
				$post_bairro= $_POST['bairro'];
				$post_idade= $_POST['idade'];
				$post_statusencaminhamento= $_POST['statusencaminhamento'];
				
				
				
		
		?>
	