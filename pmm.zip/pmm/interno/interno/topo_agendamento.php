		<table width="100%" style='background-color:#fff;'>
			<tr >
				<td><img src='../img/LogoSecretaria.png' width='200px'></td>
				<td>DIVULGAÇÃO DE VAGAS<br><a href='?lista=<?=$lista;?>&exporta=excel'><img src='../img/excel.jpg' width='40px'/></a></td>
				<td><input type='Button' name='filtro' value='&#9778; Filtro'  onclick="toggle('maisinfo');" style='padding:2px ;' /></td>
							
			</tr>
						
			
			
		</table>
		
		
	<script type="text/javascript">
	<!--
	function toggle(obj) {
		var el = document.getElementById(obj);
		if ( el.style.display != "none" ) {
			el.style.display = 'none';
		}
		else {
			el.style.display = '';
		}
	}
	-->
	
	 $(function() {


                $("#datainicio").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1970:<?= $anofinaldata; ?>',
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'],
                    dayNamesMin: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
                    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
                    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
                    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
                });
				
				 $("#datafinal").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1970:<?= $anofinaldata; ?>',
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'],
                    dayNamesMin: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
                    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
                    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
                    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
                });


            });
			
			 $().ready(function() {
                $("#ocupacao").autocomplete("789/autoComplete.php", {
                    matchContains: true,
                    mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
			});
			
	</script>
		<table width="100%" style='background-color:#002db2;color:#fff;'> 		
			<tr width='200px'>
				<td><?echo date("d/m/Y");?></td>
				<td></td>
				
				<td align='right'><?echo date("H:i:s");?></td>
			</tr>
			
		
		</table>
		
		<div id="maisinfo" style="display:none;width:100%;" align='center'>
		
		
		<form action='realtorio_agendamento.php' method='post'>
							<table border="1">
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Informe Mês / ano &nbsp;</b></font>
										</td>
										<td>
											<select name="mesbuscadata">
												<option value="">--</option>
												<option value="1">01</option>
												<option value="2">02</option>
												<option value="3">03</option>
												<option value="4">04</option>
												<option value="5">05</option>
												<option value="6">06</option>
												<option value="7">07</option>
												<option value="8">08</option>
												<option value="9">09</option>
												<option value="10">10</option>
												<option value="11">11</option>
												<option value="12">12</option>
											</select>
											&nbsp;até&nbsp;
											<select name="anobuscadata">
												<option value="">--</option>
												<option value="2015">2015</option>
												<option value="2016">2016</option>												
												<option value="2017">2017</option>
												<option value="2018">2018</option>											</select>
										</td>
									</tr>
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Tipo&nbsp;</b></font>
										</td>
										<td>
											<select name="tipo" style="width:90px;">
												<option value="">Selecione</option>
												<option value="D">DETRAN</option>
												<option value="V">VAGAS DE EMPREGO</option>
												<option value="C">CTPS</option>												
											</select>
										</td>
									</tr>
									
									
									
						
				
		
								
									
									<tr>
										<td bgcolor="#000080" colspan="2" align="center">
											<input type="submit" name="btBuscar"  value=" Buscar ">		
										<button onClick="window.location.reload();">Limpar filtro</button>											
										</td>
									</tr>
								</table>
								<input type="hidden" name="acao"  value="post">
				<form>				
				
		</div>
		
		<?
				$get_acao= $_POST['acao'];
				
				$post_datainicio= $_POST['datainicio'];
			$post_datafinal= $_POST['datafinal'];
			
			if($post_datainicio==""){
				
				$post_datainicio= date("j/n/Y");
				
			}
				
							
				
				$tipo= $_POST['tipo'];
				
				
				
				
		
		?>
	