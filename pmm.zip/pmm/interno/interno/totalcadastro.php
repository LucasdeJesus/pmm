	<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	
	
	
	?>
	
	
		
					<?
						
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			
			
						if($get_acao==""){$limit="limit 100";}else{$limit="";};
						
						//if($post_status==""){$sqlostatus="`status` IN ('A','S','C','P','E','N','I','R','O')";}else{$sqlostatus=" status='$post_status'  ";}
						if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
						if($post_descricao==""){}else{$sqldescricao="and `descricao` LIKE '%$post_descricao%' ";}				
						if($post_escolaridade==""){}else{$sqloescolaridade="and escolaridade='$post_escolaridade' ";}
						if($post_sexo==""){}else{$sqlsexo="and sexo IN ('$post_sexo') ";}
						if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
						if($post_id==""){}else{$sqlid="and id='$post_id' ";}
						if($post_atendente==""){}else{$sqlatendente="and usuarioid='$post_atendente' ";}
						if($empresaid==""){}else{$sqlempresaid="and empresaid='$empresaid' ";}
						if($post_contapcd==""){}else{$sqlcontacpd="and `vagadeficiente` = '$post_contapcd' ";}	
						//if($post_estado==""){}else{$sqlcontacpd="and `estado` = '$post_estado' ";}	
						if($post_bairro==""){}else{$sqlbairro="and  `bairro` LIKE '%$post_bairro%' ";}	
						if($post_cidade==""){}else{$sqlcidade="and `cidadeid` = '$post_cidade' ";}	
						if($post_idade==""){}else{$sql2data="and `datanascimento` LIKE '%$post_idade%' ";}

								if($_POST['acao']==""){$post_datainicio= date('d/m/Y');}else{};
						
						$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
						$post_datafinal1 = implode("-",array_reverse(explode("/",$post_datafinal)));
						
						
						if(($post_datainicio=="") || ($post_datafinal==""))
						{
							if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
							if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
							
						
						}
						else
						
						{
							$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1))); // 15/03/2006
								$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
						}
						
																		
													
						
										
											
						$query_noticias = "SELECT *  FROM `trabalhador` where id > 0   
										".$sqlostatus."				
										".$sqlcargo."				
										".$sqldescricao."				
										".$sqloescolaridade."				
										".$sqlsexo."				
										".$sqlaceitasemexperiencia."				
										".$sqlid."				
										".$sqlempresaid."
										".$sqlcontacpd."										
										".$sqlcidade."										
										".$sqlbairro."										
										".$sql2data."";
						$rs_noticiasceu1    = mysql_query($query_noticias);
						$total = mysql_num_rows($rs_noticiasceu1);	
						//echo $query_noticias;
						while($campo_noticiasceu1 = mysql_fetch_array($rs_noticiasceu1)){	
						$usuarioid11	= $campo_noticiasceu1['usuarioid'];						
										
										
						
							}
									
													?>
													
													
												<div id="getexcel">	
													
													<table border="1" width="500px"  class="sortable">
													
														
														<tr width='50%'>
															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;<?=$nomeat;?>&nbsp;</b></font>
														    </td>

														
														
														
																<td class='td2' width='50%'> <?=$totalencaminhamento;?> </td>	
																		
													
											
											</tr>
											</table>
	

							
	

<table border="1" width="500px"  class="sortable">			
			<tr width='50%'>
				<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
				<font color="#ffffff" face="Tahoma"><b>&nbsp;Total&nbsp;</b></font>
				</td>

				<td class='td2' width='50%'> <?=$total;?> </td>
			</tr>
</table>	
							
			
