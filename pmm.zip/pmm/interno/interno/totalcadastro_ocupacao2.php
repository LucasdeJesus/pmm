	
	<?
	include"../input_banco.php";
	
ini_set('default_charset','UTF-8'); // Para o charset das páginas e
mysql_set_charset('utf8'); // para a conexão com o MySQL


	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	
	
	
	?>
	<script src="../js/sorttable.js"></script>
	<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

	
		
					<?
						
						
													
					
									
													?>
													
													
												<div id="getexcel">	
													
													<table border="1" width="100%"  class="sortable">
													
													
													<tr >
														<td class='td2' width='50px%'>
															&nbsp;OR&nbsp;
														    </td>
															
															<td class='td2' width='20ppx'>
															&nbsp;NOME&nbsp;
														    </td>	
																<td class='td2' width='50%'>OCUPAÇÕES </td>	
																<td class='td2' width='80px'> IDADE</td>	
																<td class='td2' width='300pz'> ESCOLARIDADE</td>	
														</tr>
													
													<?
													
																function calcula_idade($data_nascimento, $data_calcula)
																{
																// as datas devem ser no formato aaaa-mm-dd

																//conversão das datas para o formato de tempo linux
																$data_nascimento = strtotime($data_nascimento." 00:00:00");
																$data_calcula = strtotime($data_calcula." 00:00:00");

																//cálculo da idade fazendo a diferença entre as duas datas
																$idade = floor(abs($data_calcula-$data_nascimento)/60/60/24/365);

																return($idade);
																}
		
														
										
													$or = 1;
													$query_noticias = "SELECT id,nome,datanascimento,cboid1,cboid2,cboid3 FROM `trabalhador` where id > 0   
																	".$sqlostatus."				
																	".$sqlcargo."				
																	".$sqldescricao."				
																	".$sqloescolaridade."				
																	".$sqlsexo."				
																	".$sqlaceitasemexperiencia."				
																	".$sqlid."				
																	".$sqlempresaid."
																	".$sqlcontacpd."										
																	".$sqlcidade."										
																	".$sqlbairro."										
																	".$sql2data."";
													$rs_noticiasceu1    = mysql_query($query_noticias);
													$total = mysql_num_rows($rs_noticiasceu1);	
													//echo $query_noticias;
													while($campo_noticiasceu1 = mysql_fetch_array($rs_noticiasceu1)){	
													$usuarioid11	= $campo_noticiasceu1['usuarioid'];						
													$nome	= $campo_noticiasceu1['nome'];						
													$datanascimento	= $campo_noticiasceu1['datanascimento'];						
													$cboid1	= $campo_noticiasceu1['cboid1'];						
													$cboid2	= $campo_noticiasceu1['cboid2'];						
													$cboid3	= $campo_noticiasceu1['cboid3'];						
													$id	= $campo_noticiasceu1['id'];						
																		
															
															
													if( $cboid1 > 0){
													$query_cboid1 = "SELECT * FROM `cbo` where id='$cboid1' ";
													$rs_cboid1    = mysql_query($query_cboid1 );
													while($campo_cboid1  = mysql_fetch_array($rs_cboid1)){
													$cbo1        = $campo_cboid1 ['cbo'];
													}
													}

													if( $cboid2 > 0){
													$query_cboid2 = "SELECT * FROM `cbo` where id='$cboid2' ";
													$rs_cboid2     = mysql_query($query_cboid2 );
													while($campo_cboid2  = mysql_fetch_array($rs_cboid2 )){
													$cbo2        = $campo_cboid2 ['cbo'];
													}
													}
													if( $cboid3 > 0){
													$query_cboid3 = "SELECT * FROM `cbo` where id='$cboid3' ";
													$rs_cboid3    = mysql_query($query_cboid3 );
													while($campo_cboid3  = mysql_fetch_array($rs_cboid3)){
													$cbo3        = $campo_cboid3 ['cbo'];
													}
													}
																		
													
													?>
														
														<tr  title="<?=$id;?>">
														<td class='td2'  >
															&nbsp;<?=$or++;?>&nbsp;
														    </td>
															
															<td class='td2' >
															&nbsp;<?=$nome;?>&nbsp;
														    </td>	
																<td class='td2' > <?=$cbo1;?> <br>  <?	if( $cboid2 > 0){ echo $cbo2; }?> <br> <?	if( $cboid3 > 0){echo $cbo3;}?> </td>	
																<td class='td2'><?echo calcula_idade("$datanascimento",date("Y-m-d"))." anos";?></td>	
																<td class='td2' >
																
																
																<!--------------------------------------------------------------------->
																<table>	

																	<?
																	//$query_noticias_hcp = "SELECT * FROM `escolaridade` WHERE trabalhadorid ='$id_trabalhafo_get' ";
																	$query_noticias_hcp ="SELECT DISTINCT * FROM escolaridade where trabalhadorid ='$id' ";
																	$rs_noticias_hcp    = mysql_query($query_noticias_hcp);
																	
																	while($campo_noticias_hcp = mysql_fetch_array($rs_noticias_hcp)){
															
																	$escolaridade 	= $campo_noticias_hcp['escolaridade']; 		
																	$serie = $campo_noticias_hcp['serie'];
																	$formacaoacademicaid = $campo_noticias_hcp['formacaoacademicaid'];
																	$comprovacao	 = $campo_noticias_hcp['comprovacao'];																	
																

																	?>


																	<?
																	switch ($serie){		
																	case"1":$serie_N="1º ANO";break;
																	case"2":$serie_N="2º ANO";break;
																	case"3":$serie_N="3º ANO";break;
																	case"4":$serie_N="4º ANO";break;
																	case"5":$serie_N="5º ANO";break;
																	case"6":$serie_N="6º ANO";break;
																	case"7":$serie_N="7º ANO";break;
																	case"8":$serie_N="8º ANO";break;
																	case"9":$serie_N="9º ANO";break;
																	case"C1":$serie_N="CICLO I - ALFA";break;
																	case"C2":$serie_N="CICLO II - 1ª E 2ª";break;
																	case"C3":$serie_N="CICLO III - 3ª E 4ª";break;
																	case"C4":$serie_N="CICLO IV - 5ª E 6ª";break;
																	case"C5":$serie_N="CICLO V - 7ª E 8ª";break;
																	case"F":$serie_N="ED. ESP. ENS. FUND.";break;
																	case"I":$serie_N="ED. ESP. ENS. INF.";break;
																	case"J1":$serie_N="EJA - ENS.MED - 1ª ANO";break;
																	case"J2":$serie_N="EJA - ENS.MED - 2º ANO";break;
																	case"J3":$serie_N="EJA - ENS.MED - 3º ANO";break;
																	case"M1":$serie_N="ENS.MED - 1º ANO";break;
																	case"M2":$serie_N="ENS.MED - 2º ANO";break;
																	case"M3":$serie_N="ENS.MED - 3º ANO";break;
																	case"A1":$serie_N="MATERNAL I";break;
																	case"A2":$serie_N="MATERNAL II";break;
																	case"P1":$serie_N="PRÉ I";break;
																	case"P2":$serie_N="PRÉ II";break;

																	}

																	?>
																	<?
																	switch ($escolaridade){										
																	case "N":											
																	$escolaridade_N = "Analfabeto";
																	break;
																	case "A":											
																	$escolaridade_N = "Alfabetizado";
																	break;
																	case "F":											
																	$escolaridade_N = "Fundamental";
																	break;
																	case "M":											
																	$escolaridade_N = "Médio";
																	break;
																	case "P":											
																	$escolaridade_N = "Pós-Médio";
																	break;
																	case "S":											
																	$escolaridade_N = "Superior";
																	break;
																	case "G":											
																	$escolaridade_N = "Pós-Graduação";
																	break;
																	case "E":											
																	$escolaridade_N = "Mestrado";
																	break;
																	case "D":											
																	$escolaridade_N = "Doutorado";
																	break;
																	}
																	?>

																	<tr  >

																	<td  width='205px'> <?=$escolaridade_N;?> </td>
																	
																	
																	<?if($formacaoacademicaid > 0){?>

																	<?
																	$query_formacaoacademica_db = "SELECT * FROM `formacaoacademica` WHERE id='$formacaoacademicaid' ";
																	$rs_formacaoacademica_db    = mysql_query($query_formacaoacademica_db);
																	while($campo_formacaoacademica_db = mysql_fetch_array($rs_formacaoacademica_db)){
																	$nome_formacaoacademica_db 	= $campo_formacaoacademica_db['nome']; 	
																	$id_formacaoacademica_db 	= $campo_formacaoacademica_db['id']; 	
																	?><?}?>
																	<td width='221px'> <?=$nome_formacaoacademica_db;?> </td>


																	
																	</tr>

																	<?}?>
																	<?}?>
																</table>	
																<!--------------------------------------------------------------------->
																</td>	
														</tr>
														
												<?}?>
											</table>
	

							
	

<table border="1" width="500px"  class="sortable">			
			<tr width='50%'>
				<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
				<font color="#ffffff" face="Tahoma"><b>&nbsp;Total&nbsp;</b></font>
				</td>

				<td class='td2' width='50%'> <?=$total;?> </td>
			</tr>
</table>	
							
			
