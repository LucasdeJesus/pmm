<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_POST ['acao'];
	if($exporta=="post")
	{
	$arquivo = "relatorio.xls";
header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header ("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
header ("Cache-Control: no-cache, must-revalidate");
header ("Pragma: no-cache");
header ("Content-type: application/x-m---cel");
header ("Content-Disposition: attachment; filename=\"{$arquivo}\"" );
header ("Content-Description: PHP Generated Data" );
	?>
	
	<?
	}else{}
	

	
	?>
	
<script type="text/javascript"> 
	
	$(document).ready(function(){
	      $('#mostra').click(function(){
			//mostra div
		  	$('#divMostra').show();
		  		
	      });
	      $('#fecha').click(function(){
			//oculta div
		  	$('#divMostra').hide();
		  		
	      });
	 });
     
</script>
	

<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>
	<style>
	.text_azul{color:blue;}
	span{line-height:130%;}
	</style>
	
		<?
						
				
				//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
				if($post_status==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='$post_status'  ";}
				if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
				if($post_descricao==""){}else{$sqldescricao="and `descricao` LIKE '%$post_descricao%' ";}				
				if($post_escolaridade==""){}else{$sqloescolaridade="and escolaridade='$post_escolaridade' ";}
				if($post_sexo==""){}else{$sqlsexo="and sexo IN ('$post_sexo','A') ";}
				if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
				if($post_id==""){}else{$sqlid="and id='$post_id' ";}
				if($empresaid==""){}else{$sqlempresaid="and empresaid='$empresaid' ";}
				if($post_segmentoatuacao==""){}else{$sqlsegmentoatuacao="and segmentoatuacaoid='$post_segmentoatuacao' ";}
				if($post_contapcd==""){}else{$sqlcontacpd="and `vagadeficiente` = '$post_contapcd' ";}	
				if($_POST['acao']==""){$post_datainicio= date('d/m/Y');}else{};
				
				
				$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
				$post_datafinal1 = implode("-",array_reverse(explode("/",$post_datafinal)));
						
				
				if(($post_datainicio=="") || ($post_datafinal==""))
				{
					if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
					if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
					
				
				}
				else{
				$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1))); // 15/03/2006
				$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
				}
				
				if($post_status =="" ){$statusvaga="`status` IN ( 'A',  'S',  'C',  'P',  'E',  'R',  'N',  'O',  'I',  'T')";}else{$statusvaga="status='$post_status'";}
				
		
		
			?>
		

			
						
							
<div id="getexcel">
			
	
	
		
	
		
		


		
<table border="1" width="500px" class="sortable" align='left'>

	
			<?
				
				$totaldorelatorio=0;
				$total_vaga_seguimento=0;
				
				$query_lista_vagas_seg = "SELECT id,nome FROM `segmentoatuacao` ORDER BY `segmentoatuacao`.`nome` ASC ";
												$rs_noticias_lista_vagas_seg   = mysql_query($query_lista_vagas_seg);							
												while($campo_noticias_lista_vagas_seg = mysql_fetch_array($rs_noticias_lista_vagas_seg)){
												$idseguimento  	= $campo_noticias_lista_vagas_seg['id'];
												$nomeseguimento  	= $campo_noticias_lista_vagas_seg['nome'];
												
									
												$totalG=0;
												$query_empresa_s= "SELECT id FROM `empresa` where  segmentoatuacaoid='$idseguimento'  ";
												$rs_noticias_empresa_s  = mysql_query($query_empresa_s);							
												while($campo_noticias_empresa_s = mysql_fetch_array($rs_noticias_empresa_s)){
												$id_empresa_seguimento  	= $campo_noticias_empresa_s['id'];
												
													
													$query_noticiasA = "SELECT *  FROM `vaga` where $statusvaga and empresaid='$id_empresa_seguimento'  ".$sqlcargo."				
														".$sqldescricao."				
														".$sqloescolaridade."				
														".$sqlsexo."				
														".$sqlaceitasemexperiencia."				
														".$sqlid."				
														".$sqlempresaid."	
														".$sqlcontacpd."	
														".$sql2data." ";
													$rs_noticiasA    = mysql_query($query_noticiasA); 
													$totalvagasseguimento = mysql_num_rows($rs_noticiasA);												
													while($campo_ocupacaoG  = mysql_fetch_array($rs_noticiasA )){
													$quantidadedisponivelG        = $campo_ocupacaoG ['quantidadedisponivel'];
													$totalG+="$quantidadedisponivelG";
													}
					
												}
					
			$totaldorelatorio+="$totalG";
			?>	
	
	
					<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	


					<td bgcolor="#000080" align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')" width='50%'>
					<font color="#ffffff" face="Tahoma"><b><?=$nomeseguimento;?></b></font>
					</td>

					<td  align="center" id="trCab8" class='td2'  width='50%'>
					<span color="#000" face="Tahoma"><b><?=$totalG;?></b></span>		</td>	

					<td  align="center" id="trCab8" class='td2'  width='50%'>
					<span color="#000" face="Tahoma"><b>
					<?
					$pi= (($totalG / $totaldorelatorio) * 100);
					echo number_format($pi, 1) ."%".""; 
					?>
					</b></span>
					</td>

					</tr>

		<?}?>
		
		<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	


					<td bgcolor="#000080" align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')" width='50%'>
					<font color="#ffffff" face="Tahoma"><b>Total</b></font>
					</td>

					<td  align="center" id="trCab8" class='td2'  width='50%'>
					<span color="#000" face="Tahoma"><b><?=$totaldorelatorio;?></b></span>		</td>	



		</tr>
					
	
	</table>
	
	</div>