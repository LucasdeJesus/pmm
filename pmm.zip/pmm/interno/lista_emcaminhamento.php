<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);


		
		$id = $_GET['id'];
		
		$numeo_j=1;
		$query_noticias_hcpj = "SELECT * FROM `encaminhamento`  WHERE trabalhadorid ='$id' ORDER BY `encaminhamento`.`id` DESC";
		
		$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
		while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){		
		
		$id_vaga_encamaajax  = $campo_noticias_hcpj['id'];
		$id_vaga_ajax  = $campo_noticias_hcpj['vagaid'];
		$selStatus_ajax  = $campo_noticias_hcpj['status'];
		$id_usuario_ajax  = $campo_noticias_hcpj['usuarioid'];
		
		$obs  = $campo_noticias_hcpj['observacao'];
		$id_emcaminhamento  = $campo_noticias_hcpj['id'];
		$dia_ajax  = $campo_noticias_hcpj['datacadastro'];
		$data_mosta=  date('d/m/Y H:m:s', strtotime($dia_ajax));
		
?>


	<tr class='tr_tb' >
		
		<td class='td2' width='15px'> <?=$numeo_j++;?> </td>
		<td class='td2' width='63px'> <?=$data_mosta;?></td>
			<?
			$sql = "select cargo from vaga where id  ='$id_vaga_ajax'";
			$rsd = mysql_query($sql);
			while($rs = mysql_fetch_array($rsd)) {
			
			$cargo = $rs['cargo'];
			
			}
			
			
			

			?>
		
		<td class='td2' width='214px'>  ID vaga <b><?=$id_vaga_ajax ;?></b><br> ID Enc.: <b><?=$id_vaga_encamaajax;?></b></td>				
		<td class='td2' width='214px'>  <?=$cargo;?></td>				
		<td class='td2' width='210px'>  <?=$obs;?></td>	

			<?
			$sql3 = "select nome  from usuario where id  ='$id_usuario_ajax'";
			$rsd3 = mysql_query($sql3);
			while($rs3 = mysql_fetch_array($rsd3)) {
			$usuario_ajax = $rs3['nome'];
			
			}

			?>
			
			
		<td class='td2' width='110px'>  <?=$usuario_ajax;?></td>
					<?
					switch ($selStatus_ajax ){										
					case "E":											
					$selStatus_ajax_N = "Encaminhado";
					break;

					case "I":											
					$selStatus_ajax_N = "Inserido";
					break;
					
					case "N":											
					$selStatus_ajax_N = "Não Inserido";
					break;
					}
					?>
				
		<td class='td2' width='110px'> <?=$selStatus_ajax_N ;?></td>				
		<td class='td2' >
		<a href="javascript:Abrir_Pagina('imprimi_emcaminhamento.php?id_trabalhafo_get=<?=$id ;?>&vagaid=<?=$id_vaga_ajax;?>','scrollbars=yes,width=800,height=500')" title='imprimir'><img src='img/icone_impressora.gif'></a>
		<a href="javascript:Abrir_Pagina('altera_encaminhamento.php?idencaminhamento=<?=$id_vaga_encamaajax;?>','scrollbars=yes,width=800,height=500')" title='Editar'><img src='img/editar.jpg'></a>
		<a href="javascript:Abrir_Pagina('lista_vaga_encaminhamento.php?id=<?=$id_vaga_ajax;?>','scrollbars=yes,width=800,height=500')" title='Detalhe da vaga'><img src='img/busca.png'/></a> 
		
		</td>				
</tr>
		<?}?>
	

