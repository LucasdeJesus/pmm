<?
include("../input_banco.php"); // Inclui o arquivo com o sistema de segurança
$data2 = $_GET['data'];
if($data2 ==""){}
	else{
	$pieces = explode("-", $data2);
	$pieces[0]; // ano
	$pieces[1]; // mes
	$pieces[2]; // dia

	$diasoma = $pieces[1] + 1;

	$data = $pieces[0]."-".$diasoma."-".$pieces[2];
	echo "<div style='color:red;'> Data Selecionada: <b>$data</b></div><br><br>";
					$horario="";
					$query_noticias_hcpj = "SELECT * FROM `agendamentoctps` where status='A' and data='$data' ";
					$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
					while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
					$horarioq  = $campo_noticias_hcpj['horario'];	
					$horario.="'$horarioq', ";
					}	
		
			$query_horario = "SELECT * FROM  `horarioatendimento` WHERE  `horario` NOT IN ($horario '0') ";
			$rs_noticias_horario    = mysql_query($query_horario);
			while($campo_noticias_horario = mysql_fetch_array($rs_noticias_horario)){			
			$horario_dipo  = $campo_noticias_horario['horario'];
?>
				<p><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_dipo;?>"> <?=$horario_dipo;?></p>		
<?
			}

}

?>