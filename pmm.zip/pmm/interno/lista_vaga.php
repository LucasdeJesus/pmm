<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener'>


			

			
<form  class="form" style='width:100%;'action='lista_vaga.php'method="GET" >
		<h2>Buscar Vaga</h2>
			<div class="form-row">
			<div class="label">ID Vaga</div>
			<div class="input-container" style='width:546px;'>
                            
                            
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="busca" required id="busca" maxlength="18"  tabindex="1"  style="width:194px;" type="text" class="input req-same">
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="campo" required id="campo" maxlength="18"  value='id' tabindex="1"  style="width:194px;" type="hidden" class="input req-same">
			
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Buscar" type="submit" class="sendBtn" />
			</div>
			</div>
			<a href="cadastro_vagas.php" class="myButton"><img src='img/novo_item.png' />Novo cadastro</a>
</form>			


<form  class="form" style='width:100%;'method="post" >
		<h2>Lista de Vagas</h2>
		
		<?$endereco = $_SERVER ['REQUEST_URI'];;?>
		<a href="<?=$endereco;?>" class="myButton"><img src='img/table_refresh.png' />Atualizar</a> 
	<table style='width:95%;' class="sortable">
			<tr>
				<td class='td1' >N°</td>
				<td class='td1' >ID</td>
				<td class='td1' >Empresa </td>
				<td class='td1' >Ocupação </td>
				<td class='td1'>Qtd. </td>
				<td class='td1'>Encaminhados</td>
				<td class='td1'>Datas</td>
				<td class='td1'>Datas Aguar.</td>
				
				<td class='td1'>Status</td>
				<td   width='120px'>
					<select name='lista_vaga' style='width:100%'  onchange="location = this.options[this.selectedIndex].value;">	
							<option value=''>Filtro</option>
							<?
							$query_noticias_lista_vaga = "SELECT status  FROM `vaga` GROUP BY  status ASC ";
							$rs_noticias_lista_vaga    = mysql_query($query_noticias_lista_vaga);							
							while($campo_noticias_lista_vaga = mysql_fetch_array($rs_noticias_lista_vaga)){
							$status_lista_vaga  	= $campo_noticias_lista_vaga['status']; 

							?>
							
							<?
						switch ($status_lista_vaga){										
						case "A":											
						$status_N = "Ativa";
						break;case "S":											
						$status_N = "Suspensa";
						break;case "P":											
						$status_N = "Preenchida pelo CTM";
						break;case "O":											
						$status_N = "Preenchida pelo Solicitante";
						break;case "C":											
						$status_N = "Cancelada";
						break;case "E":											
						$status_N = "Encerrada";
						break;case "R":											
						$status_N = "Aguardando Resposta";
						break;case "N":											
						$status_N = "Sem retorno ";						
						break;case "G":											
						$status_N = "Sigilosa";
						break;
						case "T":											
						$status_N = "Sem Retorno";
						break;
						}
					?>
						
						
						<option value='lista_vaga.php?status=<?=$status_lista_vaga;?>'><?=$status_N ;?></option>
						<?}?>
													<option value='lista_vaga.php?status=todas'>Todas</option>

						
						
					</select>
				</td>
				
						
			</tr>
			
						<?
						$busca_cnpj1 = $_GET['busca'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			$numero=1;
			
			if($campo==""){
			
				if($status_get==""){
				$query_noticias = "SELECT *  FROM `vaga` ORDER BY `vaga`.`id` DESC LIMIT 0 , 20";
				}
				else
				{
				if($status_get=='todas'){
				$query_noticias = "SELECT *  FROM `vaga` ORDER BY `vaga`.`id` DESC ";
				}else{
				 $query_noticias = "SELECT *  FROM `vaga` where status='$status_get' ORDER BY `vaga`.`id` DESC ";
				}
			  }
			}
			else
			{
				
				$query_noticias = "SELECT * FROM `vaga` WHERE id ='$busca_cnpj1'";	
				
			}
		
		
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){



									
									$id= $campo_noticias['id']; 	 
									$empresaid= $campo_noticias['empresaid']; 	 
									$selvagasigilosa = $campo_noticias['selvagasigilosa'];
									
									$cboid = $campo_noticias['cboid'];
									$descricao = $campo_noticias['descricao'];
									$cargo = $campo_noticias['cargo']; 
									$txvagadata = $campo_noticias['txvagadata'];
									$horariotrabalho = $campo_noticias['horariotrabalho'];
									$vagadeficiente = $campo_noticias['vagadeficiente'];
									$quantidadedisponivel = $campo_noticias['quantidadedisponivel'];
									$txvagapreenchidaCTM = $campo_noticias['txvagapreenchidaCTM']; 
									$txvagapreenchidaOutros = $campo_noticias['txvagapreenchidaOutros'];
									$txvagaCancelada = $campo_noticias['txvagaCancelada']; 
									$txvagasativas = $campo_noticias['txvagasativas']; 
									$quantidadeencaminhar = $campo_noticias['quantidadeencaminhar'];
									$datalimiteencaminhar = $campo_noticias['datalimiteencaminhar'];
									$chktemporaria = $campo_noticias['chktemporaria'];
									$ceplocal = $campo_noticias['ceplocal'];
									$txtestado_local = $campo_noticias['txtestado_local'];
									$cidadelocalid = $campo_noticias['cidadelocalid'];
									$bairrolocal = $campo_noticias['bairrolocal'];
									$enderecolocal = $campo_noticias['enderecolocal']; 
									$proximodelocal = $campo_noticias['proximodelocal']; 
									$onoffshore = $campo_noticias['onoffshore']; 
									$local = $campo_noticias['local'];
									$salario = $campo_noticias['salario'];
									$comissao = $campo_noticias['comissao'];
									$prospeccao = $campo_noticias['prospeccao'];
									$cartaoalimentacao = $campo_noticias['cartaoalimentacao']; 
									$alimentacaolocal = $campo_noticias['alimentacaolocal']; 
									$lanche = $campo_noticias['lanche'];
									$cestabasica = $campo_noticias['cestabasica']; 
									$planosaude = $campo_noticias['planosaude']; 
									$planoodonto = $campo_noticias['planoodonto'];
									$segurovida = $campo_noticias['segurovida'];
									$carteiraassinada = $campo_noticias['carteiraassinada']; 
									$valetransporte= $campo_noticias['valetransporte'];
									$premiacao = $campo_noticias['premiacao']; 
									$outrosbeneficios = $campo_noticias['outrosbeneficios'];
									$tempoano = $campo_noticias['tempoano']; 
									$tempomes = $campo_noticias['tempomes']; 
									$comprovada = $campo_noticias['comprovada'];
									$idademinima = $campo_noticias['idademinima']; 
									$idademaxima = $campo_noticias['idademaxima']; 
									$escolaridade = $campo_noticias['escolaridade'];
									$escolaridadesituacao = $campo_noticias['escolaridadesituacao'];
									$cnh= $campo_noticias['cnh']; 
									$sexo = $campo_noticias['sexo'];
									$estadocivil = $campo_noticias['estadocivil']; 
									$txvagafilhos = $campo_noticias['txvagafilhos'];
									$importanciatempo = $campo_noticias['importanciatempo']; 
									$importanciaidade = $campo_noticias['importanciaidade']; 
									$importanciaescolaridade = $campo_noticias['importanciaescolaridade']; 
									$importanciacnh = $campo_noticias['importanciacnh'];
									$importanciasexo = $campo_noticias['importanciasexo']; 
									$importanciaestadocivil = $campo_noticias['importanciaestadocivil'];
									$selvagafilhos_niv = $campo_noticias['selvagafilhos_niv'];
									$txvagaregiao = $campo_noticias['txvagaregiao'];
									$txvagahabilidades = $campo_noticias['txvagahabilidades']; 
									$txvagarestricoes = $campo_noticias['txvagarestricoes'];
									$importanciaestadocivil = $campo_noticias['importanciaestadocivil']; 
									$selvagaidiomas_niv = $campo_noticias['selvagaidiomas_niv'];
									$selvagainformatica_niv = $campo_noticias['selvagainformatica_niv'];
									$txtcep = $campo_noticias['txtcep'];
									$txtestado = $campo_noticias['txtestado'];
									$txtcidade = $campo_noticias['txtcidade'];
									$txtbairro = $campo_noticias['txtbairro'];
									$txtendereco = $campo_noticias['txtendereco']; 
									$txtproximode = $campo_noticias['txtproximode'];
									$txtfalarcom = $campo_noticias['txtfalarcom']; 
									$txtEmailEntrevista = $campo_noticias['txtEmailEntrevista']; 
									$horarioatendimento = $campo_noticias['horarioatendimento'];
									$viaencaminhamento = $campo_noticias['viaencaminhamento'];
									$observacao = $campo_noticias['observacao']; 
									$status = $campo_noticias['status']; 
									$formacaptacaoid = $campo_noticias['formacaptacaoid'];
									$localcaptacaoid = $campo_noticias['localcaptacaoid']; 
									$selpublicar = $campo_noticias['selpublicar']; 
									$dia = $campo_noticias['dia']; 
									$mes = $campo_noticias['mes']; 
									$ano = $campo_noticias['ano']; 
									
									 $softwareid1 = $campo_noticias['softwareid1']; 
									 $softwareid2 = $campo_noticias['softwareid2']; 
									 $softwareid3 = $campo_noticias['softwareid3'];
									 
									 $idiomaid1 = $campo_noticias['idiomaid1']; 
									 $leitura1 = $campo_noticias['leitura1']; 
									 $escrita1 = $campo_noticias['escrita1']; 
									 $conversacao1 = $campo_noticias['conversacao1']; 
									 
									  $idiomaid2 = $campo_noticias['idiomaid2']; 
									 $leitura2 = $campo_noticias['leitura2']; 
									 $escrita2 = $campo_noticias['escrita2']; 
									 $conversacao2 = $campo_noticias['conversacao2']; 
									 
									  $idiomaid3 = $campo_noticias['idiomaid3']; 
									 $leitura3 = $campo_noticias['leitura3']; 
									 $escrita3 = $campo_noticias['escrita3']; 
									 $conversacao3 = $campo_noticias['conversacao3']; 
									 $cadastrado_por = $campo_noticias['usuarioid']; 
									 $datacadastro = $campo_noticias['datacadastro']; 
									 $dataupdate = $campo_noticias['dataupdate']; 
									 $dataaguardamdo = $campo_noticias['dataaguardamdo']; 
									
		
			?>

			<tr class='tr_tb' >		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$id ;?> </td>
					<?
					
					
												
												
						$sql = "SELECT * FROM `empresa` where id ='$empresaid'";
						$rsd = mysql_query($sql);
						while($rs = mysql_fetch_array($rsd)) {
						$txnomed = $rs['nome'];
						$empresaidd = $rs['empresaid'];	
							}						
					?>
				<td class='td2' >  <?=$txnomed;?></td>
						<?
							
							
					$query_noticias_total_emca = "SELECT * FROM  encaminhamento  WHERE vagaid ='$id'";	
					$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
					$total_total_emca = mysql_num_rows($rs_noticias_total_emca);	
					
						?>
						
						
				<td class='td2' >  <?=$cargo;?></td>	

				
				<td class='td2' >  <?=$quantidadedisponivel;?></td>				
				<td class='td2' >  <?=$total_total_emca;?>/<?=$quantidadeencaminhar;?></td>				
				<td class='td2' >  <b>Cadastro:</b><?=$datacadastro;?><?if($dataupdate=="0000-00-00 00:00:00"){}else{?><br><b>Atualizado:</b><?=$dataupdate;}?></td>				
				<td class='td2' >  <?if($dataaguardamdo=="0000-00-00 00:00:00"){echo"- - ";}else{?><?=$dataaguardamdo;}?></td>				
							
				
						<?
						switch ($status){										
						case "A":											
						$status_N2 = "Ativa";
						break;case "S":											
						$status_N2 = "Suspensa";
						break;case "P":											
						$status_N2 = "Preenchida pelo CTM";
						break;case "O":											
						$status_N2 = "Preenchida pelo Solicitante";
						break;case "C":											
						$status_N2 = "Cancelada";
						break;case "E":											
						$status_N2 = "Encerrada";
						break;case "R":											
						$status_N2 = "Aguardando Resposta";
						break;case "N":											
						$status_N2 = "Sem retorno ";						
						break;case "G":											
						$status_N2 = "Sigilosa";
						break;
						;case "T":											
						$status_N2 = "Sem Retorno";
						break;
						}
					?>
					
				<td class='td2' >  <?=$status_N2;?></td>				
				<td class='td2' >
				<?$endereco = $_SERVER ['REQUEST_URI'];;?>
				
				<a href="javascript:Abrir_Pagina('cadastro_vagas.php?id=<?=$id;?>&empresaid=<?=$empresaid;?>','scrollbars=yes,width=800,height=500')" title='Saiba mais'><img src='img/busca.png'/></a> 
				<a href="javascript:Abrir_Pagina('lista_trabalhador_vaga.php?id=<?=$id;?>','scrollbars=yes,width=600,height=500')" title='Trabalhador Encaminhado'><img src='img/relatorio.png'/></a> 
                                <a href="cadastro_vagas.php?id=<?=$id;?>&p=I" title='Importar perfil da vaga'><img src='img/inserir_curso.png'/></a> 
				
					<script>
					function ConfirmDelete_<?=$id;?>(){

					var del=confirm("Deseja Excluir ID vaga <?=$id;?>?");
					if (del==true){
					//alert ("Excluindo..")
					Abrir_Pagina('script_vaga.php?acao=excluir&id=<?=$id;?>&nome=<?=$id;?>','scrollbars=yes,width=600,height=500')
					}else{
					alert("Excluição cancelada")
					}
					return del;
					}
					//javascript:Abrir_Pagina('script_vaga.php?acao=excluir&id=<?=$id;?>&nome=<?=$id;?>','scrollbars=yes,width=600,height=500')
					</script>
					<?if($total_total_emca > 0 ){}else{?>
						<a Onclick="ConfirmDelete_<?=$id;?>();" href="" title='Excluir'><img src='img/delete.png'/></a>
					<?}?>
				 </td>
			</tr>
		<?}?>	
		
		
	</table>
	<?
	if($total=="")
				
				{echo"<h3>Nenhuma Vaga foi encontrada.</h3>";}else{}
				
				?>
	

</form>
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
