<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <?include'topo.php';
    $id = $_GET['id'];
	$p = $_GET['p'];
    ?>

    <body onload="endereco_empresa('oi');">
        <script type="text/javascript">
            $().ready(function() {
                $("#cboid").autocomplete("789/autoComplete.php", {
                    matchContains: true,
                    mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });


                $("#selnome").autocomplete("789/consulta.empresa.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });






            });


            $(function() {


                $("#datalimiteencaminhar").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1970:<?= $anofinaldata; ?>',
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'],
                    dayNamesMin: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
                    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
                    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
                    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
                });


            });
        </script>
        <script>
            function pop_pesquisaempresa(page) {
                window.open('', 'popRelReciboEntregue', 'width=750,height=450,scrollbars');
                document.ajax_form.action = page;
                document.ajax_form.target = 'popRelReciboEntregue';
                document.ajax_form.submit();
            }

        </script>
        <div id="bg-container" class='contener'>


            <div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);margin-top:10px;' align='center' >
                <table width='960px'>
                    <tr>


                        <td width=''>


                            <?

                            $query_noticias = "SELECT * FROM `vaga` WHERE id ='$id'";	
                            $rs_noticias    = mysql_query($query_noticias); 
                            $total = mysql_num_rows($rs_noticias);			
                            while($campo_noticias = mysql_fetch_array($rs_noticias)){



                            $empresaid= $campo_noticias['empresaid']; 	 
                            $selvagasigilosa = $campo_noticias['selvagasigilosa'];

                            $cboid = $campo_noticias['cboid'];
                            $descricao = $campo_noticias['descricao'];
                            $cargo = $campo_noticias['cargo']; 
                            $txvagadata = $campo_noticias['txvagadata'];
                            $horariotrabalho = $campo_noticias['horariotrabalho'];
                            $vagadeficiente = $campo_noticias['vagadeficiente'];
                            $quantidadedisponivel = $campo_noticias['quantidadedisponivel'];
                            $txvagapreenchidaCTM = $campo_noticias['txvagapreenchidaCTM']; 
                            $txvagapreenchidaOutros = $campo_noticias['txvagapreenchidaOutros'];
                            $txvagaCancelada = $campo_noticias['txvagaCancelada']; 
                            $txvagasativas = $campo_noticias['txvagasativas']; 
                            $quantidadeencaminhar = $campo_noticias['quantidadeencaminhar'];
                            $datalimiteencaminhar = $campo_noticias['datalimiteencaminhar'];
                            $chktemporaria = $campo_noticias['chktemporaria'];
                            $ceplocal = $campo_noticias['ceplocal'];
                            $txtestado_local = $campo_noticias['txtestado_local'];
                            $cidadelocalid = $campo_noticias['cidadelocalid'];
                            $bairrolocal = $campo_noticias['bairrolocal'];
                            $enderecolocal = $campo_noticias['enderecolocal']; 
                            $proximodelocal = $campo_noticias['proximodelocal']; 
                            $onoffshore = $campo_noticias['onoffshore']; 
                            $local = $campo_noticias['local'];
                            $salario = $campo_noticias['salario'];
                            $comissao = $campo_noticias['comissao'];
                            $prospeccao = $campo_noticias['prospeccao'];
                            $cartaoalimentacao = $campo_noticias['cartaoalimentacao']; 
                            $alimentacaolocal = $campo_noticias['alimentacaolocal']; 
                            $lanche = $campo_noticias['lanche'];
                            $cestabasica = $campo_noticias['cestabasica']; 
                            $planosaude = $campo_noticias['planosaude']; 
                            $planoodonto = $campo_noticias['planoodonto'];
                            $segurovida = $campo_noticias['segurovida'];
                            $carteiraassinada = $campo_noticias['carteiraassinada']; 
                            $valetransporte= $campo_noticias['valetransporte'];
                            $premiacao = $campo_noticias['premiacao']; 
                            $outrosbeneficios = $campo_noticias['outrosbeneficios'];
                            $tempoano = $campo_noticias['tempoano']; 
                            $tempomes = $campo_noticias['tempomes']; 
                            $comprovada = $campo_noticias['comprovada'];
                            $idademinima = $campo_noticias['idademinima']; 
                            $idademaxima = $campo_noticias['idademaxima']; 
                            $escolaridade = $campo_noticias['escolaridade'];
                            $escolaridadesituacao = $campo_noticias['escolaridadesituacao'];
                            $cnh= $campo_noticias['cnh']; 
                            $sexo = $campo_noticias['sexo'];
                            $estadocivil = $campo_noticias['estadocivil']; 
                            $txvagafilhos = $campo_noticias['txvagafilhos'];
                            $importanciatempo = $campo_noticias['importanciatempo']; 
                            $importanciaidade = $campo_noticias['importanciaidade']; 
                            $importanciaescolaridade = $campo_noticias['importanciaescolaridade']; 
                            $importanciacnh = $campo_noticias['importanciacnh'];
                            $importanciasexo = $campo_noticias['importanciasexo']; 
                            $importanciaestadocivil = $campo_noticias['importanciaestadocivil'];
                            $selvagafilhos_niv = $campo_noticias['selvagafilhos_niv'];
                            $txvagaregiao = $campo_noticias['txvagaregiao'];
                            $txvagahabilidades = $campo_noticias['txvagahabilidades']; 
                            $txvagarestricoes = $campo_noticias['txvagarestricoes'];
                            $importanciaestadocivil = $campo_noticias['importanciaestadocivil']; 
                            $selvagaidiomas_niv = $campo_noticias['selvagaidiomas_niv'];
                            $selvagainformatica_niv = $campo_noticias['selvagainformatica_niv'];
                            $txtcep = $campo_noticias['txtcep'];
                            $txtestado = $campo_noticias['txtestado'];
                            $txtcidade = $campo_noticias['txtcidade'];
                            $txtbairro = $campo_noticias['txtbairro'];
                            $txtendereco = $campo_noticias['txtendereco']; 
                            $txtproximode = $campo_noticias['txtproximode'];
                            $txtfalarcom = $campo_noticias['txtfalarcom']; 
                            $txtEmailEntrevista = $campo_noticias['txtEmailEntrevista']; 
                            $horarioatendimento = $campo_noticias['horarioatendimento'];
                            $viaencaminhamento = $campo_noticias['viaencaminhamento'];
                            $observacao = $campo_noticias['observacao']; 
                            $status = $campo_noticias['status']; 
                            $formacaptacaoid = $campo_noticias['formacaptacaoid'];
                            $localcaptacaoid = $campo_noticias['localcaptacaoid']; 
                            $selpublicar = $campo_noticias['selpublicar']; 
                            $dia = $campo_noticias['dia']; 
                            $mes = $campo_noticias['mes']; 
                            $ano = $campo_noticias['ano']; 

                            $softwareid1 = $campo_noticias['softwareid1']; 
                            $softwareid2 = $campo_noticias['softwareid2']; 
                            $softwareid3 = $campo_noticias['softwareid3'];

                            $idiomaid1 = $campo_noticias['idiomaid1']; 
                            $leitura1 = $campo_noticias['leitura1']; 
                            $escrita1 = $campo_noticias['escrita1']; 
                            $conversacao1 = $campo_noticias['conversacao1']; 

                            $idiomaid2 = $campo_noticias['idiomaid2']; 
                            $leitura2 = $campo_noticias['leitura2']; 
                            $escrita2 = $campo_noticias['escrita2']; 
                            $conversacao2 = $campo_noticias['conversacao2']; 

                            $idiomaid3 = $campo_noticias['idiomaid3']; 
                            $leitura3 = $campo_noticias['leitura3']; 
                            $escrita3 = $campo_noticias['escrita3']; 
                            $conversacao3 = $campo_noticias['conversacao3']; 
                            $cadastrado_por = $campo_noticias['usuarioid']; 
                            $datacadastro = $campo_noticias['datacadastro']; 



                            }


							
							
							
							
                            ?>

			
							<?php 
							if($id=="")
							{
							$acao="cadastro";
							}
							else {
							if($p=="")
									{ 
									$acao="editar";
									}
								 else{
								 $acao="cadastro";
								 }
							
							}; ?>
                            <form  style='padding-bottom:250px;' class="form" id="ajax_form" name='ajax_form'>


                                <div><font style='font-size:16px;'>&#10144; </font> Atenção, campos com <font class='simbolo'>&#10045;</font> são obrigatorios!</div>
                                <div class="idTabs" id='idTabs'>



                                    <div id='dados_vaga' name='dados_vaga' >	

                                        <div style='margin:20px;width:100%;' align='center'>
                                            <font style='font-size:15px;color:red;font-weight:bold;'>Passo 1 &#10132; </font>
                                            <font style='font-size:15px;color:#999;font-weight:bold;'>Passo 2 &#10132; </font>
                                            <font style='font-size:15px;color:#999;font-weight:bold;'>Passo 3 &#10132; </font>
                                            <font style='font-size:15px;color:#999;font-weight:bold;'>Passo 4 &#10132; </font>
                                            <font style='font-size:15px;color:#999;font-weight:bold;'>Passo 5 </font>
                                        </div>




                                        <h2>DADOS DA VAGA</h2>


                                        <?if($id=="") {}else{?>											
                                        <div class="form-row" >
                                            <div class="label"></div>
                                            <div class="input-container" style='width:546px;'>
                                                <b>Id</b>
                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="codigoId" value='<?= $id; ?>'id="codigoId" maxlength="8" readonly="true"class="input req-same"onchange="Maiuscula(this);
                                                        EditandoRegistro();" tabindex="2" style="font-family: Tahoma; font-size: 10px; width:42px;" type="text">

                                                    <?


                                                    $query_atendente = "SELECT *  FROM  `usuario` where  id='$cadastrado_por'";	
                                                    $rs_atendente    = mysql_query($query_atendente); 													
                                                    while($campo_atendente = mysql_fetch_array($rs_atendente)){
                                                    $nome_atendente= $campo_atendente['nome']; 
                                                    }								

                                                    ?>


                                                    Atendente : <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" style='width:70px' class="input req-same" value='<?= $nome_atendente; ?>'readonly="true"  type="text"   />
                                                    &nbsp;&nbsp;&nbsp;
                                                    <b>Data de Cadastramento desta Vaga</b>
                                                    <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="txtDataCad"  value="<?= $datacadastro; ?>"id="txtDataCad" class="input req-same"readonly="true"  maxlength="10" readonly="" style="font-family: Tahoma; font-size: 10px; width:75px;" tabindex="5" type="text">
                                                        </div>
                                                        </div >
                                                        <?}?>



                                                        <div class="form-row" >
                                                            <div class="label">EMPRESA  <font class='simbolo'><font class='simbolo'>&#10045;</font></font> </div>
                                                            <div class="input-container" style='width:546px;'>		

                                                                <?if($id==""){}else{?>

                                                                <style onload="deficiente('2')"></style>

                                                                <?}?>

                                                                <script  type="text/javascript">
                                                                    // FUNÇÃO PARA BUSCA NOTICIA
                                                                    function ond_entrevistaa(cidade) {

                                                                        // Verificando Browser
                                                                        if (window.XMLHttpRequest) {
                                                                            req = new XMLHttpRequest();
                                                                        }
                                                                        else if (window.ActiveXObject) {
                                                                            req = new ActiveXObject("Microsoft.XMLHTTP");
                                                                        }

                                                                        // Arquivo PHP juntamente com o valor digitado no campo (método GET)

                                                                        var valorComboempresaid = document.getElementById("empresaid").value;

                                                                        var url = "local_entrevista.php?busca=vaga&id=<?= $id; ?>&idempresa=" + valorComboempresaid;


                                                                        // Chamada do método open para processar a requisição
                                                                        req.open("Get", url, true);
                                                                        req.setRequestHeader("Cache-Control", "no-cache,no-store");
                                                                        req.setRequestHeader("Pragma", "no-cache");

                                                                        // Quando o objeto recebe o retorno, chamamos a seguinte função;
                                                                        req.onreadystatechange = function() {

                                                                            // Exibe a mensagem "Buscando Noticias..." enquanto carrega
                                                                            if (req.readyState == 1) {
                                                                                document.getElementById('lista_local_entrevista').innerHTML = 'buscando';
                                                                            }

                                                                            // Verifica se o Ajax realizou todas as operações corretamente
                                                                            if (req.readyState == 4 && req.status == 200) {

                                                                                // Resposta retornada pelo busca.php
                                                                                var resposta = req.responseText;

                                                                                // Abaixo colocamos a(s) resposta(s) na div resultado
                                                                                document.getElementById('lista_local_entrevista').innerHTML = resposta;
                                                                            }
                                                                        }
                                                                        req.send(null);
                                                                        req.setRequestHeader("Cache-Control", "no-cache");
                                                                        req.setRequestHeader("Pragma", "no-cache");

                                                                    }
                                                                </script>

                                                                <script  type="text/javascript">
                                                                    // FUNÇÃO PARA BUSCA NOTICIA
                                                                    function endereco_empresa(cidade) {


                                                                        // Verificando Browser
                                                                        if (window.XMLHttpRequest) {
                                                                            req = new XMLHttpRequest();
                                                                        }
                                                                        else if (window.ActiveXObject) {
                                                                            req = new ActiveXObject("Microsoft.XMLHTTP");
                                                                        }

                                                                        // Arquivo PHP juntamente com o valor digitado no campo (método GET)

                                                                        var valorComboempresaid = document.getElementById("empresaid").value;

                                                                        var url = "endereco_empresa.php?busca=vaga&id=<?= $id; ?>&idempresa=" + valorComboempresaid;


                                                                        // Chamada do método open para processar a requisição
                                                                        req.open("Get", url, true);
                                                                        req.setRequestHeader("Cache-Control", "no-cache,no-store");
                                                                        req.setRequestHeader("Pragma", "no-cache");

                                                                        // Quando o objeto recebe o retorno, chamamos a seguinte função;
                                                                        req.onreadystatechange = function() {

                                                                            // Exibe a mensagem "Buscando Noticias..." enquanto carrega
                                                                            if (req.readyState == 1) {
                                                                                document.getElementById('endereco_empresa').innerHTML = 'buscando';
                                                                            }

                                                                            // Verifica se o Ajax realizou todas as operações corretamente
                                                                            if (req.readyState == 4 && req.status == 200) {

                                                                                // Resposta retornada pelo busca.php
                                                                                var resposta = req.responseText;

                                                                                // Abaixo colocamos a(s) resposta(s) na div resultado
                                                                                document.getElementById('endereco_empresa').innerHTML = resposta;
                                                                            }
                                                                        }
                                                                        req.send(null);
                                                                        req.setRequestHeader("Cache-Control", "no-cache");
                                                                        req.setRequestHeader("Pragma", "no-cache");

                                                                    }
                                                                </script>



                                                                <select name="empresaid"  required id="empresaid" style='width:490px;'class="input req-same" Onchange="endereco_empresa('oi');">

                                                                    <?
                                                                    $query_noticias2e = "SELECT * FROM `empresa` where id='$empresaid'";	
                                                                    $rs_noticias2e    = mysql_query($query_noticias2e); 													
                                                                    while($campo_noticias2e = mysql_fetch_array($rs_noticias2e)){
                                                                    $nome_empresa_bd= $campo_noticias2e['nome']; 	 
                                                                    $razaosocial_bd= $campo_noticias2e['razaosocial']; 	 
                                                                    $id_empresa_bd= $campo_noticias2e['id']; 

                                                                    ?><?}?>
                                                                    <option value='<?= $id_empresa_bd; ?>'> <?= $nome_empresa_bd; ?></option>

                                                                    <? 
                                                                    $query_noticiase = "SELECT * FROM `empresa`ORDER BY `empresa`.`nome` ASC";	
                                                                    $rs_noticiase    = mysql_query($query_noticiase); 													
                                                                    while($campo_noticiase = mysql_fetch_array($rs_noticiase)){
                                                                    $nome_empresa= $campo_noticiase['nome']; 	 
                                                                    $razaosocial= $campo_noticiase['razaosocial']; 	 
                                                                    $id_empresa= $campo_noticiase['id']; 

                                                                    ?>
                                                                    <option value='<?= $id_empresa; ?>' title='<?= $razaosocial; ?>'> <?= $nome_empresa; ?></option>
                                                                    <?}?>	
                                                                </select>

                                                               
                                                            </div>
                                                        </div>


                                                        <div class="form-row" >
                                                            <div class="label">Ocupação <font class='simbolo'><font class='simbolo'>&#10045;</font></font> </div>
                                                            <div class="input-container" style='width:546px;'>		

                                                                <?
                                                                $query_ocupacao = "SELECT * FROM `cbo` where id='$cboid' ";
                                                                $rs_ocupacao     = mysql_query($query_ocupacao );
                                                                while($campo_ocupacao  = mysql_fetch_array($rs_ocupacao )){
                                                                $cbo        = $campo_ocupacao ['cbo'];
                                                                }
                                                                ?>

                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();"  mouseover="endereco_empresa('oi');" name="cboid" required value="<?= $cbo; ?>"id="cboid" maxlength="300"class="input req-same"onkeydown="EditandoRegistro()" onchange="Maiuscula(this);
                                                                        EditandoRegistro();"  tabindex="8" type="text">




                                                            </div>
                                                        </div >	


                                                        <div class="form-row" >
                                                            <div class="label">Descrição da Vaga <font class='simbolo'><font class='simbolo'>&#10045;</font></font> </div>
                                                            <div class="input-container" style='width:546px;'>		
                                                                <textarea maxlength="400" name="descricao" required=''  style='height:63px;' id="descricao" rows="3" cols="99" tabindex="11" style="font-size: 12px; font-family: Arial;" class="input req-same" onkeyup="funTamanhoCerto('window.document.Ficha.descricao', 500);" onchange="Maiuscula(this);
                                                                        EditandoRegistro();"><?= $descricao; ?></textarea>
                                                            </div>
                                                        </div >

                                                        <div class="form-row" >
                                                            <div class="label">Cargo <font class='simbolo'><font class='simbolo'>&#10045;</font></font></div>
                                                            <div class="input-container" style='width:546px;'>		
                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="cargo" id="cargo"  required='' value="<?= $cargo; ?>"maxlength="100" onkeydown="EditandoRegistro()" class="input req-same"tabindex="12" type="text">
                                                            </div>
                                                        </div >



                                                        <script  type="text/javascript">


                                                            function deficiente(cidade) {
                                                                    
                                                                // Verificando Browser
                                                                if (window.XMLHttpRequest) {
                                                                    req = new XMLHttpRequest();
                                                                }
                                                                else if (window.ActiveXObject) {
                                                                    req = new ActiveXObject("Microsoft.XMLHTTP");
                                                                }

                                                                // Arquivo PHP juntamente com o valor digitado no campo (método GET)
                                                                if (cidade == "2")
                                                                {

                                                                    var url = "deficiente.php?escolha=<?= $vagadeficiente; ?>&id=<?= $id; ?>&test" + cidade;

                                                                }

                                                                else
                                                                {
                                                                    var url = "deficiente.php?escolha=" + cidade;

                                                                }

                                                                // Chamada do método open para processar a requisição
                                                                req.open("Get", url, true);
                                                                req.setRequestHeader("Cache-Control", "no-cache,no-store");
                                                                req.setRequestHeader("Pragma", "no-cache");

                                                                // Quando o objeto recebe o retorno, chamamos a seguinte função;
                                                                req.onreadystatechange = function() {

                                                                    // Exibe a mensagem "Buscando Noticias..." enquanto carrega
                                                                    if (req.readyState == 1) {
                                                                        document.getElementById('deficiente').innerHTML = 'Carregando aguarde...';
                                                                    }

                                                                    // Verifica se o Ajax realizou todas as operações corretamente
                                                                    if (req.readyState == 4 && req.status == 200) {

                                                                        // Resposta retornada pelo busca.php
                                                                        var resposta = req.responseText;

                                                                        // Abaixo colocamos a(s) resposta(s) na div resultado
                                                                        document.getElementById('deficiente').innerHTML = resposta;
                                                                    }
                                                                }
                                                                req.send(null);
                                                                req.setRequestHeader("Cache-Control", "no-cache");
                                                                req.setRequestHeader("Pragma", "no-cache");



                                                            }


                                                        </script>

                                                        <div class="form-row"   >
                                                            <div class="label"></div>
                                                            <div class="input-container" style='width:546px;'  >		

                                                                Aceita Deficientes <font class='simbolo'><font class='simbolo'>&#10045;</font></font>
                                                                <select name="vagadeficiente"  required='' id="vagadeficiente" onchange="deficiente(this.value);"style="width:88px;" tabindex="15">

                                                                    <?php
                                                                    switch ($vagadeficiente){										
                                                                    case "N":											
                                                                    $vagadeficiente_N = "Não";
                                                                    break;

                                                                    case "S":											
                                                                    $vagadeficiente_N = "SIM";
                                                                    break;
                                                                    }
                                                                    ?>

                                                                    <option  value="<?= $vagadeficiente; ?>"><?= $vagadeficiente_N; ?></option>
                                                                    <option  value="N" >Não</option>
                                                                    <option  value="S" >Sim</option>
                                                                </select>

                                                            </div>
                                                        </div >




                                                        <script type="text/javascript">
                                                            function validarDataw(campo) {
                                                                var expReg = /^(([0-2]\d|[3][0-1])\/([0]\d|[1][0-2])\/[1-2][0-9]\d{2})$/;
                                                                var msgErro = 'Formato inválido de data.Até que dia enviar encaminhamentos';
                                                                if ((campo.value.match(expReg)) && (campo.value != '')) {
                                                                    var dia = campo.value.substring(0, 2);
                                                                    var mes = campo.value.substring(3, 5);
                                                                    var ano = campo.value.substring(6, 10);
                                                                    if (mes == 4 || mes == 6 || mes == 9 || mes == 11 && dia > 30) {
                                                                        alert("Dia incorreto !!! O mês especificado contém no máximo 30 dias.");
                                                                        return false;
                                                                    } else {
                                                                        if (ano % 4 != 0 && mes == 2 && dia > 28) {
                                                                            alert("Data incorreta!! O mês especificado contém no máximo 28 dias.");
                                                                            return false;
                                                                        } else {
                                                                            if (ano % 4 == 0 && mes == 2 && dia > 29) {
                                                                                alert("Data incorreta!! O mês especificado contém no máximo 29 dias.");
                                                                                return false;
                                                                            } else {
                                                                                //alert ("Data correta!");
                                                                                return true;
                                                                            }
                                                                        }
                                                                    }
                                                                } else {
                                                                    alert(msgErro);
                                                                    campo.focus();
                                                                    return false;
                                                                }
                                                            }

                                                        </script> 



                                                        <div class="form-row" >
                                                            <div class="label"></div>
                                                            <div class="input-container" style='width:546px;'>		

                                                                Até que dia enviar encaminhamentos <font class='simbolo'><font class='simbolo'>&#10045;</font></font>
                                                                <?$datalimiteencaminhar1 = implode('/',array_reverse(explode('-',$datalimiteencaminhar)));?>


                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" readonly='true' onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="datalimiteencaminhar" id="datalimiteencaminhar" onblur="validarData(document.ajax_form.datalimiteencaminhar)"required=''  value='<?= $datalimiteencaminhar1; ?>'  maxlength="10" class="input req-same" style="width:88px;" tabindex="22" type="text">


                                                            </div>
                                                        </div >


                                                        <div class="form-row" >
                                                            <div class="label"></div>
                                                            <div class="input-container" style='width:546px;'>		
                                                                Horário de Trabalho <font class='simbolo'><font class='simbolo'>&#10045;</font></font>
                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="horariotrabalho"  required='' value="<?= $horariotrabalho; ?>" id="horariotrabalho" maxlength="30" class="input req-same" onblur="validarData(document.ajax_form.datalimiteencaminhar)" onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" style="width:238px;" tabindex="14" type="text">

                                                            </div>
                                                        </div >	

                                                        <div class="form-row" >
                                                            <div class="label"></div>
                                                            <div class="input-container" style='width:546px;'>		
                                                                Quantidade de vagas disponibilizadas <font class='simbolo'><font class='simbolo'>&#10045;</font></font>
                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="quantidadedisponivel"  min= "0" required='' value='<?= $quantidadedisponivel; ?>'id="quantidadedisponivel" maxlength="10" onblur="validarData(document.ajax_form.datalimiteencaminhar)"  class="input req-same"onblur="AjustaVagasAtivas();" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.quantidadedisponivel');" style="width:88px;" tabindex="16" type="number">

                                                            </div>
                                                        </div >


                                                        <div class="form-row" >
                                                            <div class="label"></div>
                                                            <div class="input-container" style='width:546px;'>		
                                                                Quantidade encaminhar para Seleção <font class='simbolo'><font class='simbolo'>&#10045;</font></font>
                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="quantidadeencaminhar"  min= "0" id="quantidadeencaminhar" required=''  value='<?= $quantidadeencaminhar; ?>' onblur="validarData(document.ajax_form.datalimiteencaminhar)"  maxlength="3" class="input req-same"onkeydown="EditandoRegistro()" onchange="Maiuscula(this)" onkeyup="verificaNumero('window.document.Ficha.quantidadeencaminhar');" style="width:88px;" tabindex="21" type="number">


                                                            </div>
                                                        </div >




                                                        <div id='deficiente' name='deficiente'class="form-row" >

                                                        </div>






                                                        <div class="form-row" >
                                                            <div class="label"></div>
                                                            <div class="input-container" style='width:546px;'>		
                                                                <a  href="#dados_vaga" style='display:none;'> DADOS DA VAGA</a>	
                                                                <a  href="#local_vaga"  class="sendBtn"  >Próximo &#9658;<a>	

                                                                        </div>
                                                                        </div >

                                                                        </div>






                                                                        <div name='local_vaga' id='local_vaga'>			

                                                                            <div style='margin:20px;width:100%;' align='center'>
                                                                                <font style='font-size:15px;color:red;font-weight:bold;'>Passo 1 &#10132; </font>
                                                                                <font style='font-size:15px;color:red;font-weight:bold;'>Passo 2 &#10132; </font>
                                                                                <font style='font-size:15px;color:#999;font-weight:bold;'>Passo 3 &#10132; </font>
                                                                                <font style='font-size:15px;color:#999;font-weight:bold;'>Passo 4 &#10132; </font>
                                                                                <font style='font-size:15px;color:#999;font-weight:bold;'>Passo 5 </font>
                                                                            </div>


                                                                            <h2>LOCAL DA VAGA</h2>





                                                                            <script  type="text/javascript">
                                                                                // FUNÇÃO PARA BUSCA NOTICIA
                                                                                function busca_cidadel(valor2) {
                                                                                    // Verificando Browser
                                                                                    if (window.XMLHttpRequest) {
                                                                                        req = new XMLHttpRequest();
                                                                                    }
                                                                                    else if (window.ActiveXObject) {
                                                                                        req = new ActiveXObject("Microsoft.XMLHTTP");
                                                                                    }

                                                                                    // Arquivo PHP juntamente com o valor digitado no campo (método GET)

                                                                                    var url = "busca_endereco.php?tipo_busca=cidade&uf=" + valor2;

                                                                                    // Chamada do método open para processar a requisição
                                                                                    req.open("Get", url, true);
                                                                                    req.setRequestHeader("Cache-Control", "no-cache,no-store");
                                                                                    req.setRequestHeader("Pragma", "no-cache");

                                                                                    // Quando o objeto recebe o retorno, chamamos a seguinte função;
                                                                                    req.onreadystatechange = function() {

                                                                                        // Exibe a mensagem "Buscando Noticias..." enquanto carrega
                                                                                        if (req.readyState == 1) {
                                                                                            document.getElementById('cidadelocalid').innerHTML = '<option >buscando</option>';
                                                                                        }

                                                                                        // Verifica se o Ajax realizou todas as operações corretamente
                                                                                        if (req.readyState == 4 && req.status == 200) {

                                                                                            // Resposta retornada pelo busca.php
                                                                                            var resposta = req.responseText;

                                                                                            // Abaixo colocamos a(s) resposta(s) na div resultado
                                                                                            document.getElementById('cidadelocalid').innerHTML = resposta;
                                                                                        }
                                                                                    }
                                                                                    req.send(null);
                                                                                    req.setRequestHeader("Cache-Control", "no-cache");
                                                                                    req.setRequestHeader("Pragma", "no-cache");

                                                                                }
                                                                            </script>
                                                                            <!--inicio---endereco vaga-->

                                                                            <script  type="text/javascript">
// FUNÇÃO PARA BUSCA NOTICIA
                                                                                function busca_bairol(cidade) {
// Verificando Browser
                                                                                    if (window.XMLHttpRequest) {
                                                                                        req = new XMLHttpRequest();
                                                                                    }
                                                                                    else if (window.ActiveXObject) {
                                                                                        req = new ActiveXObject("Microsoft.XMLHTTP");
                                                                                    }

// Arquivo PHP juntamente com o valor digitado no campo (método GET)

                                                                                    var url = "busca_endereco.php?tipo_busca=bairro&cidade=" + cidade;

// Chamada do método open para processar a requisição
                                                                                    req.open("Get", url, true);
                                                                                    req.setRequestHeader("Cache-Control", "no-cache,no-store");
                                                                                    req.setRequestHeader("Pragma", "no-cache");

// Quando o objeto recebe o retorno, chamamos a seguinte função;
                                                                                    req.onreadystatechange = function() {

// Exibe a mensagem "Buscando Noticias..." enquanto carrega
                                                                                        if (req.readyState == 1) {
                                                                                            document.getElementById('bairrolocal').innerHTML = '<option >buscando</option>';
                                                                                        }

// Verifica se o Ajax realizou todas as operações corretamente
                                                                                        if (req.readyState == 4 && req.status == 200) {

// Resposta retornada pelo busca.php
                                                                                            var resposta = req.responseText;

// Abaixo colocamos a(s) resposta(s) na div resultado
                                                                                            document.getElementById('bairrolocal').innerHTML = resposta;
                                                                                        }
                                                                                    }
                                                                                    req.send(null);
                                                                                    req.setRequestHeader("Cache-Control", "no-cache");
                                                                                    req.setRequestHeader("Pragma", "no-cache");

                                                                                }
                                                                            </script>


                                                                            <div name='endereco_empresa' id='endereco_empresa'>

                                                                            </div>
                                                                            <div class="form-row" >
                                                                                <div class="label"></div>
                                                                                <div class="input-container" style='width:546px;'>		
                                                                                    <a  href="#dados_vaga"  class="sendBtn2" Onclick="endereco_empresa('oi');"> &#9668; Anterior</a>	
                                                                                    <a  href="#BENEFiCIOS" class="sendBtn"  Onclick="ond_entrevistaa('00001');" >Próximo &#9658;</a>	

                                                                                </div>
                                                                            </div >
                                                                            <!--fim---endereco vaga-->



                                                                        </div>



                                                                        <div name='BENEFiCIOS' id='BENEFiCIOS'>				

                                                                            <div style='margin:20px;width:100%;' align='center'>
                                                                                <font style='font-size:15px;color:red;font-weight:bold;'>Passo 1 &#10132; </font>
                                                                                <font style='font-size:15px;color:red;font-weight:bold;'>Passo 2 &#10132; </font>
                                                                                <font style='font-size:15px;color:red;font-weight:bold;'>Passo 3 &#10132; </font>
                                                                                <font style='font-size:15px;color:#999;font-weight:bold;'>Passo 4 &#10132; </font>
                                                                                <font style='font-size:15px;color:#999;font-weight:bold;'>Passo 5 </font>
                                                                            </div>
                                                                            <h2>SALÁRIOS
                                                                            </h2>
                                                                            <script type="text/javascript">
                                                                                $(function() {
                                                                                    $("#salario").maskMoney({symbol: 'R$ ', showSymbol: true, thousands: '.', decimal: ',', symbolStay: true});

                                                                                })
                                                                            </script>
                                                                            <div class="form-row">
                                                                                <div class="label">Salário Fixo </div>
                                                                                <div class="input-container" style='width:546px;'>		
                                                                                    <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="salario" value='<?= $salario; ?>' id="salario" class="input req-same" maxlength="10" onkeydown="EditandoRegistro()" onkeyup="VerificaMascara('window.document.Ficha.salario', '###.###.###,##', 0);"  tabindex="32" type="text">
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-row">
                                                                                <div class="label">Comissão</div>
                                                                                <div class="input-container" style='width:546px;'>		
                                                                                    <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="comissao" value='<?= $comissao; ?>'  id="comissao" class="input req-same" maxlength="20" onkeydown="EditandoRegistro()" tabindex="33" type="text">
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-row">
                                                                                <div class="label">Prospecção</div>
                                                                                <div class="input-container" style='width:546px;'>		
                                                                                    <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="prospeccao"  value='<?= $prospeccao; ?>' id="prospeccao" class="input req-same"maxlength="20" onkeydown="EditandoRegistro()"  tabindex="34" type="text">
                                                                                </div>
                                                                            </div>

                                                                            <h2>BENEFÍCIOS</h2>

                                                                            <div class="form-row">
                                                                                <div class="label"></div>
                                                                                <div class="input-container" style='width:546px;'>		
                                                                                    <table style="width:100%;" align="left" border="0">
                                                                                        <tbody>
                                                                                            <tr  align="left">
                                                                                                <td>
                                                                                                    <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="cartaoalimentacao"  value='S'id="cartaoalimentacao" <?if($cartaoalimentacao=="S"){echo"checked=''";}else{}?>onclick="EditandoRegistro()" tabindex="35" type="Checkbox" />
                                                                                                           Cartão Alimentação
                                                                                            </td>
                                                                                            <td>
                                                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="planosaude" value='S'id="planosaude" <?if($planosaude=="S"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="36" type="Checkbox">
                                                                                                       Plano de Saúde
                                                                                        </td>
                                                                                        <td>
                                                                                            <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="carteiraassinada" value='S'id="carteiraassinada"  <?if($carteiraassinada=="S"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="37" type="Checkbox">
                                                                                                   Carteira Assinada
                                                                                    </td>
                                                                                </tr>
                                                                                <tr align="left">
                                                                                    <td>
                                                                                        <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="alimentacaolocal" value='S'id="alimentacaolocal" <?if($alimentacaolocal=="S"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="38" type="Checkbox">
                                                                                               Alimentação no Local
                                                                                </td>
                                                                                <td>
                                                                                    <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="planoodonto" value='S'id="planoodonto" <?if($planoodonto=="S"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="39" type="Checkbox">
                                                                                           Plano Odontológico
                                                                            </td>
                                                                            <td>
                                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="valetransporte" value='S'id="valetransporte" <?if($valetransporte=="S"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="40" type="Checkbox">
                                                                                       Vale Transporte
                                                                        </td>
                                                                    </tr>
                                                                    <tr align="left">
                                                                        <td>
                                                                            <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="lanche" value='S'id="lanche" <?if($lanche=="S"){echo"checked=''";}else{}?>  onclick="EditandoRegistro()" tabindex="41" type="Checkbox">
                                                                                   Lanche
                                                                    </td>
                                                                    <td>
                                                                        <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="segurovida" value='S'id="segurovida" <?if($segurovida=="S"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="42" type="Checkbox">
                                                                               Seguro de Vida
                                                                </td>
                                                                <td>
                                                                    <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="premiacao" value='S'id="premiacao" <?if($premiacao=="S"){echo"checked=''";}else{}?>  onclick="EditandoRegistro()" tabindex="43" type="Checkbox">
                                                                           Premiação
                                                            </td>
                                                        </tr>
                                                        <tr align="left">
                                                            <td>
                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="cestabasica" value='S'id="cestabasica" <?if($cestabasica=="S"){echo"checked=''";}else{}?> onclick="EditandoRegistro()" tabindex="44" type="Checkbox">
                                                                       Cesta Básica
                                                        </td>
                                                        <td colspan="2" align="right">
                                                            Outros Beneficios
                                                            <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="outrosbeneficios" value='<?= $outrosbeneficios; ?>' id="outrosbeneficios" maxlength="70" onkeydown="EditandoRegistro()" class="input req-same" onchange="Maiuscula(this)" style="width:250px;" tabindex="45" type="text">
                                                        </td>
                                                    </tr>
                                                </tbody></table>
                                        </div>
                                    </div>




                                    <div class="form-row" >
                                        <div class="label"></div>
                                        <div class="input-container" style='width:546px;'>		
                                            <a  href="#local_vaga"  class="sendBtn2"> &#9668; Anterior</a>	
                                            <a  href="#requisito" class="sendBtn"  >Próximo &#9658;</a>	

                                        </div>
                                    </div >


                                </div>		












                                <div name='requisito' id='requisito'>


                                    <div style='margin:20px;width:100%;' align='center'>
                                        <font style='font-size:15px;color:red;font-weight:bold;'>Passo 1 &#10132; </font>
                                        <font style='font-size:15px;color:red;font-weight:bold;'>Passo 2 &#10132; </font>
                                        <font style='font-size:15px;color:red;font-weight:bold;'>Passo 3 &#10132; </font>
                                        <font style='font-size:15px;color:red;font-weight:bold;'>Passo 4 &#10132; </font>
                                        <font style='font-size:15px;color:#999;font-weight:bold;'>Passo 5 </font>
                                    </div>								
                                    <h2>Requisitos</h2>



                                    <div class="form-row">
                                        <div class="label"></div>
                                        <div class="input-container" style='width:590px;'>		

                                            <table style="width:100%;" align="left" border="0">
                                                <tbody><tr align="left" >
                                                        <td colspan="2" align="left" >
                                                            <h2>Requisitos</h2>

                                                        </td>
                                                        <td  align="left"  >
                                                            <h2>Importância</h2>
                                                        </td>
                                                    </tr>
                                                    <tr align="left" >
                                                        <td style="width:200px;">
                                                            Tempo de Experiência <font class='simbolo'>&#10045;</font>
                                                        </td>
                                                        <td align="left">
                                                            Anos
                                                            <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="tempoano"  value='<?= $tempoano; ?>'  class="input req-same" id="tempoano" maxlength="10" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.tempoano');" style="width:28px;" tabindex="46" type="text">
                                                                Meses
                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="tempomes"  value='<?= $tempomes; ?>'  class="input req-same" id="tempomes" maxlength="10" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.tempomes');" style="width:28px;" tabindex="47" type="text">
                                                                    Comprovada 
                                                                    <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="comprovada"  id="comprovada" tabindex="48" value='S' <?if($comprovada=="S"){echo"checked=''";}else{}?> type="Checkbox">
                                                                           </td>
                                                                        <td style="width:90px;" align="center">
                                                                            <select name="importanciatempo" id="importanciatempo" onchange="EditandoRegistro()" style="width:85px;" tabindex="49">


                                                                                <?
                                                                                switch ($importanciatempo){										
                                                                                case "D":											
                                                                                $importanciatempo_N = "Desejável";
                                                                                break;

                                                                                case "I":											
                                                                                $importanciatempo_N = "Imprescindível";
                                                                                break;
                                                                                }
                                                                                ?>
                                                                                <option value="<?= $importanciatempo; ?>"><?= $importanciatempo_N; ?></option>
                                                                                <option value="D">Desejável</option>
                                                                                <option value="I">Imprescindível</option>
                                                                            </select>
                                                                        </td>
                                                                        </tr>
                                                                        <tr align="left" >
                                                                            <td style="width:200px;">
                                                                                Idade do Candidato
                                                                            </td>
                                                                            <td align="left">
                                                                                Mínima
                                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="idademinima" value="<?if($idademinima==""){echo"0";}else{echo"$idademinima";};?>"class="input req-same"id="idademinima" required='' value='0'maxlength="2" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.idademinima');" style="width:28px;" tabindex="50" type="text">
                                                                                    Máxima
                                                                                    <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="idademaxima" value="<?if($idademaxima==""){echo"0";}else{echo"$idademaxima";};?>" class="input req-same" id="idademaxima" required='' value='0' maxlength="2" onkeydown="EditandoRegistro()" onkeyup="verificaNumero('window.document.Ficha.idademaxima');" style="width:28px;" tabindex="51" type="text">
                                                                                        </td>
                                                                                        <td style="width:90px;" align="center">
                                                                                            <select name="importanciaidade" id="importanciaidade" onchange="EditandoRegistro()" style="width:85px;" tabindex="52">
                                                                                                <?
                                                                                                switch ($importanciaidade){										
                                                                                                case "D":											
                                                                                                $importanciaidade_N = "Desejável";
                                                                                                break;

                                                                                                case "I":											
                                                                                                $importanciaidade_N = "Imprescindível";
                                                                                                break;
                                                                                                }
                                                                                                ?>
                                                                                                <option value="<?= $importanciaidade; ?>"><?= $importanciaidade_N; ?></option>
                                                                                                <option value="D">Desejável</option>
                                                                                                <option value="I">Imprescindível</option>
                                                                                            </select>
                                                                                        </td>
                                                                                        </tr>
                                                                                        <tr align="left" >
                                                                                            <td>
                                                                                                Escolaridade / Situação <font class='simbolo'><font class='simbolo'>&#10045;</font></font>
                                                                                            </td>
                                                                                            <td align="left">
                                                                                                <select name="escolaridade" id="escolaridade" onchange="EditandoRegistro()" required='' style="width:90px;" tabindex="53">
                                                                                                    <?
                                                                                                    switch ($escolaridade){										
                                                                                                    case "F":											
                                                                                                    $escolaridade_N = "Fundamental";
                                                                                                    break;

                                                                                                    case "M":											
                                                                                                    $escolaridade_N = "Médio";
                                                                                                    break;

                                                                                                    case "P":											
                                                                                                    $escolaridade_N = "Pós-Médio";
                                                                                                    break;

                                                                                                    case "S":											
                                                                                                    $escolaridade_N = "Superior";
                                                                                                    break;
                                                                                                    }
                                                                                                    ?>

                                                                                                    <option value="<?= $escolaridade; ?>"><?= $escolaridade_N; ?></option>
                                                                                                    <option value="F">Fundamental</option>
                                                                                                    <option value="M">Médio</option>
                                                                                                    <option value="P">Pós-Médio</option>
                                                                                                    <option value="S">Superior</option>
                                                                                                </select>


                                                                                                <select name="escolaridadesituacao" id="escolaridadesituacao" onchange="EditandoRegistro()" required='' style="width:90px;" tabindex="54">

                                                                                                    <?
                                                                                                    switch ($escolaridadesituacao){										
                                                                                                    case "I":											
                                                                                                    $escolaridadesituacao_N = "Incompleto";
                                                                                                    break;

                                                                                                    case "U":											
                                                                                                    $escolaridadesituacaoe_N = "Cursando";
                                                                                                    break;

                                                                                                    case "C":											
                                                                                                    $escolaridadesituacao_N = "Completo";
                                                                                                    break;


                                                                                                    }
                                                                                                    ?>
                                                                                                    <option value="<?= $escolaridadesituacao; ?>"><?= $escolaridadesituacao_N; ?></option>
                                                                                                    <option value="I">Incompleto</option>
                                                                                                    <option value="U">Cursando</option>
                                                                                                    <option value="C">Completo</option>
                                                                                                </select>
                                                                                            </td>
                                                                                            <td style="width:90px;" align="center">
                                                                                                <select name="importanciaescolaridade" id="importanciaescolaridade" onchange="EditandoRegistro()" required='' style="width:85px;" tabindex="55">

                                                                                                    <?
                                                                                                    switch ($importanciaescolaridade){										
                                                                                                    case "D":											
                                                                                                    $importanciaescolaridade_N = "Desejável";
                                                                                                    break;

                                                                                                    case "I":											
                                                                                                    $importanciaescolaridade_N = "Imprescindível";
                                                                                                    break;
                                                                                                    }
                                                                                                    ?>
                                                                                                    <option value="<?= $importanciaescolaridade; ?>"><?= $importanciaescolaridade_N; ?></option>
                                                                                                    <option value="D">Desejável</option>
                                                                                                    <option value="I">Imprescindível</option>
                                                                                                </select>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr align="left" >
                                                                                            <td>
                                                                                                Categoria CNH
                                                                                            </td>
                                                                                            <td align="left">
                                                                                                <select name="cnh" id="cnh" onchange="EditandoRegistro()" style="width:90px;" tabindex="56">
                                                                                                    <option value="<?= $cnh; ?>"><?= $cnh; ?></option>
                                                                                                    <option value="A">A</option>
                                                                                                    <option value="B">B</option>
                                                                                                    <option value="C">C</option>
                                                                                                    <option value="D">D</option>
                                                                                                    <option value="E">E</option>
                                                                                                    <option value="AB">AB</option>
                                                                                                    <option value="AC">AC</option>
                                                                                                    <option value="AD">AD</option>
                                                                                                    <option value="AE">AE</option>
                                                                                                </select>

                                                                                            </td>
                                                                                            <td style="width:90px;" align="center">
                                                                                                <select name="importanciacnh" id="importanciacnh" onchange="EditandoRegistro()" style="width:85px;" tabindex="57">

                                                                                                    <?
                                                                                                    switch ($importanciacnh){										
                                                                                                    case "D":											
                                                                                                    $importanciacnh_N = "Desejável";
                                                                                                    break;

                                                                                                    case "I":											
                                                                                                    $importanciacnh_N = "Imprescindível";
                                                                                                    break;
                                                                                                    }
                                                                                                    ?>
                                                                                                    <option value="<?= $importanciacnh; ?>"><?= $importanciacnh_N; ?></option>
                                                                                                    <option value="D">Desejável</option>
                                                                                                    <option value="I">Imprescindível</option>
                                                                                                </select>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr align="left" >
                                                                                            <td>
                                                                                                Gênero <font class='simbolo'><font class='simbolo'>&#10045;</font></font>
                                                                                            </td>
                                                                                            <td align="left">
                                                                                                <select name="sexo" required='' id="sexo" onchange="EditandoRegistro()" style="width:90px;" tabindex="58">

                                                                                                    <?
                                                                                                    switch ($sexo){										
                                                                                                    case "F":											
                                                                                                    $sexo_N = "Masculino";
                                                                                                    break;

                                                                                                    case "M":											
                                                                                                    $sexo_N = "Feminino";
                                                                                                    break;
                                                                                                    case "A":											
                                                                                                    $sexo_N = "Ambos";
                                                                                                    break;
                                                                                                    }
                                                                                                    ?>
                                                                                                    <option value="<?= $sexo; ?>"><?= $sexo_N; ?></option>																			
                                                                                                    <option value="F">Masculino</option>
                                                                                                    <option value="M">Feminino</option>
                                                                                                    <option value="A">Ambos</option>
                                                                                                </select>

                                                                                            </td>
                                                                                            <td style="width:90px;" align="center">
                                                                                                <select name="importanciasexo" required='' id="importanciasexo" onchange="EditandoRegistro()" style="width:85px;" tabindex="59">

                                                                                                    <?
                                                                                                    switch ($importanciasexo){										
                                                                                                    case "D":											
                                                                                                    $importanciasexo_N = "Desejável";
                                                                                                    break;

                                                                                                    case "I":											
                                                                                                    $importanciasexo_N = "Imprescindível";
                                                                                                    break;
                                                                                                    }
                                                                                                    ?>
                                                                                                    <option value="<?= $importanciasexo; ?>"><?= $importanciasexo_N; ?></option>
                                                                                                    <option value="D">Desejável</option>
                                                                                                    <option value="I">Imprescindível</option>
                                                                                                </select>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr align="left" >
                                                                                            <td>
                                                                                                Estado Civil <font class='simbolo'><font class='simbolo'>&#10045;</font></font>
                                                                                            </td>
                                                                                            <td align="left">
                                                                                                <select name="estadocivil" id="estadocivil"  required=''onchange="EditandoRegistro()" style="width:90px;" tabindex="60">

                                                                                                    <?
                                                                                                    switch ($estadocivil){										
                                                                                                    case "S":											
                                                                                                    $estadocivil_N = "Solteiro";
                                                                                                    break;case "C":											
                                                                                                    $estadocivil_N = "Casado";
                                                                                                    break;case "U":											
                                                                                                    $estadocivil_N = "União Estável";
                                                                                                    break;case "E":											
                                                                                                    $estadocivil_N = "Desquitado";
                                                                                                    break;case "D":											
                                                                                                    $estadocivil_N = "Divorciado";
                                                                                                    break;case "V":											
                                                                                                    $estadocivil_N = "Viúvo";
                                                                                                    break;case "O":											
                                                                                                    $estadocivil_N = "Outro";
                                                                                                    break;


                                                                                                    }
                                                                                                    ?>
                                                                                                    <option value="<?= $estadocivil; ?>"><?= $estadocivil_N; ?></option>
                                                                                                    <?if($estadocivil==""){?>
                                                                                                    <option value="O" selected>--</option>
                                                                                                    <?}else{}?>
                                                                                                    <option value="S">Solteiro</option>
                                                                                                    <option value="C">Casado</option>
                                                                                                    <option value="U">União Estável</option>
                                                                                                    <option value="E">Desquitado</option>
                                                                                                    <option value="D">Divorciado</option>
                                                                                                    <option value="V">Viúvo</option>
                                                                                                    <option value="O">Outro</option>
                                                                                                </select>

                                                                                            </td>
                                                                                            <td style="width:90px;" align="center">
                                                                                                <select name="importanciaestadocivil" required='' id="importanciaestadocivil" onchange="EditandoRegistro()" style="width:85px;" tabindex="61">

                                                                                                    <?
                                                                                                    switch ($importanciaestadocivil){										
                                                                                                    case "D":											
                                                                                                    $importanciaestadocivil_N = "Desejável";
                                                                                                    break;

                                                                                                    case "I":											
                                                                                                    $importanciaestadocivil_N = "Imprescindível";
                                                                                                    break;
                                                                                                    }
                                                                                                    ?>
                                                                                                    <option value="<?= $importanciaestadocivil; ?>"><?= $importanciaestadocivil_N; ?></option>
                                                                                                    <?if($importanciaestadocivil==""){?>
                                                                                                    <option value="D" selected>--</option>
                                                                                                    <?}else{}?>
                                                                                                    <option value="D">Desejável</option>
                                                                                                    <option value="I">Imprescindível</option>
                                                                                                </select>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr align="left" >
                                                                                            <td>

                                                                                            </td>
                                                                                            <td align="left">

                                                                                            </td>
                                                                                            <td style="width:90px;" align="center">

                                                                                            </td>
                                                                                        </tr>



                                                                                        <tr align="left" >
                                                                                            <td colspan="3">
                                                                                                Aceita sem Experiência
                                                                                                <input onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" onChange="javascript:this.value = this.value.toUpperCase();" name="aceitasemexperiencia" value='S'id="aceitasemexperiencia"  <?if($aceitasemexperiencia=="S"){echo"checked=''";}else{}?>  onchange="EditandoRegistro()" tabindex="70" type="Checkbox">
                                                                                        </td>
                                                                                    </tr>


                                                                                    </tbody></table>

                                                                                    </div>
                                                                                    </div>




                                                                                    <div class="form-row">
                                                                                        <h2>INFORMÁTICA</h2>

                                                                                        <div class="label">1 - Programa</div>
                                                                                        <div class="input-container" style='width:546px;'>		
                                                                                            <select name="softwareid1" id="softwareid1" onchange="EditandoRegistro1()" tabindex="3" style="width:465px;">

                                                                                                <?
                                                                                                $query_software1 = "SELECT * FROM `software`where id='$softwareid1'";
                                                                                                $rs_software1    = mysql_query($query_software1);
                                                                                                while($campo_software1 = mysql_fetch_array($rs_software1)){																						
                                                                                                $nome_soft1 	= $campo_software1['nome']; 	
                                                                                                }
                                                                                                ?>																						
                                                                                                <option value="<?= $softwareid1; ?>"  ><?= $nome_soft1; ?></option>


                                                                                                <?
                                                                                                $query_noticias_hcs = "SELECT * FROM `software`ORDER BY `software`.`nome` ASC";
                                                                                                $rs_noticias_hcs    = mysql_query($query_noticias_hcs);
                                                                                                while($campo_noticias_hcs = mysql_fetch_array($rs_noticias_hcs)){
                                                                                                $id_soft 	= $campo_noticias_hcs['id']; 	
                                                                                                $soft 	= $campo_noticias_hcs['nome']; 	
                                                                                                ?>
                                                                                                <option value="<?= $id_soft; ?>"><?= $soft; ?></option>
                                                                                                <?}?>

                                                                                            </select>

                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-row">	

                                                                                        <div class="label">2 - Programa</div>
                                                                                        <div class="input-container" style='width:546px;'>		
                                                                                            <select name="softwareid2" id="softwareid2" onchange="EditandoRegistro1()" tabindex="3" style="width:465px;">

                                                                                                <?
                                                                                                $query_software2 = "SELECT * FROM `software`where id='$softwareid2'";
                                                                                                $rs_software2    = mysql_query($query_software2);
                                                                                                while($campo_software2 = mysql_fetch_array($rs_software2)){																						
                                                                                                $nome_soft2 	= $campo_software2['nome']; 	
                                                                                                }
                                                                                                ?>	

                                                                                                <option value="<?= $softwareid2; ?>"  ><?= $nome_soft2; ?></option>
                                                                                                <?
                                                                                                $query_noticias_hcs2 = "SELECT * FROM `software`ORDER BY `software`.`nome` ASC";
                                                                                                $rs_noticias_hcs2    = mysql_query($query_noticias_hcs2);
                                                                                                while($campo_noticias_hcs2 = mysql_fetch_array($rs_noticias_hcs2)){
                                                                                                $id_soft2 	= $campo_noticias_hcs2['id']; 	
                                                                                                $soft2 	= $campo_noticias_hcs2['nome']; 	
                                                                                                ?>
                                                                                                <option value="<?= $id_soft2; ?>"><?= $soft2; ?></option>
                                                                                                <?}?>

                                                                                            </select>

                                                                                        </div>

                                                                                    </div>	
                                                                                    <div class="form-row">	
                                                                                        <div class="label">3 - Programa</div>
                                                                                        <div class="input-container" style='width:546px;'>		
                                                                                            <select name="softwareid3" id="softwareid3" onchange="EditandoRegistro1()" tabindex="3" style="width:465px;">

                                                                                                <?
                                                                                                $query_software3 = "SELECT * FROM `software`where id='$softwareid3'";
                                                                                                $rs_software3    = mysql_query($query_software3);
                                                                                                while($campo_software3 = mysql_fetch_array($rs_software3)){																						
                                                                                                $nome_soft3 	= $campo_software3['nome']; 	
                                                                                                }
                                                                                                ?>	


                                                                                                <option value="<?= $softwareid3; ?>"  ><?= $nome_soft3; ?></option>
                                                                                                <?
                                                                                                $query_noticias_hcs3 = "SELECT * FROM `software`ORDER BY `software`.`nome` ASC";
                                                                                                $rs_noticias_hcs3    = mysql_query($query_noticias_hcs3);
                                                                                                while($campo_noticias_hcs3 = mysql_fetch_array($rs_noticias_hcs3)){
                                                                                                $id_soft3 	= $campo_noticias_hcs3['id']; 	
                                                                                                $soft3 	= $campo_noticias_hcs3['nome']; 	
                                                                                                ?>
                                                                                                <option value="<?= $id_soft3; ?>"><?= $soft3; ?></option>
                                                                                                <?}?>

                                                                                            </select>

                                                                                        </div>
                                                                                    </div>		







                                                                                    <div class="form-row">
                                                                                        <h2>IDIOMAS</h2>


                                                                                        <div class="input-container" style='width:546px;margin-left:79px;' >		

                                                                                            <table align='left'>

                                                                                                <tr>
                                                                                                    <td align='left'>Idioma</td>
                                                                                                    <td align='left'>Leitura</td>
                                                                                                    <td align='left'>Escrita</td>
                                                                                                    <td align='left'>Conversação</td>
                                                                                                </tr>

                                                                                                <tr>
                                                                                                    <td>
                                                                                                        <select name='idiomaid1' style='width:150px;'>

                                                                                                            <?
                                                                                                            $query_idiomaid1 = "SELECT * FROM `idioma` where id='$idiomaid1'";
                                                                                                            $rs_idiomaid1    = mysql_query($query_idiomaid1);
                                                                                                            while($campo_idiomaid1 = mysql_fetch_array($rs_idiomaid1)){																						
                                                                                                            $nome_idiomaid1 	= $campo_idiomaid1['nome']; 	
                                                                                                            }
                                                                                                            ?>	

                                                                                                            <option value="<?= $idiomaid1; ?>"  ><?= $nome_idiomaid1; ?></option>
                                                                                                            <?
                                                                                                            $query_noticias_hcs3i = "SELECT * FROM `idioma` ORDER BY `idioma`.`nome` ASC";
                                                                                                            $rs_noticias_hcs3i    = mysql_query($query_noticias_hcs3i);
                                                                                                            while($campo_noticias_hcs3i = mysql_fetch_array($rs_noticias_hcs3i)){
                                                                                                            $idiomaid11 	= $campo_noticias_hcs3i['id']; 	
                                                                                                            $nome_idioma1 	= $campo_noticias_hcs3i['nome']; 	
                                                                                                            ?>
                                                                                                            <option value="<?= $idiomaid11; ?>"><?= $nome_idioma1; ?></option>
                                                                                                            <?}?>

                                                                                                        </select>
                                                                                                    </td>

                                                                                                    <?
                                                                                                    switch ($leitura1){										
                                                                                                    case "B":											
                                                                                                    $leitura1_N = "Básica";
                                                                                                    break;case "I":											
                                                                                                    $leitura1_N = "Intermediária";
                                                                                                    break;case "A":											
                                                                                                    $leitura1_N = "Avançada";
                                                                                                    break;case "F":											
                                                                                                    $leitura1_N = "Fluente";
                                                                                                    break;
                                                                                                    }

                                                                                                    switch ($escrita1){										
                                                                                                    case "B":											
                                                                                                    $escrita1_N = "Básica";
                                                                                                    break;case "I":											
                                                                                                    $escrita1_N = "Intermediária";
                                                                                                    break;case "A":											
                                                                                                    $escrita1_N = "Avançada";
                                                                                                    break;case "F":											
                                                                                                    $escrita1_N = "Fluente";
                                                                                                    break;
                                                                                                    }

                                                                                                    switch ($conversacao1){										
                                                                                                    case "B":											
                                                                                                    $conversacao1_N = "Básica";
                                                                                                    break;case "I":											
                                                                                                    $conversacao1_N = "Intermediária";
                                                                                                    break;case "A":											
                                                                                                    $conversacao1_N = "Avançada";
                                                                                                    break;case "F":											
                                                                                                    $conversacao1_N = "Fluente";
                                                                                                    break;
                                                                                                    }


                                                                                                    ?>
                                                                                                    <td><select style='width:150px;' name='leitura1'><option value='<?= $leitura1; ?>'><?= $leitura1_N; ?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
                                                                                                    <td><select style='width:150px;' name='escrita1'><option value='<?= $escrita1; ?>'><?= $escrita1_N; ?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
                                                                                                    <td><select style='width:150px;' name='conversacao1'><option value='<?= $conversacao1; ?>'><?= $conversacao1_N; ?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
                                                                                                </tr>


                                                                                                <tr>
                                                                                                    <td>
                                                                                                        <select name='idiomaid2' style='width:150px;'>
                                                                                                            <?
                                                                                                            $query_idiomaid2 = "SELECT * FROM `idioma`where id='$idiomaid2'";
                                                                                                            $rs_idiomaid2    = mysql_query($query_idiomaid2);
                                                                                                            while($campo_idiomaid2d = mysql_fetch_array($rs_idiomaid2)){																						
                                                                                                            $nome_idiomaid2 	= $campo_idiomaid2d['nome']; 	
                                                                                                            }
                                                                                                            ?>	

                                                                                                            <option value="<?= $idiomaid2; ?>"  ><?= $nome_idiomaid2; ?></option>
                                                                                                            <?
                                                                                                            $query_noticias_hcs3i2 = "SELECT * FROM `idioma` ORDER BY `idioma`.`nome` ASC";
                                                                                                            $rs_noticias_hcs3i2    = mysql_query($query_noticias_hcs3i2);
                                                                                                            while($campo_idiomaid2 = mysql_fetch_array($rs_noticias_hcs3i2)){
                                                                                                            $idiomaid22 	= $campo_idiomaid2['id']; 
                                                                                                            $nome_idioma2 	= $campo_idiomaid2['nome']; 																						
                                                                                                            ?>
                                                                                                            <option value="<?= $idiomaid22; ?>"><?= $nome_idioma2; ?></option>
                                                                                                            <?}?>

                                                                                                        </select>
                                                                                                    </td>

                                                                                                    <?
                                                                                                    switch ($leitura2){										
                                                                                                    case "B":											
                                                                                                    $leitura2_N = "Básica";
                                                                                                    break;case "I":											
                                                                                                    $leitura2_N = "Intermediária";
                                                                                                    break;case "A":											
                                                                                                    $leitura2_N = "Avançada";
                                                                                                    break;case "F":											
                                                                                                    $leitura2_N = "Fluente";
                                                                                                    break;
                                                                                                    }

                                                                                                    switch ($escrita2){										
                                                                                                    case "B":											
                                                                                                    $escrita2_N = "Básica";
                                                                                                    break;case "I":											
                                                                                                    $escrita2_N = "Intermediária";
                                                                                                    break;case "A":											
                                                                                                    $escrita2_N = "Avançada";
                                                                                                    break;case "F":											
                                                                                                    $escrita2_N = "Fluente";
                                                                                                    break;
                                                                                                    }

                                                                                                    switch ($conversacao2){										
                                                                                                    case "B":											
                                                                                                    $conversacao2_N = "Básica";
                                                                                                    break;case "I":											
                                                                                                    $conversacao2_N = "Intermediária";
                                                                                                    break;case "A":											
                                                                                                    $conversacao2_N = "Avançada";
                                                                                                    break;case "F":											
                                                                                                    $conversacao2_N = "Fluente";
                                                                                                    break;
                                                                                                    }


                                                                                                    ?>
                                                                                                    <td><select style='width:150px;' name='leitura2'><option value='<?= $leitura2; ?>'><?= $leitura2_N; ?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
                                                                                                    <td><select style='width:150px;' name='escrita2'><option value='<?= $escrita2; ?>'><?= $escrita2_N; ?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
                                                                                                    <td><select style='width:150px;' name='conversacao2'><option value='<?= $conversacao2; ?>'><?= $conversacao2_N; ?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
                                                                                                </tr>

                                                                                                <tr>
                                                                                                    <td>
                                                                                                        <select name='idiomaid3' style='width:150px;'>

                                                                                                            <?
                                                                                                            $query_idiomaid3 = "SELECT * FROM `idioma`where id='$idiomaid3'";
                                                                                                            $rs_idiomaid3    = mysql_query($query_idiomaid3);
                                                                                                            while($campo_idiomaid3 = mysql_fetch_array($rs_idiomaid3)){																						
                                                                                                            $nome_idiomaid3 	= $campo_idiomaid3['nome']; 	
                                                                                                            }
                                                                                                            ?>	

                                                                                                            <option value="<?= $idiomaid3; ?>"  ><?= $nome_idiomaid3; ?></option>
                                                                                                            <?
                                                                                                            $query_noticias_hcs3i23 = "SELECT * FROM `idioma` ORDER BY `idioma`.`nome` ASC";
                                                                                                            $rs_noticias_hcs3i23    = mysql_query($query_noticias_hcs3i23);
                                                                                                            while($campo_noticias_hcs3i2 = mysql_fetch_array($rs_noticias_hcs3i23)){
                                                                                                            $idiomaid123 	= $campo_noticias_hcs3i2['id']; 
                                                                                                            $nome_idioma3 	= $campo_noticias_hcs3i2['nome'];

                                                                                                            ?>
                                                                                                            <option value="<?= $idiomaid123; ?>"><?= $nome_idioma3; ?></option>
                                                                                                            <?}?>

                                                                                                        </select>
                                                                                                    </td>

                                                                                                    <?
                                                                                                    switch ($leitura3){										
                                                                                                    case "B":											
                                                                                                    $leitura3_N = "Básica";
                                                                                                    break;case "I":											
                                                                                                    $leitura3_N = "Intermediária";
                                                                                                    break;case "A":											
                                                                                                    $leitura3_N = "Avançada";
                                                                                                    break;case "F":											
                                                                                                    $leitura3_N = "Fluente";
                                                                                                    break;
                                                                                                    }

                                                                                                    switch ($escrita3){										
                                                                                                    case "B":											
                                                                                                    $escrita3_N = "Básica";
                                                                                                    break;case "I":											
                                                                                                    $escrita3_N = "Intermediária";
                                                                                                    break;case "A":											
                                                                                                    $escrita3_N = "Avançada";
                                                                                                    break;case "F":											
                                                                                                    $escrita3_N = "Fluente";
                                                                                                    break;
                                                                                                    }

                                                                                                    switch ($conversacao3){										
                                                                                                    case "B":											
                                                                                                    $conversacao3_N = "Básica";
                                                                                                    break;case "I":											
                                                                                                    $conversacao3_N = "Intermediária";
                                                                                                    break;case "A":											
                                                                                                    $conversacao3_N = "Avançada";
                                                                                                    break;case "F":											
                                                                                                    $conversacao3_N = "Fluente";
                                                                                                    break;
                                                                                                    }


                                                                                                    ?>
                                                                                                    <td><select style='width:150px;' name='leitura3'><option value='<?= $leitura3; ?>'><?= $leitura3_N; ?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
                                                                                                    <td><select style='width:150px;' name='escrita3'><option value='<?= $escrita3; ?>'><?= $escrita3_N; ?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
                                                                                                    <td><select style='width:150px;' name='conversacao3'><option value='<?= $conversacao3; ?>'><?= $conversacao3_N; ?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
                                                                                                </tr>




                                                                                            </table>

                                                                                        </div>
                                                                                    </div>








                                                                                    <div class="form-row" >
                                                                                        <div class="label"></div>
                                                                                        <div class="input-container" style='width:546px;'>		
                                                                                            <a  href="#BENEFiCIOS"  class="sendBtn2"> &#9668; Anterior</a>	
                                                                                            <a  href="#local_entrevista" class="sendBtn"  >Próximo &#9658;</a>	


                                                                                        </div>
                                                                                    </div >												

                                                                                    </div>		












                                                                                    <div name='local_entrevista' id='local_entrevista'>			


                                                                                        <div style='margin:20px;width:100%;' align='center'>
                                                                                            <font style='font-size:15px;color:red;font-weight:bold;'>Passo 1 &#10132; </font>
                                                                                            <font style='font-size:15px;color:red;font-weight:bold;'>Passo 2 &#10132; </font>
                                                                                            <font style='font-size:15px;color:red;font-weight:bold;'>Passo 3 &#10132; </font>
                                                                                            <font style='font-size:15px;color:red;font-weight:bold;'>Passo 4 &#10132; </font>
                                                                                            <font style='font-size:15px;color:red;font-weight:bold;'>Passo 5 </font>
                                                                                        </div>	

                                                                                        <h2>LOCAL ENTREVISTA</h2>


                                                                                        <script  type="text/javascript">
                                                                                            // FUNÇÃO PARA BUSCA NOTICIA
                                                                                            function busca_cidade(valor2) {
                                                                                                // Verificando Browser
                                                                                                if (window.XMLHttpRequest) {
                                                                                                    req = new XMLHttpRequest();
                                                                                                }
                                                                                                else if (window.ActiveXObject) {
                                                                                                    req = new ActiveXObject("Microsoft.XMLHTTP");
                                                                                                }

                                                                                                // Arquivo PHP juntamente com o valor digitado no campo (método GET)

                                                                                                var url = "busca_endereco.php?tipo_busca=cidade&uf=" + valor2;

                                                                                                // Chamada do método open para processar a requisição
                                                                                                req.open("Get", url, true);
                                                                                                req.setRequestHeader("Cache-Control", "no-cache,no-store");
                                                                                                req.setRequestHeader("Pragma", "no-cache");

                                                                                                // Quando o objeto recebe o retorno, chamamos a seguinte função;
                                                                                                req.onreadystatechange = function() {

                                                                                                    // Exibe a mensagem "Buscando Noticias..." enquanto carrega
                                                                                                    if (req.readyState == 1) {
                                                                                                        document.getElementById('txtcidade').innerHTML = '<option >buscando</option>';
                                                                                                    }

                                                                                                    // Verifica se o Ajax realizou todas as operações corretamente
                                                                                                    if (req.readyState == 4 && req.status == 200) {

                                                                                                        // Resposta retornada pelo busca.php
                                                                                                        var resposta = req.responseText;

                                                                                                        // Abaixo colocamos a(s) resposta(s) na div resultado
                                                                                                        document.getElementById('txtcidade').innerHTML = resposta;
                                                                                                    }
                                                                                                }
                                                                                                req.send(null);
                                                                                                req.setRequestHeader("Cache-Control", "no-cache");
                                                                                                req.setRequestHeader("Pragma", "no-cache");

                                                                                            }
                                                                                        </script>


                                                                                        <script  type="text/javascript">
                                                                                            // FUNÇÃO PARA BUSCA NOTICIA
                                                                                            function busca_bairo(cidade) {
                                                                                                // Verificando Browser
                                                                                                if (window.XMLHttpRequest) {
                                                                                                    req = new XMLHttpRequest();
                                                                                                }
                                                                                                else if (window.ActiveXObject) {
                                                                                                    req = new ActiveXObject("Microsoft.XMLHTTP");
                                                                                                }

                                                                                                // Arquivo PHP juntamente com o valor digitado no campo (método GET)

                                                                                                var url = "busca_endereco.php?tipo_busca=bairro&cidade=" + cidade;

                                                                                                // Chamada do método open para processar a requisição
                                                                                                req.open("Get", url, true);
                                                                                                req.setRequestHeader("Cache-Control", "no-cache,no-store");
                                                                                                req.setRequestHeader("Pragma", "no-cache");

                                                                                                // Quando o objeto recebe o retorno, chamamos a seguinte função;
                                                                                                req.onreadystatechange = function() {

                                                                                                    // Exibe a mensagem "Buscando Noticias..." enquanto carrega
                                                                                                    if (req.readyState == 1) {
                                                                                                        document.getElementById('txtbairro').innerHTML = '<option >buscando</option>';
                                                                                                    }

                                                                                                    // Verifica se o Ajax realizou todas as operações corretamente
                                                                                                    if (req.readyState == 4 && req.status == 200) {

                                                                                                        // Resposta retornada pelo busca.php
                                                                                                        var resposta = req.responseText;

                                                                                                        // Abaixo colocamos a(s) resposta(s) na div resultado
                                                                                                        document.getElementById('txtbairro').innerHTML = resposta;
                                                                                                    }
                                                                                                }
                                                                                                req.send(null);
                                                                                                req.setRequestHeader("Cache-Control", "no-cache");
                                                                                                req.setRequestHeader("Pragma", "no-cache");

                                                                                            }
                                                                                        </script>




                                                                                        <script  type="text/javascript">
                                                                                            // FUNÇÃO PARA BUSCA NOTICIA
                                                                                            function busca_cidade_entrevista(valor2) {

                                                                                                // Verificando Browser
                                                                                                if (window.XMLHttpRequest) {
                                                                                                    req = new XMLHttpRequest();
                                                                                                }
                                                                                                else if (window.ActiveXObject) {
                                                                                                    req = new ActiveXObject("Microsoft.XMLHTTP");
                                                                                                }

                                                                                                // Arquivo PHP juntamente com o valor digitado no campo (método GET)

                                                                                                var url = "busca_endereco.php?tipo_busca=cidade&uf=" + valor2;

                                                                                                // Chamada do método open para processar a requisição
                                                                                                req.open("Get", url, true);
                                                                                                req.setRequestHeader("Cache-Control", "no-cache,no-store");
                                                                                                req.setRequestHeader("Pragma", "no-cache");

                                                                                                // Quando o objeto recebe o retorno, chamamos a seguinte função;
                                                                                                req.onreadystatechange = function() {

                                                                                                    // Exibe a mensagem "Buscando Noticias..." enquanto carrega
                                                                                                    if (req.readyState == 1) {
                                                                                                        document.getElementById('cidadeentrevistaid').innerHTML = '<option >buscando</option>';
                                                                                                    }

                                                                                                    // Verifica se o Ajax realizou todas as operações corretamente
                                                                                                    if (req.readyState == 4 && req.status == 200) {

                                                                                                        // Resposta retornada pelo busca.php
                                                                                                        var resposta = req.responseText;

                                                                                                        // Abaixo colocamos a(s) resposta(s) na div resultado
                                                                                                        document.getElementById('cidadeentrevistaid').innerHTML = resposta;
                                                                                                    }
                                                                                                }
                                                                                                req.send(null);
                                                                                                req.setRequestHeader("Cache-Control", "no-cache");
                                                                                                req.setRequestHeader("Pragma", "no-cache");

                                                                                            }
                                                                                        </script>
                                                                                        <div id='lista_local_entrevista' name='lista_local_entrevista'>
                                                                                        </div>


                                                                                        <div class="form-row">
                                                                                            <div class="label">Horário de Atendimento e outros Detalhes <font class='simbolo'><font class='simbolo'>&#10045;</font></font></div>
                                                                                            <div class="input-container" style='width:546px;'>		
                                                                                                <textarea maxlength="400" name="horarioatendimento" required='' value="<?= $horarioatendimento; ?>"  id="horarioatendimento"  style='width:100%;height:50px;'class="input req-same"  rows="3" cols="99" tabindex="83" style="font-size: 12px; font-family: Arial;" onkeyup="funTamanhoCerto('window.document.Ficha.horarioatendimento', 500);" onchange="Maiuscula(this);
                                                                                                        EditandoRegistro();"><?= $horarioatendimento; ?></textarea>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="form-row">
                                                                                            <div class="label">Encaminhar Candidato Via <font class='simbolo'><font class='simbolo'>&#10045;</font></font></div>
                                                                                            <div class="input-container" style='width:546px;'>		
                                                                                                <select name="viaencaminhamento"  required  id="viaencaminhamento" onchange="EditandoRegistro()"  tabindex="84">

                                                                                                    <?
                                                                                                    switch ($viaencaminhamento){										
                                                                                                    case "I":											
                                                                                                    $viaencaminhamento_N = "Ir ao Endereço";
                                                                                                    break;case "L":											
                                                                                                    $viaencaminhamento_N = "Ligar Antes";
                                                                                                    break;case "E":											
                                                                                                    $viaencaminhamento_N = "Email (Currículo)";
                                                                                                    break;
                                                                                                    case "D":											
                                                                                                    $viaencaminhamento_N = "Deixar currículos na SEMTRE";
                                                                                                    break;
                                                                                                    }
                                                                                                    ?>
                                                                                                    <option value="<?= $viaencaminhamento; ?>"><?= $viaencaminhamento_N; ?></option>
                                                                                                    <option value="I">Ir ao Endereço</option>
                                                                                                    <option value="L">Ligar Antes</option>
                                                                                                    <option value="E">Email (Currículo)</option>
                                                                                                    <option value="D">Deixar currículo na SEMTRE</option>
                                                                                                </select>
                                                                                            </div>
                                                                                        </div>





                                                                                        <h2>OBSERVAÇÕES</h2>
                                                                                        <div class="form-row">
                                                                                            <div class="label"></div>
                                                                                            <div class="input-container" style='width:546px;'>		
                                                                                                <textarea maxlength="400" name="observacao" id="observacao" rows="3" cols="99" style='width:100%;height:50px;'class="input req-same"  tabindex="85" style="font-size: 12px; font-family: Arial;" onkeyup="funTamanhoCerto('window.document.Ficha.observacao', 500);" onchange="Maiuscula(this);
                                                                                                        EditandoRegistro();"><?= $observacao; ?></textarea>
                                                                                            </div>
                                                                                        </div>




                                                                                        <div class="form-row">
                                                                                            <div class="label">Status da Vaga </div>
                                                                                            <div class="input-container" style='width:546px;'>		
                                                                                                <select name="status" required id="status" onchange="EditandoRegistro()"  tabindex="86">
                                                                                                    <?
                                                                                                    switch ($status){										
                                                                                                    case "A":											
                                                                                                    $status_N = "Ativa";
                                                                                                    break;case "S":											
                                                                                                    $status_N = "Suspensa";
                                                                                                    break;case "P":											
                                                                                                    $status_N = "Preenchida pelo CTM";
                                                                                                    break;case "O":											
                                                                                                    $status_N = "Preenchida pelo Solicitante";
                                                                                                    break;case "C":											
                                                                                                    $status_N = "Cancelada";
                                                                                                    break;case "E":											
                                                                                                    $status_N = "Encerrada";
                                                                                                    break;case "R":											
                                                                                                    $status_N = "Aguardando Resposta";
                                                                                                    break;case "N":											
                                                                                                    $status_N = "NPFP";						
                                                                                                    break;case "G":											
                                                                                                    $status_N = "Sigilosa";
                                                                                                    break;
                                                                                                    }
                                                                                                    ?>

                                                                                                    <option value="<?= $status; ?>"><?= $status_N; ?></option>
                                                                                                    <option value="A" >Ativa</option>
                                                                                                    <option value="S">Suspensa</option>
                                                                                                    <option value="P">Preenchida pelo CTM</option>
                                                                                                    <option value="O">Preenchida pelo Solicitante</option>
                                                                                                    <option value="C">Cancelada</option>
                                                                                                    <option value="E">Encerrada</option>
                                                                                                    <option value="R">Aguardando Resposta</option>
                                                                                                    <option value="N">NPFP</option>
                                                                                                    <option value="G">Sigilosa</option>
                                                                                                </select>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="form-row">
                                                                                            <div class="label"></div>
                                                                                            <div class="input-container" style='width:546px;'>		
                                                                                                Através de
                                                                                                <select name="formacaptacaoid" required id="formacaptacaoid" onchange="EditandoRegistro()" style="width:235px;" tabindex="88">


                                                                                                    <?
                                                                                                    $query_formacaptacaoid_db = "SELECT * FROM `formacaptacao` where id='$formacaptacaoid'";
                                                                                                    $rs_formacaptacaoid_db    = mysql_query($query_formacaptacaoid_db);
                                                                                                    while($campo_formacaptacaoid_db = mysql_fetch_array($rs_formacaptacaoid_db)){
                                                                                                    $nome_formacaptacao_db       = $campo_formacaptacaoid_db['nome'];							

                                                                                                    ?><?}?>
                                                                                                    <option value="<?= $formacaptacaoid; ?>"><?= $nome_formacaptacao_db; ?></option>


                                                                                                    <?
                                                                                                    $query_formacaptacaoid = "SELECT * FROM `formacaptacao`";
                                                                                                    $rs_formacaptacaoid    = mysql_query($query_formacaptacaoid);
                                                                                                    while($campo_formacaptacaoid = mysql_fetch_array($rs_formacaptacaoid)){
                                                                                                    $nome_formacaptacao       = $campo_formacaptacaoid['nome'];	
                                                                                                    $id_formacaptacao       = $campo_formacaptacaoid['id'];	

                                                                                                    ?>
                                                                                                    <option value="<?= $id_formacaptacao; ?>"><?= $nome_formacaptacao; ?></option>
                                                                                                    <?}?>

                                                                                                </select>
                                                                                                Referência
                                                                                                <select name="localcaptacaoid" required id="localcaptacaoid" onchange="EditandoRegistro()" tabindex="89" style="width:162px;">

                                                                                                    <?
                                                                                                    $query_localcaptacaoid = "SELECT * FROM `localcaptacao` where id='$localcaptacaoid'";
                                                                                                    $rs_localcaptacaoid    = mysql_query($query_localcaptacaoid);
                                                                                                    while($campo_localcaptacaoid = mysql_fetch_array($rs_localcaptacaoid)){
                                                                                                    $nome_localcaptacaoid       = $campo_localcaptacaoid['nome'];	

                                                                                                    ?><?}?>
                                                                                                    <option value="<?= $localcaptacaoid; ?>"><?= $nome_localcaptacaoid; ?></option>


                                                                                                    <?
                                                                                                    $query_noticiascp2l = "SELECT * FROM `localcaptacao` ORDER BY `localcaptacao`.`nome` ASC";
                                                                                                    $rs_noticiascp2l    = mysql_query($query_noticiascp2l);
                                                                                                    while($campo_noticiascp2l = mysql_fetch_array($rs_noticiascp2l)){
                                                                                                    $nome_localcaptacao       = $campo_noticiascp2l['nome'];	
                                                                                                    $id_localcaptacao       = $campo_noticiascp2l['id'];
                                                                                                    ?>
                                                                                                    <option value="<?= $id_localcaptacao; ?>"><?= $nome_localcaptacao; ?></option>
                                                                                                    <?}?>
                                                                                                </select>
                                                                                            </div>
                                                                                        </div>





                                                                                        <div class="form-row" >
                                                                                            <div class="label"></div>
                                                                                            <div class="input-container" style='width:546px;'>		
                                                                                                <a  href="#requisito"  class="sendBtn2"> &#9668; Anterior</a>	


                                                                                                <script type="text/javascript">

                                                                                                    var tempo1 = window.setInterval(carrega, 900000);
                                                                                                    function carrega()
                                                                                                    {
                                                                                                        $('#mensagem').load("menssagem_form.php");

                                                                                                    }
                                                                                                </script>
                                                                                                

                                                                                            </div>
                                                                                        </div >

                                                                                        <div class="form-row" >
                                                                                            <div class="label"></div>
                                                                                            <div class="input-container" style='width:546px;'>		


                                                                                                <div id='mensagem' name='mensagem'></div>

                                                                                            </div>
                                                                                        </div >


                                                                                    </div>		












                                                                                    </div>






                                                                                    </form>

                                                                                    </td>	

                                                                                    </tr>
                                                                                    </table>

                                                                                    </div>



                                                                                    <script type="text/javascript" src="jquery.idTabs.min.js"></script>

                                                                                    <script type="text/javascript">
                                                                                                    $('div.abas').click(function() {
                                                                                                        $('div.abas').removeClass("abas_ative");
                                                                                                        $(this).addClass("abas_ative");
                                                                                                    });
                                                                                    </script>



                                                                                    </body>
                                                                                    </html>
