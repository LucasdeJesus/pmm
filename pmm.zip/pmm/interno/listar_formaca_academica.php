<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body >




						
						
						<div class='conteudo_centro'width='99%' >

								<div style='border: 0px none; position: fixed; width: 100%; margin-top: -6px;'>
									<table border='0'width='99%' >
										<tr>
											<td class='td1'width='5%'>Nº</td>
											<td class='td1' width='75%'>Formação Acadêmica </td>
											<td class='td1'width=''>Função</td>
										</tr>
									</table>
								</div>

								<div style='margin-top: 15px;'>
									<table border='0'width='99%'>
									
									<?
									$numero=1;
									$query_noticias = "SELECT * FROM `formacao_academica` ORDER BY `formacao_academica`.`nome` ASC";
									$rs_noticias    = mysql_query($query_noticias);
									while($campo_noticias = mysql_fetch_array($rs_noticias)){

									$nome       = $campo_noticias['nome'];					
									$id_captadores       = $campo_noticias['id_captadores'];					
									?>
										<tr class='tr_tb' >
											<td class='td2'width='5%'><?=$numero++;?></td>
											<td class='td2' width='75%'><?=$nome;?></td>	
											<td class='td2' width=''>
												<img src='img/editar.jpg' width='16px' title='editar'/>
												<img src='img/delete.png' width='16px' title='excluir'/>
												<img src='img/table_refresh.png' width='16px' title='atualizar'/>
											</td>	
										</tr>
									<?}?>	
										
										
										
									</table>
								</div>									
						</div>									
															
															

</body>
</html>