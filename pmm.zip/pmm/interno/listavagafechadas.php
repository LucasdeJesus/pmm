<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener'>


			

<form  class="form" style='width:100%;'method="post" >
		
		
		<?$endereco = $_SERVER ['REQUEST_URI'];;?>
		<a href="<?=$endereco;?>" class="myButton"><img src='img/table_refresh.png' />Atualizar</a> 
		<!-------------------------vagas via site ----------------------------------------------------------------------->
		
	
	
	<!-------------------------vagas via site ----------------------------------------------------------------------->
		<h2>Vagas Aguardando resposta</h2>
		<div style='overflow:auto;'>
		<table style='width:95%;' class="sortable">
			<tr>
				<td class='td1' >N°</td>
				<td class='td1' >ID</td>
				<td class='td1' >Empresa </td>
				<td class='td1' >Ocupação </td>
				<td class='td1'>Qtd. </td>
				<td class='td1'>Encaminhados</td>
				<td class='td1'>Data</td>
				<td class='td1'>Status</td>
				
				
				
						
			</tr>
			
						<?
		$numero =1;
		$query_noticias = "SELECT *  FROM `vaga` where status='R'ORDER BY `dataaguardamdo` DESC LIMIT 0 , 50";				
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){



									
									$id= $campo_noticias['id']; 	 
									$empresaid= $campo_noticias['empresaid']; 	 
									$selvagasigilosa = $campo_noticias['selvagasigilosa'];
									
									$cboid = $campo_noticias['cboid'];
									$descricao = $campo_noticias['descricao'];
									$cargoid = $campo_noticias['cargoid']; 
									$txvagadata = $campo_noticias['txvagadata'];
									$horariotrabalho = $campo_noticias['horariotrabalho'];
									$vagadeficiente = $campo_noticias['vagadeficiente'];
									$quantidadedisponivel = $campo_noticias['quantidadedisponivel'];
									$txvagapreenchidaCTM = $campo_noticias['txvagapreenchidaCTM']; 
									$txvagapreenchidaOutros = $campo_noticias['txvagapreenchidaOutros'];
									$txvagaCancelada = $campo_noticias['txvagaCancelada']; 
									$txvagasativas = $campo_noticias['txvagasativas']; 
									$quantidadeencaminhar = $campo_noticias['quantidadeencaminhar'];
									$datalimiteencaminhar = $campo_noticias['datalimiteencaminhar'];
									$chktemporaria = $campo_noticias['chktemporaria'];
									$ceplocal = $campo_noticias['ceplocal'];
									$txtestado_local = $campo_noticias['txtestado_local'];
									$cidadelocalid = $campo_noticias['cidadelocalid'];
									$bairrolocal = $campo_noticias['bairrolocal'];
									$enderecolocal = $campo_noticias['enderecolocal']; 
									$proximodelocal = $campo_noticias['proximodelocal']; 
									$onoffshore = $campo_noticias['onoffshore']; 
									$local = $campo_noticias['local'];
									$salario = $campo_noticias['salario'];
									$comissao = $campo_noticias['comissao'];
									$prospeccao = $campo_noticias['prospeccao'];
									$cartaoalimentacao = $campo_noticias['cartaoalimentacao']; 
									$alimentacaolocal = $campo_noticias['alimentacaolocal']; 
									$lanche = $campo_noticias['lanche'];
									$cestabasica = $campo_noticias['cestabasica']; 
									$planosaude = $campo_noticias['planosaude']; 
									$planoodonto = $campo_noticias['planoodonto'];
									$segurovida = $campo_noticias['segurovida'];
									$carteiraassinada = $campo_noticias['carteiraassinada']; 
									$valetransporte= $campo_noticias['valetransporte'];
									$premiacao = $campo_noticias['premiacao']; 
									$outrosbeneficios = $campo_noticias['outrosbeneficios'];
									$tempoano = $campo_noticias['tempoano']; 
									$tempomes = $campo_noticias['tempomes']; 
									$comprovada = $campo_noticias['comprovada'];
									$idademinima = $campo_noticias['idademinima']; 
									$idademaxima = $campo_noticias['idademaxima']; 
									$escolaridade = $campo_noticias['escolaridade'];
									$escolaridadesituacao = $campo_noticias['escolaridadesituacao'];
									$cnh= $campo_noticias['cnh']; 
									$sexo = $campo_noticias['sexo'];
									$estadocivil = $campo_noticias['estadocivil']; 
									$txvagafilhos = $campo_noticias['txvagafilhos'];
									$importanciatempo = $campo_noticias['importanciatempo']; 
									$importanciaidade = $campo_noticias['importanciaidade']; 
									$importanciaescolaridade = $campo_noticias['importanciaescolaridade']; 
									$importanciacnh = $campo_noticias['importanciacnh'];
									$importanciasexo = $campo_noticias['importanciasexo']; 
									$importanciaestadocivil = $campo_noticias['importanciaestadocivil'];
									$selvagafilhos_niv = $campo_noticias['selvagafilhos_niv'];
									$txvagaregiao = $campo_noticias['txvagaregiao'];
									$txvagahabilidades = $campo_noticias['txvagahabilidades']; 
									$txvagarestricoes = $campo_noticias['txvagarestricoes'];
									$importanciaestadocivil = $campo_noticias['importanciaestadocivil']; 
									$selvagaidiomas_niv = $campo_noticias['selvagaidiomas_niv'];
									$selvagainformatica_niv = $campo_noticias['selvagainformatica_niv'];
									$txtcep = $campo_noticias['txtcep'];
									$txtestado = $campo_noticias['txtestado'];
									$txtcidade = $campo_noticias['txtcidade'];
									$txtbairro = $campo_noticias['txtbairro'];
									$txtendereco = $campo_noticias['txtendereco']; 
									$txtproximode = $campo_noticias['txtproximode'];
									$txtfalarcom = $campo_noticias['txtfalarcom']; 
									$txtEmailEntrevista = $campo_noticias['txtEmailEntrevista']; 
									$horarioatendimento = $campo_noticias['horarioatendimento'];
									$viaencaminhamento = $campo_noticias['viaencaminhamento'];
									$observacao = $campo_noticias['observacao']; 
									$status = $campo_noticias['status']; 
									$formacaptacaoid = $campo_noticias['formacaptacaoid'];
									$localcaptacaoid = $campo_noticias['localcaptacaoid']; 
									$selpublicar = $campo_noticias['selpublicar']; 
									$dia = $campo_noticias['dia']; 
									$mes = $campo_noticias['mes']; 
									$ano = $campo_noticias['ano']; 
									
									 $softwareid1 = $campo_noticias['softwareid1']; 
									 $softwareid2 = $campo_noticias['softwareid2']; 
									 $softwareid3 = $campo_noticias['softwareid3'];
									 
									 $idiomaid1 = $campo_noticias['idiomaid1']; 
									 $leitura1 = $campo_noticias['leitura1']; 
									 $escrita1 = $campo_noticias['escrita1']; 
									 $conversacao1 = $campo_noticias['conversacao1']; 
									 
									  $idiomaid2 = $campo_noticias['idiomaid2']; 
									 $leitura2 = $campo_noticias['leitura2']; 
									 $escrita2 = $campo_noticias['escrita2']; 
									 $conversacao2 = $campo_noticias['conversacao2']; 
									 
									  $idiomaid3 = $campo_noticias['idiomaid3']; 
									 $leitura3 = $campo_noticias['leitura3']; 
									 $escrita3 = $campo_noticias['escrita3']; 
									 $conversacao3 = $campo_noticias['conversacao3']; 
									 $cadastrado_por = $campo_noticias['usuarioid']; 
									 $datacadastro = $campo_noticias['datacadastro']; 
									 $dataaguardamdo = $campo_noticias['dataaguardamdo']; 
									
		
			?>

			<tr class='tr_tb' >		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$id ;?> </td>
					<?
					
					
												
												
						$sql = "SELECT * FROM `empresa` where id ='$empresaid'";
						$rsd = mysql_query($sql);
						while($rs = mysql_fetch_array($rsd)) {
						$txnomed = $rs['nome'];
						$empresaidd = $rs['empresaid'];	
							}						
					?>
				<td class='td2' >  <?=$txnomed;?></td>
						<?
							
							
					$query_noticias_total_emca = "SELECT * FROM  encaminhamento  WHERE vagaid ='$id'";	
					$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
					$total_total_emca = mysql_num_rows($rs_noticias_total_emca);	
					
						?>
						
						<?
													$query_ocupacao = "SELECT * FROM `cbo` where id='$cboid' ";
													$rs_ocupacao     = mysql_query($query_ocupacao );
													while($campo_ocupacao  = mysql_fetch_array($rs_ocupacao )){
													$cbo        = $campo_ocupacao ['cbo'];
													}
												?>
				<td class='td2' >  <?=$cbo;?></td>	

				
				<td class='td2' >  <?=$quantidadedisponivel;?></td>				
				<td class='td2' >  <?=$total_total_emca;?>/<?=$quantidadeencaminhar;?></td>		
				<td class='td2' > <?if($dataaguardamdo==""){}else{?>Aguardando em:<?=$dataaguardamdo;?> <br><?}?> Cadastro:<?=$datacadastro;?></td>								
							
				
						<?
						switch ($status){										
						case "A":											
						$status_N2 = "Ativa";
						break;case "S":											
						$status_N2 = "Suspensa";
						break;case "P":											
						$status_N2 = "Preenchida pelo CTM";
						break;case "O":											
						$status_N2 = "Preenchida pelo Solicitante";
						break;case "C":											
						$status_N2 = "Cancelada";
						break;case "E":											
						$status_N2 = "Encerrada";
						break;case "R":											
						$status_N2 = "Aguardando Resposta";
						break;case "N":											
						$status_N2 = "Sem retorno ";						
						break;
						case "G":											
						$status_N2 = "Sigilosa";
						break;
						
						case "I":											
						$status_N2 = "Em análise";
						break;
						}
					?>
					
				<td class='td2' >  <?=$status_N2;?></td>				
				
			</tr>
		<?}?>	
		
		
	</table>
	<?
				if($total=="")
				
				{echo"<h3>Nenhuma Vaga foi encontrada.</h3>";}else{}
				
				?>
	
	</div>
	

</form>
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
