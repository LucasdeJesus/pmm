
<html>
    <head>
	  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    </head>
	
	
	
	<body style='background-color: #157FCC;'>
	
			<div style='width:100%;' align='center'> 
				<div style='background-color:#1f4367;border:1px solid #173B5F;width:400px;box-shadow: 0 0 12px rgba(0, 0, 0, 0.6);margin:7%;color:#fff;'align='left'> 
					<form method="post" action="valida.php" style='padding:30px;'> 
					<p><img src='img/LogoSecretaria.png' width='346px'/></p>
					<p>
					<label>Usuário</label><br>
					<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="text" name="usuario" maxlength="50" style='width:100%; background-color:#E9EDF0;border: 1px solid #173B5F;height:30px;' />
					</p>
					<p>
					<label>Senha</label><br>
					<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="password" name="senha" maxlength="50" style='width:100%; background-color:#E9EDF0;border: 1px solid #173B5F;height:30px;' />
					</p>
					<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type="submit" value="Entrar" />
					</form>
				</div>
			</div>

</body>
</html>
