<?php
include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<head>

			<!-- prefix free to deal with vendor prefixes -->
			<script src="js/prefixfree-1.0.7.js" type="text/javascript"></script>
			<!-- jQuery -->
			<script src="js/jquery-1.7.1.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="css.css"/>
			<link rel="stylesheet" type="text/css" href="assets/reset.css" />
			<link rel="stylesheet" type="text/css" href="assets/styles.css" />
			<script type="text/javascript" src="assets/jquery.1.3.2.js"></script>
			<script type="text/javascript" src="jquery.ufvalidator-1.0.4.js"></script>


			</head>
		
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>
	<script>
function SelecionaMenu(Menu)
{
	parent.mainFrame.location.href = Menu
}


function minhaFuncao2(n)
{
	if(n=="ocuta")
	{
	
	document.getElementById('menutodo').style.display = 'none';
	}
	else{
    document.getElementById('menutodo').style.display = 'block';
	}
	
	
}

</script>



	<script type="text/javascript" >
	
/*jQuery time*/
$(document).ready(function(){
	$("#accordian h3").click(function(){
		//slide up all the link lists
		$("#accordian ul ul").slideUp();
		//slide down the link list below the h3 clicked - only if its closed
		if(!$(this).next().is(":visible"))
		{
			$(this).next().slideDown();
		}
	})
})
	</script>
	
	<script type='text/javascript'>

$(document).ready(function(){

// Executa o evento CLICK em todos os links do menu

 $('#menu a').live('click',function(){

  // Faz o carregamento da página de acordo com o COD da página, que vai pegar os valores da página page.php.

  $('#conteudo').load($(this).attr('href'));

  return false;

    

 });



});

</script>
	
<script type="text/javascript">

</script>
	</head>
	<body style='background-color: #FAFAFA;' width='100%' height='100%'>
	
	
		<?
		
			$sql32 = "SELECT * FROM `usuario` WHERE `id` = '$usuarioID'";
			$rsd32 = mysql_query($sql32);
			while($rs32 = mysql_fetch_array($rsd32)) {
			$perfil = $rs32['perfil'];
			$usuariologado = $rs32['usuario'];
			
			}
		
		?>
		
			<div style='background-color:#fff;margin: 4px;'id='menu'>
			<div id="accordian">
			<p><img src='img/LogoSecretaria.png' width='200px'/></p>
		<div class='barra' ><b>SEMTRE, Olá <?=$usuariologado;?><b></b>  </b></div>

		
			
		<div id='menutodo' name='menutodo' style='display:block;'>
	<ul>
		<? if($perfil=="W"){?>
		<li >
			<h3><span ><img src='img/icone/table_refresh.png'></span>Vagas  (<font id="totalvagasnovas" style="color:red;"> </font>) novas</h3>
			<ul>
				<li><a href="#" onClick="SelecionaMenu('lista_vaga.php')" >Cadastro de Vagas</a></li>
				<li><a href="#" onClick="SelecionaMenu('listavagasite.php')" >Gestor de Vagas</a></li>
				<li><a href="#"  onClick="SelecionaMenu('lista_empresa.php')" >Empresas / Grupos Produtivos</a></li>
				
			</ul>
		</li>
		<?}?>
		
		<? if($perfil=="A"){?>
		<li class="active">
			<h3><span ><img src='img/icone/user_suit.gif'></span>Trabalhadores</h3>
			<ul id='ultrabalhador'  name='ultrabalhador'>
				<li><a href="#"  onClick="SelecionaMenu('cadastro.php')">Cadastro de Trabalhador</a></li>				
				<li><a href="#" onClick="SelecionaMenu('busca_trabalhador_cbo.php')">Buscar Trabalhador CBO</a></li>				
				<li><a href="#" onClick="SelecionaMenu('listavagafechadas.php')">Vagas em Aguardando</a></li>				
				<li><a href="#" onClick="SelecionaMenu('painelltrabalhador.php')">Mural vaga</a></li>				
					
			</ul>
			
		</li>
		<? if(($usuarioID=="1")OR($usuarioID=="13") OR ($usuarioID=="35230578")){?>
		<li>
			<h3><span ><img src='img/icone/grid.png'></span>Estatísticas e Resultados</h3>
			<ul>
				<li><a href="#" onClick="SelecionaMenu('resultados.php')">Resultados</a></li>				
			</ul>
		</li>
			<?}?>
		<?}?>
		
		<? if($perfil=="W"){?>
		<li class="active">
			<h3><span ><img src='img/icone/user_suit.gif'></span>Trabalhadores</h3>
			<ul>
				<li><a href="#"  onClick="SelecionaMenu('cadastro.php')">Cadastro de Trabalhador</a></li>				
				<li><a href="#" onClick="SelecionaMenu('busca_trabalhador_cbo.php')">Buscar Trabalhador CBO</a></li>	
<li><a href="#" onClick="SelecionaMenu('listavagafechadas.php')">Vagas em Aguardando</a></li>					
			</ul>
		</li>
		<li>
			<h3><span ><img src='img/icone/grid.png'></span>Estatísticas e Resultados</h3>
			<ul>
				<li><a href="#" onClick="SelecionaMenu('resultados.php')">Resultados</a></li>				
			</ul>
		</li>
		
		
		
		
		<li >
			<h3><span ><img src='img/icone/rss_go.png'></span>SMS</h3>
			<ul>
				<li><a href="#"  onClick="SelecionaMenu('smseventos.php')">SMS Eventos</a></li>			
				<li><a href="#"  onClick="SelecionaMenu('smsinformativo.php')">SMS Aviso Vaga Trabalhador</a></li>			
					
								
			</ul>
		</li>
		
		<?}?>
		
		<? if(($perfil=="W") OR ($perfil=="A") ){?>
		<li >
			<h3><span ><img src='img/icone/book.png'></span>Agendamentos</h3>
			<ul>
					<? if(($usuarioID=="94") OR ($usuarioID=="21") OR ($usuarioID=="352")  OR ($usuarioID=="904") OR ($usuarioID=="30") OR ($usuarioID=="7738") OR ($usuarioID=="1") OR ($usuarioID=="35230578")){?>
				<li><a href="#"  onClick="SelecionaMenu('agendamento/indexprincipal.php')">Disponibilizar data</a></li>	
				<li><a href="#" onClick="SelecionaMenu('../agendamento/agendamento_interno.php?tipo=V&iduaruario=<?=$usuarioID;?>')">Agendamento para Vagas Interno</a></li>				
				<li><a href="#" onClick="SelecionaMenu('../agendamento/agendamento_interno.php?tipo=D&iduaruario=<?=$usuarioID;?>')">Agendamento Emissão RG Interno</a></li>				
				<li><a href="#" onClick="SelecionaMenu('../agendamento/agendamento_interno.php?tipo=C&iduaruario=<?=$usuarioID;?>')">Agendamento Emissão  CTPS Interno</a></li>	
								
				<?}?>
				<li><a href="#" onClick="SelecionaMenu('../agendamento/agendamento.php?tipo=V')">Agendamento para Vagas</a></li>				
				<li><a href="#" onClick="SelecionaMenu('../agendamento/agendamento.php?tipo=D')">Agendamento Emissão RG</a></li>				
				<li><a href="#" onClick="SelecionaMenu('../agendamento/agendamento.php?tipo=C')">Agendamento Emissão  CTPS</a></li>			
				
				<li><a href="#" onClick="SelecionaMenu('agendamento/agendados.php')">Listar Agendamento </a></li>				
			</ul>
		</li>
		<?}?>
		
		
		<li>
			<h3><span ><img src='img/stop.png'></span>Trocar Senha</h3>
			<ul>
				<li><a href="#" onClick="SelecionaMenu('troca_senha.php')">Trocar senha </a></li>				
			</ul>
		</li>
		<li>
			<h3><span ><img src='img/icone/delete.gif'></span>Desconectar</h3>
			<ul>
				<li><a href="#" Onclick="JavaScript:parent.location='sair.php'">Sair</a></li>				
			</ul>
		</li>
		
	</ul>
	</div>
	
	
</div>
</div>


	</body>		
	</html>		
	