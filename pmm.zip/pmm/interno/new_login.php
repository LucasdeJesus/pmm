﻿

</head><body >
<div style='100%' align='center'>
<a href="#" Onclick="JavaScript:parent.location='login.php'">
<img src='img/SessaoExpirou.png'/>
</a>
</div>
</body></html>

