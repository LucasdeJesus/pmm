<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener'>

 <script type="text/javascript">
            $().ready(function() {
                $("#ocupacao").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });				

            });
        </script>
     
			

			
<form  class="form" style='width:100%;'action=''method="GET" >
		<h2>VAGAS</h2>
		
		
		<a  href="javascript:Abrir_Pagina('interno/muralexterno_imprimir.php','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/mural.png' />Mural</a> 			
				
		
			
</form>	




			
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
