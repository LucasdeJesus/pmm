<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener' align='center' style="margin:10%;">
<img src='img/LogoSecretaria.png'>
</div>

<?
		$datadehj = date("Y-m-d"); 
		$query_noticias = "SELECT id,datalimiteencaminhar FROM `vaga` where status='A' ORDER BY  `vaga`.`id` ASC ";						
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$datalimiteencaminhar = $campo_noticias['datalimiteencaminhar'];
		$idvaga = $campo_noticias['id'];
		
			if($datalimiteencaminhar=="0000-00-00"){}else{
				if(strtotime($datalimiteencaminhar) <= strtotime($datadehj)){
				
				$query_atualiza_status_vaga="UPDATE `vaga` set status ='R'  where  id ='$idvaga' ";
				$rs_atualiza= mysql_query($query_atualiza_status_vaga);	
				
					
				}
			}
		
		}
		
		
$datahjbusca= date("Y-m-d");
$query_noticias = "SELECT id FROM  `smstrabalhador` WHERE  `data` LIKE  '%$datahjbusca%' limit 1 " ;
$rs_noticiasceu1    = mysql_query($query_noticias);
$total = mysql_num_rows($rs_noticiasceu1);

if($total > 0){}else{
		

					$datahojevagassms =  date("d-m-Y"); 
					$datavagamias5dias = date('Y-m-d', strtotime("-1 days",strtotime($datahojevagassms)));
					//echo $datavagamias5dias;

					$cboidsvagas = '';
					$idvagadata = '';
					$query_vagassms = "SELECT cboid,id FROM  `vaga` WHERE  `datacadastro` LIKE  '%$datavagamias5dias%' and status IN ('A')";
					//echo $query_vagassms;
					$rs_vagassms   = mysql_query($query_vagassms);
					while($campo_vagasms = mysql_fetch_array($rs_vagassms)){																						
					$cboid 	= $campo_vagasms['cboid'];
					$idvaga 	= $campo_vagasms['id'];	
					$cboidsvagas.=",$cboid" ;		
					$idvagadata.=",$idvaga" ;		
					}
					$cbodasvagas= $cboidsvagas;
					$sqlidvaga= "0".$idvagadata;


					

					$numerotelefone="";
					$anohoje =  date("Y"); 
					$query_vagassmst = "SELECT comprovada,id,sexo,vagadeficiente,cboid,idademinima,idademaxima ,quantidadeencaminhar FROM  `vaga` WHERE  id IN ($sqlidvaga )and status IN ('A')";
					$rs_vagassmst   = mysql_query($query_vagassmst);
					while($campo_vagasmst = mysql_fetch_array($rs_vagassmst)){		
					$cboidtrabalhador 	= $campo_vagasmst['cboid'];
					$sexo 	= $campo_vagasmst['sexo'];
					$vagadeficientet 	= $campo_vagasmst['vagadeficiente'];
					$idademinima = $campo_vagasmst['idademinima']; 
					$idademaxima = $campo_vagasmst['idademaxima']; 
					$quantidadeencaminhar = $campo_vagasmst['quantidadeencaminhar']; 
					$comprovada = $campo_vagasmst['comprovada']; 
					$limit = $quantidadeencaminhar*2;
					$idvaga = $campo_vagasmst['id']; 

					$dataminima = $anohoje-$idademinima;		
					$newdataminima = date("Y-d-m", strtotime($dataminima));		
					$datamaxima = $anohoje-$idademaxima;
					$newmaxima = date("Y-d-m", strtotime($datamaxima));

					if(($idademinima > 0) ||($idademaxima > 0)){

					$sqlidadedata="and `datanascimento` BETWEEN '$newdataminima' AND '$newmaxima'";
					}


					$idtrabalhadoragrupada ="";
					$query_trabalhadorsms= "SELECT nome,telcel,id FROM  `trabalhador` WHERE   cadbf='$' 
					and sexo IN ('A','$sexo') and vagadeficiente='$vagadeficientet'
					".$sqlidadedata."  and (`cboid1`='$cboidtrabalhador' or `cboid2`='$cboidtrabalhador'  or `cboid3`='$cboidtrabalhador') ORDER BY  `trabalhador`.`datacadastro` DESC 
					LIMIT $limit";		
					//echo $query_trabalhadorsms;
					$rs_trabalhadorsms   = mysql_query($query_trabalhadorsms);
					while($campo_trabalhadorsms = mysql_fetch_array($rs_trabalhadorsms)){																						
					$nome 	= $campo_trabalhadorsms['nome'];
					$telcel 	= $campo_trabalhadorsms['telcel'];
					$idtrabalhador 	= $campo_trabalhadorsms['id'];
					//$cboinome.=",$cbo" ;	
					//echo $nome."<br>";
					//echo $telcel."<br>";

					$vowels = array("(", ")", ".", "-");
					$numerocelular = str_replace($vowels, "", $telcel);
					$numerotelefone.= "55".$numerocelular."," ;
					$idtrabalhadoragrupada.=",".$idtrabalhador;
					}




					//$query="insert INTO `smstrabalhador` (`idvaga`,`idtrabalhador`) VALUES ('$idvaga','$idtrabalhadoragrupada')";									  
					$queryinserte="INSERT INTO  `smstrabalhador` (`id` ,`idvaga` ,`idtrabalhador` ,`data`)VALUES (NULL ,  '$idvaga',  '$idtrabalhadoragrupada', CURRENT_TIMESTAMP);";									  
					$rsinserte= mysql_query($queryinserte);		


					//echo $queryinserte;
					}

					
					if ($rsinserte) {

						
						
					

					?>

					<script>
					$.ajax({
					crossDomain: true,
					  headers: {"X-My-Custom-Header": "some value"},
					dataType: 'jsonp',
					url: 'http://app.smsconecta.com.br/SendAPI/Send.aspx?usr=cetep&pwd=cetep357&number=<?=$numerotelefone;;?>5522997437124&sender=AGETRAB&msg=existe vagas de emprego que pode lhe interessar, favor acessar: www.macae.rj.gov.br/agetrab clique area do trabalhador e vaga de emprego',
					success: function(data) {	
					//alert (data);
					if($.trim(data)  > 2){

					//document.getElementById("sms").innerHTML = "<h3>Enviamos uma SMS para <?=$numerocelular;?>  com detalhes de acesso ao sistema , favor verificar seu Celular </h3>";		

					}
					}

					});

					
					</script>
					
					
					
					<?
					
			$sql323 = "SELECT * FROM `usuario` WHERE `id` = '$usuarioID'";
			$rsd323 = mysql_query($sql323);
			while($rs323 = mysql_fetch_array($rsd323)) {
			$perfil3 = $rs323['perfil'];
			$usuariologado3 = $rs323['usuario'];
			
			}
			
			
		
			?>
					<script>
					$.ajax({
					crossDomain: true,
					  headers: {"X-My-Custom-Header": "some value"},
					dataType: 'jsonp',
					url: 'http://app.smsconecta.com.br/SendAPI/Send.aspx?usr=cetep&pwd=cetep357&number=5522992781618,5522997437124&sender=AGETRAB&msg=O usuario <?=$usuariologado3;?> acabou de acessar o sistema.',
					success: function(data) {	
					//alert (data);
					if($.trim(data)  > 2){

					//document.getElementById("sms").innerHTML = "<h3>Enviamos uma SMS para <?=$numerocelular;?>  com detalhes de acesso ao sistema , favor verificar seu Celular </h3>";		

					}
					}

					});
					</script>
					
				
					
					
					
					<?
					} else {
							
						
									
					}
					
					?>
<?}?>


			

</body>
</html>
