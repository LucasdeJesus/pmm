  <script type="text/javascript">
            $().ready(function() {
                $("#txtocupacao1").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
				
				
				 $("#txtocupacao2").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
				
				 $("#txtocupacao3").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
				
				$("#txtocupacao4").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
				$("#txtocupacao_h").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });$("#txtcargo").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
            });
        </script>
     


	<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('#objetivo').submit(function(){
			var dados = jQuery( this ).serialize();

			jQuery.ajax({
				type: "POST",
				url: "script_cadastro.php?acao=proficional",
				data: dados,
				success: function( data )
				{
					alert( data );
				}
			});

			return false;
		});
		
		jQuery('#historico').submit(function(){
			var dados = jQuery( this ).serialize();

			jQuery.ajax({
				type: "POST",
				url: "script_cadastro.php?acao=historico",
				data: dados,
				success: function( data )
				{
					alert( data );
				}
			});

			return false;
		});
	});
	
	
	</script>

		<script type="text/javascript">
		$(function(){
			$("#txtPretensaoSalarial").maskMoney({symbol:'R$ ',showSymbol:true, thousands:'.', decimal:',', symbolStay: true});
			$("#txtUltimoSalario").maskMoney({symbol:'R$ ',showSymbol:true, thousands:'.', decimal:',', symbolStay: true});
		})
		</script>

		




  	<form id="objetivo"  name='objetivo'class="form" method="Post" action="" >
	
	<h2>TRABALHADOR</h2>

			<div class="form-row">
			<div class="label">CPF</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  value="<?echo $cpf;?>" size="60" maxlength="60"  disabled=""class="input req-same" tabindex="22" type="text"/> 
			
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Nome</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?echo $nome;?>" tabindex="23"type="text"/>
			
			</div>
			</div>
			
	<h2>OBJETIVOS / HABILIDADES</h2>
	<h4>Ocupações Pretendidas / Habilidades</h5>
	
	<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_trabalhador' type='hidden' value='<?=$id_trabalhador;?>'/>
	
	<div class="form-row">
	    <div class="label">1-</div>
	    <div class="input-container">		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtocupacao1" id="txtocupacao1" value="<?echo $txtocupacao1;?>" class="input req-same" size="60" maxlength="200" onchange="EditandoRegistro2()" tabindex="1"  type="text">			
			<textarea name="txthabilidades1" id="txthabilidades1" class="input req-same" rows="2" cols="99" tabindex="4" style="font-size: 12px; font-family: Arial;height:36px;" onkeyup="funTamanhoCerto('window.document.Ficha.txthabilidades1', 200);" onchange="Maiuscula(this);EditandoRegistro2();"><?echo $txthabilidades1;?></textarea>
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">2-</div>
	    <div class="input-container">		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtocupacao2" id="txtocupacao2" class="input req-same" value="<?echo $txtocupacao2;?>"size="60" maxlength="200" onchange="EditandoRegistro2()" tabindex="1"   type="text">			
			<textarea name="txthabilidades2" id="txthabilidades2" class="input req-same" rows="2" cols="99" tabindex="4" style="font-size: 12px; font-family: Arial;height:36px;" onkeyup="funTamanhoCerto('window.document.Ficha.txthabilidades1', 200);" onchange="Maiuscula(this);EditandoRegistro2();"><?echo $txthabilidades2;?></textarea>
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">3-</div>
	    <div class="input-container">		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtocupacao3" id="txtocupacao3" value="<?echo $txtocupacao3;?>"class="input req-same" size="60" maxlength="200" onchange="EditandoRegistro2()" tabindex="1"  type="text">			
			<textarea name="txthabilidades3" id="txthabilidades3" class="input req-same" rows="2" cols="99" tabindex="4" style="font-size: 12px; font-family: Arial;height:36px;" onkeyup="funTamanhoCerto('window.document.Ficha.txthabilidades1', 200);" onchange="Maiuscula(this);EditandoRegistro2();"><?echo $txthabilidades3;?></textarea>
		</div>
	</div>
	
	
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			Pretensão Salarial
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtPretensaoSalarial"  id="txtPretensaoSalarial" value="<?echo $txtPretensaoSalarial;?>"  maxlength="14"  class="input req-same"onchange="EditandoRegistro2();" style="font-family: Tahoma; font-size: 10px;width:100px;" tabindex="17" value="" type="text"/> 
			Último Salário
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtUltimoSalario" id="txtUltimoSalario" value="<?echo $txtUltimoSalario;?>"  maxlength="14"  class="input req-same" onchange="EditandoRegistro2();" style="font-family: Tahoma; font-size: 10px;width:100px;" tabindex="18" value="" type="text"/> 
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar" type="submit" class="sendBtn" />
				<div id="errorDiv2" class="error-div"></div>
		</div>
	</div>
	
</form>






<form id="historico" class="form" method="Post" action="" onload='Ajax();'>
<h2>HISTÓRICO PROFISSIONAL</h2>


<!---------------------------------------------------------empresa 1------------------------------------------------->
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_trabalhador' type='hidden' value='<?=$id_trabalhador;?>'/>
			<h4>EMPRESA</h4>
			<div class="form-row">
			<div class="label">Ocupação</div>
			<div class="input-container" style='width:546px;height:;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtocupacao_h" id="txtocupacao_h" size="60" maxlength="200" value="<?echo $txtocupacao_h;?>" class="input req-same"  tabindex="20" type="text"/>
			
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Empresa</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtempresa" value="<?echo $txtempresa;?>" size="60" maxlength="60" class="input req-same"id="txtempresa" tabindex="22" type="text"/> 
			
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Cargo</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtcargo" size="60" maxlength="60" class="input req-same" id="txtcargo" value="<?echo $txtcargo;?>" tabindex="23"type="text"/>
			
			</div>
			</div>
			
			
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			
				Carteira Assinada?
			<select name="selCartAssinada" id="selCartAssinada"  tabindex="24" style="width:42px;">
				<option value="<?=$selCartAssinada;?>" selected=""><?=$selCartAssinada;?></option>
				<option value="Não" selected="">Não</option>
				<option value="Sim">Sim</option>
			</select>
			&nbsp;
			Ainda Ativo?
			<select name="selAtivo" id="selAtivo"  tabindex="25" style="width:42px;">
				<option value="<?=$selAtivo;?>" selected=""><?=$selAtivo;?></option>
				<option value="Não" selected="">Não</option>
				<option value="Sim">Sim</option>
			</select>
			Período: Início
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtdtinicio" id="txtdtinicio" value="<?echo $txtdtinicio;?>" maxlength="10" class="input req-same" onkeypress="formatar_mascara(this, '##/##/##')" tabindex="26" style="width:55px;" type="text"/>
			Final
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtdtfinal" id="txtdtfinal" value="<?echo $txtdtfinal;?>" maxlength="10" class="input req-same" onkeypress="formatar_mascara(this, '##/##/##')"  tabindex="27" style="width:55px;" type="text"/>
			
			</div>
			
			</div>
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			Caso NÃO saiba o período exato, informar:&nbsp;
			Tempo: Ano(s)
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txttempoano" value="<?echo $txttempoano;?>" size="5" maxlength="2" class="input req-same" style="width:56px;" id="txttempoano" tabindex="28" type="text"/>
			Mês(es)
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txttempomes" value="<?echo $txttempomes;?>" size="5" maxlength="2" class="input req-same"  style="width:56px;" id="txttempomes" tabindex="29" type="text"/>
		
			</div>
			</div>
			
			
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar" type="submit" class="sendBtn" />
			<div id="errorDiv2" class="error-div"></div>
			</div>
			</div>
			
		<table>
			<tr>
				<td class='td1' width='160px'> Ocupação </td>
				<td class='td1' width='136px'> Empresa </td>
				<td class='td1' width='83px'> Período / Tempo (AA/MM)  </td>
				<td class='td1' width='100px'> Cargo   </td>
				<td class='td1' width='55px'> Carteira Assinada?   </td>
				<td class='td1'width='55px' > Ainda Ativo?  </td>
			</tr>

		</table>
		
				

	<script type="text/javascript">


					function carrega_historico_proficional(){

					var xmlHttp;
					try{    
					xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					catch (e){
					alert("No AJAX!?");
					return false;
					}
					}
					}

					xmlHttp.onreadystatechange=function(){
					if(xmlHttp.readyState==4){
					document.getElementById('ReloadThis').innerHTML=xmlHttp.responseText;
					setTimeout('carrega_historico_proficional()',100);
					}
					}
					xmlHttp.open("GET","historico.php?id_trabalhafo_get=<?=$id_trabalhador;?>&nome=<?=$nome;?>&cpf=<?=$cpf;?>",true); // aqui configuramos o arquivo
					xmlHttp.send(null);
					}

					window.onload=function(){
					setTimeout('carrega_historico_proficional()',100); // aqui o tempo entre uma atualização e outra
					}

					</script>
				
			<table id="ReloadThis" name='ReloadThis'>
			
			</table>
		
</form>
<!---------------------------------------------------------empresa 1------------------------------------------------->






