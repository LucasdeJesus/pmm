



	<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('#qualificacao_form').submit(function(){
			var dados = jQuery( this ).serialize();

			jQuery.ajax({
				type: "POST",
				url: "script_cadastro.php?acao=qualificacao",
				data: dados,
				success: function( data )
				{
					alert( data );
				}
			});

			return false;
		});
		
		jQuery('#curso_palestras').submit(function(){
			var dados = jQuery( this ).serialize();

			jQuery.ajax({
				type: "POST",
				url: "script_cadastro.php?acao=curso_palestras",
				data: dados,
				success: function( data )
				{
					alert( data );
				}
			});

			return false;
		});
	});
	
	
	</script>
	
		

	
	<form id="qualificacao_form"  name='qualificacao_form'class="form" method="Post" action="">
	
	<h2>TRABALHADOR</h2>

			<div class="form-row">
			<div class="label">CPF</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  value="<?echo $cpf;?>" size="60" maxlength="60"  disabled=""class="input req-same" tabindex="22" type="text"/> 
			
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Nome</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"  size="60" maxlength="60" class="input req-same"  disabled="" value="<?echo $nome;?>" tabindex="23"type="text"/>
			
			</div>
			</div>
			
			
	<h2>FORMAÇÃO</h2>
	
		<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_trabalhador2' type='hidden' value='<?=$id_trabalhador;?>'/>
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="codigoEsc" id="codigoEsc" type="hidden">
			<b>Escolaridade</b>
			<select name="cboescolaridade" id="cboescolaridade" tabindex="1" style="width:90px" onchange="fun_escolaridade();EditandoRegistroEsc();">
				<option value="<?=$cboescolaridade;?>"  ><?=$cboescolaridade;?></option>
				<option value="Analfabeto">Analfabeto</option>
				<option value="Alfabetizado">Alfabetizado</option>
				<option value="Fundamental">Fundamental</option>
				<option value="Médio">Médio</option>
				<option value="Pós-Médio">Pós-Médio</option>
				<option value="Superior">Superior</option>
				<option value="Pós-Graduação">Pós-Graduação</option>
				<option value="Mestrado">Mestrado</option>	
				<option value="Doutorado">Doutorado</option>
			</select>
			<b>Situação</b>
			<select name="cbosituacao" id="cbosituacao" onchange="fun_escolaridade();EditandoRegistroEsc();" tabindex="2" style="width:73px">
				<option value="<?=$cbosituacao;?>"  ><?=$cbosituacao;?></option>
				<option value="Completo">Completo</option>
				<option value="Incompleto">Incompleto</option>	
				<option value="Cursando">Cursando</option>	
			</select>
			<b>Série</b>
			<select name="cboserie" id="cboserie" tabindex="3" style="width:208px" onchange="EditandoRegistroEsc();">
			<option value="<?=$cboserie;?>"  ><?=$cboserie;?></option>
							<option value="1º ANO">1º ANO</option>
							<option value="2º ANO">2º ANO</option>
							<option value="3º ANO">3º ANO</option>
							<option value="4º ANO">4º ANO</option>
							<option value="5º ANO">5º ANO</option>
							<option value="6º ANO">6º ANO</option>
							<option value="7º ANO">7º ANO</option>
							<option value="8º ANO">8º ANO</option>
							<option value="9º ANO">9º ANO</option>
							<option value="CICLO I - ALFA">CICLO I - ALFA</option>
							<option value="CICLO II - 1ª E 2ª">CICLO II - 1ª E 2ª</option>
							<option value="CICLO III - 3ª E 4ª">CICLO III - 3ª E 4ª</option>
							<option value="CICLO IV - 5ª E 6ª">CICLO IV - 5ª E 6ª</option>
							<option value="CICLO V - 7ª E 8ª">CICLO V - 7ª E 8ª</option>
							<option value="ED. ESP. ENS. FUND.">ED. ESP. ENS. FUND.</option>
							<option value="ED. ESP. ENS. INF.">ED. ESP. ENS. INF.</option>
							<option value="EJA - ENS.MED - 1ª ANO">EJA - ENS.MED - 1ª ANO</option>
							<option value="EJA - ENS.MED - 2º ANO">EJA - ENS.MED - 2º ANO</option>
							<option value="EJA - ENS.MED - 3º ANO">EJA - ENS.MED - 3º ANO</option>
							<option value="ENS.MED - 1º ANO">ENS.MED - 1º ANO</option>
							<option value="ENS.MED - 2º ANO">ENS.MED - 2º ANO</option>
							<option value="ENS.MED - 3º ANO">ENS.MED - 3º ANO</option>
							<option value="MATERNAL I">MATERNAL I</option>
							<option value="MATERNAL II">MATERNAL II</option>
							<option value="PRÉ I">PRÉ I</option>
							<option value="PRÉ II">PRÉ II</option>
								
			</select>
		</div>
	</div>
	

	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<b>Turno</b>
			<select name="cboturno" id="cboturno" tabindex="4" style="width:68px" onchange="EditandoRegistroEsc();">
					<option value="<?=$cboturno;?>"  ><?=$cboturno;?></option>
				<option value="Manhã">Manhã</option>
				<option value="Tarde">Tarde</option>	
				<option value="Noite">Noite</option>	
			</select>				   
<!--
			<b>Pós Graduação </b>
-->
			<select name="cbopos" id="cbopos" tabindex="5" style="width:70px; display:none;" onchange="EditandoRegistroEsc();">
			<option value="<?=$cbopos;?>"  ><?=$cbopos;?></option>
				<option value="Pós">Pós</option>
				<option value="Mestrado">Mestrado</option>	
				<option value="Doutorado">Doutorado</option>
			</select>
			<b>Curso</b>
			<select name="cbocurso" id="cbocurso" tabindex="6" style="width:380px" onchange="EditandoRegistroEsc();">
			<option value="<?=$cbocurso;?>"  ><?=$cbocurso;?></option>
				<option value="">Outros</option>
				<?
					$query_noticias_hc = "SELECT * FROM `formacao_academica` ORDER BY `formacao_academica`.`nome` ASC";
					$rs_noticias_hc    = mysql_query($query_noticias_hc);
					while($campo_noticias_hc = mysql_fetch_array($rs_noticias_hc)){
					$nome_formacao 	= $campo_noticias_hc['nome']; 	
				?>
					<option value="<?=$nome_formacao;?>"><?=$nome_formacao;?></option>
				<?}?>
			</select>
			
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Outro Curso</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtoutrocurso" id="txtoutrocurso" value="<?=$txtoutrocurso;?>" class="input req-same"maxlength="100" onchange="Maiuscula(this);EditandoRegistroEsc();" tabindex="7" style="width:453" type="text">
				
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Última Instituição</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtinstituicao" value="<?=$txtinstituicao;?>" id="txtinstituicao" class="input req-same" maxlength="100" onchange="Maiuscula(this);EditandoRegistroEsc();" tabindex="8" style="width:421" type="text">
				
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Apresentou Comprovação</div>
	    <div class="input-container" style='width:546px;'>		
			<select name="selcomprovacao" id="selcomprovacao" tabindex="9"  onchange="EditandoRegistroEsc();">
					<option value="<?=$selcomprovacao;?>"  ><?=$selcomprovacao;?></option>
				<option value="Não" >Não</option>
				<option value="Sim">Sim</option>
			</select>
				
		</div>
	</div>
	
	




<div class="form-row">
		<h2>INFORMÁTICA</h2>

	    <div class="label">1 - Software</div>
	    <div class="input-container" style='width:546px;'>		
						<select name="txIdioma" id="txIdioma" onchange="EditandoRegistro1()" tabindex="3" style="width:465px;">
					<option value="<?=$txIdioma;?>"  ><?=$txIdioma;?></option>
						<?
					$query_noticias_hcs = "SELECT * FROM `softwares`ORDER BY `softwares`.`softwares` ASC";
					$rs_noticias_hcs    = mysql_query($query_noticias_hcs);
					while($campo_noticias_hcs = mysql_fetch_array($rs_noticias_hcs)){
					$soft 	= $campo_noticias_hcs['softwares']; 	
					?>
						<option value="<?=$soft;?>"><?=$soft;?></option>
					<?}?>

						</select>
				
		</div>
	</div>

<div class="form-row">	
		
		<div class="label">2 - Software</div>
	    <div class="input-container" style='width:546px;'>		
						<select name="txIdioma2" id="txIdioma2" onchange="EditandoRegistro1()" tabindex="3" style="width:465px;">
					<option value="<?=$txIdioma2;?>"  ><?=$txIdioma2;?></option>
						<?
					$query_noticias_hcs2 = "SELECT * FROM `softwares`ORDER BY `softwares`.`softwares` ASC";
					$rs_noticias_hcs2    = mysql_query($query_noticias_hcs2);
					while($campo_noticias_hcs2 = mysql_fetch_array($rs_noticias_hcs2)){
					$soft2 	= $campo_noticias_hcs2['softwares']; 	
					?>
						<option value="<?=$soft2;?>"><?=$soft2;?></option>
					<?}?>

						</select>
				
		</div>
		
</div>	
<div class="form-row">	
		<div class="label">3 - Software</div>
	    <div class="input-container" style='width:546px;'>		
						<select name="txIdioma3" id="txIdioma3" onchange="EditandoRegistro1()" tabindex="3" style="width:465px;">
					<option value="<?=$txIdioma3;?>"  ><?=$txIdioma3;?></option>
						<?
					$query_noticias_hcs3 = "SELECT * FROM `softwares`ORDER BY `softwares`.`softwares` ASC";
					$rs_noticias_hcs3    = mysql_query($query_noticias_hcs3);
					while($campo_noticias_hcs3 = mysql_fetch_array($rs_noticias_hcs3)){
					$soft3 	= $campo_noticias_hcs3['softwares']; 	
					?>
						<option value="<?=$soft3;?>"><?=$soft3;?></option>
					<?}?>

						</select>
				
		</div>
</div>		
		
		
		
		
		
		
		
		<div class="form-row">
		<h2>IDIOMAS</h2>

	   
	    <div class="input-container" style='width:546px;margin-left:79px;' >		
			
			<table align='left'>
				
				<tr>
					<td align='left'>Idioma</td>
					<td align='left'>Leitura</td>
					<td align='left'>Escrita</td>
					<td align='left'>Conversação</td>
				</tr>
				
				<tr>
					<td>
						<select name='idioma1' style='width:150px;'>
						<option value="<?=$idioma1;?>"  ><?=$idioma1;?></option>
							<?
						$query_noticias_hcs3i = "SELECT * FROM `idiomas` ORDER BY `idiomas`.`idioma` ASC";
						$rs_noticias_hcs3i    = mysql_query($query_noticias_hcs3i);
						while($campo_noticias_hcs3i = mysql_fetch_array($rs_noticias_hcs3i)){
						$idioma11 	= $campo_noticias_hcs3i['idioma']; 	
						?>
							<option value="<?=$idioma11;?>"><?=$idioma11;?></option>
						<?}?>
					
						</select>
					</td>
					<td><select style='width:150px;' name='leitura1'><option value='<?=$leitura1;?>'><?=$leitura1;?></option> <option value='Básico'>Básica</option><option value='Intermediária'>Intermediária</option><option value='Avançada'>Avançada</option><option value='Fluente'>Fluente</option></select></td>
					<td><select style='width:150px;' name='escrita1'><option value='<?=$escrita1;?>'><?=$escrita1;?></option> <option value='Básico'>Básica</option><option value='Intermediária'>Intermediária</option><option value='Avançada'>Avançada</option><option value='Fluente'>Fluente</option></select></td>
					<td><select style='width:150px;' name='convesacao1'><option value='<?=$convesacao1;?>'><?=$convesacao1;?></option> <option value='Básico'>Básica</option><option value='Intermediária'>Intermediária</option><option value='Avançada'>Avançada</option><option value='Fluente'>Fluente</option></select></td>
				</tr>
				
				
				<tr>
					<td>
						<select name='idioma2' style='width:150px;'>
						<option value="<?=$idioma2;?>"  ><?=$idioma2;?></option>
							<?
						$query_noticias_hcs3i2 = "SELECT * FROM `idiomas` ORDER BY `idiomas`.`idioma` ASC";
						$rs_noticias_hcs3i2    = mysql_query($query_noticias_hcs3i2);
						while($campo_noticias_hcs3i2 = mysql_fetch_array($rs_noticias_hcs3i2)){
						$idioma22 	= $campo_noticias_hcs3i2['idioma']; 	
						?>
							<option value="<?=$idioma22;?>"><?=$idioma22;?></option>
						<?}?>
					
						</select>
					</td>
					<td><select style='width:150px;' name='leitura2'><option value='<?=$leitura2;?>'><?=$leitura2;?></option> <option value='Básico'>Básica</option><option value='Intermediária'>Intermediária</option><option value='Avançada'>Avançada</option><option value='Fluente'>Fluente</option></select></td>
					<td><select style='width:150px;' name='escrita2'><option value='<?=$escrita2;?>'><?=$escrita2;?></option> <option value='Básico'>Básica</option><option value='Intermediária'>Intermediária</option><option value='Avançada'>Avançada</option><option value='Fluente'>Fluente</option></select></td>
					<td><select style='width:150px;' name='convesacao2'><option value='<?=$convesacao2;?>'><?=$convesacao2;?></option> <option value='Básico'>Básica</option><option value='Intermediária'>Intermediária</option><option value='Avançada'>Avançada</option><option value='Fluente'>Fluente</option></select></td>
				</tr>
				
				<tr>
					<td>
						<select name='idioma3' style='width:150px;'>
						<option value="<?=$idioma3;?>"  ><?=$idioma3;?></option>
							<?
						$query_noticias_hcs3i23 = "SELECT * FROM `idiomas` ORDER BY `idiomas`.`idioma` ASC";
						$rs_noticias_hcs3i23    = mysql_query($query_noticias_hcs3i23);
						while($campo_noticias_hcs3i2 = mysql_fetch_array($rs_noticias_hcs3i23)){
						$idioma123 	= $campo_noticias_hcs3i2['idioma']; 	
						?>
							<option value="<?=$idioma123;?>"><?=$idioma123;?></option>
						<?}?>
					
						</select>
					</td>
					<td><select style='width:150px;' name='leitura3'><option value='<?=$leitura3;?>'><?=$leitura3;?></option> <option value='Básico'>Básica</option><option value='Intermediária'>Intermediária</option><option value='Avançada'>Avançada</option><option value='Fluente'>Fluente</option></select></td>
					<td><select style='width:150px;' name='escrita3'><option value='<?=$escrita3;?>'><?=$escrita3;?></option> <option value='Básico'>Básica</option><option value='Intermediária'>Intermediária</option><option value='Avançada'>Avançada</option><option value='Fluente'>Fluente</option></select></td>
					<td><select style='width:150px;' name='convesacao3'><option value='<?=$convesacao3;?>'><?=$convesacao3;?></option> <option value='Básico'>Básica</option><option value='Intermediária'>Intermediária</option><option value='Avançada'>Avançada</option><option value='Fluente'>Fluente</option></select></td>
				</tr>
				
				
				
				
			</table>
				
		</div>
	</div>

	
	
	
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar" type="submit" class="sendBtn" />
			<div id="errorDiv2" class="error-div"></div>
			</div>
			</div>
	




</form>





<form id="curso_palestras"  name='curso_palestras'class="form" method="Post" action="" >

<div class="form-row">
		<h2>CURSOS / PALESTRAS</h2>
		<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id_trabalhador3' type='hidden' value='<?=$id_trabalhador;?>'/>
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
						Situação
			<select name="selSituacao" id="selSituacao" onchange="EditandoRegistro()" tabindex="14" style="width:70px;">
				<option value="<?=$selSituacao;?>"  ><?=$selSituacao;?></option>
				<option value="Solicitado" >Solicitado</option>
				<option value="Cursando">Cursando</option>
				<option value="Efetuado">Efetuado</option>
			</select>			
			Segmento de Atuação
<!--
			<select name="selArea" id="selArea" onchange="EditandoRegistro(); CarregaCursos('1');" tabindex="15" style="width:283px;">
-->
			<select name="selArea" id="selArea" onchange="EditandoRegistro();" tabindex="16" style="width:283px;">
				<option value="<?=$selArea;?>"  ><?=$selArea;?></option>
				<?
					$query_noticias_hcsa = "SELECT * FROM `segmento_atuacao` ORDER BY `segmento_atuacao`.`seguimento` ASC";
					$rs_noticias_hcsa    = mysql_query($query_noticias_hcsa);
					while($campo_noticias_hcsa = mysql_fetch_array($rs_noticias_hcsa)){
					$seguimento 	= $campo_noticias_hcsa['seguimento']; 	
					?>
						<option value="<?=$seguimento;?>"><?=$seguimento;?></option>
					<?}?>
			</select>
				
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Cursos</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="selcurso" id="selcurso" value="<?=$selcurso;?>" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="17" style="width:480" type="text">
				
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Apresentou Comprovação</div>
	    <div class="input-container" style='width:546px;'>		
			<select name="selcomprovacao_curso" id="selcomprovacao_curso" tabindex="19" style="width:50" onchange="EditandoRegistro();">
				<option value="<?=$selcomprovacao_curso;?>" ><?=$selcomprovacao_curso;?></option>
				<option value="Não" selected="">Não</option>
				<option value="Sim">Sim</option>
			</select>	
		</div>
	</div>
	
	
	<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Salvar" type="submit" class="sendBtn" />
			<div id="errorDiv2" class="error-div"></div>
			</div>
			</div>
			
			
			<table >
			<tr>
				<td class='td1' width='205px'>Segmento de Atuação  </td>
				<td class='td1' width='221px'> Curso </td>
				<td class='td1' width='83px'> Situação   </td>
				<td class='td1' width='83px'> AP. Comp.   </td>
						
			</tr>

		</table>
		
		
							<script type="text/javascript">


					function carrega_proficional(){

					var xmlHttp;
					try{    
					xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					catch (e){
					alert("No AJAX!?");
					return false;
					}
					}
					}

					xmlHttp.onreadystatechange=function(){
					if(xmlHttp.readyState==4){
					document.getElementById('cursos_palestra_lista').innerHTML=xmlHttp.responseText;
					setTimeout('carrega_proficional()',100);
					}
					}
					xmlHttp.open("GET","curso_palestras.php?id_trabalhador=<?=$id_trabalhador;?>&nome=<?=$nome;?>&cpf=<?=$cpf;?>",true); // aqui configuramos o arquivo
					xmlHttp.send(null);
					}

					window.onload=function(){
					setTimeout('carrega_proficional()',100); // aqui o tempo entre uma atualização e outra
					}

					</script>

					
			<table id="cursos_palestra_lista" name='cursos_palestra_lista' >
			
			</table>
			
			
	</form>



		

