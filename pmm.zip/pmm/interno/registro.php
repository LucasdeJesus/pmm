<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);



$file = 'arquivo.txt';


$lines = file($file);

for($c = 0; $line = $lines[$c]; $c++){
        $line = trim($line);
        $parts = explode(" ", $line);
        
        $start = $parts[0];
        $end = str_replace('"', '', $parts[1]);
        $code_2 = str_replace('"', '', $parts[2]);
        $code_3 = str_replace('"', '', $parts[3]);
        $name = str_replace('"', '', $parts[4]);
        
        //$sql = "INSERT INTO cbo ('codigocbo', 'cbo') VALUES ('".$start."',  '".$code_3."');";
		  $sql = "INSERT INTO `cbo`( `codigocbo`, `cbo`) VALUES ('".$start."',  '".$code_3."');";
        mysql_query($sql);
        
        echo $sql . '<br>';
}
?>
