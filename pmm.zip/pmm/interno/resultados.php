<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener'>

 <script type="text/javascript">
            $().ready(function() {
                $("#ocupacao").autocomplete("789/autoComplete.php", {
                    width: 546,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });				

            });
        </script>
     
			

			
<form  class="form" style='width:100%;'action=''method="GET" >
		<h2>VAGAS</h2>
		
		<a href="javascript:Abrir_Pagina('interno/?lista=interno','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/interno.png' />Interno</a> 	
		<a  href="javascript:Abrir_Pagina('interno/muralexterno_imprimir.php','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/mural.png' />Mural</a> 			
		<a  href="javascript:Abrir_Pagina('interno/?lista=vagastotal','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/grafico.png' />Total vaga</a> 			
		<a  href="javascript:Abrir_Pagina('interno/?lista=vagastotal_seguimento','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/grafico.png' />Total vaga Seguimento </a> 			
		<a  href="javascript:Abrir_Pagina('interno/?lista=listapararadio','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/mural.png' />Lista para rádio</a> 			
		
			
</form>	

<form  class="form" style='width:100%;'action=''method="GET" >
		<h2>EMPRESA</h2>
		
		<a  href="javascript:Abrir_Pagina('interno/?lista=empresa','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/empresas.png' />Empresa</a> 	
		<a  href="javascript:Abrir_Pagina('interno/?lista=contatoempresa','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/contatoempresa.png' />Contatos Empresa</a> 	
		<a  href="javascript:Abrir_Pagina('interno/?lista=mapaempresa','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/mapa.png' />Mapa Empresa</a> 
<a  href="javascript:Abrir_Pagina('interno/?lista=totalempresa','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/grafico.png' />Total Empresa</a> 					
</form>		


<form  class="form" style='width:100%;'action=''method="GET" >
		<h2>Encaminhamento</h2>		
		<a  href="javascript:Abrir_Pagina('interno/?lista=listaencaminhamento','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/encaminhamento.png' />Lista Encaminhamento</a> 		
		<a  href="javascript:Abrir_Pagina('interno/?lista=totalemcaminhamento','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/grafico.png' />Total Enc. Atendente</a> 		
		<a  href="javascript:Abrir_Pagina('interno/?lista=relatoriomes','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/grafico.png' />Relatório</a> 		
		<a  href="javascript:Abrir_Pagina('interno/?lista=atendimentosalao','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/grafico.png' />CTPM + DETRAN</a> 		
</form>		


<form  class="form" style='width:100%;'action=''method="GET" >
		<h2>Cadastro Trabalhador</h2>
<a  href="javascript:Abrir_Pagina('interno/?lista=totalcadastro','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/grafico.png' />Total Cadastro Trab.</a> 				
<a  href="javascript:Abrir_Pagina('interno/?lista=totalcadastro_ocupacao','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/grafico.png' />Trabalhador / Ocupação .</a> 				
<a  href="javascript:Abrir_Pagina('interno/trabalhadorregiao.php','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/mapa.png' />Trabalhador /Região .</a> 				
		
</form>

<form  class="form" style='width:100%;'action=''method="GET" >
		<h2>Trabalhador</h2>				
		<a  href="javascript:Abrir_Pagina('interno/pcd.php','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/grafico.png' />Relatório Trabalhador</a> 		
</form>		
	
	
	<form  class="form" style='width:100%;'action=''method="GET" >
		<h2>Agendamento</h2>				
		<a  href="javascript:Abrir_Pagina('interno/realtorio_agendamento.php','scrollbars=yes','fullscreen=yes')" class="myButton"><img src='img/grafico.png' />Relatório Agendamento</a> 		
</form>	

			
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
