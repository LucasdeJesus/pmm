<?php
$host="localhost"; // Host name
$username="root"; // Mysql username
$password="web"; // Mysql password
$db_name="semtre"; // Database name
 
    $con = mysql_connect($host,$username,$password)   or die(mysql_error());
    mysql_select_db($db_name, $con)  or die(mysql_error());
 
$q = strtolower($_GET["q"]);
if (!$q) return;
 
$sql = "select DISTINCT cbo from cbo where cbo LIKE '%$q%'";
$rsd = mysql_query($sql);
while($rs = mysql_fetch_array($rsd)) {
    $cname = $rs['cbo'];
    echo "$cname\n";
}
?>