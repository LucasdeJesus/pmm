<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">


<body bgcolor='#157FCC'>
<script type="text/javascript">  
function target_popup(form) {
    window.open('', 'formpopup', 'width=400,height=400,resizeable,scrollbars');
    form.target = 'formpopup';
}

</script>  
<div style='width:100%;' align='right'>
<form action="interno/?lista=listaencaminhamento" method="post" onsubmit="target_popup(this)">
	<?$datahoje = date('d/m/Y');?>
	<input type=hidden name="datainicio" id="datainicio" maxlength=10 style="width:55px;" value="<?=$datahoje;?>">
	<input type=hidden name="atendente" id="atendente" maxlength=10 style="width:55px;" value="<?=$usuarioID;?>">
	<input type="submit" value='Meus Encaminhamentos'> 
</form>

</div>
</body>
</html>
