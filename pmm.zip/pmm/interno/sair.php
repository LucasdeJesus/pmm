<?
session_start();
session_unset();
session_destroy();

  setcookie("usuario","");
?>
<html>

</head><body >
Saindo...
<SCRIPT language="JavaScript">window.location.href="login.php";</SCRIPT>
</body></html>

