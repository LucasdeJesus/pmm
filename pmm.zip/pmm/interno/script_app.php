		<?include("input_banco.php"); // Inclui o arquivo com o sistema de segurança
 
		$acao = $_GET['acao'];
		switch ($acao) {
			case vagacargo:
			
				$arr = array();

				$rs = mysql_query("SELECT * FROM vaga where status='A'");
				while($obj = mysql_fetch_object($rs)) {
				$arr[] = $obj;
				}
				//echo '{"members":'.json_encode($arr).'}';
				echo $_GET['jsoncallback'] . '(' . json_encode($arr) . ');';
			
			
			break;
			
		
		}
	
		
		?>		