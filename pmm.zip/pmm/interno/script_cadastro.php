		<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);


$acao = $_GET['acao'];


$id 	=(string)addslashes($_POST['id']); 
$cadbf 	=(string)addslashes($_POST['cadbf']); 
$cpf 	=(string)addslashes($_POST['cpf']); 	 		 			 	
$nome 	=(string)addslashes($_POST['nome']); 
	 		 			 	
$mae 	=(string)addslashes($_POST['mae']);	 		 			 	
$pai 	=(string)addslashes($_POST['pai']);	 		 			 	
$datanascimento_1 	=(string)addslashes($_POST['datanascimento']); 
$datanascimento = implode("-",array_reverse(explode("/",$datanascimento_1)));
//$data = implode("/",array_reverse(explode("-",$data)));	 		 			 	
$naturalidade 	=(string)addslashes($_POST['naturalidade']); 	 		 			 	
$sexo 	=(string)addslashes($_POST['sexo']); 	 		 			 	
$estadocivil 	=(string)addslashes($_POST['estadocivil']); 
$intencao 	=(string)addslashes($_POST['intencao']); 
$cep 	=(string)addslashes($_POST['cep']); 	 		 			 	
$vagadeficiente 	=(string)addslashes($_POST['vagadeficiente']); 
$endereco 	=(string)addslashes($_POST['endereco']); 	 		 			 	
$telres 	=(string)addslashes($_POST['telres']); 	 		 			 	
$telcel 	=(string)addslashes($_POST['telcel']); 	 		 			 	
$telrec 	=(string)addslashes($_POST['telrec']); 	 		 			 	
$nmrecado 	=(string)addslashes($_POST['nmrecado']); 	 		 			 	
$email 	=(string)addslashes($_POST['email']);	 		 			 	
$identidade 	=(string)addslashes($_POST['identidade']); 	 		 			 	
$orgaoexpedidor 	=(string)addslashes($_POST['orgaoexpedidor']); 	 		 			 	
$txttitulo 	=(string)addslashes($_POST['txttitulo']); 	 		 			 	
$txtzona 	=(string)addslashes($_POST['txtzona']); 	 		 			 	
$txtsecao 	=(string)addslashes($_POST['txtsecao']); 	 		 			 	
$tipocnh 	=(string)addslashes($_POST['tipocnh']); 
$seriect 	=(string)addslashes($_POST['seriect']);
$orgaoreg 	=(string)addslashes($_POST['orgaoreg']); 	 		 			 	
$pispasep 	=(string)addslashes($_POST['pispasep']); 	 		 			 	
$passaporte 	=(string)addslashes($_POST['passaporte']);
$programasocialid 	=(string)addslashes($_POST['programasocialid']); 	 		 			 	
$cboprocesso 	=(string)addslashes($_POST['cboprocesso']); 	 		 			 	
$cbosoube_caet 	=(string)addslashes($_POST['cbosoube_caet']); 	 		 			 	
$selcidacaptado 	=(string)addslashes($_POST['selcidacaptado']); 	 		 			 	
$selcidaatraves 	=(string)addslashes($_POST['selcidaatraves']); 	 		 			 	
$selLocalDocs 	=(string)addslashes($_POST['selLocalDocs']);
$codigocid =(string)addslashes($_POST['codigocid']); 
$infotrabalhado =(string)addslashes($_POST['infotrabalhado']); 


 $necEspAuditiva=(string)addslashes($_POST['necEspAuditiva']); 
 if(empty($necEspAuditiva)){$necEspAuditiva='N';};
 
 $necEspAuditivaTipo=(string)addslashes($_POST['necEspAuditivaTipo']);
 $necEspAuditivaUniBi=(string)addslashes($_POST['necEspAuditivaUniBi']);
 $necEspFala=(string)addslashes($_POST['necEspFala']);
 if(empty($necEspFala)){$necEspFala='N';};
 
 $necEspFalaTipo=(string)addslashes($_POST['necEspFalaTipo']);
 $necEspFisica=(string)addslashes($_POST['necEspFisica']);
 if(empty($necEspFisica)){$necEspFisica='N';};
 
 $necEspFisicaTipo=(string)addslashes($_POST['necEspFisicaTipo']);
 $necEspFisicaInfSup=(string)addslashes($_POST['necEspFisicaInfSup']);
 $necEspMental=(string)addslashes($_POST['necEspMental']);
 if(empty($necEspMental)){$necEspMental='N';};
 
 $necEspRecursosCom=(string)addslashes($_POST['necEspRecursosCom']);
 if(empty($necEspRecursosCom)){$necEspRecursosCom='N';};
 $necEspCuidadoPess=(string)addslashes($_POST['necEspCuidadoPess']);
 if(empty($necEspCuidadoPess)){$necEspCuidadoPess='N';};
 $necEspLazer=(string)addslashes($_POST['necEspLazer']);
 if(empty($necEspLazer)){$necEspLazer='N';};
 $necEspSaudeSeg=(string)addslashes($_POST['necEspSaudeSeg']);
 if(empty($necEspSaudeSeg)){$necEspSaudeSeg='N';};
 $necEspHabSocial=(string)addslashes($_POST['necEspHabSocial']);
 if(empty($necEspHabSocial)){$necEspHabSocial='N';};
 $necEspHabAcad=(string)addslashes($_POST['necEspHabAcad']);
 if(empty($necEspHabAcad)){$necEspHabAcad='N';};
 $necEspComunic=(string)addslashes($_POST['necEspComunic']);
 if(empty($necEspComunic)){$necEspComunic='N';};
 $necEspTrabalho=(string)addslashes($_POST['necEspTrabalho']);
 if(empty($necEspTrabalho)){$necEspTrabalho='N';};
 $necEspVisual=(string)addslashes($_POST['necEspVisual']);
 if(empty($necEspVisual)){$necEspVisual='N';};
 $necEspVisualTipo=(string)addslashes($_POST['necEspVisualTipo']);
 $necEspVisualUniBi=(string)addslashes($_POST['necEspVisualUniBi']);
 $etnia=(string)addslashes($_POST['etnia']);
 $statusjovem=(string)addslashes($_POST['statusjovem']);
 
	
	
	$cboid1_query =  $_POST['cboid1'];
	if($cboid1_query==""){$cboid1='';}else{
	
		$query_cboid1 = "SELECT * FROM  `cbo` WHERE  `cbo`  LIKE  '%$cboid1_query'";	
		$rs_cboid1    = mysql_query($query_cboid1); 													
		while($campo_cboid1 = mysql_fetch_array($rs_cboid1)){		 
		$cboid1= $campo_cboid1['id']; }	
	}
	
	
	$cboid2_query =  $_POST['cboid2'];
	if($cboid2_query==""){$cboid2='';}else{
	$query_cboid2 = "SELECT * FROM  `cbo` WHERE  `cbo`  LIKE  '%$cboid2_query'";	
	$rs_cboid2    = mysql_query($query_cboid2); 													
	while($campo_cboid2= mysql_fetch_array($rs_cboid2)){		 
	$cboid2= $campo_cboid2['id']; }	
	}
	
	
	$cboid3_query =  $_POST['cboid3'];
	if($cboid3_query==""){$cboid3='';}else{
	
		$query_cboid3 = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid3_query'";	
		$rs_cboid3    = mysql_query($query_cboid3); 													
		while($campo_cboid3= mysql_fetch_array($rs_cboid3)){		 
		$cboid3= $campo_cboid3['id']; }	
	}
	

$pretensaosalarial_1 =  $_POST['pretensaosalarial'];
$pretensaosalarial1 = str_replace(".","",$pretensaosalarial_1);
$pretensaosalarial = str_replace(",",".",$pretensaosalarial1);
//$pretensaosalarial =  number_format($pretensaosalarial12, 2, ',', '.'); 

$ultimosalario_1 =  $_POST['ultimosalario'];
$ultimosalario1 = str_replace(".","","$ultimosalario_1");
$ultimosalario = str_replace(",",".","$ultimosalario1");
//$ultimosalario =  number_format($ultimosalario12, 2, ',', '.'); 



 $softwareid1=(string)addslashes($_POST['softwareid1']);
 if(empty($softwareid1)){$softwareid1='18';};
 $softwareid2=(string)addslashes($_POST['softwareid2']);
 if(empty($softwareid2)){$softwareid2='18';};
 $softwareid3=(string)addslashes($_POST['softwareid3']);
 if(empty($softwareid3)){$softwareid3='18';};
 
 
 $idiomaid1=(string)addslashes($_POST['idiomaid1']);
 if(empty($idiomaid1)){$idiomaid1='21';};
 $idiomaid2=(string)addslashes($_POST['idiomaid2']);
 if(empty($idiomaid2)){$idiomaid2='21';};
 $idiomaid3=(string)addslashes($_POST['idiomaid3']);
 if(empty($idiomaid3)){$idiomaid3='21';};
 
 
$leitura1 	=(string)addslashes($_POST['leitura1']); 
$leitura2 	=(string)addslashes($_POST['leitura2']); 
$leitura3	=(string)addslashes($_POST['leitura3']); 
$conversacao1	=(string)addslashes($_POST['conversacao1']); 
$conversacao2	=(string)addslashes($_POST['conversacao2']); 
$conversacao3	=(string)addslashes($_POST['conversacao3']); 
$escrita1	=(string)addslashes($_POST['escrita1']); 
$escrita2	=(string)addslashes($_POST['escrita2']); 
$escrita3	=(string)addslashes($_POST['escrita3']); 	
$carteiratrabalho	=(string)addslashes($_POST['carteiratrabalho']); 	
		
		$dia= date("d");
		$mes= date("m");
		$ano= date("Y");
		$hora = date("H:i:s");
		$ano_fixo= date("Y-m-d");  		
		$data_fixa ="$ano_fixo $hora";
		
		$cidadeid 	=(string)addslashes($_POST['cidadeid']); 	 		 			 	
		$bairro 	=(string)addslashes($_POST['bairro']);
		$txtestado 	=(string)addslashes($_POST['txtestado']);
		
		
	$escolaridade 	=$_POST['escolaridade']; 
	$situacao 	=$_POST['situacao']; 
	$serie 	=$_POST['serie']; 
	$turno 	=$_POST['turno']; 				 
	$formacaoacademicaid 	=$_POST['formacaoacademicaid']; 
	$outrocurso 	=$_POST['outrocurso']; 
	$instituicao 	=$_POST['instituicao']; 
	$comprovacao 	=$_POST['comprovacao'];
	
		
switch ($acao) {
			
		case cadastro:
		
				
			$query = "INSERT INTO `trabalhador` ( `nome`, `cpf`,  `mae`, `pai`,`statusjovem`,`etnia`,`datanascimento`, `naturalidade`, `sexo`, `estadocivil`, `vagadeficiente`, `necEspAuditiva`, `necEspAuditivaTipo`, `necEspAuditivaUniBi`, `necEspFala`, `necEspFalaTipo`, `necEspFisica`, `necEspFisicaTipo`, `necEspFisicaInfSup`, `necEspMental`, `necEspRecursosCom`, `necEspCuidadoPess`, `necEspLazer`, `necEspSaudeSeg`, `necEspHabSocial`, `necEspHabAcad`, `necEspComunic`, `necEspTrabalho`, `necEspVisual`, `necEspVisualTipo`, `necEspVisualUniBi`, `codigocid`, `intencao`, `cep`, `cidadeid`, `bairro`, `endereco`, `telres`, `telcel`, `telrec`, `nmrecado`, `email`, `identidade`, `orgaoexpedidor`, `tipocnh`, `carteiratrabalho`, `seriect`, `orgaoreg`, `pispasep`, `passaporte`, `programasocialid`,`infotrabalhado`, `cboid1`, `cboid2`, `cboid3`, `pretensaosalarial`, `ultimosalario`, `softwareid1`, `softwareid2`, `softwareid3`, `idiomaid1`, `idiomaid2`, `idiomaid3`, `leitura1`, `leitura2`, `leitura3`, `escrita1`, `escrita2`, `escrita3`, `conversacao1`, `conversacao2`, `conversacao3`, `usuarioid`,`cadbf`) VALUES 
			( '$nome','$cpf','$mae','$pai','$statusjovem','$etnia','$datanascimento','$naturalidade','$sexo','$estadocivil','$vagadeficiente','$necEspAuditiva','$necEspAuditivaTipo','$necEspAuditivaUniBi','$necEspFala','$necEspFalaTipo','$necEspFisica','$necEspFisicaTipo','$necEspFisicaInfSup','$necEspMental','$necEspRecursosCom','$necEspCuidadoPess','$necEspLazer','$necEspSaudeSeg','$necEspHabSocial','$necEspHabAcad','$necEspComunic','$necEspTrabalho','$necEspVisual','$necEspVisualTipo','$necEspVisualUniBi','$codigocid','$intencao','$cep','$cidadeid','$bairro','$endereco','$telres','$telcel','$telrec','$nmrecado','$email','$identidade','$orgaoexpedidor','$tipocnh','$carteiratrabalho','$seriect','$orgaoreg','$pispasep','$passaporte','$programasocialid','$infotrabalhado','$cboid1','$cboid2','$cboid3','$pretensaosalarial','$ultimosalario','$softwareid1','$softwareid2','$softwareid3','$idiomaid1','$idiomaid2','$idiomaid3','$leitura1','$leitura2','$leitura3','$escrita1','$escrita2','$escrita3','$conversacao1','$conversacao2','$conversacao3','$usuarioID','$cadbf') 

			";
			$rs= mysql_query($query);	
			
			
			$query_trabalhado = "SELECT * FROM  `trabalhador` WHERE  cpf='$cpf'";	
			$rs_trabalhado    = mysql_query($query_trabalhado); 													
			while($campo_trabalhado= mysql_fetch_array($rs_trabalhado)){		 
			$trabalhadorid= $campo_trabalhado['id'];
			}	
					
			$cboid_query = $_POST['cboid'];		
			$empresa = $_POST['empresa'];			
			$cargo = $_POST['cargo'];			
			$carteiraassinada = $_POST['carteiraassinada'];
			$ativo = $_POST['ativo'];			
			$datainicio_1 	=$_POST['datainicio'];
			$datafinal_1 	=$_POST['datafinal'];				
			$tempanos	 = $_POST['tempanos'];
			$tempomes = $_POST['tempomes'];
			
				$i1=0;				
				$i2=0;				
				$i3=0;				
				$i4=0;				
				$i5=0;				
				$i6=0;				
				$i7=0;				
				$i8=0;				
				$i9=0;				
					
				while ($cboid_query[$i1] != NULL) {
					
				$i1++;				
				$i2++;				
				$i3++;				
				$i4++;				
				$i5++;				
				$i6++;				
				$i7++;				
				$i8++;				
				$i9++;
				
					$query_cboid = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid_query[$i1]%'";	
					$rs_cboid    = mysql_query($query_cboid); 													
					while($campo_cboid= mysql_fetch_array($rs_cboid)){		 
					$cboid= $campo_cboid['id'];
					}	
					
					$datainicio = implode("-",array_reverse(explode("/","$datainicio_1[$i6]")));
					$datafinal = implode("-",array_reverse(explode("/","$datafinal_1[$i7]")));							
			
				
					$query2 ="INSERT INTO historico ( `trabalhadorid`, `cboid`, `empresa`, `cargo`, `carteiraassinada`, `ativo`, `datainicio`, `datafinal`, `tempanos`, `tempomes`) VALUES
					( '$trabalhadorid', '$cboid', '$empresa[$i2]', '$cargo[$i3]', '$carteiraassinada[$i4]', '$ativo[$i5]', '$datainicio', '$datafinal ', '$tempanos[$i8]', '$tempomes[$i9]');";
					$rs2 = mysql_query($query2);
					
					$delete="DELETE from historico WHERE empresa=''";
					$deleters= mysql_query($delete);

				}
				
				/////////////ESCOLARIDADE				
				
				

				
				$escolaridadei1=0;				
				$escolaridadei2=0;				
				$escolaridadei3=0;				
				$escolaridadei4=0;				
				$escolaridadei5=0;				
				$escolaridadei6=0;				
				$escolaridadei7=0;				
				$escolaridadei8=0;				
				
				
				
				while ($escolaridade[$escolaridadei1] != NULL) {
				
				$escolaridadei1++;				
				$escolaridadei2++;				
				$escolaridadei3++;				
				$escolaridadei4++;				
				$escolaridadei5++;				
				$escolaridadei6++;				
				$escolaridadei7++;				
				$escolaridadei8++;				
				
				
				
				$query_curso_escolaridade="INSERT INTO escolaridade (`trabalhadorid` , `escolaridade`, `situacao`, `serie`, `turno`, `formacaoacademicaid`, `outrocurso`, `instituicao`, `comprovacao`)VALUES
				( '$trabalhadorid','$escolaridade[$escolaridadei1]','$situacao[$escolaridadei2]','$serie[$escolaridadei3]','$turno[$escolaridadei4]','$formacaoacademicaid[$escolaridadei5]','$outrocurso[$escolaridadei6]','$instituicao[$escolaridadei7]','$comprovacao[$escolaridadei8]')";	
				$rs2_query_curso_escolaridade= mysql_query($query_curso_escolaridade);
				
				$deletecescolaridade="DELETE from escolaridade WHERE escolaridade=''";
				$deleterscescolaridade= mysql_query($deletecescolaridade);
				
					if ($rs2_query_curso_escolaridade) {

					?>
					
					<?

					} else {

						?>
						<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Não foi possível inserir Escolaridade, tente novamente. n\ ")</SCRIPT>
						<SCRIPT language="JavaScript">//window.history.go(-1);</SCRIPT>
						<?
				
							//echo "<br />Dados sobre o erro:" . mysql_error();

					}
				
				}
				
				///////////////FIM ESCOLARIDADE
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				$situacaocurso 	= $_POST['situacaocurso']; 
				$segmentoatuacaoid 	= $_POST['segmentoatuacaoid']; 
				$curso 	= $_POST['curso']; 
				$comprovacaocurso 	= $_POST['comprovacaocurso']; 
				
				$i1curso_palestras=0;				
				$i2curso_palestras=0;				
				$i3curso_palestras=0;				
				$i4curso_palestras=0;				
							
					
				while ($segmentoatuacaoid[$i1curso_palestras] != NULL) {
					
				$i1curso_palestras++;				
				$i2curso_palestras++;				
				$i3curso_palestras++;				
				$i4curso_palestras++;	

				$query_curso_palestras="INSERT INTO cursopalestra (`trabalhadorid` ,`situacao` ,`segmentoatuacaoid` ,`curso` ,`comprovacao`)VALUES
				( '$trabalhadorid', '$situacaocurso[$i1curso_palestras]', '$segmentoatuacaoid[$i2curso_palestras]', '$curso[$i3curso_palestras]', '$comprovacaocurso[$i4curso_palestras]')";	
				$rs2_query_curso_palestras= mysql_query($query_curso_palestras);
				
				$deletec="DELETE from cursopalestra WHERE segmentoatuacaoid=''";
				$deletersc= mysql_query($deletec);
				
				}
			
		
			if ($rs) {

					?>
					<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Cadastro salvo !")</SCRIPT>
						<SCRIPT language="JavaScript">window.location.href="emcaminhamento.php?cpf_busca=<?=$cpf;?>";</SCRIPT>
					<?

				} else {

					?>
					<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Não foi possível inserir a notícia, tente novamente. n\ ")</SCRIPT>
					<SCRIPT language="JavaScript">//window.history.go(-1);</SCRIPT>
					<?
			
						//echo "<br />Dados sobre o erro:" . mysql_error();

				}
		break;
		
		case editar:	
			$query = "						
				 				update  trabalhador set
				cadbf='$cadbf',
				nome='$nome',
				cpf='$cpf',				
				mae='$mae',
				pai='$pai',
				datanascimento='$datanascimento',
				naturalidade='$naturalidade',
				sexo='$sexo',
				estadocivil='$estadocivil',
				vagadeficiente='$vagadeficiente',
				necEspAuditiva='$necEspAuditiva',
				necEspAuditivaTipo='$necEspAuditivaTipo',
				necEspAuditivaUniBi='$necEspAuditivaUniBi',
				necEspFala='$necEspFala',
				necEspFalaTipo='$necEspFalaTipo',
				necEspFisica='$necEspFisica',
				necEspFisicaTipo='$necEspFisicaTipo',
				necEspFisicaInfSup='$necEspFisicaInfSup',
				necEspMental='$necEspMental',
				necEspRecursosCom='$necEspRecursosCom',
				necEspCuidadoPess='$necEspCuidadoPess',
				necEspLazer='$necEspLazer',
				necEspSaudeSeg='$necEspSaudeSeg',
				necEspHabSocial='$necEspHabSocial',
				necEspHabAcad='$necEspHabAcad',
				necEspComunic='$necEspComunic',
				necEspTrabalho='$necEspTrabalho',
				necEspVisual='$necEspVisual',
				necEspVisualTipo='$necEspVisualTipo',
				necEspVisualUniBi='$necEspVisualUniBi',
				codigocid='$codigocid',
				intencao='$intencao',
				cep='$cep',
				cidadeid='$cidadeid',
				bairro='$bairro',
				endereco='$endereco',
				telres='$telres',
				telcel='$telcel',
				telrec='$telrec',
				nmrecado='$nmrecado',
				email='$email',
				identidade='$identidade',
				orgaoexpedidor='$orgaoexpedidor',
				tipocnh='$tipocnh',
				carteiratrabalho='$carteiratrabalho',
				seriect='$seriect',
				orgaoreg='$orgaoreg',
				pispasep='$pispasep',
				passaporte='$passaporte',
				programasocialid='$programasocialid',
				infotrabalhado='$infotrabalhado',
				cboid1='$cboid1',
				cboid2='$cboid2',
				cboid3='$cboid3',
				pretensaosalarial='$pretensaosalarial',
				ultimosalario='$ultimosalario',				
				softwareid1='$softwareid1',
				softwareid2='$softwareid2',
				softwareid3='$softwareid3',
				idiomaid1='$idiomaid1',
				idiomaid2='$idiomaid2',
				idiomaid3='$idiomaid3',
				leitura1='$leitura1',
				leitura2='$leitura2',
				leitura3='$leitura3',
				escrita1='$escrita1',
				escrita2='$escrita2',
				escrita3='$escrita3',
				conversacao1='$conversacao1',
				conversacao2='$conversacao2',
				conversacao3='$conversacao3',statusjovem='$statusjovem',etnia='$etnia',
				usuarioID='$usuarioID',dataupdate= NOW()
				

			where id ='$id'";
			$rs= mysql_query($query);	

			$cboid_query = $_POST['cboid'];		
			$empresa = $_POST['empresa'];			
			$cargo = $_POST['cargo'];			
			$carteiraassinada = $_POST['carteiraassinada'];
			$ativo = $_POST['ativo'];			
			$datainicio_1 	=$_POST['datainicio'];
			$datafinal_1 	=$_POST['datafinal'];				
			$tempanos	 = $_POST['tempanos'];
			$tempomes = $_POST['tempomes'];
			
				$i1=0;				
				$i2=0;				
				$i3=0;				
				$i4=0;				
				$i5=0;				
				$i6=0;				
				$i7=0;				
				$i8=0;				
				$i9=0;				
					
				while ($cboid_query[$i1] != NULL) {
					
				$i1++;				
				$i2++;				
				$i3++;				
				$i4++;				
				$i5++;				
				$i6++;				
				$i7++;				
				$i8++;				
				$i9++;
				
					$query_cboid = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid_query[$i1]%'";	
					$rs_cboid    = mysql_query($query_cboid); 													
					while($campo_cboid= mysql_fetch_array($rs_cboid)){		 
					$cboid= $campo_cboid['id'];
					}	
					
					$datainicio = implode("-",array_reverse(explode("/","$datainicio_1[$i6]")));
					$datafinal = implode("-",array_reverse(explode("/","$datafinal_1[$i7]")));							
			
					
					$query2 ="INSERT INTO historico ( `trabalhadorid`, `cboid`, `empresa`, `cargo`, `carteiraassinada`, `ativo`, `datainicio`, `datafinal`, `tempanos`, `tempomes`) VALUES
					( '$id', '$cboid', '$empresa[$i2]', '$cargo[$i3]', '$carteiraassinada[$i4]', '$ativo[$i5]', '$datainicio', '$datafinal ', '$tempanos[$i8]', '$tempomes[$i9]');";
					$rs2 = mysql_query($query2);
					
					$delete="DELETE from historico WHERE empresa=''";
					$deleters= mysql_query($delete);

				}	


				
				
				
				/////////////ESCOLARIDADE				
				
				

				
				$escolaridadei1=0;				
				$escolaridadei2=0;				
				$escolaridadei3=0;				
				$escolaridadei4=0;				
				$escolaridadei5=0;				
				$escolaridadei6=0;				
				$escolaridadei7=0;				
				$escolaridadei8=0;				
				
				
				
				while ($escolaridade[$escolaridadei1] != NULL) {
				
				$escolaridadei1++;				
				$escolaridadei2++;				
				$escolaridadei3++;				
				$escolaridadei4++;				
				$escolaridadei5++;				
				$escolaridadei6++;				
				$escolaridadei7++;				
				$escolaridadei8++;				
				
				
				
				$query_curso_escolaridade="INSERT INTO escolaridade (`trabalhadorid` , `escolaridade`, `situacao`, `serie`, `turno`, `formacaoacademicaid`, `outrocurso`, `instituicao`, `comprovacao`)VALUES
				( '$id','$escolaridade[$escolaridadei1]','$situacao[$escolaridadei2]','$serie[$escolaridadei3]','$turno[$escolaridadei4]','$formacaoacademicaid[$escolaridadei5]','$outrocurso[$escolaridadei6]','$instituicao[$escolaridadei7]','$comprovacao[$escolaridadei8]')";	
				$rs2_query_curso_escolaridade= mysql_query($query_curso_escolaridade);
				
				$deletecescolaridade="DELETE from escolaridade WHERE escolaridade=''";
				$deleterscescolaridade= mysql_query($deletecescolaridade);
				
					if ($rs2_query_curso_escolaridade) {

					?>
					
					<?

					} else {

						?>
						<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Não foi possível inserir Escolaridade, tente novamente. n\ ")</SCRIPT>
						<SCRIPT language="JavaScript">//window.history.go(-1);</SCRIPT>
						<?
				
							//echo "<br />Dados sobre o erro:" . mysql_error();

					}
				
				}
				
				///////////////FIM ESCOLARIDADE
				
				
				$situacaocurso 	= $_POST['situacaocurso']; 
				$segmentoatuacaoid 	= $_POST['segmentoatuacaoid']; 
				$curso 	= $_POST['curso']; 
				$comprovacaocurso 	= $_POST['comprovacaocurso']; 

				$i1curso_palestras=0;				
				$i2curso_palestras=0;				
				$i3curso_palestras=0;				
				$i4curso_palestras=0;				


				while ($segmentoatuacaoid[$i1curso_palestras] != NULL) {

				$i1curso_palestras++;				
				$i2curso_palestras++;				
				$i3curso_palestras++;				
				$i4curso_palestras++;	

				$query_curso_palestras="INSERT INTO cursopalestra (`trabalhadorid` ,`situacao` ,`segmentoatuacaoid` ,`curso` ,`comprovacao`)VALUES
				( '$id', '$situacaocurso[$i1curso_palestras]', '$segmentoatuacaoid[$i2curso_palestras]', '$curso[$i3curso_palestras]', '$comprovacaocurso[$i4curso_palestras]')";	
				$rs2_query_curso_palestras= mysql_query($query_curso_palestras);
					
				$deletec="DELETE from cursopalestra WHERE segmentoatuacaoid=''";
				$deletersc= mysql_query($deletec);
				}				
			
				if ($rs) {

					?>
					<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Cadastro salvo!")</SCRIPT>
					<SCRIPT language="JavaScript">window.location.href="emcaminhamento.php?cpf_busca=<?=$cpf;?>";</SCRIPT>
					<?

				} else {

					?>
					<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Não foi possível Salvar os dados , tente novamente. n\ ")</SCRIPT>
					<SCRIPT language="JavaScript">window.history.go(-1);</SCRIPT>
					<?
			
						//echo "<br />Dados sobre o erro:" . mysql_error();

				}
			
			
			
			
		break;
					
			
		?>			
			
		<?
		break;
		
		case historico:
		
			$id 	= $_GET['id']; 
			
			$cboid_query = $_POST['cboid'];			
			$query_cboid = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$cboid_query%'";	
			$rs_cboid    = mysql_query($query_cboid); 													
			while($campo_cboid= mysql_fetch_array($rs_cboid)){		 
			$cboid= $campo_cboid['id'];
			}		
			$empresa = $_POST['empresa'];			
			$cargo = $_POST['cargo'];			
			$carteiraassinada = $_POST['carteiraassinada'];
			$ativo = $_POST['ativo'];			
			$datainicio_1 	=(string)addslashes($_POST['datainicio']); 
			$datainicio = implode("-",array_reverse(explode("/",$datainicio_1)));			
			$datafinal_1 	=(string)addslashes($_POST['datafinal']); 
			$datafinal = implode("-",array_reverse(explode("/",$datafinal_1)));			
			$tempanos	 = $_POST['tempanos'];
			$tempomes = $_POST['tempomes'];
			
			$query ="INSERT INTO historico ( `trabalhadorid`, `cboid`, `empresa`, `cargo`, `carteiraassinada`, `ativo`, `datainicio`, `datafinal`, `tempanos`, `tempomes`) VALUES ( '$id', '$cboid', '$empresa ', '$cargo', '$carteiraassinada', '$ativo', '$datainicio', '$datafinal ', '$tempanos', '$tempomes');";
			$rs = mysql_query($query);
			
			$query3 = "update  trabalhador set usuarioid='$usuarioID'  where id ='$id';";
			$rs3= mysql_query($query3);	
		
			?>
					
			<?
			
		
		
		break;
		
		case qualificacao:
		
		$id 	= $_POST['id2']; 
		$escolaridade 	= $_POST['escolaridade']; 
		$situacao 	= $_POST['situacao']; 
		$serie 	= $_POST['serie']; 
		$turno 	= $_POST['turno']; 
		$formacaoacademicaidbusca 	= $_POST['formacaoacademicaidbusca']; 
		$formacaoacademicaid 	= $_POST['formacaoacademicaid']; 
		$outrocurso 	= $_POST['outrocurso']; 
		$instituicao 	= $_POST['instituicao']; 
		$comprovacao 	= $_POST['comprovacao']; 
		$softwareid1 	= $_POST['softwareid1']; 
		$softwareid2 	= $_POST['softwareid2']; 
		$softwareid3 	= $_POST['softwareid3']; 
		$idiomaid1 	= $_POST['idiomaid1']; 
		$idiomaid2 	= $_POST['idiomaid2']; 
		$idiomaid3 	= $_POST['idiomaid3']; 
		$leitura1 	= $_POST['leitura1']; 
		$leitura2 	= $_POST['leitura2']; 
		$leitura3	= $_POST['leitura3']; 
		$conversacao1	= $_POST['conversacao1']; 
		$conversacao2	= $_POST['conversacao2']; 
		$conversacao3	= $_POST['conversacao3']; 
		$escrita1	= $_POST['escrita1']; 
		$escrita2	= $_POST['escrita2']; 
		$escrita3	= $_POST['escrita3']; 
		
		
		
		$query2 = "update  trabalhador set usuarioid='$usuarioID',  escolaridade='$escolaridade', situacao='$situacao', serie='$serie', turno='$turno', formacaoacademicaidbusca='$formacaoacademicaidbusca', formacaoacademicaid='$formacaoacademicaid', outrocurso='$outrocurso',instituicao='$instituicao', comprovacao='$comprovacao', softwareid1='$softwareid1',softwareid2='$softwareid2',softwareid3='$softwareid3', idiomaid1='$idiomaid1' , idiomaid2='$idiomaid2' , idiomaid3='$idiomaid3', leitura1='$leitura1' ,leitura2='$leitura2',leitura3='$leitura3' , conversacao1='$conversacao1',conversacao2='$conversacao2', conversacao3='$conversacao3' , escrita1 ='$escrita1' , escrita2='$escrita2' , escrita3='$escrita3' where id ='$id';";
		$rs2= mysql_query($query2);	
		
		echo"DADOS SALVO!";
		
		break;
		
		case curso_palestras:
		
		$id 	= $_GET['id']; 
		$situacao 	= $_GET['situacaocurso']; 
		$segmentoatuacaoid 	= $_GET['segmentoatuacaoid']; 
		$curso 	= $_GET['curso']; 
		$comprovacao 	= $_GET['comprovacaocurso']; 	
		
		
		$query2c="INSERT INTO cursopalestra (`trabalhadorid` ,`situacaocurso` ,`segmentoatuacaoid` ,`curso` ,`comprovacaocurso`)VALUES ( '$id', '$situacao', '$segmentoatuacaoid', '$curso', '$comprovacao')";	
		$rs2c= mysql_query($query2c);
		
		$query3ct = "update  trabalhador set usuarioid='$usuarioID'  where id ='$id';";
		$rs3ct= mysql_query($query3ct);	
		
			
		?>

		
		
		<?
		break;
		
}		
		?>		