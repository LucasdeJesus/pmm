		<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);


 
		$idencaminhamento= $_POST['idencaminhamento']; 	 
		$id_vaga= $_POST['id_vaga_e']; 	 
		$status_e= $_POST['status']; 	 
		$id_trabalhadore= $_POST['id_trabalhadore_e']; 	 
		$obs = $_POST['obs']; 	 
		
		$id_emcaminhamento= $_POST['id_emcaminhamento_e'];
		$cpf= $_POST['cpf3'];
		
		$acao= $_GET['acao']; 	 		 			 	
				 			 	
		
		$dia= date("d");
		$mes= date("m");
		$ano= date("Y");
		
		switch ($acao) {
			case cadastro:
			
				if($id_emcaminhamento =="")
				{
				
				
				
						$query_noticias_total_emcav = "SELECT * FROM  encaminhamento  WHERE vagaid ='$id_vaga' and trabalhadorid='$id_trabalhadore'";	
						$rs_noticias_total_emcav   = mysql_query($query_noticias_total_emcav); 
						$total_total_emcav = mysql_num_rows($rs_noticias_total_emcav);
						
						if($total_total_emcav > 0)
						{
						echo"2";
						}else{
								if($id_vaga > 0){
								
									$query="INSERT INTO `encaminhamento` ( `trabalhadorid`, `vagaid`, `observacao`, `status`, `usuarioid` ) VALUES ('$id_trabalhadore', '$id_vaga', '$obs', '$status_e', '$usuarioID');";
									$rs= mysql_query($query);	

									$query_noticias = "SELECT * FROM `vaga` where id ='$id_vaga'";			
									$rs_noticias    = mysql_query($query_noticias); 
									while($campo_noticias = mysql_fetch_array($rs_noticias)){							
									$quantidadeencaminhar= $campo_noticias['quantidadeencaminhar']; 
									}
								
									
									
									
									$query_noticias_total_emca = "SELECT * FROM  encaminhamento  WHERE vagaid ='$id_vaga'";	
									$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
									$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
									
									if($total_total_emca >= $quantidadeencaminhar )

									{
									$date = date('Y-m-d H:i:s');
									$query_atualiza_status_vaga="UPDATE `vaga` set status ='R' , dataaguardamdo ='$date' where  id ='$id_vaga' ";
									$rs_atualiza= mysql_query($query_atualiza_status_vaga);	
										
									}
									
									echo"1";
									
									}
						}
									 
								
					
					
					
						
				}
				else
				{

				
					
					/*$query="UPDATE `emcaminhamento` SET id_trabalhandor='$id_trabalhandor ', id_vaga='$id_vaga ', obs='$obs ', selStatus='$selStatus ', data=CURRENT_TIMESTAMP, id_usuario='$usuarioID ', dia='$dia ', mes='$mes ', ano='$ano' where id_emcaminhamento='$id_emcaminhamento'";
					$rs= mysql_query($query);	*/
				
				
					//echo"Alteração  Feita!";
				}					
					
					
			
			
			break;
			
			
			
			case atendimento:
			
			$atendimento= $_POST['atendimento'];
			$id_trabalhadore_e= $_POST['id_trabalhadore_e'];
			if($atendimento==""){}else{
			
				
					
					
						$query="INSERT INTO `atendimento` (`atividade`,`usuarioID`,`idtrabalhador`) VALUES ('$atendimento','$usuarioID','$id_trabalhadore_e')";
						$rs= mysql_query($query);					
						if ($rs) {}else{echo"$query";}
				
					
					
			}
			?>
			
			<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Atendimento Finalizado!")</SCRIPT>
					<SCRIPT language="JavaScript">window.location.href="conteudo.php";</SCRIPT>
			<?
			
			break;
			
			
			case editar:
			
		
					
			$query="UPDATE `encaminhamento` SET  vagaid='$id_vaga', usuarioid='$usuarioID', observacao='$obs' where id='$idencaminhamento'";
			$rs= mysql_query($query);					
			if ($rs) {?>
			<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Encaminhamento Salvo!")</SCRIPT>
					<SCRIPT language="JavaScript">window.location.href="altera_encaminhamento.php?idencaminhamento=<?=$idencaminhamento;?>";</SCRIPT>
			<?}else{			
			?>
			<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Não foi possível cadastrar, tente novamente.  ")</SCRIPT>
					<SCRIPT language="JavaScript">window.history.go(-1);</SCRIPT>
			
			<?}
				
					
					
			
			break;
			
			
			case excluir:
			
			$id_encaminhamento= $_GET['id'];
			$nome= $_GET['nome'];
			?>
			
			
				<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
				
				decisao = confirm("Deseja realmente excluir Encaminhamento ID:\n <?=$id_encaminhamento;?>?");				
				if (decisao){
				
				<?
				$query="DELETE FROM  encaminhamento where id='$id_encaminhamento'";
				$rs= mysql_query($query);	
				?>
				alert ("Encaminhamentoexcluida com sucesso!");
				setTimeout("self.close();",2);
				
				} 
				else 
				
				{				
				alert ("Opreação cancelada,\n"			
				);
				setTimeout("self.close();",2);
				
				}
				
				</SCRIPT>
			<?
		
			break;
			
			
		
		}
	
		
		?>		