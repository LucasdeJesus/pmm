		<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);

		$id= $_GET['id'];	 
		$cnpj 	=(string)addslashes($_POST['cnpj']);	 		 			 	
		$selTipo	=(string)addslashes($_POST['selTipo']);	 		 			 	
		$razaosocial	=(string)addslashes($_POST['razaosocial']);	 		 			 	
		$nome	=(string)addslashes($_POST['nome']);	 		 			 	
		$segmentoatuacaoid	=(string)addslashes($_POST['segmentoatuacaoid']);	 		 			 	
		$inscmunicipal	=(string)addslashes($_POST['inscmunicipal']);	 		 			 	
		$inscestadual	=(string)addslashes($_POST['inscestadual']);	 		 			 	
		$endereco	=(string)addslashes($_POST['endereco']);	 		 			 	
		$bairro	=(string)addslashes($_POST['bairro']);	 		 			 	
		$cidadeid	=(string)addslashes($_POST['cidadeid']);	 		 			 	
		$txtestado	=(string)addslashes($_POST['txtestado']);	 		 			 	
		$cep	=(string)addslashes($_POST['cep']);	
		$emailresponsavel	=(string)addslashes($_POST['emailresponsavel']);	 		 			 	
		$tel1=(string)addslashes($_POST['tel1']);	 		 			 	
		$tel2=(string)addslashes($_POST['tel2']);	 		 			 	
		$tel3=(string)addslashes($_POST['tel3']);	 		 			 	
		$cepentrevista=(string)addslashes($_POST['cepentrevista']);	 		 			 	
		$email=(string)addslashes($_POST['email']);	 		 			 	
		$homepage=(string)addslashes($_POST['homepage']);	 		 			 	
		$responsavel=(string)addslashes($_POST['responsavel']);	 		 			 	
		$cargoresponsavel=(string)addslashes($_POST['cargoresponsavel']);	 		 			 	
		$contato=(string)addslashes($_POST['contato']);	 		 			 	
		$cargocontato=(string)addslashes($_POST['cargocontato']);	 		 			 	
		$senha=(string)addslashes($_POST['senha']);	 		 			 	
		$emailcontato=(string)addslashes($_POST['emailcontato']);	 		 		 			 	
		$captadorid=(string)addslashes($_POST['captadorid']);	 		 			 	
		 		 			 	
		$status=(string)addslashes($_POST['status']);	 		 			 	
		$observacao=(string)addslashes($_POST['observacao']);	 		 			 	
		$acao= $_GET['acao'];	 	
		$localcaptacaoid=(string)addslashes($_POST['localcaptacaoid']);	 	

		$jovemaprendiz=(string)addslashes($_POST['jovemaprendiz']);	 
		$estagios=(string)addslashes($_POST['estagios']);	 
		$contapcd=(string)addslashes($_POST['contapcd']);	 
		$quantempregados=(string)addslashes($_POST['quantempregados']);												
		$referenciaend=(string)addslashes($_POST['referenciaend']);		
			
 $cepentrevista=(string)addslashes($_POST['cepentrevista']); 
 $cidadeentrevistaid=(string)addslashes($_POST['cidadeentrevistaid']);
 $bairroentrevista=(string)addslashes($_POST['bairroentrevista']);
 $enderecoentrevista=(string)addslashes($_POST['enderecoentrevista']);
 $proximode=(string)addslashes($_POST['proximode']);
 $falarcom=(string)addslashes($_POST['falarcom']);
 $numero=(string)addslashes($_POST['numero']);
 $numeroentrevista=(string)addslashes($_POST['numeroentrevista']);
		
				 	
				 			 	
		
		$dia= date("d");
		$mes= date("m");
		$ano= date("Y");
		
		switch ($acao) {
			case cadastro:
			
			$query="INSERT INTO `empresa` ( `localcaptacaoid`, `jovemaprendiz`,`estagios`, `contapcd`, `quantempregados`,`razaosocial`,`cnpj`,  `nome`, `segmentoatuacaoid`, `inscmunicipal`, `inscestadual`, `endereco`, `numero`, `bairro`, `cidadeid`,  `cep`,  `tel1`, `tel2`, `tel3`, `email`, `homepage`, `responsavel`, `cargoresponsavel`, `emailresponsavel`, `emailcontato`, `contato`, `cargocontato`, `captadorid`,  `status`, `observacao`, `usuarioid`,`referenciaend`,  `cepentrevista`,  `cidadeentrevistaid`, `bairroentrevista`, `enderecoentrevista`,`numeroentrevista`,  `proximode`, `falarcom`) VALUES ( '$localcaptacaoid','$jovemaprendiz', '$estagios', '$contapcd', '$quantempregados','$razaosocial','$cnpj',  '$nome', '$segmentoatuacaoid', '$inscmunicipal', '$inscestadual', '$endereco', '$numero','$bairro', '$cidadeid','$cep', '$tel1', '$tel2', '$tel3', '$email', '$homepage', '$responsavel', '$cargoresponsavel', '$emailresponsavel', '$emailcontato', '$contato', '$cargocontato', '$captadorid', '$status', '$observacao', '$usuarioID','$referenciaend','$cepentrevista','$cidadeentrevistaid','$bairroentrevista','$enderecoentrevista','$numeroentrevista','$proximode','$falarcom')";
			$rs= mysql_query($query);	
			
			
						
			if ($rs) {

					?>
					<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Cadastro Efetuado")</SCRIPT>
			<SCRIPT language="JavaScript">window.location.href="cadastro_empresa.php";</SCRIPT>
					<?

				} else {
			
					?>
					<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Não foi possível cadastrar, tente novamente.  ")</SCRIPT>
					<SCRIPT language="JavaScript">window.history.go(-1);</SCRIPT>
					<?
			
						//echo "<br />Dados sobre o erro:" . mysql_error();

				}

				//echo"$query";
				
			break;
		
		case editar:
		
			$query="update  empresa set  referenciaend='$referenciaend', localcaptacaoid='$localcaptacaoid',jovemaprendiz= '$jovemaprendiz', estagios= '$estagios', contapcd= '$contapcd', 	 quantempregados= '$quantempregados', cnpj='$cnpj', razaosocial='$razaosocial',  nome='$nome', segmentoatuacaoid='$segmentoatuacaoid', inscmunicipal='$inscmunicipal', inscestadual='$inscestadual', endereco='$endereco', bairro='$bairro', cidadeid='$cidadeid', cep='$cep', tel1='$tel1', tel2='$tel2', tel3='$tel3', email='$email', homepage='$homepage',responsavel='$responsavel', cargoresponsavel='$cargoresponsavel', emailresponsavel='$emailresponsavel', emailcontato='$emailcontato', contato='$contato', cargocontato='$cargocontato', captadorid='$captadorid',  status='$status', observacao='$observacao', usuarioid='$usuarioID' ,
			cepentrevista= '$cepentrevista',					 
			cidadeentrevistaid= '$cidadeentrevistaid',
			bairroentrevista= '$bairroentrevista',
			enderecoentrevista= '$enderecoentrevista',
			proximode= '$proximode',
			numero= '$numero',
			numeroentrevista= '$numeroentrevista',
			falarcom= '$falarcom'
			where id='$id'";
			$rs= mysql_query($query);		
		
			
			
						
			if ($rs) {

					?>
					<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Cadastro Efetuado!")</SCRIPT>
			<SCRIPT language="JavaScript">window.location.href="cadastro_empresa.php?cnpj=<?=$cnpj;?>";</SCRIPT>
					<?

				} else {

					?>
					<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Não foi possível cadastrar, tente novamente.  ")</SCRIPT>
					<SCRIPT language="JavaScript">//window.history.go(-1);</SCRIPT>
					<?
			
						echo "$query";

				}
			break;
			
			case excluir:
			
			$id= $_GET['id'];
			$nome= $_GET['nome'];
			?>
			
			
				<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
				
						<?
						
					$query_noticias_total_emca = "SELECT * FROM  encaminhamento  WHERE empresaid ='$id'";	
					$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
					$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
					if($total_total_emca >0 ){
					
					?>
					
							alert("Não permetido excluir  Empresa \n existe  vagas para esta Empresa! ")
						setTimeout("self.close();",2);
				
						
						
						<?
					}
					else
					{
					
						
						$query_noticias = "SELECT * FROM `empresa` where id='$id'";
						$rs_noticias    = mysql_query($query_noticias);
						while($campo_noticias = mysql_fetch_array($rs_noticias)){
						$cnpj 	= $campo_noticias['cnpj']; 	 		 			 	
						 }	
		
		
						
						
						$queryu="DELETE FROM  usuario  where usuario='$cnpj'";
						$rsu= mysql_query($queryu);	
						$query="DELETE FROM  empresa  where id='$id'";
						$rs= mysql_query($query);	
						
						
						?>
						alert("Excluindo Empresa <?=$nome;?> ?");
						window.location.href="lista_empresa.php?cnpj=<?=$cnpj;?>";
						<?}?>
				
				</SCRIPT>
			<?
		
			break;
			
			
			case excluirpalaestra:
			
			$id= $_GET['id'];
			$nome= $_GET['nome'];
			?>
			
			
				<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
				
						<?
						
						$queryu="DELETE FROM  palestra  where id='$id'";
						$rsu= mysql_query($queryu);	
						
						
						
						?>
						alert("Excluindo !");
						window.location.href="smseventos.php";
						
				
				</SCRIPT>
			<?
		
			break;
			
			
		
		}
	
		
		?>		