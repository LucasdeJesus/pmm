<?php
include"input_banco.php";
?>
<html lang="en" class="no-js">
<!--<![endif]-->


<!-- Mirrored from www.scoopthemes.com/templates/Oleose/Freeze/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Sep 2015 12:49:54 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<?
    $login_cookie = $_COOKIE['usuario'];
        if(isset($login_cookie)){
           // echo"Bem-Vindo, $login_cookie <br>";
            //echo"Essas informações <font color='red'>PODEM</font> ser acessadas por você";
			
			
			
			
        }else{
            ?>
			<script>
			parent.location="login.php";
			
			</script>
			<?
        }
		
		function protegepagina(){};
		
		
		
		$sql32u = "SELECT * FROM `usuario` WHERE `usuario` = '$login_cookie' limit 1";
			$rsd32u = mysql_query($sql32u);
			while($rs32u = mysql_fetch_array($rsd32u)) {
			//$perfil = $rs32u['perfil'];
			$usuarioID = $rs32u['id'];
			//echo"$usuarioID";
			}
			
		
		
?>


