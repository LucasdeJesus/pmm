<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener'>

<script type="text/javascript">
function mascaraMutuario(o,f){
    v_obj=o
    v_fun=f
    setTimeout('execmascara()',1)
}
 
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
 
function cpfCnpj(v){
 
    //Remove tudo o que não é dígito
    v=v.replace(/\D/g,"")
 
    if (v.length <= 13) { //CPF
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        //de novo (para o segundo bloco de números)
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um hífen entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")
 
    } else { //CNPJ
 
        //Coloca ponto entre o segundo e o terceiro dígitos
        v=v.replace(/^(\d{2})(\d)/,"$1.$2")
 
        //Coloca ponto entre o quinto e o sexto dígitos
        v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
 
        //Coloca uma barra entre o oitavo e o nono dígitos
        v=v.replace(/\.(\d{3})(\d)/,".$1/$2")
 
        //Coloca um hífen depois do bloco de quatro dígitos
        v=v.replace(/(\d{4})(\d)/,"$1-$2")
 
    }
 
    return v
 
}
			</script>
			

			
	
<form  class="form" style='width:100%;'action='smseventos.php'method="GET" >						
			<div class="form-row">
			<div class="label">NOME</div>
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="campo"  name='campo' value="nome" type="hidden"  />
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="busca_nome" id="busca_nome"   style="width:456px;"  tabindex="1"  type="text" class="input req-same">
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Buscar" type="submit" class="sendBtn" />
			</div>
			</div>
			
		
</form>

		

<form  class="form" style='width:100%;'method="post" >

		<h2>Palestras</h2>
			<a href="smseventos.php?busca_cnpj1=1&campo=1">1 - RH nos Momentos de Adversidades e o Fator Humano na Gestão de Empresas de Energia</a><br>
			<a href="smseventos.php?busca_cnpj1=2&campo=1">2 - Planejamento de Carreira</a><br>
			<a href="smseventos.php?busca_cnpj1=3&campo=1">3 - Como posso agregar valor à empresa e para meu desenvolvimento</a><br>
			<a href="smseventos.php?busca_cnpj1=4&campo=1">4 - Dando a volta por cima</a><br>
			<a href="smseventos.php?busca_cnpj1=5&campo=1">5 - Qualificação Profissional alavancando a carreira</a><br><br><br>
			
		<h2>Lista de Cadastro</h2>
		<?$endereco = $_SERVER ['REQUEST_URI'];;?>
		<a href="smseventos.php" class="myButton"><img src='img/table_refresh.png' />Atualizar</a> 
	<table style='width:95%;'>
			<tr>
				<td class='td1' >N°</td>
				<td class='td1' >Nome </td>
				<td class='td1' >Cargo</td>
				
				<td class='td1' >Email</td>			
				<td class='td1'>Celular</td>
				<td class='td1'>Empresa</td>
				<td class='td1'>TEl. Empresa</td>
				<td class='td1'>Palestra</td>
				
				
				<td class='td1'style='width:80px'>
				
				</td>
			
						
			</tr>
			
						<?
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
			$numero=1;
			
			if($campo==""){
			$query_noticias = "SELECT * FROM `palestra` ORDER BY `id` DESC LIMIT 0 , 300";
			}
			else
			{
				if($busca_nome=='')
				{
				
				$query_noticias = "SELECT * FROM `palestra`WHERE  `palestra` LIKE '%$busca_cnpj1%' ";
				echo"Busca pela Palestra $busca_cnpj1";
				}
				else
				{
				$query_noticias = "SELECT * FROM `palestra` WHERE `nome` LIKE '%$busca_nome%'  ";
				}
				
			}
		
		
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);	
		
			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$id 	= $campo_noticias['id']; 	 		 			 	
		$nome 	= $campo_noticias['nome']; 	 		 			 	
		$cargo 	= $campo_noticias['cargo']; 	 		 			 	
		$email 	= $campo_noticias['email']; 	 		 			 	
		$palestra 	= $campo_noticias['palestra']; 	 		 			 	
		$celular 	= $campo_noticias['celular']; 	 		 			 	
		$empresa 	= $campo_noticias['empresa']; 	 		 			 	
		$telefone 	= $campo_noticias['telefone']; 	 		 			 	
		 
		
		
		
		
			?>

			<tr class='tr_tb' >		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$nome ;?> </td>
				<td class='td2' >  <?=$cargo;?></td>				
				<td class='td2' >  <?=$email;?></td>		
							
													
													
				<td class='td2' >  <?=$celular;?></td>				
				<td class='td2' >  <?=$empresa;?></td>				
				<td class='td2' >  <?=$telefone;?></td>				
				<td class='td2' >  <?=$palestra;?></td>				
				<td class='td2' >
				
				 
				<!--<a href="javascript:Abrir_Pagina('cadastro_empresa.php?cnpj=<?=$cnpj;?>','scrollbars=yes,width=600,height=500')" title='Enviar SMS para <?=$nome ;?> '><img src='img/novo_item.png'/></a> -->
				<a href="javascript:Abrir_Pagina('enviarsms.php','scrollbars=yes,width=600,height=500')" title='Enviar Sms '><img src='img/inserir_curso.png'/></a> 
				
				
				<script>
					function ConfirmDelete_<?=$id;?>(){

					var del=confirm("Deseja Excluir  <?=$nome;?> ?");
					if (del==true){
					//alert ("Excluindo..")
					window.location.href="script_empresa.php?acao=excluirpalaestra&id=<?=$id;?>&nome=<?=$nome;?>";
					}else{
					alert("Excluição cancelada")
					}
					return del;
					}
					//javascript:Abrir_Pagina('script_vaga.php?acao=excluir&id_vaga=<?=$id_vaga;?>&nome=<?=$id_vaga;?>','scrollbars=yes,width=600,height=500')
					</script>
					
				<a href="#" Onclick="ConfirmDelete_<?=$id;?>();" title='Excluir'><img src='img/delete.png'/></a> </td> 
			</tr>
		<?}?>	

	</table>
	
		<?
	if($total=="")
				
				{echo"<h3>Nenhuma Empresa foi encontrada.</h3>";}else{}
				
				?>
	

</form>
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
