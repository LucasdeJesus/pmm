<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener'>
<script type="text/javascript">
	<!--
	function toggle(obj) {
		var el = document.getElementById(obj);
		if ( el.style.display != "none" ) {
			el.style.display = 'none';
		}
		else {
			el.style.display = '';
		}
	}
	-->
	
	 $(function() {


                $("#datainicio").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1970:<?= $anofinaldata; ?>',
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'],
                    dayNamesMin: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
                    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
                    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
                    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
                });
				
				 $("#datafinal").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1970:<?= $anofinaldata; ?>',
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'],
                    dayNamesMin: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
                    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
                    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
                    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
                });


            });
			
			 $().ready(function() {
                $("#ocupacao").autocomplete("789/autoComplete.php", {
                    matchContains: true,
                    mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
			});
			
	</script>
<script type="text/javascript">
function mascaraMutuario(o,f){
    v_obj=o
    v_fun=f
    setTimeout('execmascara()',1)
}
 
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
 
function cpfCnpj(v){
 
    //Remove tudo o que não é dígito
    v=v.replace(/\D/g,"")
 
    if (v.length <= 13) { //CPF
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        //de novo (para o segundo bloco de números)
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um hífen entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")
 
    } else { //CNPJ
 
        //Coloca ponto entre o segundo e o terceiro dígitos
        v=v.replace(/^(\d{2})(\d)/,"$1.$2")
 
        //Coloca ponto entre o quinto e o sexto dígitos
        v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
 
        //Coloca uma barra entre o oitavo e o nono dígitos
        v=v.replace(/\.(\d{3})(\d)/,".$1/$2")
 
        //Coloca um hífen depois do bloco de quatro dígitos
        v=v.replace(/(\d{4})(\d)/,"$1-$2")
 
    }
 
    return v
 
}
			</script>
			

			
	
<form  class="form" style='width:100%;'action='smsinformativo.php'method="post" >						
		<table border="1" style='width:50%;'>
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Data de Cadastro&nbsp;</b></font>
										</td>
										<td>
											<input type=text name="datainicio" id="datainicio" maxlength=10 onBlur="verificaData('window.document.Ficha.flt_Data_ini');" onKeyUp="VerificaMascara('window.document.Ficha.flt_Data_ini','##/##/####',1)" style="width:55px;" value="">
											&nbsp;até&nbsp;
											<input type=text name="datafinal" id="datafinal" maxlength=10 onBlur="verificaData('window.document.Ficha.flt_Data_fim');" onKeyUp="VerificaMascara('window.document.Ficha.flt_Data_fim','##/##/####',1)" style="width:55px;" value="">
										</td>
									</tr>
									
				
		
								
									
									<tr>
										<td bgcolor="#000080" colspan="2" align="center">
											<input type="submit" name="btBuscar"  value=" Buscar ">		
											<input type="hidden" name="filtro"  value="Buscar ">		
										<button onClick="window.location.reload();">Limpar filtro</button>											
										</td>
									</tr>
								</table>
								<input type="hidden" name="acao"  value="post">
				
		
</form>

		

<form  class="form" style='width:100%;'method="post" >

		<h2>SMS Enviadas</h2>
			
		<h2>Lista de Cadastro</h2>
		<?$endereco = $_SERVER ['REQUEST_URI'];;?>
		<a href="smseventos.php" class="myButton"><img src='img/table_refresh.png' />Atualizar</a> 
	<table style='width:95%;'>
			<tr>
				
				<td class='td1' >Vaga </td>
				
				
			
						
			</tr>
			
						<?
						
		$post_datainicio = $_POST['datainicio'];	
		$post_datafinal = $_POST['datafinal'];	
		$filtro = $_POST['filtro'];	
		
		$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
		$post_datafinal1 = implode("-",array_reverse(explode("/",$post_datafinal)));	
		
		$post_datainicio1 = date("Y-m-d", strtotime($post_datainicio1));
				
		if(($post_datainicio=="") || ($post_datafinal==""))
		{
			
			//$post_datainicio1 = date("Y-n-j", strtotime($post_datainicio));
			//$post_datafinal1 = date("Y-n-j", strtotime($post_datafinal));
			
			
			if($post_datainicio==""){}else{
				
				//$post_datainicio1 = date("Y-n-j", strtotime($post_datainicio1));
				$sql2data=" `data` LIKE '%$post_datainicio1%' ";
			}
			if($post_datafinal1==""){}else{
				$post_datafinal1 = date("Y-m-d", strtotime($post_datafinal1));
				$sql2data=" `data` LIKE '%$post_datafinal1%' ";}
			
		
		}
		else{
		$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1))); // 15/03/2006
		$sql2data= " `data` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
		}
				
			
		$totalsms = 0;	
		if($filtro=="")	{
		$datahjbusca= date("Y-m-d");
		$query_noticias = "SELECT id,idvaga,idtrabalhador FROM  `smstrabalhador` WHERE  `data` LIKE  '%$datahjbusca%'  " ;
		
		}else{
			
			$query_noticias = "SELECT id,idvaga,idtrabalhador FROM  `smstrabalhador` WHERE  $sql2data " ;	
			
		}
		//echo $query_noticias;
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);		
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$idvaga 	= $campo_noticias['idvaga']; 	 		 			 	
		$idtrabalhador 	= $campo_noticias['idtrabalhador']; 	 		 			 	


		 
		
				 		 			 	
				
		
			?>

			<tr class='tr_tb' >		
				<?
				
				$query_noticiasvaga = "SELECT id,cargo FROM  `vaga` WHERE  id='$idvaga'  " ;
				$rs_noticiasvaga    = mysql_query($query_noticiasvaga); 
				$totalvaga = mysql_num_rows($rs_noticiasvaga);		
				while($campo_noticiasvaga = mysql_fetch_array($rs_noticiasvaga)){
				$cargo 	= $campo_noticiasvaga['cargo']; 	
				$idvagasalva 	= $campo_noticiasvaga['id']; 	
				?>
				<td class='td2' > <b>ID vaga: <?=$idvagasalva ;?> - <?=$cargo ;?> </b></td>
				<?}?>
			</tr>
			
			
			<tr class='tr_tb' >		
				
				<td class='td2' >
				
					<table style='width:95%;'>
					
					
							<?
							$or=1;
							$query_noticiastrabalhador = "SELECT id,nome,telcel FROM  `trabalhador` WHERE   id IN (0$idtrabalhador )  " ;
							$rs_noticiastrabalhador   = mysql_query($query_noticiastrabalhador); 
							$totaltrabalhador = mysql_num_rows($rs_noticiastrabalhador);
							$totalsms+=$totaltrabalhador;
							while($campo_noticiastrabalhador = mysql_fetch_array($rs_noticiastrabalhador)){
							$nome 	= $campo_noticiastrabalhador['nome']; 	
							$telcel 	= $campo_noticiastrabalhador['telcel']; 	
							?>
					
						<tr class='tr_tb' >	
					
							<td class='td2'  width="5%"><?=$or++;?>	</td>
							<td class='td2'  width="70%"><?=$nome;?>	</td>
							<td class='td2' width="25%"><?=$telcel;?>	</td>
						</tr>
						<?}?>
					</table>
					
					
				</td>
				
			</tr>
		<?}?>	

	</table>
	<?=$totalsms;?>
		<?
	if($total=="")
				
				{echo"<h3>Nenhuma Empresa foi encontrada.</h3>";}else{}
				
				?>
	

</form>
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
