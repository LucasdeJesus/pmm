
	
<h2>PERFIL SÓCIO-ECONÔMICO</h2>

			<div class="form-row">
			<div class="label">Alguém na residência está inscrito em algum Programa Social</div>
			<div class="input-container" style='width:546px;'>		
			<select name="selprogramassociais" id="selprogramassociais" onclick="ajusta_lista('window.document.Ficha.selprogramassociais','window.document.Ficha.hidprogramassociais')" style="width:497px;" tabindex="4" multiple="" size="8" onblur="EditandoRegistro();">
			<option value="7">APOSENTADORIA - IDADE</option>
			<option value="8">APOSENTADORIA - INVALIDEZ</option>
			<option value="6">AUXILIO DOENÇA</option>
			<option value="1">BOLSA FAMILIA</option>
			<option value="5">CESTA BÁSICA</option>
			<option value="10">JOVEM APRENDIZ</option>
			<option value="9">OUTROS</option>
			<option value="3">PETI</option>
			<option value="2">SEGURO DESEMPREGO</option>

			</select>	

			</div>
			</div>
			
			
			<h2>COMPOSIÇÃO FAMILIAR</h2>
			
			
			<div class="form-row">
			<div class="label">Tipo</div>
			<div class="input-container" style='width:546px;'>		
					<select name="cbotipo" id="cbotipo" onchange="EditandoRegistro();" tabindex="6" style="width:100">
						<option value="">Selecione</option>
						<option value="1">Pai / Mãe</option>
						<option value="2">Irmã(o)</option>
						<option value="3">Companheiro(a)</option>
						<option value="4">Filho(a)</option>
						<option value="5">Outros</option>
					</select>

			</div>
			</div>
			
			
			
			<div class="form-row">
			<div class="label">Nome</div>
			<div class="input-container" style='width:546px;'>		
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txnome_morador" id="txnome_morador" maxlength="100" class="input req-same" onchange="Maiuscula(this)" tabindex="7"  type="text">
			</div>
			</div>
			
			
			
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
				<b>Data Nascimento</b>
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtdtnasc_morador" id="txtdtnasc_morador" maxlength="10" class="input req-same" onchange="EditandoRegistro();" onblur="verificaData('window.document.Ficha.txtdtnasc_morador')" onkeyup="VerificaMascara('window.document.Ficha.txtdtnasc_morador','##/##/####',1)" tabindex="8" style="width:55px;" type="text">
			<b>Escolaridade</b>
			<select name="cboescolaridade" id="cboescolaridade" tabindex="9" style="width:90px" onchange="EditandoRegistro();">
				<option value="">Selecione</option>
				<option value="0">Analfabeto</option>
				<option value="L">Alfabetizado</option>
				<option value="1">Fundamental</option>
				<option value="2">Médio</option>
				<option value="3">Pós-Médio</option>
				<option value="4">Superior</option>
				<option value="P">Pós-Graduação</option>
				<option value="M">Mestrado</option>	
				<option value="D">Doutorado</option>
			</select>
			<b>Situação</b>
			<select name="cbosituacao" id="cbosituacao" onchange="EditandoRegistro();" tabindex="10" style="width:73px">
				<option value="">Selecione</option>
				<option value="C">Completo</option>
				<option value="I">Incompleto</option>	
				<option value="U">Cursando</option>	
			</select>
			
			
			</div>
			</div>
			
	
	
	<div class="form-row">
	    <div class="label">Renda</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtrendafamiliar" id="txtrendafamiliar" class="input req-same" maxlength="20" onchange="EditandoRegistro();" onkeyup="VerificaMascara('window.document.Ficha.txtrendafamiliar','###.###.###,##',0)" tabindex="11" type="text">
		</div>
	</div>
	<div class="form-row">
	    <div class="label">Ocupação Exercida</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="txtocupacao1" id="txtocupacao1" size="60" class="input req-same" maxlength="200" onchange="EditandoRegistro()" tabindex="12"  value="" type="text">
		</div>
	</div>
	