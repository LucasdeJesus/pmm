<head>
<?$baseurl = "http://" .$_SERVER['SERVER_NAME']."/pmm/interno"; ;

		
			$sql323r = "SELECT usuario FROM `usuario` WHERE `id` = '$usuarioID'";
			$rsd323r = mysql_query($sql323r);
			while($rs323r = mysql_fetch_array($rsd323r)) {
			
			$usuariologado3 = $rs323r['usuario'];
			
			}
//$actual_link = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
$actual_link = 'http' . (($_SERVER['HTTPS'] == 'on') ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
date_default_timezone_set('America/Sao_Paulo');
$datewww = date('Y-m-d H:i');

/* arquivo a ser aberto | coloque um valor padrão na 1ª linha */
$arquivo3="log.txt";
 
/* abre o arquivo para leitura */
$lendo3=fopen($arquivo3, "r+");
 
/* pega o conteúdo do arquivo */
$conteudo33=fread($lendo3,filesize($arquivo3));
 
/* fecha o arquivo */
fclose($lendo3);
 
/* abre o arquivo para escrita */
$escrevendo3=fopen($arquivo3, "w+");
 
/* pega o conteúdo atual do arquivo */
$dados3="$conteudo33";
 
/* abaixo é pulado uma linha no conteúdo atual e somado: novo texto */
$dados3.="\n $actual_link - $usuariologado3 - $datewww";
 
/* é escrito o novo valor */
$escreve3=fwrite($escrevendo3,$dados3);
 
/* fecha o arquivo */
fclose($escrevendo3);
 
/* mostra o conteúdo escrito */
//echo nl2br($conteudo33);

$horaagora = date('H');
if($horaagora > 19){
	if($usuariologado3=="lucas"){
	}else{
	
	}

}

?>
<!--------------------css paginas--------------->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Utopic Farm - Form Validator 1.0.4</title>
    <link rel="stylesheet" type="text/css" href="<?=$baseurl;?>/assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="<?=$baseurl;?>/assets/styles.css" />
			
			<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>	

	<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-62329413-1', 'auto');
  ga('send', 'pageview');

</script> 
	<!--------------------valida cpf--------------->										
<script language="JavaScript">
function validar_cpf(){
var cpf_busca = document.cadastro.cpf_busca.value;
var idtr = document.cadastro.idtr.value;
if(idtr ==""){
	var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
	if(!filtro.test(cpf_busca)){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}

	cpf_busca = remove(cpf_busca, ".");
	cpf_busca = remove(cpf_busca, "-");

	if(cpf_busca.length != 11 || cpf_busca == "00000000000" || cpf_busca == "11111111111" ||
	cpf_busca == "22222222222" || cpf_busca == "33333333333" || cpf_busca == "44444444444" ||
	cpf_busca == "55555555555" || cpf_busca == "66666666666" || cpf_busca == "77777777777" ||
	cpf_busca == "88888888888" || cpf_busca == "99999999999"){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}

	soma = 0;
	for(i = 0; i < 9; i++)
	soma += parseInt(cpf_busca.charAt(i)) * (10 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(9))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	soma = 0;
	for(i = 0; i < 10; i ++)
	soma += parseInt(cpf_busca.charAt(i)) * (11 - i);
	resto = 11 - (soma % 11);
	if(resto == 10 || resto == 11)
	resto = 0;
	if(resto != parseInt(cpf_busca.charAt(10))){
	window.alert("CPF INVÁLIDO. TENTE NOVAMENTE.");
	return false;
	}
	return true;
  }
}

	function remove(str, sub) {
	i = str.indexOf(sub);
	r = "";
	if (i == -1) return str;
	r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
	return r;
	}
	
</script>

<link rel="stylesheet" href="<?=$baseurl;?>/css/jquery-ui.css" />
<script type="text/javascript" src="<?=$baseurl;?>/js/jquery-1.8.2.js"/></script>
<script type="text/javascript" src="<?=$baseurl;?>/js/jquery-ui.js"/></script>

<?php $anofinaldata= date("Y"); ?>


	<script type="text/javascript">		
		$(function() {
		$("#datanascimento").datepicker({
		changeMonth: true,
		changeYear: true,
		yearRange: '1900:<?=$anofinaldata;?>',
		dateFormat: 'dd/mm/yy',
        dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
        dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
        dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
        monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
        monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
		});
		});

	  </script>
	  
<!--------------------carrega jquery e autocomplete imputs--------------->
		
        <script type='text/javascript' src="<?=$baseurl;?>/789/js/jquery.autocomplete.js"></script>
        <link rel="stylesheet" type="text/css" href="<?=$baseurl;?>/789/js/jquery.autocomplete.css" />
		<script type="text/javascript" src="<?=$baseurl;?>/jquery.maskedinput-1.1.4.pack.js"/></script>
		<script type="text/javascript" src="<?=$baseurl;?>/js/jquery.popupWindow.js"/></script>
		<script src="js/jquery.validate.min.js" type="text/javascript"></script>
		
		

		
	<!--------------------///qcarrega jquery e autocomplete imputs--------------->

	<!--------------------Mascaras --------------->
<script type="text/javascript">
function formatar_mascara(src, mascara) {
	var campo = src.value.length;
	var saida = mascara.substring(0,1);
	var texto = mascara.substring(campo);
	if(texto.substring(0,1) != saida) {
		src.value += texto.substring(0,1);
	}
}
</script>
		<script src="<?=$baseurl;?>/jquery.maskMoney.js" type="text/javascript"></script>
		<script type="text/javascript">
			$(document).ready(function(){	$("#cpf_trabalhador").mask("999.999.999-99");});
			$(document).ready(function(){	$("#cpf_login").mask("999.999.999-99");});
			$(document).ready(function(){	$("#cpf").mask("999.999.999-99");});
			$(document).ready(function(){	$("#tel1").mask("(99)9999.9999");});
			$(document).ready(function(){	$("#tel2").mask("(99)99999.9999");});
			$(document).ready(function(){	$("#tel3").mask("(99)9999.9999");});
			$(document).ready(function(){	$("#telres").mask("(99)9999.9999");});
			$(document).ready(function(){	$("#telrec").mask("(99)99999.9999");});			
			$(document).ready(function(){	$("#telcel").mask("(99)99999.9999");});			
						
			$(document).ready(function(){	$("#datainicio").mask("99/99/9999");});			
			$(document).ready(function(){	$("#datafinal").mask("99/99/9999");});			
			$(document).ready(function(){	$("#txvagadata").mask("99/99/9999");});			
			$(document).ready(function(){	$("#datalimiteencaminhar").mask("99/99/9999");});			
			$(document).ready(function(){	$("#datanascimento").mask("99/99/9999");});			
			$(document).ready(function(){	$("#cpf_busca").mask("999.999.999-99");});			
			$(document).ready(function(){	$("#cep").mask("99999-999");});			
			$(document).ready(function(){	$("#cepentrevista").mask("99999-999");});			
			$(document).ready(function(){	$("#ceplocal").mask("99999-999");});			
			
			$(function() {

				$('#numero').keypress(function(event) {
					var tecla = (window.event) ? event.keyCode : event.which;
					if ((tecla > 47 && tecla < 58)) return true;
					else {
						if (tecla != 8) return false;
						else return true;
					}
				});
				
				$('#numerolocal').keypress(function(event) {
					var tecla = (window.event) ? event.keyCode : event.which;
					if ((tecla > 47 && tecla < 58)) return true;
					else {
						if (tecla != 8) return false;
						else return true;
					}
				});
				
				$('#numeroentrevista').keypress(function(event) {
					var tecla = (window.event) ? event.keyCode : event.which;
					if ((tecla > 47 && tecla < 58)) return true;
					else {
						if (tecla != 8) return false;
						else return true;
					}
				});
				
				
				

			});
						
		
		</script>
		<!--------------------///mascara--------------->


    
		<!--------------------load paginas--------------->

		<style>
		#loading {
		background:#000 url(<?=$baseurl;?>/img/carregamento-da-pagina-com-loading.gif) no-repeat center center;
		height: 99%;
		width: 100%;
		position: fixed;

		z-index: 1000;
		}
		</style>

		<script src="<?=$baseurl;?>/js/sorttable.js"></script>
<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>


		</head>
		<!--<div id="loading"></div>-->
		<!--------------------///load paginas--------------->