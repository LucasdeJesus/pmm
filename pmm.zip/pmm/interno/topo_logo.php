<style>
#loading {
background:#000 url(img/carregamento-da-pagina-com-loading.gif) no-repeat center center;
height: 50px;
width: 250px;
position: fixed;
left: 50%;
top: 50%;
margin: -25px 0 0 -25px;
z-index: 1000;
}
</style>

<script>
	
	function Abrir_Pagina(URL) {
			  window.open(URL,'','width=1000,height=500');      
			} 
			
	</script>
<script type='text/javascript'>

$(document).ready(function(){

// Executa o evento CLICK em todos os links do menu

 $('#cssmenu a').live('click',function(){

  // Faz o carregamento da página de acordo com o COD da página, que vai pegar os valores da página page.php.

  $('#paginatoda').load($(this).attr('href'));

  return false;

    

 });



});

</script>
<!--<div id="loading"></div>-->

<div style='width:100%;border-top:3px solid #00B8AD; border-bottom:1px solid #D1D8DB;background-color:#FAFAFA;margin-top:20px;' align='center' >
		
			<table width='960px' >
				<tr>
					<td >
						<a href='index.php'><img src='img/logo.jpg'/></a>
					</td>
					
					<td>
						<div id='cssmenu'>
							<ul>								
								<!--<li class='has-sub'><a ><span>Atendimento Agendado</span></a>
									<ul>
										
										<li class='has-sub'><a  title="Candidatar para Vagas de Emprego" data-reveal-id="cadastro_trabalhador"><span> Vagas de Emprego</span></a> </li>
										
										<li class='has-sub'><a href='carregaagendamento.php?urlifreme=agendamento/agendamento.php?tipo=D' title="Emissão de Carteira de Identidade" ><span>Emissão RG</span></a> </li>
										<li class='has-sub'><a href='carregaagendamento.php?urlifreme=agendamento/agendamento.php?tipo=C' title="Emissão de Carteira de Trabalho"><span>Emissão CTPS</span></a> </li>
										
									</ul>
								</li>-->
								
								<li class='has-sub'><a ><span>Cadastro </span></a>
									<ul>
										
										<li class='has-sub'><a  title="Cadastro do Trabalhado" data-reveal-id="cadastro_trabalhador"><span>Cadastro do Trabalhado</span></a> </li>										
										<li class='has-sub'><a  title="Cadastro do Empregador" data-reveal-id="cadastro_empresa"><span>Cadastro do Empregador</span></a> </li>										
																				
									</ul>
								</li>
								
								<li class='has-sub'><a ><span>Login </span></a>
									<ul>
										
										<li class='has-sub'><a  title="Login do Trabalhado" data-reveal-id="myModal"><span>Login do Trabalhado</span></a> </li>										
										<li class='has-sub'><a  title="Login do Empregador" data-reveal-id="myModal2"><span>Login do Empregador</span></a> </li>										
																				
									</ul>
								</li>
								
								
							</ul>
						</div>
					</td>
					
				</tr>
			</table>
		</div>

		
		<div id="myModal" class="reveal-modal">
								
										<script type="text/javascript">
										function exibe(id) {
										if(document.getElementById(id).style.display=="none") {
										document.getElementById(id).style.display = "inline";
										}
										else {
										document.getElementById(id).style.display = "none";
										}
										}
										</script>
								
								
								
								
										<?
										$pass= $_POST['pass'];
										$cpf_trabalhador_cadastro_POST= $_POST['cpf_trabalhador'];
										
										if($pass == 2){
											$query_user = "SELECT * FROM `usuario` WHERE usuario = '$cpf_trabalhador_cadastro_POST'";										
											$rs_user   = mysql_query($query_user);
											while($campo_user = mysql_fetch_array($rs_user)){
											$iduser 	= $campo_user['id']; 											
											$senhauser 	= $campo_user['senha']; 											
											$usuariouser 	= $campo_user['usuario']; 											
											}	
											
											if($iduser > 0){											
													
													$query_dadoslembrete = "SELECT * FROM `trabalhador` WHERE cpf = '$cpf_trabalhador_cadastro_POST'";										
													$rs_dadoslembrete   = mysql_query($query_dadoslembrete);
													while($campo_dadoslembrete = mysql_fetch_array($rs_dadoslembrete)){
													$idsecao 	= $campo_dadoslembrete['id']; 
													$nometrabalhador 	= $campo_dadoslembrete['nome']; 
													$email 	= $campo_dadoslembrete['email']; 
													$emailresponsavel 	= $campo_dadoslembrete['emailresponsavel']; 
													
													}	
													

													$assunto	= "Solicitação de Senha SISTEMA SEMTRE";
													global $email;
													$data      = date("d/m/y");                     
													$ip        = $_SERVER['REMOTE_ADDR'];          
													$navegador = $_SERVER['HTTP_USER_AGENT'];       
													$hora      = date("H:i");                       
													$remetente      = "semtrevagas@macae.rj.gov.br"  ;                   
													$destinatario      = "$email,$emailresponsavel"  ;               

													
												$headers = "MIME-Version: 1.0\r\n";
												$headers .= "Content-type: text/html; charset=".$charset."\r\n";
												//$headers .= "Cc: semtrevagas@macae.rj.gov.br\r\n";
												$headers .= "Bcc: $email\r\n"; 
												$headers .= "From: ".$remetente."\r\n";
												$corpo=" <div style='border:1px solid #ddd;padding:10px' >Sr(a),$nometrabalhador segue dados de  acesso sistema SEMTRE: <br><br> LOGIN: $usuariouser <br>SENHA: $senhauser\n <br>LINK:  <a href='http://sistemas.macae.rj.gov.br:84/catalogo/semtre'>http://sistemas.macae.rj.gov.br:84/catalogo/semtre</a> </div>";
													
													
													
													if(mail($destinatario, $assunto, $corpo, $headers)) {
														echo "<script>alert('Dados de Acesso enviado para email $email')</script>";
														echo "<SCRIPT language='JavaScript'>window.location.href='index.php';</SCRIPT>";
														}
														else {
														echo "<script>alert('Erro: tente novamente')</script>";
														}
														
											}
										}
										?>
										
										<h2>Acesso área do Trabalhador</h2>
										<form  class="form" method="POST" action="valida_trabalhado.php"  id="cpf_loginF" name='cpf_loginF' onSubmit="return cpf_loginfun()">
												
												
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container">
													<input name="cpf_login" id='cpf_login' required   onkeypress='mascaraMutuario(this,cpfCnpj)'  placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  />
												</div>
												</div>
												
												
												<div class="form-row">
												<div class="label">Senha</div>
												<div class="input-container"><input name="senha" id='senha' required  placeholder="senha" type="password"  style='width:130px;'class="input req-same"   /></div>
												</div>

												
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn" value='acessar'  /></div>
												</div>
												
												<p> Se você esqueceu sua senha, <a href='#' onclick="javascript: exibe('conteudo');">clique aqui</a></p>			
												
												
										
										</form>
										
										<!-----envia senha email ---->
										<div id="conteudo" style="display: none;">
										
										<form  class="form" action='?pass=2' method='post'>
										<h2>Informa seu CPF Cadastrado</h2>
										<p>Você recebara um email com a senha!</p>
												
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container"><input name="cpf_trabalhador" id='cpf_trabalhador_cadastro'  onkeypress='mascaraMutuario(this,cpfCnpj)'  required  placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  /></div>
												</div>
												
												
												<div class="form-row">
											<div class="label"></div>
											<div class="input-container" style='width:246px;'>		
												<input type='hidden' value ='2' name='pass'/>
											
												<input id="submitBtn2" value="Enviar" type="submit" class="sendBtn" />
													<div id="errorDiv2" class="error-div"></div>
											</div>
										</div>
										
													
										</form>
										
										
										</div>
										
										<!------------envia senha email -------------->
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
								
								<div id="cadastro_trabalhador" class="reveal-modal">
								
								
										<h2>Serviços ao  Trabalhador</h2>
										<h4> &#9745; Acesso as Vagas</h4>
										<h4> &#9745; Agendar atendimento</h4>
										<h4> &#9745; Cadastra Currículo</h4>
										
										<br><h2>Cadastre-se Já</h2>
										<form  class="form" method="POST" action="cadatro_trabalhador_1.php"  id="cpf_trabalhadorF" name='cpf_trabalhadorF' onSubmit="return cpf_trabalhadorfun()">
												
												
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container"><input name="cpf_trabalhador" id='cpf_trabalhador' required  onkeypress='mascaraMutuario(this,cpfCnpj)' placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  /></div>
												</div>
												
												
												
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn"  value='Avançar'  /></div>
												</div>
												
											
										
										</form>
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
								
								
								
								<div id="myModal2" class="reveal-modal">
								
								
								
								
										<h2>Acesso área do Empregador</h2>
										<form  class="form" method="post" action="valida_empresa.php"  id="cadastroem" name='cadastroem' onSubmit=" return ValidarCNPJ(cadastroem.txCNPJ);">
												
												
												<div class="form-row">
												<div class="label">CNPJ</div>
												<div class="input-container">
													<input name="txCNPJ" id="txCNPJ" required value=''maxlength="18" placeholder="Insira o CNPJ" tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)' onBlur="ValidarCNPJ(cadastroem.txCNPJ);" style="width:194px;" type="text" class="input req-same">
												</div>
												</div>
												
												
												<div class="form-row">
												<div class="label">Senha</div>
												<div class="input-container"><input name="senha" required  id='senha' placeholder="senha" type="password"  style='width:130px;'class="input req-same"   /></div>
												</div>
												
												<input type='hidden' name="enviado" value="posted">
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn" onclick='return validar_cpf()' value='acessar'  /></div>
												</div>
						
													<p> Se você esqueceu sua senha, <a href='#' onclick="javascript: exibe('conteudo_empresa');">clique aqui</a></p>
													
													
													
													
										</form>
										
										<?
										$pass= $_POST['pass'];
										$txCNPJ_POST= $_POST['txCNPJ'];
										
										if($pass == 1){
											$query_user = "SELECT * FROM `usuario` WHERE usuario = '$txCNPJ_POST'";										
											$rs_user   = mysql_query($query_user);
											while($campo_user = mysql_fetch_array($rs_user)){
											$iduser 	= $campo_user['id']; 											
											$senhauser 	= $campo_user['senha']; 											
											$usuariouser 	= $campo_user['usuario']; 											
											}	
											
											if($iduser > 0){											
													
													$query_dadoslembrete = "SELECT * FROM `empresa` WHERE cnpj = '$txCNPJ_POST'";										
													$rs_dadoslembrete   = mysql_query($query_dadoslembrete);
													while($campo_dadoslembrete = mysql_fetch_array($rs_dadoslembrete)){
													$idsecao 	= $campo_dadoslembrete['id']; 
													$nomeempresa 	= $campo_dadoslembrete['nome']; 
													$email 	= $campo_dadoslembrete['email']; 
													$emailresponsavel 	= $campo_dadoslembrete['emailresponsavel']; 
													
													}	
													

													$assunto	= "Solicitação de Senha SISTEMA SEMTRE";
													global $email;
													$data      = date("d/m/y");                     
													$ip        = $_SERVER['REMOTE_ADDR'];          
													$navegador = $_SERVER['HTTP_USER_AGENT'];       
													$hora      = date("H:i");                       
													$remetente      = "semtrevagas@macae.rj.gov.br"  ;                   
													$destinatario      = "$email,$emailresponsavel"  ;               

													
												$headers = "MIME-Version: 1.0\r\n";
												$headers .= "Content-type: text/html; charset=".$charset."\r\n";
												//$headers .= "Cc: semtrevagas@macae.rj.gov.br\r\n";
												$headers .= "Bcc: $email\r\n"; 
												$headers .= "From: ".$remetente."\r\n";
												$corpo="<div style='border:1px solid #ddd;padding:10px' > $nomeempresa segue dados de  acesso sistema SEMTRE: <br><br> LOGIN: $usuariouser <br>SENHA: $senhauser\n <br>LINK:  <a href='http://sistemas.macae.rj.gov.br:84/catalogo/semtre'>http://sistemas.macae.rj.gov.br:84/catalogo/semtre</a> </div>";
													
													
													
													if(mail($destinatario, $assunto, $corpo, $headers)) {
														echo "<script>alert('Dados de Acesso enviado para email $email')</script>";
														echo "<SCRIPT language='JavaScript'>window.location.href='index.php';</SCRIPT>";
														}
														else {
														echo "<script>alert('Erro: tente novamente')</script>";
														}
														
											}
										}
										?>
										
										<!-----envia senha email ---->
										<div id="conteudo_empresa" style="display: none;">
										
										<form  class="form"   action="?pass=1"id='lembrasenha' method="post"name='lembrasenha' onSubmit=" return  ValidarCNPJ(lembrasenha.txCNPJ);">
										<h2>Informa seu CPF/CNPJ Cadastrado</h2>
										<p>Você recebara um email com a senha!</p>
												
												<div class="form-row">
												<div class="label">CNPJ</div>
												<div class="input-container">
													<input name="txCNPJ" id="txCNPJ" required value=''maxlength="18" placeholder="Insira o CNPJ" tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)' onBlur="ValidarCNPJ(lembrasenha.txCNPJ);" style="width:194px;" type="text" class="input req-same">
												</div>
												</div>
												
												<div class="form-row">
											<div class="label"></div>
											<div class="input-container" style='width:246px;'>		
												<input type='hidden' value ='1' name='pass'/>
											
												<input id="submitBtn2" value="Enviar" type="submit" class="sendBtn" />
													<div id="errorDiv2" class="error-div"></div>
											</div>
										</div>
										
													
										</form>
										
										
										</div>
										
										<!------------envia senha email -------------->
										
										
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
								
								
								<div id="cadastro_empresa" class="reveal-modal">
								
								
										<h2>Cadastro do Empregador</h2>
										<form  class="form" method="GET" onSubmit="return  ValidarCNPJ(cadastroem2.txCNPJ);" action="cadatro_empresa_1.php"  id="cadastroem2" name='cadastroem2' >
												
												
												<div class="form-row">
												<div class="label">CNPJ</div>
												<div class="input-container">
													<input name="txCNPJ" id="txCNPJ" required value=''maxlength="18" placeholder="Insira o CNPJ" tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)' onkeypress='mascaraMutuario(this,cpfCnpj)'style="width:194px;" type="text" class="input req-same">
												</div>
												</div>
												
																								
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn"  onmouseover="ValidarCNPJ(cadastroem2.txCNPJ);" value='próximo &#10132;'  /></div>
												</div>
						
													
										</form>
										
										
										
										
										
								
								<a class="close-reveal-modal">&#215;</a>
								</div>