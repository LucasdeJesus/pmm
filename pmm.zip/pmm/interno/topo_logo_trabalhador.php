<style>
#loading {
background:#000 url(img/carregamento-da-pagina-com-loading.gif) no-repeat center center;
height: 99%;
width: 100%;
position: fixed;

z-index: 1000;
}
</style>
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>	
<!--<div id="loading"></div>-->



	<div style='width:100%;' align='center'>
	<table width='960px' >
	<tr>
	<td >
	Olá <?=$usuario_nome;?> SEU ID <?=$usuario_id;?>, <a href='sair.php'  class="sendBtn ">sair</a>

	</td>

	</tr>
	</table>
	</div>
<div style='width:100%;border-top:3px solid #00B8AD; border-bottom:1px solid #D1D8DB;background-color:#FAFAFA;margin-top:20px;' align='center' >
		
			<table width='960px' >
				<tr>
					<td >
						<a href='#'><img src='img/logo.jpg'/></a>
					</td>
					
					<td>
						<div id='cssmenu'>
							<ul>
								<li ><a href='area_trabalhador.php'><span>Home</span></a></li>
								<li class='has-sub'><a href='#'><span>Vagas</span></a>
									<ul>
										<li class='has-sub'><a href='listar_vaga_disponivel_trabalhador.php'><span>Vagas Compatíveis Disponíveis</span></a> </li>
										<li class='has-sub'><a href='#' Onclick="Abrir_Pagina('http://sistemas.macae.rj.gov.br:84/catalogo/semtre/index/mural');"><span>Todas Vagas Disponíveis</span></a> </li>
										

									</ul>
								</li>
								<li><a href='' ><span>Meu Currículo</span></a>
									<ul>
										<li class='has-sub'><a href='area_trabalhador.php?semtre=ok'><span>Editar Currículo</span></a> </li>
										<!--<li class='has-sub'><a href='imprimi_curriculo_trabalhado.php?semtre=ok'><span>Imprimir Currículo</span></a> </li>-->
										

									</ul>
								</li>
								
								
								<!--<li class='has-sub'><a href='#'><span>Agendamento</span></a>
									<ul>
										
										<!--<li class='has-sub'><a  href="carregaagendamento.php?urlifreme=agendamento/agendamento.php?tipo=V" title="Candidatar para Vagas de Emprego" ><span> Vagas de Emprego</span></a> </li>										
										<li class='has-sub'><a href="carregaagendamento.php?urlifreme=agendamento/agendamento.php?tipo=D"  title="Emissão de Carteira de Identidade" ><span>Emissão RG</span></a> </li>-->
										<!--<li class='has-sub'><a href="carregaagendamento.php?urlifreme=agendamento/agendamento.php?tipo=C"  title="Emissão de Carteira de Trabalho"><span>Emissão CTPS</span></a> </li>
										
									</ul>
								</li>-->
							</ul>
						</div>
					</td>
					
				</tr>
			</table>
		</div>
		