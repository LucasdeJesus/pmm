
		<table width="100%" style='background-color:#fff;'>
			<tr >
				<td><img src='../img/LogoSecretaria.png' width='200px'></td>
				<td>DIVULGAÇÃO DE VAGAS<br><a href='?lista=<?=$lista;?>&exporta=excel'><img src='../img/excel.jpg' width='40px'/></a></td>
				<td><input type='Button' name='filtro' value='&#9778; Filtro'  onclick="toggle('maisinfo');" style='padding:2px ;' /></td>
							
			</tr>
						
			
			
		</table>
		
		
	<script type="text/javascript">
	<!--
	function toggle(obj) {
		var el = document.getElementById(obj);
		if ( el.style.display != "none" ) {
			el.style.display = 'none';
		}
		else {
			el.style.display = '';
		}
	}
	-->
	
	 $(function() {


                $("#datainicio").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1970:<?= $anofinaldata; ?>',
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'],
                    dayNamesMin: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
                    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
                    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
                    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
                });
				
				 $("#datafinal").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1970:<?= $anofinaldata; ?>',
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'],
                    dayNamesMin: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
                    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
                    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
                    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
                });


            });
			
			 $().ready(function() {
                $("#ocupacao").autocomplete("789/autoComplete.php", {
                    matchContains: true,
                    mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
			});
			
	</script>
		<table width="100%" style='background-color:#002db2;color:#fff;'> 		
			<tr width='200px'>
				<td><?echo date("d/m/Y");?></td>
				<td></td>
				
				<td align='right'><?echo date("H:i:s");?></td>
			</tr>
			
		
		</table>
		
		<div id="maisinfo" style="display:none;width:100%;" align='center'>
		
		
		<form action='pcd.php' method='post'>
							<table border="1">
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Data de Cadastro&nbsp;</b></font>
										</td>
										<td>
											<input type=text name="datainicio" id="datainicio" maxlength=10 onBlur="verificaData('window.document.Ficha.flt_Data_ini');" onKeyUp="VerificaMascara('window.document.Ficha.flt_Data_ini','##/##/####',1)" style="width:55px;" value="">
											&nbsp;até&nbsp;
											<input type=text name="datafinal" id="datafinal" maxlength=10 onBlur="verificaData('window.document.Ficha.flt_Data_fim');" onKeyUp="VerificaMascara('window.document.Ficha.flt_Data_fim','##/##/####',1)" style="width:55px;" value="">
										</td>
									</tr>
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Intenção&nbsp;</b></font>
										</td>
										<td>
											<select name="intencao" id="intencao"  tabindex="22" style="width:240">
														
														
																			
																		
																		<option value="" >--</option>
																		<option value="E" >Emprego</option>
																		<option value="1">Jovem Aprendiz</option>
																		<option value="T">Estágio</option>
																		<option value="C">Curso</option>
																		<option value="D">Emissão de Documentos</option>
																		<option value="G">Emprego/Curso</option>
																		<option value="M">Emprego/Emissão de Documentos</option>
																		<option value="U">Curso/Emissão de Documentos</option>
																		<option value="S">Todas</option>
																	</select>
										</td>
									</tr>
									
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Conta PCD&nbsp;</b></font>
										</td>
										<td>
											<select name="contapcd" style="width:90px;">
												<option value="">-X-</option>
												<option value="N">Não</option>
												<option value="S">Sim</option>
											</select>
										</td>
									</tr>
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Gênero&nbsp;</b></font>
										</td>
										<td>
											<select name="sexo" style="width:90px;">
												<option value="">Selecione</option>
												<option value="A">Ambos</option>
												<option value="M">Masculino</option>
												<option value="F">Feminino</option>
											</select>
										</td>
									</tr>
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Escolaridade&nbsp;</b></font>
										</td>
										<td>
											<select name="escolaridade" style="width:90px;">
												<option value="">Selecione</option>
												<option value="F">Fundamental</option>
												<option value="M">Médio</option>
												<option value="P">Pós-Médio</option>
												<option value="S">Superior</option>
											</select>
										</td>
									</tr>
									
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;Escolaridade status&nbsp;</b></font>
										</td>
										<td>
											<select name="escolaridade" style="width:90px;">
												<option value="">Selecione</option>
												<option value="C">Completo</option>
												<option value="U">Cursando</option>
												<option value="I">Incompleto</option>												
											</select>
										</td>
									</tr>
									
									<tr>
										<td bgcolor="#000080">
											<font color="#ffffff" face="Tahoma"><b>&nbsp;PCD status&nbsp;</b></font>
										</td>
										<td>
											<select name="pcd_status" style="width:90px;">
												<option value="">Selecione</option>
												<option value="A">Aguardando Treinamento</option>
												<option value="T">Treinado</option>
												<option value="I">Inserido</option>												
												<option value="C">Encaminhado</option>												
											</select>
										</td>
									</tr>
									
									
									
									
						
				
		
								
									
									<tr>
										<td bgcolor="#000080" colspan="2" align="center">
											<input type="submit" name="btBuscar"  value=" Buscar ">		
										<button onClick="window.location.reload();">Limpar filtro</button>											
										</td>
									</tr>
								</table>
								<input type="hidden" name="acao"  value="post">
				<form>				
				
		</div>
		
		<?
				$get_acao= $_POST['acao'];
				$post_jovemaprendiz= $_POST['jovemaprendiz'];			
				$post_escolaridade= $_POST['escolaridade'];
				$post_sexo= $_POST['sexo'];
				$post_datainicio= $_POST['datainicio'];
				$post_datafinal= $_POST['datafinal'];				
				$post_contapcd= $_POST['contapcd'];
				$post_intencao= $_POST['intencao'];
				$post_statusescolaridade= $_POST['statusescolaridade'];
				$post_pcd_status= $_POST['pcd_status'];
				
				
				
		
		?>
	