<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);


						/*$query_noticias1 = "SELECT *  FROM `vaga` where status='I'ORDER BY `vaga`.`id` DESC LIMIT 0 , 30";				
							$rs_noticias1    = mysql_query($query_noticias1); 
							$total1 = mysql_num_rows($rs_noticias1);	
							echo $total1 ;*/
?>

		
	

