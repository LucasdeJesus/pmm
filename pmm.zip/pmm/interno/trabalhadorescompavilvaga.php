﻿<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);

include("topo.php"); 	
?>
	<link rel="stylesheet" type="text/css" href="assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="assets/styles.css" />
	<script src="js/sorttable.js"></script>
<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>
<?

$sqlidvaga = $_GET['id'];
$cargovaga = $_GET['cargo'];

?>
	<form class="form" >
	<h2>Trabalhadores  para vaga ID: <?=$sqlidvaga;?> , <?=$cargovaga;?></h2>
	<table width='100%' class='sortable'>
	
				<tr>
				<td class='td1' >N°</td>
				<td class='td1' >Nome</td>
				<td class='td1' >CPF</td>
				<td class='td1' >Celular</td>
				<td class='td1' >Ação</td>
				
				</tr>
				
				
				<?
				
				
				$numerotelefone="";
					$anohoje =  date("Y"); 
					$query_vagassmst = "SELECT * FROM  `vaga` WHERE  id ='$sqlidvaga' ";
					$rs_vagassmst   = mysql_query($query_vagassmst);
					while($campo_vagasmst = mysql_fetch_array($rs_vagassmst)){		
					$cboidtrabalhador 	= $campo_vagasmst['cboid'];
					$sexo 	= $campo_vagasmst['sexo'];
					$vagadeficientet 	= $campo_vagasmst['vagadeficiente'];
					$idademinima = $campo_vagasmst['idademinima']; 
					$idademaxima = $campo_vagasmst['idademaxima']; 
					$quantidadeencaminhar = $campo_vagasmst['quantidadeencaminhar']; 
					$limit = $quantidadeencaminhar*2;
					$idvaga = $campo_vagasmst['id']; 
					$comprovada = $campo_vagasmst['comprovada']; 

					$dataminima = $anohoje-$idademinima;		
					$newdataminima = date("Y-d-m", strtotime($dataminima));		
					$datamaxima = $anohoje-$idademaxima;
					$newmaxima = date("Y-d-m", strtotime($datamaxima));

					if(($idademinima > 0) ||($idademaxima > 0)){

					$sqlidadedata="and `datanascimento` BETWEEN '$newdataminima' AND '$newmaxima'";
					}


					$idtrabalhadoragrupada ="";
					$query_trabalhadorsms= "SELECT * FROM  `trabalhador` WHERE  
					 sexo IN ('A','$sexo') and vagadeficiente='$vagadeficientet' 
					".$sqlidadedata."  and (`cboid1`='$cboidtrabalhador' or `cboid2`='$cboidtrabalhador'  or `cboid3`='$cboidtrabalhador') ORDER BY  `trabalhador`.`datacadastro` DESC 
					LIMIT $limit";		
					//echo $query_trabalhadorsms;
					$rs_trabalhadorsms   = mysql_query($query_trabalhadorsms);
					while($campo_trabalhadorsms = mysql_fetch_array($rs_trabalhadorsms)){																						
					$nome 	= $campo_trabalhadorsms['nome'];
					$telcel 	= $campo_trabalhadorsms['telcel'];
					$idtrabalhador 	= $campo_trabalhadorsms['id'];
					$cpfidtrabalhador 	= $campo_trabalhadorsms['cpf'];
					//$cboinome.=",$cbo" ;	
					//echo $nome."<br>";
					//echo $telcel."<br>";

					$vowels = array("(", ")", ".", "-");
					$numerocelular = str_replace($vowels, "", $telcel);
					$numerotelefone.= "55".$numerocelular."," ;
					$idtrabalhadoragrupada.=",".$idtrabalhador;
					

				
				
				?>
			
				<tr class='tr_tb' >		
					<td class='td2' ><?=$numero++;?></td>
					<td class='td2' ><?=$nome;?></td>
					<td class='td2' ><?=$cpfidtrabalhador;?></td>
					<td class='td2' ><?=$telcel;?></td>
					<td class='td2' ><a href="javascript:Abrir_Pagina('conteudo.php?cpf_busca=<?=$cpfidtrabalhador;?>','scrollbars=yes,width=800,height=500')" title='Saiba mais'><img src='img/busca.png'/></a> </td>
									
					
				</tr>
			<?}}?>
			
	</table>	

<textarea style="width:300px;height:300px"><?=$numerotelefone;?></textarea>	<input type="button" name="botao-ok" class="sendBtn" onclick="avisatrabalhedores()"value="clicque aqui para enviar sms ">
	<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
	
	function avisatrabalhedores(){
		
		
		$.ajax({
					crossDomain: true,
					dataType: 'jsonp',
					 type: "GET",
					url: 'http://app.smsconecta.com.br/SendAPI/Send.aspx?usr=cetep&pwd=cetep357&number=<?=$numerotelefone;;?>5522997437124&sender=AGETRAB&msg=existe vagas de emprego que pode lhe interessar, favor acessar: www.macae.rj.gov.br/agetrab clique area do trabalhador e vaga de emprego',
					success: function(data) {	
					//alert (data);
					

					alert("Aviso enviado com sucesso");

					
					}

					});

	}
</script>
	<form>