<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener' align='center' style="margin:10%;">



				<?
				
				
				$novasenha = $_POST['novasenha'];
				if($novasenha=="")
				{}				
				else
				{
				
						$query="update  usuario set  senha= '$novasenha' where id='$usuarioID'";
						$rs= mysql_query($query);
				
				?>
					<script>alert("Senha alterada com sucesso!");</script>
					<SCRIPT language="JavaScript">window.location.href="troca_senha.php";</SCRIPT>
				<?	
				}
				
				$query_noticias_hcpjvg = "SELECT * FROM `usuario` where id='$usuarioID'";
				$rs_noticias_hcpjvg    = mysql_query($query_noticias_hcpjvg);
				while($campo_noticias_hcpjvg = mysql_fetch_array($rs_noticias_hcpjvg)){			
				$senha  = $campo_noticias_hcpjvg['senha'];
				}
				
				
				?>
				
				<form class="form" align='left' method='POST' action=''>
				<h2>Trocar Senha</h2>
										<div class="form-row" >
												<div class="label">Nova Senha:</div>
												<div class="input-container"><input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="novasenha" style='width:250px;'id='novasenha' placeholder="Nova Senha" type="password"  value='<?=$senha;?>' class="input req-same" maxlength="14"  />
												
												<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" type='submit' class="sendBtn3"  value='&#10004; CONCLUIR'  />
												</div>
												</div>
											
				</form>

</div>




</body>
</html>
