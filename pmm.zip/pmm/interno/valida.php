<?php
include"input_banco.php";
    $login = $_POST['usuario'];   
    $senha = $_POST['senha'];
	
    
                     
            $verifica = mysql_query("SELECT * FROM usuario WHERE usuario = '$login' AND senha = '$senha'") or die("erro ao selecionar");
                if (mysql_num_rows($verifica)<=0){
                    echo"<script language='javascript' type='text/javascript'>alert('Login e/ou senha incorretos');window.location.href='login.php';</script>";
                    die();
                }else{
                    setcookie("usuario",$login);
                    header("Location:index.php");
                }
       
?>


