<?// ==============================

$database="mysql01.bestcursos.hospedagemdesites.ws"; // SERVIDOR E PORTA UTILIZADA   
$dbname="bestcursos"; // BASE DE DADOS 
$usuario="bestcursos"; // USUÁRIO DO MYSQL
$dbsenha="al1975"; // SENHA DO MYSQL

$conexao=mysql_connect ($database, $usuario, $dbsenha);
if($conexao){
      if (mysql_select_db($dbname, $conexao)){ print "";
      }else{ print "Não foi possível selecionar o Banco de Dados"; }
}else{ print "Erro ao conectar o MySQL"; }

ini_set('default_charset','UTF-8'); // Para o charset das páginas e
mysql_set_charset('utf8'); // para a conexão com o MySQL

function protegepagina(){};

?>