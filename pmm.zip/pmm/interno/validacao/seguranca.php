﻿<?session_start();

if (empty($_SESSION['id'])) {
 //echo "Acesso negado!";
 ?>
 <script>alert("Sessão Expirada ")</script>
 <script>document.location = 'login.php';</script>
 <?
 exit;
}else{
include('input_banco.php');
//$permicao = "1";
$usuarioID   = $_SESSION['id'];
$nome_usuario_login = $_SESSION['nome'];


}




?>