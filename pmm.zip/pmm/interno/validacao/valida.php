<?session_start();
include"input_banco.php";


$cliente_username = $_POST["usuario"];
$cliente_password = $_POST["senha"];
;

   
	
if (!isset($cliente_username) or !isset($cliente_password)) { echo "Erro!";	exit; }  
if (empty($cliente_username) or empty($cliente_password)) { echo "Dados inválidos!"; exit; }

$query = "select * from usuario where usuario = '$cliente_username' and senha = '$cliente_password' limit 1";
$result = mysql_query($query);
$number = mysql_num_rows($result);

if ($number==0) { ?><script>alert('Autorização inexistente/Senha inválida ou expirada.');history.back();</script>
<?
	exit;
} else {
	$_SESSION['id'] = mysql_result($result,0,'id');
	$_SESSION['nome'] = mysql_result($result,0,'nome');
	
	?><script>document.location = 'index.php'</script><?
}


 



?>