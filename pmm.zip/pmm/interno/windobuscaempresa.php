<?php include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?php include'topo.php';?>

<body onload="endereco_empresa('oi');">

<script>

function atualizaForm(id,nome){ 
//window.opener.document.ajax_form.empresaid.value = id; 

window.close();
var option = window.opener.document.createElement("option");
option.text = nome;
option.value = id;
var select = window.opener.document.getElementById("empresaid");
select.appendChild(option);
window.opener.document.emcaminhamentof.empresaid.value = id;

 

}

</script>

			
		
			

<script type="text/javascript">
function mascaraMutuario(o,f){
    v_obj=o
    v_fun=f
    setTimeout('execmascara()',1)
}
 
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
 
function cpfCnpj(v){
 
    //Remove tudo o que não é dígito
    v=v.replace(/\D/g,"")
 
    if (v.length <= 13) { //CPF
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        //de novo (para o segundo bloco de números)
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um hífen entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")
 
    } else { //CNPJ
 
        //Coloca ponto entre o segundo e o terceiro dígitos
        v=v.replace(/^(\d{2})(\d)/,"$1.$2")
 
        //Coloca ponto entre o quinto e o sexto dígitos
        v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
 
        //Coloca uma barra entre o oitavo e o nono dígitos
        v=v.replace(/\.(\d{3})(\d)/,".$1/$2")
 
        //Coloca um hífen depois do bloco de quatro dígitos
        v=v.replace(/(\d{4})(\d)/,"$1-$2")
 
    }
 
    return v
 
}
			</script>
			

			
<form  class="form" style='width:100%;'action=''method="GET" >
		<h2>Buscar Empresa</h2>
			<div class="form-row">
			<div class="label">CPF / CNPJ</div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();"requered  name="busca_cnpj1" id="busca_cnpj1" maxlength="18"  tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)'  style="width:194px;" type="text" class="input req-same">
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="campo"  name='campo' value="cnpj" type="hidden" />
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Buscar" type="submit" class="sendBtn" />
			</div>
			</div>
</form>			
<form  class="form" style='width:100%;'action=''method="GET" >						
			<div class="form-row">
			<div class="label">NOME</div>
				<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="campo"  name='campo' value="nome" type="hidden"  />
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" requered name="busca_nome" id="busca_nome"  maxlength="18" style="width:456px;"  tabindex="1"  type="text" class="input req-same">
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" id="submitBtn2" value="Buscar" type="submit" class="sendBtn" />
			</div>
			</div>			
		
</form>

<form  class="form" style='width:100%;'method="post" >
		<h2>Lista de Empresas</h2>
		
		
	<table style='width:95%;'>
			<tr>
				<td class='td1' >N°</td>
				<td class='td1' >CNPJ/CPF </td>
				<td class='td1' >Razão Social</td>
				<td class='td1' >Nome</td>
			
				<td class='td1'>Seg.Atuação</td>
				<td class='td1'>Ins. Municipal</td>
				<td class='td1'>Ins. Estadual</td>
						
						
			</tr>
			
						<?php
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
			$numero=1;
			
			if($campo==""){
		
			}
			else
			{
				if($busca_nome=='')
				{
				
				$query_noticias = "SELECT * FROM `empresa` WHERE `cnpj` LIKE '%$busca_cnpj1%'";
				}
				else
				{
				$query_noticias = "SELECT * FROM `empresa` WHERE `nome` LIKE '%$busca_nome%' OR `razaosocial` LIKE '%$busca_nome%' ";
				}
				
			}
		
		
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);	
		
			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$cnpj 	= $campo_noticias['cnpj']; 	 		 			 	
		$selTipo	= $campo_noticias['selTipo']; 	 		 			 	
		$razaosocial	= $campo_noticias['razaosocial']; 	 		 			 	
		$nome	= $campo_noticias['nome']; 	 		 			 	
		$segmentoatuacaoid	= $campo_noticias['segmentoatuacaoid']; 	 		 			 	
		$inscmunicipal	= $campo_noticias['inscmunicipal']; 	 		 			 	
		$inscestadual	= $campo_noticias['inscestadual']; 	 		 			 	
		$endereco	= $campo_noticias['endereco']; 	 		 			 	
		$bairro	= $campo_noticias['bairro']; 	 		 			 	
		$cidadeid	= $campo_noticias['cidadeid']; 			 			 	
		$cep	= $campo_noticias['cep']; 
		$emailresponsavel	= $campo_noticias['emailresponsavel']; 	 		 			 	
		$tel1= $campo_noticias['tel1']; 	 		 			 	
		$tel2= $campo_noticias['tel2']; 	 		 			 	
		$tel3= $campo_noticias['tel3']; 	 		 			 	
		$email= $campo_noticias['email']; 	 		 			 	
		$homepage= $campo_noticias['homepage']; 	 		 			 	
		$responsavel= $campo_noticias['responsavel']; 	 		 			 	
		$cargoresponsavel= $campo_noticias['cargoresponsavel']; 	 		 			 	
		$contato= $campo_noticias['contato']; 	 		 			 	
		$cargocontato= $campo_noticias['cargocontato']; 	 		 			 	
		$emailcontato= $campo_noticias['emailcontato']; 	 		 			 	
		$captadorid= $campo_noticias['captadorid']; 	 		 			 	
		$localcaptacaoid= $campo_noticias['localcaptacaoid']; 	 		 			 	
		$status= $campo_noticias['status']; 	 		 			 	
		$observacao= $campo_noticias['observacao']; 	 
		$id= $campo_noticias['id']; 	 
		$txtestadoentrevista= $campo_noticias['txtestadoentrevista']; 	 
		$cepentrevista= $campo_noticias['cepentrevista']; 	 
		$senha= $campo_noticias['senha']; 	 
		$jovemaprendiz= $campo_noticias['jovemaprendiz']; 	 
		$estagios= $campo_noticias['estagios']; 	 
		$contapcd= $campo_noticias['contapcd']; 	 
		$quantempregados= $campo_noticias['quantempregados']; 	 
		$referenciaend= $campo_noticias['referenciaend']; 	 
		
		
		
		
			?>

			<tr class='tr_tb'  onclick="javascript:atualizaForm('<?=$id;?>','<?=$nome;?>'); "  id="<?=$nome;?>" bgcolor="#E7E7E7">
		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$cnpj ;?> </td>
				<td class='td2' >  <?=$razaosocial;?></td>				
				<td class='td2' >  <?=$nome;?></td>		
					<?php
					$query_seguimentoatuacao_db = "SELECT * FROM  `segmentoatuacao` where id='$segmentoatuacaoid' ";
					$rs_seguimentoatuacao_db    = mysql_query($query_seguimentoatuacao_db);
					while($campo_seguimentoatuacao_db = mysql_fetch_array($rs_seguimentoatuacao_db)){		
					$seguimento_id_db 	= $campo_seguimentoatuacao_db['id']; 
					$seguimento_nome_db 	= $campo_seguimentoatuacao_db['nome']; 
					}
					?>
													
													
				<td class='td2' >  <?=$seguimento_nome_db;?></td>				
				<td class='td2' >  <?=$inscmunicipal;?></td>				
				<td class='td2' >  <?=$inscestadual;?></td>				

			</tr>
		<?}?>	

	</table>
	
		<?php
	if($total=="")
				
				{echo"<h3>Nenhuma Empresa foi encontrada.</h3>";}else{}
				
				?>
	

</form>
	


			
</body>
</html>    