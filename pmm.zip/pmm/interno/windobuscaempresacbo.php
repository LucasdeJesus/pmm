<?php include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?php include'topo.php';?>

<body onload="endereco_empresa('oi');">

<script>

function atualizaForm(cbo){ 
window.opener.document.ajax_form.ocupacao.value = cbo; 
}

</script>



<form  class="form" style='width:100%;'method="post" >
		<h2>Lista de CBO</h2>
		
		
	<table style='width:95%;'>
			<tr>
				<td class='td1' >N°</td>
				<td class='td1' >cbo </td>
				
						
			</tr>
			
						<?php
						$nomecbo = $_GET['nomecbo'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
			$numero=1;
			
			
		
		$query_noticias = "SELECT * FROM `cbo` WHERE `cbo` LIKE '%$nomecbo%'";	
		$rs_noticias    = mysql_query($query_noticias); 		
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$id= $campo_noticias['id']; 
		$cbo= $campo_noticias['cbo']; 
		$codigocbo= $campo_noticias['codigocbo']; 
		
		
		
			?>

			<tr class='tr_tb'  onclick="javascript:atualizaForm('<?=$cbo;?>'); window.close();"  id="<?=$cbo;?>" bgcolor="#E7E7E7">
		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$cbo ;?> </td>
				
			</tr>
		<?}?>	

	</table>
	
		<?php
	if($total=="")
				
				{echo"<h3>Nenhuma Empresa foi encontrada.</h3>";}else{}
				
				?>
	

</form>
	


			
</body>
</html>    