
<?
$pagina1 = $_GET['pagina1'];
$pagina2 = $_GET['pagina2'];
$tela = $_GET['tela'];

?>
<frameset frameborder="0" framespacing="0" rows="<?=$tela;?>%,*">
<frame scrolling="No" style="border-bottom:5px solid #157FCC;"framespacing="0" marginheight="0" marginwidth="0" noresize="" frameborder="0" name="FrmMenu" src="<?=$pagina1;?>.php">
<frame framespacing="0" marginheight="0" marginwidth="5" frameborder="0" name="FrmDados" id='FrmDados'src="<?=$pagina2;?>.php">
</frameset>