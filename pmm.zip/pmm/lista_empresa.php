<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener'>

<script type="text/javascript">
function mascaraMutuario(o,f){
    v_obj=o
    v_fun=f
    setTimeout('execmascara()',1)
}
 
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
 
function cpfCnpj(v){
 
    //Remove tudo o que não é dígito
    v=v.replace(/\D/g,"")
 
    if (v.length <= 13) { //CPF
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        //de novo (para o segundo bloco de números)
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um hífen entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")
 
    } else { //CNPJ
 
        //Coloca ponto entre o segundo e o terceiro dígitos
        v=v.replace(/^(\d{2})(\d)/,"$1.$2")
 
        //Coloca ponto entre o quinto e o sexto dígitos
        v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
 
        //Coloca uma barra entre o oitavo e o nono dígitos
        v=v.replace(/\.(\d{3})(\d)/,".$1/$2")
 
        //Coloca um hífen depois do bloco de quatro dígitos
        v=v.replace(/(\d{4})(\d)/,"$1-$2")
 
    }
 
    return v
 
}
			</script>
			

			
<form  class="form" style='width:100%;'action='lista_empresa.php'method="GET" >
		<h2>Buscar Empresa</h2>
			<div class="form-row">
			<div class="label">CPF / CNPJ</div>
			<div class="input-container" style='width:546px;'>		
			<input name="busca_cnpj1" id="busca_cnpj1" maxlength="18"  tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)'  style="width:194px;" type="text" class="input req-same">
			<input id="campo"  name='campo' value="txCNPJ" type="hidden" />
			<input id="submitBtn2" value="Buscar" type="submit" class="sendBtn" />
			</div>
			</div>
</form>			
<form  class="form" style='width:100%;'action='lista_empresa.php'method="GET" >						
			<div class="form-row">
			<div class="label">NOME</div>
				<input id="campo"  name='campo' value="nome" type="hidden"  />
			<div class="input-container" style='width:546px;'>		
			<input name="busca_nome" id="busca_nome"  maxlength="18" style="width:456px;"  tabindex="1"  type="text" class="input req-same">
			<input id="submitBtn2" value="Buscar" type="submit" class="sendBtn" />
			</div>
			</div>
			
		
</form>

<form  class="form" style='width:100%;'method="post" >
		<h2>Lista de Empresas</h2>
	<table style='width:95%;'>
			<tr>
				<td class='td1' >N°</td>
				<td class='td1' >CNPJ/CPF </td>
				<td class='td1' >Razão Social</td>
				<td class='td1' >Nome</td>
				<td class='td1'>Tipo</td>
				<td class='td1'>Seg.Atuação</td>
				<td class='td1'>Ins. Municipal</td>
				<td class='td1'>Ins. Estadual</td>
				<td ><a href="cadastro_empresa.php" class="myButton"><img src='img/novo_item.png' />Novo cadastro</a></td>
						
			</tr>
			
						<?
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
			$numero=1;
			
			if($campo==""){
			$query_noticias = "SELECT * FROM `empresa` ORDER BY `empresa`.`id_empresa` DESC LIMIT 0 , 30";
			}
			else
			{
				if($busca_nome=='')
				{
				
				$query_noticias = "SELECT * FROM `empresa` WHERE `txCNPJ` LIKE '%$busca_cnpj1%'";
				}
				else
				{
				$query_noticias = "SELECT * FROM `empresa` WHERE `txnome` LIKE '%$busca_nome%'";
				}
				
			}
		
		
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);	
		
			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$txCNPJ 	= $campo_noticias['txCNPJ']; 	 		 			 	
		$selTipo	= $campo_noticias['selTipo']; 	 		 			 	
		$txrazaosocial	= $campo_noticias['txrazaosocial']; 	 		 			 	
		$txnome	= $campo_noticias['txnome']; 	 		 			 	
		$selArea	= $campo_noticias['selArea']; 	 		 			 	
		$txinscmunicipal	= $campo_noticias['txinscmunicipal']; 	 		 			 	
		$txinscestadual	= $campo_noticias['txinscestadual']; 	 		 			 	
		$txtendereco	= $campo_noticias['txtendereco']; 	 		 			 	
		$txtbairro	= $campo_noticias['txtbairro']; 	 		 			 	
		$txtcidade	= $campo_noticias['txtcidade']; 	 		 			 	
		$txtestado	= $campo_noticias['txtestado']; 	 		 			 	
		$txtcep	= $campo_noticias['txtcep']; 	 		 			 	
		$txtenderecoentrevista	= $campo_noticias['txtenderecoentrevista']; 	 		 			 	
		$txtbairroentrevista	= $campo_noticias['txtbairroentrevista']; 	 		 			 	
		$txtcidadeentrevista	= $campo_noticias['txtcidadeentrevista']; 	 		 			 	
		$txtPertoDeEntrevista	= $campo_noticias['txtPertoDeEntrevista']; 	 		 			 	
		$txtFalarComEntrevista	= $campo_noticias['txtFalarComEntrevista']; 	 		 			 	
		$txtEmailEntrevista	= $campo_noticias['txtEmailEntrevista']; 	 		 			 	
		$txemailresponsavel	= $campo_noticias['txemailresponsavel']; 	 		 			 	
		$txtel1= $campo_noticias['txtel1']; 	 		 			 	
		$txtel2= $campo_noticias['txtel2']; 	 		 			 	
		$txtel3= $campo_noticias['txtel3']; 	 		 			 	
		$txemail= $campo_noticias['txemail']; 	 		 			 	
		$txHomePage= $campo_noticias['txHomePage']; 	 		 			 	
		$txresponsavel= $campo_noticias['txresponsavel']; 	 		 			 	
		$txcargoresponsavel= $campo_noticias['txcargoresponsavel']; 	 		 			 	
		$txnomecontato= $campo_noticias['txnomecontato']; 	 		 			 	
		$txcargocontato= $campo_noticias['txcargocontato']; 	 		 			 	
		$txemailContato= $campo_noticias['txemailContato']; 	 		 			 	
		$selconsultor= $campo_noticias['selconsultor']; 	 		 			 	
		$selcidaatraves= $campo_noticias['selcidaatraves']; 	 		 			 	
		$txtstatus= $campo_noticias['txtstatus']; 	 		 			 	
		$txtObs= $campo_noticias['txtObs']; 	 
		$id_empresa= $campo_noticias['id_empresa']; 	 
		
		
		
			?>

			<tr class='tr_tb' >		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$txCNPJ ;?> </td>
				<td class='td2' >  <?=$txrazaosocial;?></td>				
				<td class='td2' >  <?=$txnome;?></td>				
				<td class='td2' >  <?=$selTipo;?></td>				
				<td class='td2' >  <?=$selArea;?></td>				
				<td class='td2' >  <?=$txinscmunicipal;?></td>				
				<td class='td2' >  <?=$txinscestadual;?></td>				
				<td class='td2' >
				<?$endereco = $_SERVER ['REQUEST_URI'];;?>
				<a href="<?=$endereco ;?>" title='Atualizar lista'><img src='img/table_refresh.png'/></a> 
				<a href="javascript:Abrir_Pagina('cadastro_empresa.php?txCNPJ=<?=$txCNPJ;?>','scrollbars=yes,width=600,height=500')" title='Saiba mais'><img src='img/busca.png'/></a> 
				
				<script>
					function ConfirmDelete_<?=$id_empresa;?>(){

					var del=confirm("Deseja Excluir Empresa <?=$txnome;?>");
					if (del==true){
					//alert ("Excluindo..")
					Abrir_Pagina('script_empresa.php?acao=excluir&id_empresa=<?=$id_empresa;?>&nome=<?=$txnome;?>','scrollbars=yes,width=600,height=500')
					}else{
					alert("Excluição cancelada")
					}
					return del;
					}
					//javascript:Abrir_Pagina('script_vaga.php?acao=excluir&id_vaga=<?=$id_vaga;?>&nome=<?=$id_vaga;?>','scrollbars=yes,width=600,height=500')
					</script>
					
				<a href="#" Onclick="ConfirmDelete_<?=$id_empresa;?>();" title='Excluir'><img src='img/delete.png'/></a> </td> 
			</tr>
		<?}?>	

	</table>
	

</form>
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
