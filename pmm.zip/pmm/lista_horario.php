<?
include("../interno/input_banco.php"); // Inclui o arquivo com o sistema de segurança
$data2 = $_GET['data'];
$tipo = $_GET['tipo'];
if($data2 ==""){}
	else{
	$pieces = explode("-", $data2);
	$pieces[0]; // ano
	$pieces[1]; // mes
	$pieces[2]; // dia

	$diasoma = $pieces[1] + 1;

	$data = $pieces[0]."-".$diasoma."-".$pieces[2];
	$datapt = date("d-m-Y", strtotime($data));
	echo "<p style='color:red;'> Data Selecionada: <b>$datapt</b></p>";
					
					$query_horario = "SELECT horario FROM  `horarioatendimento`  order by horario ASC ";
					$rs_noticias_horario    = mysql_query($query_horario);
					while($campo_noticias_horario = mysql_fetch_array($rs_noticias_horario)){			
					$horario_banco  = $campo_noticias_horario['horario'];
					
							if(($horario_banco > "11:30")&&($horario_banco < "14:00")){$valorhorario=5;}else{$valorhorario=10;};
						
							$query_horario_disponivel = "SELECT horario FROM  `agendamentoctps`  where horario='$horario_banco' and data='$data'  ";
							$rs_noticias_horario_disponivel    = mysql_query($query_horario_disponivel);
							$total_horario_disponivel = mysql_num_rows($rs_noticias_horario_disponivel);	
							
							
							//echo $valorhorario;
								if($total_horario_disponivel==$valorhorario){}else{	
							
								?>
									<div style="float:left;margin:5px;"><INPUT TYPE="RADIO" NAME="horario" id="horario"  onclick="salvaragendamento();" VALUE="<?=$horario_banco;?>"> <?=$horario_banco;?></div>		
								<?
							
							
								}
						}
	}
					
					?>