﻿<?include("conf.php"); // Inclui o arquivo com o sistema de segurança


error_reporting(0);

		$id_vaga = $_GET['id'];
?>
	<link rel="stylesheet" type="text/css" href="assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="assets/styles.css" />
	<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>
	<form class="form" >
	<h2>Trabalhadores encaminhado para vaga ID: <?=$id_vaga;?></h2>
	<table width='100%'>
	
				<tr>
				<td class='td1' >N°</td>
				<td class='td1' >Candidato</td>
				<td class='td1' >Telefone</td>
				<td class='td1' >Ocupação</td>
				<td class='td1' >Atendente</td>
				<td class='td1' >Status</td>
				<td class='td1' >Curriculum</td>				
				<td class='td1' >Data</td>
				</tr>

			<?	
			
			$numero=1;
			$query_noticiasj = "SELECT * FROM `vaga` where id='$id_vaga'";			
			$rs_noticiasj    = mysql_query($query_noticiasj);				
			while($campo_noticiasj = mysql_fetch_array($rs_noticiasj)){
			$txcbonome = $campo_noticiasj['cboid'];			
			$txEncaminhar = $campo_noticiasj['txEncaminhar'];			
			
			}
					$numero=1;
					$query_noticias_total_emca = "SELECT * FROM  encaminhamento  WHERE vagaid ='$id_vaga'";	
					$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
					while($campo_noticiasjR = mysql_fetch_array($rs_noticias_total_emca)){
					$id_trabalhandor  = $campo_noticiasjR['trabalhadorid'];						
					$data   = $campo_noticiasjR['datacadastro'];						
					$id_usuario   = $campo_noticiasjR['usuarioid'];						
					$status_e    = $campo_noticiasjR['status'];						
					$obs     = $campo_noticiasjR['observacao'];						
				
			?>
				<tr class='tr_tb' >		
					<td class='td2' ><?=$numero++;?></td>
					
												<?
									
								$query_noticias_hcpjvgetc = "SELECT * FROM `cbo` where id='$txcbonome' ";
								$rs_noticias_hcpjvgetc    = mysql_query($query_noticias_hcpjvgetc);
								while($campo_noticias_hcpjvgetc = mysql_fetch_array($rs_noticias_hcpjvgetc)){			
								$cbo  = $campo_noticias_hcpjvgetc['cbo'];
								
								
								}
							
							
						$sql3et = "select nome,telcel,telres,id from trabalhador where id  ='$id_trabalhandor'";
						$rsd3et = mysql_query($sql3et);
						while($rs3et = mysql_fetch_array($rsd3et)) {
						$telrest= $rs3et['telres'];	
						$telselt= $rs3et['telcel'];	
						$idselt= $rs3et['id'];	
						$nometrabalhador= $rs3et['nome'];	}
						
						
						
							?>
					
					<td class='td2' ><?=$nometrabalhador;?></td>
					<td class='td2' ><?=$telselt;?> <?if($telrest==""){}else{?>/ <?=$telrest;}?></td>
					<td class='td2' ><?=$cbo;?></td>
							<?
							$sql3e = "select nome  from usuario where id  ='$id_usuario'";
							$rsd3e = mysql_query($sql3e);
							while($rs3e = mysql_fetch_array($rsd3e)) {
							$usuario_ajaxe= $rs3e['nome'];	}
							?>
					<td class='td2' >  <?=$usuario_ajaxe;?></td>
					
					<?
					switch ($status_e ){										
					case "E":											
					$status_N = "Encaminhado";
					break;

					case "I":											
					$status_N = "Inserido";
					break;
					
					case "N":											
					$status_N = "Não Inserido";
					break;
					}
					?>
					
					<td class='td2' >  <?=$status_N ;?></td>
					<td class='td2' ><a href="javascript:Abrir_Pagina('interno/candidatocurriculum.php?id=<?=$idselt;?>','scrollbars=yes,width=600,height=500')" title='Verificar Curriculum'><img src='interno/img/relatorio.png'/></a> </td>
					
					<td class='td2' >  <?=date("d-m-Y H:i:s", strtotime($data));;?></td>
				</tr>
			<?}?>
			
	</table>		
	
	<form>