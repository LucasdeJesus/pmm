<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body>

<div id="bg-container" class='contener'>


			

			
<form  class="form" style='width:100%;'action='lista_vaga.php'method="GET" >
		<h2>Buscar Vaga</h2>
			<div class="form-row">
			<div class="label">ID Vaga</div>
			<div class="input-container" style='width:546px;'>		
			<input name="busca_cnpj1" required id="busca_cnpj1" maxlength="18"  tabindex="1"  style="width:194px;" type="text" class="input req-same">
			<input id="campo"  name='campo' value="id_vaga" type="hidden" />
			<input id="submitBtn2" value="Buscar" type="submit" class="sendBtn" />
			</div>
			</div>
			<a href="cadastro_vagas.php" class="myButton"><img src='img/novo_item.png' />Novo cadastro</a>
</form>			


<form  class="form" style='width:100%;'method="post" >
		<h2>Lista de Vagas</h2>
	<table style='width:95%;'>
			<tr>
				<td class='td1' >N°</td>
				<td class='td1' >ID</td>
				<td class='td1' >Empresa </td>
				<td class='td1' >Ocupação </td>
				<td class='td1'>Qtd. </td>
				<td class='td1'>Encaminhados</td>
				<td class='td1'>Publicação</td>
				<td class='td1'>Mudança Status </td>
				<td class='td1'>Status</td>
				<td >
					<select name='lista_vaga' style='width:100%'  onchange="location = this.options[this.selectedIndex].value;">	
							<option value=''>Filtro</option>
							<?
							$query_noticias_lista_vaga = "SELECT selvagastatus  FROM `vagas` GROUP BY  selvagastatus ASC LIMIT 0 , 30";
							$rs_noticias_lista_vaga    = mysql_query($query_noticias_lista_vaga);							
							while($campo_noticias_lista_vaga = mysql_fetch_array($rs_noticias_lista_vaga)){
							$selvagastatus_lista_vaga  	= $campo_noticias_lista_vaga['selvagastatus']; 

							?>
						
						
						<option value='lista_vaga.php?selvagastatus=<?=$selvagastatus_lista_vaga;?>'><?=$selvagastatus_lista_vaga ;?></option>
						<?}?>
													<option value='lista_vaga.php'>Todas</option>

						
						
					</select>
				</td>
				
						
			</tr>
			
						<?
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$selvagastatus_get= $_GET['selvagastatus'];
			$numero=1;
			
			if($campo==""){
			
				if($selvagastatus_get==""){
				$query_noticias = "SELECT *  FROM `vagas` ORDER BY `vagas`.`id_vaga` DESC LIMIT 0 , 30";
				}
				else
				{
				$query_noticias = "SELECT *  FROM `vagas` where selvagastatus='$selvagastatus_get' ORDER BY `vagas`.`id_vaga` DESC LIMIT 0 , 30";
				}
			}
			else
			{
				
				$query_noticias = "SELECT * FROM `vagas` WHERE id_vaga ='$busca_cnpj1'";	
				
			}
		
		
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){


			$id_vaga= $campo_noticias['id_vaga']; 	 
			$id_empresa= $campo_noticias['id_empresa']; 	 
			$selvagasigilosa = $campo_noticias['selvagasigilosa'];
			$id_empresa = $campo_noticias['id_empresa']; 
			$txcbonome = $campo_noticias['txcbonome'];
			$txtdescrvaga = $campo_noticias['txtdescrvaga'];
			$txcargo = $campo_noticias['txcargo']; 
			$txvagadata = $campo_noticias['txvagadata'];
			$txvagahorario = $campo_noticias['txvagahorario'];
			$selvagadeficiente = $campo_noticias['selvagadeficiente'];
			$txvagaquantidade = $campo_noticias['txvagaquantidade'];
			$txvagapreenchidaCTM = $campo_noticias['txvagapreenchidaCTM']; 
			$txvagapreenchidaOutros = $campo_noticias['txvagapreenchidaOutros'];
			$txvagaCancelada = $campo_noticias['txvagaCancelada']; 
			$txvagasativas = $campo_noticias['txvagasativas']; 
			$txEncaminhar = $campo_noticias['txEncaminhar'];
			$txvagadataenc = $campo_noticias['txvagadataenc'];
			$chktemporaria = $campo_noticias['chktemporaria'];
			$txtcep_local = $campo_noticias['txtcep_local'];
			$txtestado_local = $campo_noticias['txtestado_local'];
			$txtcidade_local = $campo_noticias['txtcidade_local'];
			$txtbairro_local = $campo_noticias['txtbairro_local'];
			$txtendereco_local = $campo_noticias['txtendereco_local']; 
			$txtproximode_local = $campo_noticias['txtproximode_local']; 
			$cbo_on_off_shore = $campo_noticias['cbo_on_off_shore']; 
			$txvagalocal = $campo_noticias['txvagalocal'];
			$txvagasalario = $campo_noticias['txvagasalario'];
			$txvagaComissao = $campo_noticias['txvagaComissao'];
			$txvagaProspeccao = $campo_noticias['txvagaProspeccao'];
			$chkcartao_alimentacao = $campo_noticias['chkcartao_alimentacao']; 
			$chkalimentacao_local = $campo_noticias['chkalimentacao_local']; 
			$chklanche = $campo_noticias['chklanche'];
			$chkcesta_basica = $campo_noticias['chkcesta_basica']; 
			$chkplano_saude = $campo_noticias['chkplano_saude']; 
			$chkplano_odonto = $campo_noticias['chkplano_odonto'];
			$chkseguro_vida = $campo_noticias['chkseguro_vida'];
			$chkcarteira_assinada = $campo_noticias['chkcarteira_assinada']; 
			$chkvale_transporte= $campo_noticias['chkvale_transporte'];
			$chkpremiacao = $campo_noticias['chkpremiacao']; 
			$txvagabeneficios = $campo_noticias['txvagabeneficios'];
			$txvagatempoano = $campo_noticias['txvagatempoano']; 
			$txvagatempomes = $campo_noticias['txvagatempomes']; 
			$txvagaExpeCT = $campo_noticias['txvagaExpeCT'];
			$txvagaidademin = $campo_noticias['txvagaidademin']; 
			$txvagaidademax = $campo_noticias['txvagaidademax']; 
			$selvagaescolaridade = $campo_noticias['selvagaescolaridade'];
			$selvagaescolaridadesituacao = $campo_noticias['selvagaescolaridadesituacao'];
			$selvagacnh= $campo_noticias['selvagacnh']; 
			$selvagasexo = $campo_noticias['selvagasexo'];
			$selvagaestadocivil = $campo_noticias['selvagaestadocivil']; 
			$txvagafilhos = $campo_noticias['txvagafilhos'];
			$selvagatempo_niv = $campo_noticias['selvagatempo_niv']; 
			$selvagaidade_niv = $campo_noticias['selvagaidade_niv']; 
			$selvagaescolaridade_niv = $campo_noticias['selvagaescolaridade_niv']; 
			$selvagacnh_niv = $campo_noticias['selvagacnh_niv'];
			$selvagasexo_niv = $campo_noticias['selvagasexo_niv']; 
			$selvagaestadocivil_niv = $campo_noticias['selvagaestadocivil_niv'];
			$selvagafilhos_niv = $campo_noticias['selvagafilhos_niv'];
			$txvagaregiao = $campo_noticias['txvagaregiao'];
			$txvagahabilidades = $campo_noticias['txvagahabilidades']; 
			$txvagarestricoes = $campo_noticias['txvagarestricoes'];
			$txsemexperiencia = $campo_noticias['txsemexperiencia']; 
			$selvagaidiomas_niv = $campo_noticias['selvagaidiomas_niv'];
			$selvagainformatica_niv = $campo_noticias['selvagainformatica_niv'];
			$txtcep = $campo_noticias['txtcep'];
			$txtestado = $campo_noticias['txtestado'];
			$txtcidade = $campo_noticias['txtcidade'];
			$txtbairro = $campo_noticias['txtbairro'];
			$txtendereco = $campo_noticias['txtendereco']; 
			$txtproximode = $campo_noticias['txtproximode'];
			$txtfalarcom = $campo_noticias['txtfalarcom']; 
			$txtEmailEntrevista = $campo_noticias['txtEmailEntrevista']; 
			$txvagahorarioatend = $campo_noticias['txvagahorarioatend'];
			$selViaEncaminhamento = $campo_noticias['selViaEncaminhamento'];
			$txObs = $campo_noticias['txObs']; 
			$selvagastatus = $campo_noticias['selvagastatus']; 
			$selvagaatraves = $campo_noticias['selvagaatraves'];
			$selcidaatraves = $campo_noticias['selcidaatraves']; 
			$selpublicar = $campo_noticias['selpublicar']; 
			$dia = $campo_noticias['dia']; 
			$mes = $campo_noticias['mes']; 
			$ano = $campo_noticias['ano']; 

			
		
		
			?>

			<tr class='tr_tb' >		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$id_vaga ;?> </td>
					<?
						$sql = "select DISTINCT txnome,id_empresa from empresa where id_empresa ='$id_empresa'";
						$rsd = mysql_query($sql);
						while($rs = mysql_fetch_array($rsd)) {
						$txnomed = $rs['txnome'];
						$id_empresad = $rs['id_empresa'];	
							}						
					?>
				<td class='td2' >  <?=$txnomed;?></td>
						<?
							$n = preg_replace('/[0-9]/', '', $txcbonome);
							
					$query_noticias_total_emca = "SELECT * FROM  emcaminhamento  WHERE id_vaga ='$id_vaga'";	
					$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
					$total_total_emca = mysql_num_rows($rs_noticias_total_emca);	
					
						?>
				<td class='td2' >  <?=$n;?></td>				
				<td class='td2' >  <?=$txvagaquantidade;?></td>				
				<td class='td2' >  <?=$total_total_emca;?>/<?=$txEncaminhar;?></td>				
				<td class='td2' >  <?=$selpublicar;?></td>				
				<td class='td2' >  <?=$dia;?>/<?=$mes;?>/<?=$ano;?></td>				
				<td class='td2' >  <?=$selvagastatus;?></td>				
				<td class='td2' >
				<?$endereco = $_SERVER ['REQUEST_URI'];;?>
				<a href="<?=$endereco ;?>" title='Atualizar lista'><img src='img/table_refresh.png'/></a> 
				<a href="javascript:Abrir_Pagina('cadastro_vagas.php?id_vaga=<?=$id_vaga;?>&id_empresa=<?=$id_empresa;?>','scrollbars=yes,width=800,height=500')" title='Saiba mais'><img src='img/busca.png'/></a> 
				<a href="javascript:Abrir_Pagina('lista_trabalhador_vaga.php?id_vaga=<?=$id_vaga;?>','scrollbars=yes,width=600,height=500')" title='Trabalhador Encaminhado'><img src='img/relatorio.png'/></a> 
				
					<script>
					function ConfirmDelete_<?=$id_vaga;?>(){

					var del=confirm("Deseja Excluir ID vaga <?=$id_vaga;?>?");
					if (del==true){
					//alert ("Excluindo..")
					Abrir_Pagina('script_vaga.php?acao=excluir&id_vaga=<?=$id_vaga;?>&nome=<?=$id_vaga;?>','scrollbars=yes,width=600,height=500')
					}else{
					alert("Excluição cancelada")
					}
					return del;
					}
					//javascript:Abrir_Pagina('script_vaga.php?acao=excluir&id_vaga=<?=$id_vaga;?>&nome=<?=$id_vaga;?>','scrollbars=yes,width=600,height=500')
					</script>
				<a Onclick="ConfirmDelete_<?=$id_vaga;?>();" href="" title='Excluir'><img src='img/delete.png'/></a> </td>
			</tr>
		<?}?>	
		
		
	</table>
	

</form>
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

</body>
</html>
