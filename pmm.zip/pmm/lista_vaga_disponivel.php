<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);

		
?>
	<option value=''>Selecione</option>
<?
			$query_noticiasj = "SELECT * FROM `vagas` where selvagastatus IN ('Ativa', 'Preenchida pelo CTM', 'Preenchida pelo Solicitante','NPFP')";			
			$rs_noticiasj    = mysql_query($query_noticiasj);				
			while($campo_noticiasj = mysql_fetch_array($rs_noticiasj)){

			$id_vagam= $campo_noticiasj['id_vaga']; 			
			$txcbonome = $campo_noticiasj['txcbonome'];			
			$txEncaminhar = $campo_noticiasj['txEncaminhar'];			
			$n = preg_replace('/[0-9]/', '', $txcbonome);
			
				$query_noticias_total_emca = "SELECT * FROM  emcaminhamento  WHERE id_vaga ='$id_vagam'";	
				$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
				$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
				
				if($total_total_emca >=$txEncaminhar )
				
				{
				}
				else{
			?>
			<option value='<?=$id_vagam;?>'><?=$id_vagam;?> - <?=$n;?></option>

			<?}}?>