<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	
	
	
	?>
	

<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>
	<style>
	.text_azul{color:blue;}
	span{line-height:130%;}
	</style>
	
	<div id="getexcel">
			<table border="1" width="500px" class="sortable" align='left'>
			<?				
		
		
		
		$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			$numero=1;
			
			
			
				if($get_acao==""){
				$query_noticias = "SELECT * FROM vaga where status='A'  GROUP BY cargo ORDER BY cargo ASC   ";
				}
				else
				{
				//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
				if($post_status==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='$post_status'  ";}
				if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
				if($post_descricao==""){}else{$sqldescricao="and `descricao` LIKE '%$post_descricao%' ";}				
				if($post_escolaridade==""){}else{$sqloescolaridade="and escolaridade='$post_escolaridade' ";}
				if($post_sexo==""){}else{$sqlsexo="and sexo='$post_sexo' ";}
				if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
				if($post_id==""){}else{$sqlid="and id='$post_id' ";}
				if($empresaid==""){}else{$sqlempresaid="and empresaid='$empresaid' ";}
				
				
				$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
				$post_datafinal1s = implode("-",array_reverse(explode("/",$post_datafinal)));
						$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1s))); // 15/03/2006
				
				if(($post_datainicio=="") || ($post_datafinal==""))
				{
					if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
					if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
					
				
				}
				else{
				$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
				}
				
				
				$query_noticias = "SELECT *  FROM `vaga` where  
				".$sqlostatus."				
				".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."				
				".$sqlempresaid."	
				".$sql2data."
				GROUP BY cargo ORDER BY cargo ASC ";
				}
			
			$totalgeral=0;
			$rs_noticiasA    = mysql_query($query_noticias); 
			while($campo_noticias = mysql_fetch_array($rs_noticiasA)){									
			$cargoobj= $campo_noticias['cargo']; 	
			
			$totalvagadisponivel=0;
			$query_noticiasI = "SELECT * FROM vaga where status='A' and  `cargo`= '$cargoobj'  ";
			$rs_noticiasA2  = mysql_query($query_noticiasI); 
			while($campo_noticias2 = mysql_fetch_array($rs_noticiasA2)){									
			$quantidadeencaminhar= $campo_noticias2['quantidadedisponivel']; 
			$totalvagadisponivel+= $quantidadeencaminhar;
			
			}
			$totalgeral+=$totalvagadisponivel
			
			?>
	
		<tr  class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >		
			<td  id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
						<?=$cargoobj;?>
			</b></span>
			</td>	
			
			<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
						<?=$totalvagadisponivel;?>
			</b></span>
			</td>
		</tr>	
		<?}?>
		
		<tr  class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >		
			<td  id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
						Total
			</b></span>
			</td>	
			
			<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
						<?=$totalgeral;?>
			</b></span>
			</td>
		</tr>	
	
		
	
	</table>
	</div>