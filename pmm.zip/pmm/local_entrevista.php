<?include("conf.php"); // Inclui o arquivo com o sistema de segurança
// Chama a função que protege a página
error_reporting(0);


		$busca = $_GET['busca'];
		$id = $_GET['id'];
		$id_empresa = $_GET['idempresa'];
		
		if($id==""){
				
				
				$query_noticias = "SELECT * FROM `empresa` WHERE id='$id_empresa'";
				$rs_noticias    = mysql_query($query_noticias);
				while($campo_noticias = mysql_fetch_array($rs_noticias)){		
											
				$enderecoentrevista1	= $campo_noticias['enderecoentrevista']; 
						if($enderecoentrevista1==""){
						
								$enderecoentrevista	= $campo_noticias['endereco']; 	 		 			 	
								$bairroentrevista	= $campo_noticias['bairro']; 	 		 			 	
								$cidadeentrevista	= $campo_noticias['cidadeid'];	 			 	
								$cepentrevista	= $campo_noticias['cep'];		 		 			 	
								$falarcom	= $campo_noticias['responsavel'];									
								$emailentrevista	= $campo_noticias['email']; 	 		 			 	
								$proximode	= $campo_noticias['referenciaend']; 
								$numeroentrevista	= $campo_noticias['numero']; 			 	
								
								
								
								
						
						}else{
								$enderecoentrevista	= $campo_noticias['enderecoentrevista']; 
								$bairroentrevista	= $campo_noticias['bairroentrevista']; 	 		 			 	
								$cidadeentrevista	= $campo_noticias['cidadeentrevistaid'];	 			 	
								$cepentrevista	= $campo_noticias['cepentrevista'];		 		 			 	
								$falarcom	= $campo_noticias['falarcom'];									
								$emailentrevista	= $campo_noticias['email']; 
								$proximode	= $campo_noticias['proximode'];										 	
								$numeroentrevista	= $campo_noticias['numeroentrevista']; 	

								
								
						
						}
				}
				
 				
					 
				
				
					 		 			 	
					 
				
				
				
				
		}
		else
		{
					$query_noticias = "SELECT * FROM `vaga` WHERE id ='$id'";
					$rs_noticias    = mysql_query($query_noticias);
					while($campo_noticias = mysql_fetch_array($rs_noticias)){												
					$enderecoentrevista	= $campo_noticias['enderecoentrevista']; 	 		 			 	
					}	

					
					if($enderecoentrevista==""){
					
					
								
								
								$query_noticias = "SELECT * FROM `empresa` WHERE id='$id_empresa'";
								$rs_noticias    = mysql_query($query_noticias);
								while($campo_noticias = mysql_fetch_array($rs_noticias)){		
															
								$enderecoentrevista1	= $campo_noticias['enderecoentrevista']; 
										if($enderecoentrevista1==""){
										
												$enderecoentrevista	= $campo_noticias['endereco']; 	 		 			 	
												$bairroentrevista	= $campo_noticias['bairro']; 	 		 			 	
												$cidadeentrevista	= $campo_noticias['cidadeid'];	 			 	
												$cepentrevista	= $campo_noticias['cep'];		 		 			 	
												$falarcom	= $campo_noticias['responsavel'];									
												$emailentrevista	= $campo_noticias['email']; 	 		 			 	
												$proximode	= $campo_noticias['referenciaend']; 
												$numeroentrevista	= $campo_noticias['numero']; 
												
												
												
										
										}else{
												$enderecoentrevista	= $campo_noticias['enderecoentrevista']; 
												$bairroentrevista	= $campo_noticias['bairroentrevista']; 	 		 			 	
												$cidadeentrevista	= $campo_noticias['cidadeentrevistaid'];	 			 	
												$cepentrevista	= $campo_noticias['cepentrevista'];		 		 			 	
												$falarcom	= $campo_noticias['falarcom'];									
												$emailentrevista	= $campo_noticias['email']; 
												$proximode	= $campo_noticias['proximode'];
												$numeroentrevista	= $campo_noticias['numeroentrevista'];

												
												
										
										}
				}
					
					
					}else{
					$query_noticias = "SELECT * FROM `vaga` WHERE id ='$id'";
					$rs_noticias    = mysql_query($query_noticias);
					while($campo_noticias = mysql_fetch_array($rs_noticias)){												
					$enderecoentrevista	= $campo_noticias['enderecoentrevista']; 	 		 			 	
					$bairroentrevista	= $campo_noticias['bairroentrevista']; 	 		 			 	
					$cidadeentrevista	= $campo_noticias['cidadeentrevistaid'];		 	
					$cepentrevista	= $campo_noticias['cepentrevista']; 			 	
					$falarcom	= $campo_noticias['falarcom']; 	 		 			 	
					$emailentrevista	= $campo_noticias['emailentrevista'];
					$numeroentrevista	= $campo_noticias['numeroentrevista'];					
					$proximode	= $campo_noticias['proximode']; }	
					
					}
		}
		
		
		
												
												?>					
														
									<div class="form-row">
										<div class="label"></div>
										<div class="input-container" style='width:546px;'>	

											
											<b>CEP</b>
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cepentrevista" value="<?echo $cepentrevista;?>" id="cepentrevista" maxlength="8" class="input req-same" onchange="EditandoRegistro();" onkeyup="verificaNumero('window.document.Ficha.cepentrevista');" tabindex="75" style="width:65px;" type="text">
											<b>Estado <font class='simbolo'><font class='simbolo'>&#10045;</font></font> </b>
												<select name="estadoentrevista" required id="estadoentrevista" onchange="busca_cidade_entrevista(this.value);" style='width:77px;' >

												<?	
												$query_estado_db = "SELECT * FROM `cidade` where id='$cidadeentrevista' ";
												$rs_estado_db     = mysql_query($query_estado_db );
												while($campo_estado_db  = mysql_fetch_array($rs_estado_db )){
												$ufid        = $campo_estado_db ['ufid'];

													$query_estado_dbuf = "SELECT * FROM `uf` where id='$ufid' ";
													$rs_estado_dbuf     = mysql_query($query_estado_dbuf );
													while($campo_estado_dbuf  = mysql_fetch_array($rs_estado_dbuf )){
													$uf_nome        = $campo_estado_dbuf ['uf'];
													$id_uf_db        = $campo_estado_dbuf ['id'];
													}
											
												}	
												?>
												<option value='<?=$id_uf_db;?>'><?=$uf_nome ;?></option>
																						
												<?
												$query_noticias_estado = "SELECT *  FROM  `uf` ORDER BY  `uf`.`uf` ASC ";
												$rs_noticias_estado    = mysql_query($query_noticias_estado);
												while($campo_noticias_estado = mysql_fetch_array($rs_noticias_estado)){		
												$iduf 	= $campo_noticias_estado['id']; 
												$nome_uf 	= $campo_noticias_estado['uf']; 
												
												?>
												<option value='<?=$iduf;?>'><?=$nome_uf ;?></option>			
												<?}?>
												</select>	
												
												
											<b>Cidade <font class='simbolo'><font class='simbolo'>&#10045;</font></font></b>
											
											
											

												<?	
												$query_noticias_cidadecp = "SELECT * FROM `cidade` where id='$cidadeentrevista' ";
												$rs_noticias_cidadecp    = mysql_query($query_noticias_cidadecp);
												while($campo_noticias_cidadecp = mysql_fetch_array($rs_noticias_cidadecp)){
												$nome_cidade        = $campo_noticias_cidadecp['nome'];	
												$id_cidade        = $campo_noticias_cidadecp['id'];	
												}	
												?>
		
		
											<select name="cidadeentrevistaid" required id="cidadeentrevistaid" onchange="busca_bairo(this.value);"  style='width:220px;'>
											<option value='<?=$cidadeentrevista;?>'><?=$nome_cidade;?></option>
											</select>	
										</div>
									</div>
									
									
									<div class="form-row">
										<div class="label">Bairro <font class='simbolo'><font class='simbolo'>&#10045;</font></font></div>
										<div class="input-container" style='width:546px;'>		
										
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="bairroentrevista"  required='' value="<?echo $bairroentrevista;?>"  id="enderecoentrevista" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="79" type="text">
										</div>
									</div>
									
									<div class="form-row">
										<div class="label">Endereço <font class='simbolo'><font class='simbolo'>&#10045;</font></font></div>
										<div class="input-container" style='width:546px;'>		
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="enderecoentrevista"  required='' value="<?echo $enderecoentrevista;?>"  id="enderecoentrevista" maxlength="400" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="79" type="text">
												
										</div>
									</div>
									
									<div class="form-row">
										<div class="label">Numero <font class='simbolo'>&#10045;</font></div>
										<div class="input-container" style='width:546px;'>	
											<i>Favor informa apenas numero</i>	
											<input  style='width:146px;'onChange="javascript:this.value=this.value.toUpperCase();" required onChange="javascript:this.value=this.value.toUpperCase();" name="numeroentrevista"   value="<?=$numeroentrevista;?>"  id="numeroentrevista"  class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="79" type="numbre">
												
										</div>
									</div>
															
									<div class="form-row">
										<div class="label">Próximo de</div>
										<div class="input-container" style='width:546px;'>	
												<i>Ex: loja A, perto de,...</i>											
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="proximode" value="<?= $proximode;?>" id="proximode" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="80"  type="text">
										</div>
									</div>
									
									<div class="form-row">
										<div class="label">Falar com <font class='simbolo'><font class='simbolo'>&#10045;</font></font> </div>
										<div class="input-container" style='width:546px;'>		
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="falarcom" required='' value="<?=$falarcom;?>" id="falarcom" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="81"  type="text">
										</div>
									</div>
									
									<div class="form-row">
										<div class="label">Email <font class='simbolo'><font class='simbolo'>&#10045;</font></font> </div>
										<div class="input-container" style='width:546px;'>		
											<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="emailentrevista" required='' value="<?=$emailentrevista;?>" id="emailentrevista" class="input req-same" maxlength="100" onchange="EditandoRegistro();" tabindex="82"  type="text">
										</div>
									</div>
									
									