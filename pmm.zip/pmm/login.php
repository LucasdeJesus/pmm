<?include'conexao.php';?>

<html>
<?include'topo.php';?>

<body>
	<?include"topo_logo.php";?>


	
									
<script language="JavaScript">
function cpf_loginfun(){
var cpf_login = document.cpf_loginF.cpf_login.value;
var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
if(!filtro.test(cpf_login)){
window.alert("CPF inválido. Tente novamente.");
return false;
}

cpf_login = remove(cpf_login, ".");
cpf_login = remove(cpf_login, "-");

if(cpf_login.length != 11 || cpf_login == "00000000000" || cpf_login == "11111111111" ||
cpf_login == "22222222222" || cpf_login == "33333333333" || cpf_login == "44444444444" ||
cpf_login == "55555555555" || cpf_login == "66666666666" || cpf_login == "77777777777" ||
cpf_login == "88888888888" || cpf_login == "99999999999"){
window.alert("cpf inválido. Tente novamente.");
return false;
}

soma = 0;
for(i = 0; i < 9; i++)
soma += parseInt(cpf_login.charAt(i)) * (10 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_login.charAt(9))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
soma = 0;
for(i = 0; i < 10; i ++)
soma += parseInt(cpf_login.charAt(i)) * (11 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_login.charAt(10))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
return true;
}

function remove(str, sub) {
i = str.indexOf(sub);
r = "";
if (i == -1) return str;
r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
return r;
}
</script>	

		
									
<script language="JavaScript">
function cpf_trabalhadorfun(){
var cpf_trabalhador = document.cpf_trabalhadorF.cpf_trabalhador.value;
var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
if(!filtro.test(cpf_trabalhador)){
window.alert("CPF inválido. Tente novamente.");
return false;
}

cpf_trabalhador = remove(cpf_trabalhador, ".");
cpf_trabalhador = remove(cpf_trabalhador, "-");

if(cpf_trabalhador.length != 11 || cpf_trabalhador == "00000000000" || cpf_trabalhador == "11111111111" ||
cpf_trabalhador == "22222222222" || cpf_trabalhador == "33333333333" || cpf_trabalhador == "44444444444" ||
cpf_trabalhador == "55555555555" || cpf_trabalhador == "66666666666" || cpf_trabalhador == "77777777777" ||
cpf_trabalhador == "88888888888" || cpf_trabalhador == "99999999999"){
window.alert("cpf inválido. Tente novamente.");
return false;
}

soma = 0;
for(i = 0; i < 9; i++)
soma += parseInt(cpf_trabalhador.charAt(i)) * (10 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_trabalhador.charAt(9))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
soma = 0;
for(i = 0; i < 10; i ++)
soma += parseInt(cpf_trabalhador.charAt(i)) * (11 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_trabalhador.charAt(10))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
return true;
}

function remove(str, sub) {
i = str.indexOf(sub);
r = "";
if (i == -1) return str;
r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
return r;
}
</script>	

									<script type="text/javascript">
										function exibe(id) {
										if(document.getElementById(id).style.display=="none") {
										document.getElementById(id).style.display = "inline";
										}
										else {
										document.getElementById(id).style.display = "none";
										}
										}
										
										
										</script>
										
										<script type="text/javascript">
function formatar_mascara(src, mascara) {
	var campo = src.value.length;
	var saida = mascara.substring(0,1);
	var texto = mascara.substring(campo);
	if(texto.substring(0,1) != saida) {
		src.value += texto.substring(0,1);
	}
}


</script>
		<div style='width:100%;background: url("img/cidade.png") repeat-x scroll center 100% rgba(0, 0, 0, 0);height:500px;margin-top:50px;' align='center' >
		
		
		
				<?
				
					$pass = $_POST['pass'];
				
				///////////////lembra senha trabalhador
				if($pass=="2"){
								$cpf_trabalhador_cadastro = $_POST['cpf_trabalhador_cadastro'];											
							
								$datanascimento_1 	=(string)addslashes($_POST['datanascimento']); 
								$datanascimento = implode("-",array_reverse(explode("/",$datanascimento_1)));
								
								$query_noticias_hcpj = "SELECT usuario,senha,id  FROM `usuario` where usuario='$cpf_trabalhador_cadastro'";	
								$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
								while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
								$idusuario  = $campo_noticias_hcpj['id'];								
																
								$usuariouser  = $campo_noticias_hcpj['usuario'];								
								}
								
								if($idusuario > 0){
									
									
													function geraSenha($tamanho = 8, $maiusculas = true, $numeros = true, $simbolos = false)
													{
													$lmin = 'abcdefghijklmnopqrstuvwxyz';
													$lmai = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
													$num = '1234567890';
													$simb = '!@#$%*-';
													$retorno = '';
													$caracteres = '';

													$caracteres .= $lmin;
													if ($maiusculas) $caracteres .= $lmai;
													if ($numeros) $caracteres .= $num;
													if ($simbolos) $caracteres .= $simb;

													$len = strlen($caracteres);
													for ($n = 1; $n <= $tamanho; $n++) {
													$rand = mt_rand(1, $len);
													$retorno .= $caracteres[$rand-1];
													}
													return $retorno;
													}
													$senhauser  = geraSenha(5);
														
													$query="update  usuario set senha ='$senhauser' where id='$idusuario' ";
													$rs= mysql_query($query);
													
													
													
													
													$query_noticias_dados = "SELECT email,nome,id,telcel  FROM `trabalhador` where cpf='$cpf_trabalhador_cadastro' and datanascimento='$datanascimento' ";	
													$rs_noticias_dados    = mysql_query($query_noticias_dados);
													while($campo_noticias_dados = mysql_fetch_array($rs_noticias_dados)){			
													$email  = $campo_noticias_dados['email'];
													$nometrabalhador 	= $campo_noticias_dados['nome']; 													
													$idtrabalhador 	= $campo_noticias_dados['id']; 													
													$telcel 	= $campo_noticias_dados['telcel']; 													
													
													$vowels = array("(", ")", ".", "-");
													$numerocelular = str_replace($vowels, "", $telcel);
				
													}
													
													if($email=="")
														
													{
														
														echo"
														<script language= 'JavaScript'>
															location.href='cadastra_email_trabalhador.php?id=$idtrabalhador'
														</script>
														";
													 
																											 ;
														
													}else{
													
													/* Medida preventiva para evitar que outros domínios sejam remetente da sua mensagem. */
												
													$emailsender = "ctm@macae.rj.gov.br";
													//    Na linha acima estamos forçando que o remetente seja 'webmaster@seudominio',
													// você pode alterar para que o remetente seja, por exemplo, 'contato@seudominio'.
													

													/* Verifica qual é o sistema operacional do servidor para ajustar o cabeçalho de forma correta. Não alterar */
													if(PHP_OS == "Linux") $quebra_linha = "\n"; //Se for Linux
													elseif(PHP_OS == "WINNT") $quebra_linha = "\r\n"; // Se for Windows
													else die("Este script nao esta preparado para funcionar com o sistema operacional de seu servidor");

													// Passando os dados obtidos pelo formulário para as variáveis abaixo
													$nomeremetente     = "Secretaria Trabalho e Renda";
													$emailremetente    = "ctm@macae.rj.gov.br";
													$emaildestinatario = "$email";
													$comcopia          = "$email";
													$comcopiaoculta    = "";
													$assunto           = "Solicitação de Senha Sistema SEMTRE CTM 2.0";



													/* Montando a mensagem a ser enviada no corpo do e-mail. */
													$mensagemHTML = "<div style='border:1px solid #ddd;padding:10px' >Sr(a),$nometrabalhador segue dados de  acesso sistema SEMTRE: <br><br> LOGIN: $usuariouser <br>NOVA SENHA: $senhauser\n <br>LINK:  <a href='http://sistemas.macae.rj.gov.br:84/catalogo/semtre'>http://sistemas.macae.rj.gov.br:84/catalogo/semtre</a> <br>Acessando sua área podera alterar senha  </div>";


													/* Montando o cabeçalho da mensagem */
													$headers = "MIME-Version: 1.1".$quebra_linha;
													$headers .= "Content-type: text/html; charset=ISO-8859-1".$quebra_linha;
													// Perceba que a linha acima contém "text/html", sem essa linha, a mensagem não chegará formatada.
													$headers .= "From: ".$emailsender.$quebra_linha;
													$headers .= "Return-Path: " . $emailsender . $quebra_linha;
													// Esses dois "if's" abaixo são porque o Postfix obriga que se um cabeçalho for especificado, deverá haver um valor.
													// Se não houver um valor, o item não deverá ser especificado.
													if(strlen($comcopia) > 0) $headers .= "Cc: ".$comcopia.$quebra_linha;
													if(strlen($comcopiaoculta) > 0) $headers .= "Bcc: ".$comcopiaoculta.$quebra_linha;
													$headers .= "Reply-To: ".$emailremetente.$quebra_linha;
													// Note que o e-mail do remetente será usado no campo Reply-To (Responder Para)

													/* Enviando a mensagem */
													mail($emaildestinatario, $assunto, $mensagemHTML, $headers, "-r". $emailsender);

													echo"<div  align='center'  style='font-size:18px;color:#057FD0;width:110%;border:1px solid #057FD0;padding:10px;background-color:#fff'> ATENÇÃO<br> Sua nova senha é <b style='color:red;font-size:23px;'>$senhauser </b> e foi  enviado para: <br> $emaildestinatario , sms para $numerocelular</div>";
														
														
														?>

																			<?if($numerocelular=="00000000000"){}else{?>
																			<script>
																			$.ajax({
																			url: 'http://app.smsconecta.com.br/SendAPI/Send.aspx?usr=cetep&pwd=cetep357&number=55<?=$numerocelular;?>&sender=SEMTRE&msg=Dados de acesso sistema SEMTRE CTM 2.0 Login seu CPF e sua nova senha é <?=$senhauser;?> ',
																			success: function(data) {				
																			if($.trim(data)  > 2){
																			document.getElementById("sms").innerHTML = "<h3>Enviamos uma SMS para <?=$numerocelular;?>  com detalhes de acesso ao sistema , favor verificar seu Celular </h3>";		

																			}
																			}

																			});


																			</script>

																			<?}?>

														<?
														
														}
								}else{
									echo"<div   align='center'  style='font-size:14px;color:red;width:110%;border:1px solid #057FD0;padding:10px;background-color:#fff'> Usuário não encontrado para $cpf_trabalhador_cadastro </div>";
									
								}
					
				}
				///////////////lembra senha trabalhador	
				
				
				///////////////lembra senha trabalhador
				if($pass=="1"){
								$txCNPJ = $_POST['txCNPJ'];													
								$query_noticias_hcpj = "SELECT usuario,senha,id  FROM `usuario` where usuario='$txCNPJ'";	
								$rs_noticias_hcpj    = mysql_query($query_noticias_hcpj);
								while($campo_noticias_hcpj = mysql_fetch_array($rs_noticias_hcpj)){			
								$idusuario  = $campo_noticias_hcpj['id'];								
								$senhauser  = $campo_noticias_hcpj['senha'];								
								$usuariouser  = $campo_noticias_hcpj['usuario'];								
								}
								
								if($idusuario > 0){
								
													$query_noticias_dados = "SELECT email,emailresponsavel,nome  FROM `empresa` where cnpj='$txCNPJ'";	
													$rs_noticias_dados    = mysql_query($query_noticias_dados);
													while($campo_noticias_dados = mysql_fetch_array($rs_noticias_dados)){			
													$email  = $campo_noticias_dados['email'];	
													$emailresponsavel  = $campo_noticias_dados['emailresponsavel'];
													$nometrabalhador 	= $campo_noticias_dados['nome']; 														
													}
													
													
													/* Medida preventiva para evitar que outros domínios sejam remetente da sua mensagem. */
													
													$emailsender = "ldeconte@macae.rj.gov.br";
													//    Na linha acima estamos forçando que o remetente seja 'webmaster@seudominio',
													// você pode alterar para que o remetente seja, por exemplo, 'contato@seudominio'.
													

													/* Verifica qual é o sistema operacional do servidor para ajustar o cabeçalho de forma correta. Não alterar */
													if(PHP_OS == "Linux") $quebra_linha = "\n"; //Se for Linux
													elseif(PHP_OS == "WINNT") $quebra_linha = "\r\n"; // Se for Windows
													else die("Este script nao esta preparado para funcionar com o sistema operacional de seu servidor");

													// Passando os dados obtidos pelo formulário para as variáveis abaixo
													$nomeremetente     = "Secretaria Trabalho e Renda";
													$emailremetente    = "ldeconte@macae.rj.gov.br";
													$emaildestinatario = "$emailresponsavel";
													$comcopia          = "$email";
													$comcopiaoculta    = "";
													$assunto           = "Solicitação de Senha Sistema SEMTRE CTM 2.0";



													/* Montando a mensagem a ser enviada no corpo do e-mail. */
													$mensagemHTML = "<div style='border:1px solid #ddd;padding:10px' >Sr(a),$nometrabalhador segue dados de  acesso sistema SEMTRE: <br><br> LOGIN: $usuariouser <br>SENHA: $senhauser\n <br>LINK:  <a href='http://sistemas.macae.rj.gov.br:84/catalogo/semtre'>http://sistemas.macae.rj.gov.br:84/catalogo/semtre</a> </div>";


													/* Montando o cabeçalho da mensagem */
													$headers = "MIME-Version: 1.1".$quebra_linha;
													$headers .= "Content-type: text/html; charset=ISO-8859-1".$quebra_linha;
													// Perceba que a linha acima contém "text/html", sem essa linha, a mensagem não chegará formatada.
													$headers .= "From: ".$emailsender.$quebra_linha;
													$headers .= "Return-Path: " . $emailsender . $quebra_linha;
													// Esses dois "if's" abaixo são porque o Postfix obriga que se um cabeçalho for especificado, deverá haver um valor.
													// Se não houver um valor, o item não deverá ser especificado.
													if(strlen($comcopia) > 0) $headers .= "Cc: ".$comcopia.$quebra_linha;
													if(strlen($comcopiaoculta) > 0) $headers .= "Bcc: ".$comcopiaoculta.$quebra_linha;
													$headers .= "Reply-To: ".$emailremetente.$quebra_linha;
													// Note que o e-mail do remetente será usado no campo Reply-To (Responder Para)

													/* Enviando a mensagem */
													mail($emaildestinatario, $assunto, $mensagemHTML, $headers, "-r". $emailsender);

													echo"<div  align='center'  style='font-size:18px;color:#057FD0;width:110%;border:1px solid #057FD0;padding:10px;background-color:#fff'> ATENÇÃO<br> Sua nova senha é <b style='color:red;font-size:23px;'>$senhauser </b> e foi  enviado para: <br> $emaildestinatario , sms para $numerocelular</div>";
								
								}else{
									echo"<div   align='center'  style='font-size:14px;color:red;width:110%;border:1px solid #057FD0;padding:10px;background-color:#fff'> Usuário não encontrado para $txCNPJ </div>";
									
								}
				}
				///////////////lembra senha trabalhador	
				
				
			
				
				
				
				
					
				
				?>
				
				<?$msg = $_GET['msg'];?>
				
				<h3 style="font-size:18px;"><?=$msg;?></h3>
				
			<table width='960px'>
					<tr>
					
					
						<td width='460'  style='height:225px;border: 3px dotted  #00B8AD;margin:10px;border-radius: 5px;margin-top:10px;color:#00B8AD;padding:15px;color:#00b8AD'>
							<div>
							<h3><img src='img/traba.png'>Login Trabalhador</h3>
							
									

												<form  class="form" method="POST" action="valida_trabalhado.php"  id="cpf_loginF" name='cpf_loginF' onSubmit="return cpf_loginfun()">

														<a href="#"  data-reveal-id="myModal" ><img src='img/logintrabalhador.jpg'  border="0"/></a>
														

												</form>	


											<!-----envia senha email ---->
										
										
										<!------------envia senha email -------------->			
								
								
								
								
								
							</div>							
						</td>	

						
						
						
						
							<td width='460' style='border: 3px dotted #F36C34;margin:10px;border-radius: 5px;margin-top:10px;color:#F36C34;padding:15px;color:#f36c36'>
							<div >
								<h3><img src='img/empregador.png'> Login Empregador</h3>
								
								
								<form  class="form" method="post" action="valida_empresa.php"  id="cadastroem" name='cadastroem' onSubmit="return validar_cpf()">
										<a href="#"  data-reveal-id="myModal2" ><img src='img/loginempregador.jpg' border="0"/></a>

								</form>

								
										
										<!------------envia senha email -------------->
								
								
							
							</div>
							
						</td>	
						
						
						
						

						
					</tr>
				</table>
				
		</div>
		
		
		
			<?include"rodape_novo.php";?>
	
</body>
</html>