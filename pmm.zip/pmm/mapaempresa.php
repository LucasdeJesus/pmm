	
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
 <script type="text/javascript"src="../js/gmaps.js"></script> 
	<?

	include"../input_banco.php"
	
	
	?>
	

<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>
	<style>
	.text_azul{color:blue;}
	span{line-height:130%;}
	</style>
	<?
	function soNumero($str) {
    return preg_replace("/[^0-9]/", "", $str);
}
	?>
	
	
	<script type="text/javascript" >
	var geocoder;
var map;
var markersArray = [];

//plot initial point using geocode instead of coordinates (works just fine)
  function initialize() {
    geocoder = new google.maps.Geocoder();
     latlang = geocoder.geocode( { 'address': 'Rio de janeiro, Macaé'}, function(results, status) { //use latlang to enter city instead of coordinates 
            if (status == google.maps.GeocoderStatus.OK) {
                map.setCenter(results[0].geometry.location);
                marker = new google.maps.Marker({
                map: map,
                title:"Centro da Cidade",
                position: results[0].geometry.location
                });
            markersArray.push(marker);

            }
            else{
            //alert("Seu navegador não suporta Geolocalização" + status);
            }
        });
    var myOptions = {
        center: latlang, zoom: 8, mapTypeId: google.maps.MapTypeId.ROADMAP,
        navigationControlOptions: {
            style: google.maps.NavigationControlStyle.SMALL
        }
    };
     map = new google.maps.Map(document.getElementById("map"),
        myOptions);
     plotMarkers();
  }

///////////////////////////////////////////////////////////
//Everything below this line is for attempting to plot the markers

  var locationsArray = [   <?
     $query_noticias = "SELECT *  FROM `empresa` ORDER BY `empresa`.`nome` ASC LIMIT 10";
		$rs_noticias    = mysql_query($query_noticias); 
		$total = mysql_num_rows($rs_noticias);			
		while($campo_noticias = mysql_fetch_array($rs_noticias)){
		$endereco	= $campo_noticias['endereco']; 	 		 			 	
		$bairro	= $campo_noticias['bairro']; 	 		 			 	
		$cidadeid	= $campo_noticias['cidadeid']; 
		$cep	= $campo_noticias['cep'];
		$id	= $campo_noticias['id'];		
		$numero	= $campo_noticias['numero'];		
					$query_noticias_cidadecp = "SELECT * FROM `cidade` where id='$cidadeid' ";
					$rs_noticias_cidadecp    = mysql_query($query_noticias_cidadecp);
					while($campo_noticias_cidadecp = mysql_fetch_array($rs_noticias_cidadecp)){
					$nome_cidade        = $campo_noticias_cidadecp['nome'];	
					$id_cidade        = $campo_noticias_cidadecp['id'];	
					$ufid        = $campo_noticias_cidadecp ['ufid'];				};				
				$query_estado_dbuf = "SELECT * FROM `uf` where id='$ufid' ";
				$rs_estado_dbuf     = mysql_query($query_estado_dbuf );
				while($campo_estado_dbuf  = mysql_fetch_array($rs_estado_dbuf )){
				$uf_nome        = $campo_estado_dbuf ['nome'];
				$id_uf_db        = $campo_estado_dbuf ['id'];	};  
				
				$semnumero = str_replace(array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9'), '', $endereco); 
				$vowels = array( "S/N" ,"/", "(", ")", ":","SALA","SALAS");
				$filtro = str_replace($vowels, "", "$semnumero");
				?>    
				"<?=$uf_nome;?>,<?= $nome_cidade; ?>,<?=$bairro;?>,<?=$filtro;?>,<?=$numero;?>", <?};?>  ];
    
     var detalhesArrey = [
         <?		 
		 $query_noticiasd = "SELECT *  FROM `empresa` ORDER BY `empresa`.`nome` ASC LIMIT 10 ";
		$rs_noticiasd    = mysql_query($query_noticiasd); 
		$totald = mysql_num_rows($rs_noticiasd);			
		while($campo_noticiasd = mysql_fetch_array($rs_noticiasd)){
		$cnpj 	= $campo_noticiasd['cnpj']; 	 		 			 	
		$nome 	= $campo_noticiasd['nome']; 	 		 			 	
		$razaosocial 	= $campo_noticiasd['razaosocial']; 	 		 			 	
		$tel1 	= $campo_noticiasd['tel1']; 	 		 			 	
		$tel2 	= $campo_noticiasd['tel2']; 	 		 			 	
		$tel3 	= $campo_noticiasd['tel3']; 	 		 			 	
		$email 	= $campo_noticiasd['email']; 
       ?>
       "<p style='width:200px'><div><b><?=$nome;?></b></div><div><?=$razaosocial;?></div><div>Tel.:<?=$tel1;?> / <?=$tel2;?> / <?=$tel2;?></div><div><?=$email;?></div></p>",
	   <?};?> 
          
		 ];

  function plotMarkers(){
   
    
    for(var i = 0; i < locationsArray.length; i++){      
         for(var d = 0; d < detalhesArrey.length; d++){            
         codeAddresses(locationsArray[i],detalhesArrey[i]);
        }

    }    
    
  }

  function codeAddresses(address,detalhe){
    geocoder.geocode( { 'address': address}, function(results, status) { 
            if (status == google.maps.GeocoderStatus.OK) {
                map.setCenter(results[0].geometry.location);
                var icon1 = "../iconsmapa/b1.gif";
                marker = new google.maps.Marker({ 
                icon:icon1,
                title:address,
		map: map,
                position: results[0].geometry.location
                });		
         
	   var infowindow = new google.maps.InfoWindow();
             google.maps.event.addListener(marker, 'click', (function(marker) {
            return function() {
                var content = detalhe;
                infowindow.setContent(content);
                infowindow.open(map, marker);
            }
          })(marker));
		  
		  
            //markersArray.push(marker); 
            }
            else{
            //alert("Seu navegador não suporta geolocalização! " );
            }
  });
  }

      google.maps.event.addDomListener(window, 'load', initialize);
    </script>
<div id="map" style=" top: 0px;
     height: 600px;
     width: 100%;
     left: 0;
     top: 0;
     overflow: hidden;
     "></div>