<?php
include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<head>

			<!-- prefix free to deal with vendor prefixes -->
			<script src="js/prefixfree-1.0.7.js" type="text/javascript"></script>
			<!-- jQuery -->
			<script src="js/jquery-1.7.1.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="css.css"/>
			<link rel="stylesheet" type="text/css" href="assets/reset.css" />
			<link rel="stylesheet" type="text/css" href="assets/styles.css" />
			<script type="text/javascript" src="assets/jquery.1.3.2.js"></script>
			<script type="text/javascript" src="jquery.ufvalidator-1.0.4.js"></script>


			</head>
	
	<script>
function SelecionaMenu(Menu)
{
	parent.mainFrame.location.href = Menu
}

</script>



	<script type="text/javascript" >
	
/*jQuery time*/
$(document).ready(function(){
	$("#accordian h3").click(function(){
		//slide up all the link lists
		$("#accordian ul ul").slideUp();
		//slide down the link list below the h3 clicked - only if its closed
		if(!$(this).next().is(":visible"))
		{
			$(this).next().slideDown();
		}
	})
})
	</script>
	
	<script type='text/javascript'>

$(document).ready(function(){

// Executa o evento CLICK em todos os links do menu

 $('#menu a').live('click',function(){

  // Faz o carregamento da página de acordo com o COD da página, que vai pegar os valores da página page.php.

  $('#conteudo').load($(this).attr('href'));

  return false;

    

 });



});

</script>
	
	</head>
	<body style='background-color: #3892D3;' width='100%' height='100%'>
	
	
		
			<div style='background-color:#fff;margin: 4px;'id='menu'>
			<div id="accordian">
			<p><img src='img/LogoSecretaria.png' width='200px'/></p>
		<div class='barra' ><b>SEMTRE, Olá <b><?=$nome_usuario_login;?></b>  </b></div>

	<ul>
		<li>
			<h3><span ><img src='img/icone/folder_go.gif'></span>Cadastros Básicos</h3>
			<ul>
				<li><a href="#"  >Armazenagem de Documentos</a></li>
				<li><a href="#"onClick="SelecionaMenu('layout_duplo.php?pagina1=cadastro_captadores&pagina2=listar_captadores&tela=30')" >Captadores</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=cadastro_cargo&pagina2=listar_cargo&tela=30')" >Cargos</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=cadastro_formaca_academica&pagina2=listar_formaca_academica&tela=30')" >Economia Solidária</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=cadastro_formaca_academica&pagina2=listar_formaca_academica&tela=30')" >Formação Acadêmica</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=cadastro_forma_cap&pagina2=listar_forma_cap&tela=30')" >Formas de Captação</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=idiomas&pagina2=listar_idiomas&tela=30')" >Idiomas</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=locais_cap&pagina2=listar_locais_cap&tela=30')" >Locais de Captação</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=programa_social&pagina2=listar_programa_social&tela=30')" >Programas Sociais</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=seguimento_atuacao&pagina2=listar_seguimento_atuacao&tela=30')" >Segmento de Atuação</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=aba_cadastro&pagina2=conteudo&tela=30')" >Sinônimos do CBO</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=softwere&pagina2=listar_softwere&tela=30')" >Softwares</a></li>
			<!--<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=aba_cadastro&pagina2=conteudo')" >Status para Alunos</a></li>
				<li><a href="#" onClick="SelecionaMenu('layout_duplo.php?pagina1=aba_cadastro&pagina2=conteudo')" >Valores Referência</a></li>-->
				
			</ul>
		</li>
		<!-- we will keep this LI open by default -->
		<li >
			<h3><span ><img src='img/icone/table_refresh.png'></span>Vagas</h3>
			<ul>
				<li><a href="#" onClick="SelecionaMenu('lista_vaga.php')" >Cadastro</a></li>
				<li><a  onClick="SelecionaMenu('lista_empresa.php')" >Empresas / Grupos Produtivos</a></li>
				
			</ul>
		</li>
		<li class="active">
			<h3><span ><img src='img/icone/user_suit.gif'></span>Trabalhadores</h3>
			<ul>
				<li><a href="#"  onClick="SelecionaMenu('cadastro.php')">Cadastro</a></li>				
				<li><a href="#" onClick="SelecionaMenu('busca_trabalhador_cbo.php')">Buscar Trabalhador CBO</a></li>				
			</ul>
		</li>
		<li>
			<h3><span ><img src='img/icone/folder_go.gif'></span>Cursos/Palestras Oferecidos</h3>
			<ul>
				<li><a href="conteudo.html">Cadastro</a></li>				
			</ul>
		</li>
		
		<li>
			<h3><span ><img src='img/icone/grid.png'></span>Estatísticas e Resultados</h3>
			<ul>
				<li><a href="conteudo.html">Resultados</a></li>				
			</ul>
		</li>
		
		<li>
			<h3><span ><img src='img/icone/delete.gif'></span>Desconectar</h3>
			<ul>
				<li><a href="#" Onclick="JavaScript:parent.location='sair.php'">Sair</a></li>				
			</ul>
		</li>
		
	</ul>
</div>
</div>


	</body>		
	</html>		
	