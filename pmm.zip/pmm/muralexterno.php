<?
ini_set('default_charset','UTF-8'); // Para o charset das páginas e	
error_reporting(1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<link rel="stylesheet" type="text/css" href="<?=$baseurl;?>/assets/reset.css" />
  <link rel="stylesheet" type="text/css" href="<?=$baseurl;?>/assets/styles.css" />

<style>
#conteudo_vagas{
    height:200px;
    overflow-y:auto;
}
</style>
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js" type="text/javascript"></script>  
    <script>
      $(document).ready(function() {
        
            $.ajax({
              type: "post",
              url: "minha_pagina_acesso_banco.php?limit=20",
              success: function(data) {
                  //manipula os dados
                  $("#content").append(data);
              },
              error: function() {
              }
            });
         
		
		
		 $(window).scroll(function() {
         if($(window).scrollTop() == $(document).height() - $(window).height()) {
            //console.log("fim");
			
			var limit = $('#limit').val();
			
			
			 limit = parseInt(limit) +20;	
			$('#limit').val(limit);
			
			//alert(limit);
           // $("#content").append("");

            $.ajax({
              type: "post",
              url: "minha_pagina_acesso_banco.php?table=n&limit="+limit+",20",
              success: function(data) {
                  //manipula os dados
                  $("#content").append(data);
              },
              error: function() {
              }
            });
          }
        });
		
		
      });
    </script>
<input type="text" value="20" name="limit" id='limit' style="display:none;"/>

<table width="100%" style='background-color:#fff;'>
			<tr >
				<td><img src='../img/LogoSecretaria.png' width='200px'></td>
				<td>DIVULGAÇÃO DE VAGAS<br>
				
				</td>

				
 
			</tr>
						
			
			
		</table>
		

		<table width="100%"  style='background-color:#002db2;color:#fff;'> 		
			<tr width='200px'>
				<td><?echo date("d/m/Y");?></td>
				<td></td>
				
				<td align='right'></td>
			</tr>
			
		
		</table>
		

		
		

			<div id="content">
			</div >
				

			
	

</body>
</html>
