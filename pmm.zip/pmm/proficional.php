  

								<script type="text/javascript">
					var input = 2;
					function mais(campo) {

					//var valor = "input "+input+" - "+campo+" <input type='text' name='"+campo+"' value=''><br>";
					var nova = document.getElementById("aqui");
					var novadiv = document.createElement("div");
					var nomediv = "div";
								var form="<h4>EMPRESA "+input+"</h4>"+
			"<div class='form-row'>"+
			"<div class='label'>Ocupação</div>"+
			"<div class='input-container' style='width:546px;height:;'>	"+	
			"<input   name='cboid[]'  placeholder='Ocupação' id='cboidc"+input+"'  onchange='javascript:this.value=this.value.toUpperCase();' autocomplete='off' size='60' maxlength='200' value='' class='input req-same'  tabindex='20' type='text'/>"+
			//"<input type='image' src='img/busca.png' onClick=\"javascript:var id=document.getElementById('cboidc"+input+"').value;targetitem"+input+" = document.forms['cadastro'].elements['cboidc"+input+"']; dataitem = window.open('buscacbo.php?consulta='"+id+"'&getform="+input+"', 'dataitem', 'toolbar=no,menubar=no,scrollbars=yes,width=650,height=350'); dataitem.targetitem"+input+" = targetitem"+input+"\"/>"+
						
			"</div>"+
			"</div>"+
			
			"<div class='form-row'>"+
			"<div class='label'>Empresa</div>"+
			"<div class='input-container' style='width:546px;'>	"+	
			"<input   name='empresa[]' value='<?echo $empresa;?>' size='60' maxlength='160' class='input req-same'id='empresa' tabindex='22' type='text'/> "+
			
			"</div>"+
			"</div>"+
			
			"<div class='form-row'>"+
			"<div class='label'>cargo</div>"+
			"<div class='input-container' style='width:546px;'>"+		
			"<input   name='cargo[]' size='60' maxlength='160' class='input req-same' id='cargo' value='<?echo $cargo;?>' tabindex='23'type='text'/>"+
			
			"</div>"+
			"</div>"+
			
			
			"<div class='form-row'>"+
			"<div class='label'></div>"+
			"<div class='input-container' style='width:546px;'>"+
			
			"	Carteira Assinada?"+
			"<select name='carteiraassinada[]' id='carteiraassinada'  style='width:72px;'>"+
				"<option value='<?=$carteiraassinada;?>' selected=''><?=$carteiraassinada;?></option>"+
				"<option value='N' >Não</option>"+
				"<option value='S'>Sim</option>"+
			"</select>"+
			"&nbsp;"+
			"Ainda Ativo?"+
			"<select name='ativo[]' id='ativo'   style='width:72px;'>"+
				"<option value='<?=$ativo;?>' selected=''><?=$ativo;?></option>"+
				"<option value='N' >Não</option>"+
				"<option value='S'>Sim</option>"+
			"</select>"+
			
			"</div>"+
			
			"</div>"+
			
			
			"<div class='form-row'>"+
			"<div class='label'></div>"+
			"<div class='input-container' style='width:546px;'>	"+	
			"Período: Início"+
			"<input   name='datainicio[]' id='datainicio"+input+"' onkeypress=\"formatar_mascara(this, '##/##/####')\" readonly='true' value='<?echo $datainicio;?>' maxlength='10' class='input req-same' tabindex='26' style='width:133px;' type='text'/>"+
			"Final"+
			"<input   name='datafinal[]' id='datafinal"+input+"' value='<?echo $datafinal;?>' readonly='true' onkeypress=\"formatar_mascara(this, '##/##/####')\"  maxlength='10' class='input req-same'  tabindex='27' style='width:133px;' type='text'/>"+
			
			"</div>"+
			"</div>"+
			
			
			"<div class='form-row'>"+
			"<div class='label'></div>"+
			"<div class='input-container' style='width:546px;'>"+
			"Caso NÃO saiba o período exato, informar:&nbsp;"+
			"Tempo: Ano(s)"+
			"<input   name='tempanos[]' value='<?echo $tempanos;?>' size='5' maxlength='2' class='input req-same' style='width:56px;' id='tempanos' tabindex='28' type='text'/>"+
			"Mês(es)"+
			"<input   name='tempomes[]' value='<?echo $tempomes;?>' size='5' maxlength='2' class='input req-same'  style='width:56px;' id='tempomes' tabindex='29' type='text'/>"+
		
			"</div>"+
			"</div>";
					novadiv.innerHTML = form;
					nova.appendChild(novadiv);

					input++;
					}
					</script>
				
	<div id="historico" class="form"  onload='Ajax();'>
	<h2>HISTÓRICO PROFISSIONAL</h2>
	<div style="font-size:14px;color:red;">
	<b>&#9755; ATENÇÃO:</B> Seu histórico profissional só sera visualizado após conclusão do cadastro!
	</div></br></br>
	
	
					
											<div class="form-row"   >
												<div class="label"></div>
												<div class="input-container" style='width:546px;'  >		

												
													<script>
													
														
														
															
													
													</script>
													--> Possui Experiência PROFISSIONAL?<font class='simbolo'><font class='simbolo'>&#10045;</font></font>
													<select name="cadbf"  onChange="experiencia()" requered id="cadbf" style="width:88px;" tabindex="15">
														
														<?
																switch ($cadbf){										
																case "N":											
																$cadbf_N = "Não";
																break;case "S":											
																$cadbf_N = "Sim";
																break;
																}
															if($cadbf=="")	{}else{
														?>
														<option value="<?=$cadbf;?>"><?=$cadbf_N;?></option>
														<?}?>
														<option value='N' >Não</option>
														<option value='S' >Sim</option>
													</select>
													
												</div>
											</div >
											
<div border='0'width='100%' id="aqui"  >
<!---------------------------------------------------------empresa 1------------------------------------------------->
			<input type='hidden' name='cboid[]' value='nao'/>
			<input type='hidden' name='empresa[]'value='nao' />
			<input type='hidden' name='cargo[]'value='nao' />
			<input type='hidden' name='carteiraassinada[]' value='nao'/>
			<input type='hidden' name='ativo[]' value='nao'/>
			<input type='hidden' name='datainicio[]' value='nao'/>
			<input type='hidden' name='datafinal[]'value='nao' />
			<input type='hidden' name='tempanos[]'value='nao'/>
			<input type='hidden' name='tempomes[]'value='nao' />
			
			
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name='id' type='hidden' value='<?=$id;?>'/>
			<h4>EMPRESA</h4>
			<div class="form-row">
			<div class="label">Ocupação <font class='simbolo'><font class='simbolo'>&#10045;</font></div>
			<div class="input-container" style='width:546px;height:;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();"  onChange="javascript:this.value=this.value.toUpperCase();" name="cboid[]"  placeholder="Ocupação" id="cboid" size="60" maxlength="200" value="<?echo $cboid;?>" class="input req-same"  tabindex="20" type="text"/>			
			
			<!--<input type="image" src="img/busca.png" onClick="javascript:var id=document.getElementById('cboid').value;targetitem0 = document.forms['cadastro'].elements['cboid']; dataitem = window.open('buscacbo.php?consulta='+id+'&getform=0', 'dataitem', 'toolbar=no,menubar=no,scrollbars=yes,width=650,height=350'); dataitem.targetitem0 = targetitem0"/>-->
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Empresa <font class='simbolo'><font class='simbolo'>&#10045;</font></div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();"   onChange="javascript:this.value=this.value.toUpperCase();" name="empresa[]" value="<?echo $empresa;?>" size="60" maxlength="160" class="input req-same"id="empresa" tabindex="22" type="text"/> 
			
			</div>
			</div>
			
			<div class="form-row">
			<div class="label">Cargo <font class='simbolo'><font class='simbolo'>&#10045;</font></div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="cargo[]" size="60" maxlength="160" class="input req-same" id="cargo" value="<?echo $cargo;?>" tabindex="23"type="text"/>
			
			</div>
			</div>
			
			
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			
				Carteira Assinada? <font class='simbolo'><font class='simbolo'>&#10045;</font>
			<select name="carteiraassinada[]" id="carteiraassinada"  style="width:72px;">
				<option value="<?=$carteiraassinada;?>" selected=""><?=$carteiraassinada;?></option>
				<option value='N' >Não</option>
				<option value='S'>Sim</option>
			</select>
			&nbsp;
			Ainda Ativo? <font class='simbolo'><font class='simbolo'>&#10045;</font>
			<select name="ativo[]" id="ativo"   style="width:72px;">
				<option value="<?=$ativo;?>" selected=""><?=$ativo;?></option>
				<option value='N' >Não</option>
				<option value='S'>Sim</option>
			</select>
			
			</div>
			
			</div>
			
			
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			Período: Início
			<input onChange="javascript:this.value=this.value.toUpperCase();" name="datainicio[]" readonly='true'id="datainicio" value="<?echo $datainicio;?>" maxlength="10" class="input req-same" onkeypress="formatar_mascara(this, '##/##/####')" tabindex="26" style="width:133px;" type="text"/>
			Final
			<input onChange="javascript:this.value=this.value.toUpperCase();"  name="datafinal[]" readonly='true'id="datafinal" value="<?echo $datafinal;?>" maxlength="10" class="input req-same" onkeypress="formatar_mascara(this, '##/##/####')"  tabindex="27" style="width:133px;" type="text"/>
			
			</div>
			</div>
			
			
			<div class="form-row">
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			Caso NÃO saiba o período exato, informar:&nbsp;
			Tempo: Ano(s)
			<input onChange="javascript:this.value=this.value.toUpperCase();"  name="tempanos[]"  value="<?echo $tempanos	;?>" size="5" maxlength="2" class="input req-same" style="width:56px;" id="tempanos	" tabindex="28" type="text"/>
			Mês(es)
			<input onChange="javascript:this.value=this.value.toUpperCase();"  name="tempomes[]"  value="<?echo $tempomes;?>" size="5" maxlength="2" class="input req-same"  style="width:56px;" id="tempomes" tabindex="29" type="text"/>
		
			</div>
			</div>
	</div>
			
			<div class="form-row" style='padding-bottom:30px;'>
			<div class="label"><font style='color:red;font-size:13px;'>  </font></div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="maisimput"id="maisimput" type="button" class="sendBtn" onClick="mais('cidade');" value="&#10010; Incluir Histórico"/>
			
			<div id="errorDiv2" class="error-div"></div>
			</div>
			</div>
			
			<div id='mdg_historico' name='mdg_historico'></div>
					
		<script type="text/javascript">
																			$("#maisimput").click(function() {																	
																			
																			$("#cboidc2").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});
																			
																			$("#cboidc3").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});
																			
																			$("#cboidc4").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});
																			
																			$("#cboidc5").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});
																			$("#cboidc6").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});
																			$("#cboidc7").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});$("#cboidc8").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});$("#cboidc9").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});$("#cboidc10").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});$("#cboidc11").autocomplete("789/autoComplete.php", {
																			width: 546,
																			matchContains: true,
																			mustMatch: true,																			
																			highlight: false,																			
																			selectFirst: false
																			});
																			
																			
																			
																			
																			});
																			</script>

								<script type="text/javascript">		
										$(function() {
										
										
										$("#datainicio").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datafinal").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
									});	
										
										$("#maisimput").click(function() {
										
										$("#datainicio2").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datafinal2").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datainicio3").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datafinal3").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datainicio4").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datafinal4").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datainicio5").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datafinal5").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datainicio6").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datafinal6").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datainicio7").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datafinal7").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datainicio8").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datafinal8").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datainicio9").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
										
										$("#datafinal9").datepicker({
										changeMonth: true,
										changeYear: true,
										yearRange: '1970:<?=$anofinaldata;?>',
										dateFormat: 'dd/mm/yy',
										dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
										dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
										dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
										monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
										monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
										});
								});

								</script>

		<!---------------------------------------fim------------------------------------------------------>
			

		<div class="form-row" style='padding-bottom:30px;'>
		
		<h2> HISTÓRICO PROFISSIONAL CADASTRADOS</h2>
			

		
		<table >
			<tr>
						<td class="td1" width="215px"> Ocupação </td>
						<td class="td1" width="174px"> Empresa </td>
						<td class="td1" width="158px"> Período / Tempo (AA/MM) </td>
						<td class="td1" width="176px"> cargo </td>
						<td class="td1" width="55px"> CTPS Assinada? </td>
						<td class="td1" width="55px">  Ativo? </td> 
						<td class="td1" width="55px"> Ver </td> 
			</tr>

		</table>
		
				

	<script type="text/javascript">

					carrega_historico_proficional();
					function carrega_historico_proficional(){
						
						
					var xmlHttp;
					try{    
					xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					catch (e){
					alert("No AJAX!?");
					return false;
					}
					}
					}

					xmlHttp.onreadystatechange=function(){
					if(xmlHttp.readyState==4){
					document.getElementById('lista_historico_aqui').innerHTML=xmlHttp.responseText;
					setTimeout('carrega_historico_proficional()',10000000);
					}
					}
					xmlHttp.open("GET","historico.php?id=<?=$id;?>&nome=<?=$nome;?>&cpf=<?=$cpf_busca;?>",true); // aqui configuramos o arquivo
					xmlHttp.send(null);
					}

					

					</script>
				
				
			<table id="lista_historico_aqui" name='lista_historico_aqui' >
			
			</table>
			
			</div>
</div>

<!---------------------------------------------------------empresa 1------------------------------------------------->






