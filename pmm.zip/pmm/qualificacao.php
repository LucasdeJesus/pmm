
		
													<script type="text/javascript">
					var inputqualificacao = 2;
					function maiscamposqualificacao(campo) {
					
					var nova1 = document.getElementById("divescolaridade");
					var novadiv1 = document.createElement("div");
					var nomediv1 = "div";
					
				
					formqualificacao="<div id='divescolaridade1'  name='divescolaridade1 style='border-top:2px solid #cdcdcd'>"+
										"<div class='form-row'>"+
											"<div class='label'></div>"+
											"<div class='input-container' style='width:546px;'>"+	
												
												"<b>Escolaridade <font class='simbolo'>&#10045;</font> </b>"+		
												"<select name='escolaridade[]' required id='escolaridade' tabindex='1' style='width:213px' onchange='escolaridade(this.value);' >"+	
													"<option value='' >selecione</option>"+
													"<option value='N'>Analfabeto</option>"+
													"<option value='A'>Alfabetizado</option>"+
													"<option value='F'>Fundamental</option>"+
													"<option value='M'>Médio</option>"+
													"<option value='P'>Pós-Médio</option>"+
													"<option value='S'>Superior</option>"+
													"<option value='G'>Pós-Graduação</option>"+
													"<option value='E'>Mestrado</option>"+
													"<option value='D'>Doutorado</option>"+
												"</select>"+
												"<b>Situação <font class='simbolo'>&#10045;</font> </b>"+
												"<select name='situacao[]' id='situacao' required onchange='fun_escolaridade();EditandoRegistroEsc();' tabindex='2' style='width:133px'>"+
													
													"<option value='' >selecione</option>"+
													"<option value='C'>Completo</option>"+
													"<option value='I'>Incompleto</option>"+
													"<option value='U'>Cursando</option>"+
												"</select>"+
												
												
											"</div>"+
										"</div>"+
										
										"<div class='form-row'>"+
											"<div class='label'></div>"+
											"<div class='input-container' style='width:546px;'>	<b>Série </b>"+
									"<select name='serie[]' id='serie' tabindex='3' style='width:208px' onchange='EditandoRegistroEsc();'>"+

																"<option value='' >selecione</option>"+
																"<option value='1'>1º ANO</option>"+
																"<option value='2'>2º ANO</option>"+
																"<option value='3'>3º ANO</option>"+
																"<option value='4'>4º ANO</option>"+
																"<option value='5'>5º ANO</option>"+
																"<option value='6'>6º ANO</option>"+
																"<option value='7'>7º ANO</option>"+
																"<option value='8'>8º ANO</option>"+
																"<option value='9'>9º ANO</option>"+
																"<option value='C1'>CICLO I - ALFA</option>"+
																"<option value='C2'>CICLO II - 1ª E 2ª</option>"+
																"<option value='C3'>CICLO III - 3ª E 4ª</option>"+
																"<option value='C4'>CICLO IV - 5ª E 6ª</option>"+
																"<option value='C5'>CICLO V - 7ª E 8ª</option>"+
																"<option value='F'>ED. ESP. ENS. FUND.</option>"+
																"<option value='I'>ED. ESP. ENS. INF.</option>"+
																"<option value='J1'>EJA - ENS.MED - 1ª ANO</option>"+
																"<option value='J2'>EJA - ENS.MED - 2º ANO</option>"+
																"<option value='J3'>EJA - ENS.MED - 3º ANO</option>"+
																"<option value='M1'>ENS.MED - 1º ANO</option>"+
																"<option value='M2'>ENS.MED - 2º ANO</option>"+
																"<option value='M3'>ENS.MED - 3º ANO</option>"+
																"<option value='A1'>MATERNAL I</option>"+
																"<option value='A2'>MATERNAL II</option>"+
																"<option value='P1'>PRÉ I</option>"+
																"<option value='P2'>PRÉ II</option>"+
																
												"</select>"+
											"</div>"+
										"</div>"+									

										"<div class='form-row'>"+
											"<div class='label'></div>"+
										   "<div class='input-container' style='width:546px;'>"+	
												"<b>Turno</b>"+
												"<select name='turno[]' id='turno' tabindex='4' style='width:68px' onchange='EditandoRegistroEsc();'>"+
												
												   "<option value='' >selecione</option>"+
													"<option value='M'>Manhã</option>"+
													"<option value='T'>Tarde</option>"+	
													"<option value='N'>Noite</option>"+
												"</select>"+		   

												
												"<b>Curso</b>"+
												"<select name='formacaoacademicaid[]' id='formacaoacademicaid' tabindex='6' style='width:380px' onchange='EditandoRegistroEsc();'>"+		
												
													"<option value='' >selecione</option>"+													
													<?
													$query_formacaoacademica = 'SELECT * FROM `formacaoacademica` ORDER BY `formacaoacademica`.`nome` ASC';
													$rs_formacaoacademica    = mysql_query($query_formacaoacademica);
													while($campo_formacaoacademica = mysql_fetch_array($rs_formacaoacademica)){
													$nome_formacaoacademica 	= $campo_formacaoacademica['nome']; 	
													$id_formacaoacademica 	= $campo_formacaoacademica['id']; 	
													?>
													"<option value='<?=$id_formacaoacademica;?>'><?=$nome_formacaoacademica;?></option>"+
													<?}?>
													

												"</select>"+
												
											"</div>"+
										"</div>"+
										
										"<div class='form-row'>"+
										   " <div class='label'>Outro Curso</div>"+
										   " <div class='input-container' style='width:546px;'>"+		
												"<input  name='outrocurso[]' id='outrocurso' class='input req-same' maxlength='300' onchange='Maiuscula(this);EditandoRegistroEsc();' tabindex='7' style='width:453' type='text'>"+
													
											"</div>"+
										"</div>"+
										
										
										"<div class='form-row'>"+
										   " <div class='label'>Última Instituição</div>"+
											"<div class='input-container' style='width:546px;'>"+	
												"<input onChange='javascript:this.value=this.value.toUpperCase();' onChange='javascript:this.value=this.value.toUpperCase();' name='instituicao[]'  id='instituicao' class='input req-same' maxlength='300' onchange='Maiuscula(this);EditandoRegistroEsc();' tabindex='8' style='width:421' type='text'>"+
													
											"</div>"+
										"</div>"+
										
										
										"<div class='form-row'>"+
										   " <div class='label'>Tem Comprovação <font class='simbolo'>&#10045;</font>  </div>"+
										   " <div class='input-container' style='width:546px;'>"+	
												"<select name='comprovacao[]' id='comprovacao' required tabindex='9'  onchange='EditandoRegistroEsc();'>"+
												
														"<option value='' >selecione</option>"+
													"<option value='N' >Não</option>"+
													"<option value='S'>Sim</option>"+
												"</select>"+
													
											"</div>"+
										"</div>"+
									"</div>";
	
	
								
							novadiv1.innerHTML = formqualificacao;
							nova1.appendChild(novadiv1);
							inputqualificacao++;
					
					}
					</script>
		

			
		<input type='hidden' name='escolaridade[]' value='nao'/>
		<input type='hidden' name='situacao[]' value='nao'/>
		<input type='hidden' name='serie[]' value='nao'/>
		<input type='hidden' name='turno[]' value='nao'/>
		<input type='hidden' name='formacaoacademicaid[]' value='nao'/>
		<input type='hidden' name='outrocurso[]' value='nao'/>
		<input type='hidden' name='instituicao[]' value='nao'/>
		<input type='hidden' name='comprovacao[]' value='nao'/>
	<h2>FORMAÇÃO</h2>
	
	<p style="font-size:14px;color:red;">
	<b>&#9755; ATENÇÃO:</B> Sua formação profissional só sera visualizado após conclusão do cadastro!
	</p>
	
	</br></br>
	
	<div id='divescolaridade'  name='divescolaridade'>	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			
			<b>Escolaridade <font class='simbolo'>&#10045;</font> </b>			
			<select name="escolaridade[]" <?if($id < 1){echo"required";}?> id="escolaridade" tabindex="1" style="width:213px" onchange="escolaridade(this.value);" >			
				<option value="" >selecione</option>
				<option value="N">Analfabeto</option>
				<option value="A">Alfabetizado</option>
				<option value="F">Fundamental</option>
				<option value="M">Médio</option>
				<option value="P">Pós-Médio</option>
				<option value="S">Superior</option>
				<option value="G">Pós-Graduação</option>
				<option value="E">Mestrado</option>	
				<option value="D">Doutorado</option>
			</select>
			<b>Situação <font class='simbolo'>&#10045;</font> </b>
			<select name="situacao[]" id="situacao"  <?if($id < 1){echo"required";}?> onchange="fun_escolaridade();EditandoRegistroEsc();" tabindex="2" style="width:133px">
				
				<option value="" >selecione</option>
				<option value="C">Completo</option>
				<option value="I">Incompleto</option>	
				<option value="U">Cursando</option>	
			</select>
			
			
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>	<b>Série </b>	
<select name="serie[]" id="serie" tabindex="3" style="width:208px" onchange="EditandoRegistroEsc();">

			<option value="" >selecione</option>
							<option value="1">1º ANO</option>
							<option value="2">2º ANO</option>
							<option value="3">3º ANO</option>
							<option value="4">4º ANO</option>
							<option value="5">5º ANO</option>
							<option value="6">6º ANO</option>
							<option value="7">7º ANO</option>
							<option value="8">8º ANO</option>
							<option value="9">9º ANO</option>
							<option value="C1">CICLO I - ALFA</option>
							<option value="C2">CICLO II - 1ª E 2ª</option>
							<option value="C3">CICLO III - 3ª E 4ª</option>
							<option value="C4">CICLO IV - 5ª E 6ª</option>
							<option value="C5">CICLO V - 7ª E 8ª</option>
							<option value="F">ED. ESP. ENS. FUND.</option>
							<option value="I">ED. ESP. ENS. INF.</option>
							<option value="J1">EJA - ENS.MED - 1ª ANO</option>
							<option value="J2">EJA - ENS.MED - 2º ANO</option>
							<option value="J3">EJA - ENS.MED - 3º ANO</option>
							<option value="M1">ENS.MED - 1º ANO</option>
							<option value="M2">ENS.MED - 2º ANO</option>
							<option value="M3">ENS.MED - 3º ANO</option>
							<option value="A1">MATERNAL I</option>
							<option value="A2">MATERNAL II</option>
							<option value="P1">PRÉ I</option>
							<option value="P2">PRÉ II</option>
								
			</select>
		</div>
	</div>
	
	

	<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
			<b>Turno</b>
			<select name="turno[]" id="turno" tabindex="4" style="width:68px" onchange="EditandoRegistroEsc();">
			
			   <option value="" >selecione</option>
				<option value="M">Manhã</option>
				<option value="T">Tarde</option>	
				<option value="N">Noite</option>	
			</select>				   
<!--
			<b>Pós Graduação </b>
-->
			
			
			<b>Curso</b>
			<select name="formacaoacademicaid[]" id="formacaoacademicaid" tabindex="6" style="width:380px" onchange="EditandoRegistroEsc();">		
			
				<option value="" >selecione</option>
				
				<?
				$query_formacaoacademica = "SELECT * FROM `formacaoacademica` ORDER BY `formacaoacademica`.`nome` ASC";
				$rs_formacaoacademica    = mysql_query($query_formacaoacademica);
				while($campo_formacaoacademica = mysql_fetch_array($rs_formacaoacademica)){
				$nome_formacaoacademica 	= $campo_formacaoacademica['nome']; 	
				$id_formacaoacademica 	= $campo_formacaoacademica['id']; 	
				?>
				<option value="<?=$id_formacaoacademica;?>"><?=$nome_formacaoacademica;?></option>
				<?}?>

			</select>
			
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Outro Curso</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="outrocurso[]" id="outrocurso"  class="input req-same"maxlength="300" onchange="Maiuscula(this);EditandoRegistroEsc();" tabindex="7" style="width:453" type="text">
				
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Última Instituição</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="instituicao[]"  id="instituicao" class="input req-same" maxlength="300" onchange="Maiuscula(this);EditandoRegistroEsc();" tabindex="8" style="width:421" type="text">
				
		</div>
	</div>
	
	
	<div class="form-row">
	    <div class="label">Tem Comprovação <font class='simbolo'>&#10045;</font>  </div>
	    <div class="input-container" style='width:546px;'>		
			<select name="comprovacao[]" <?if($id < 1){echo"required";}?> id="comprovacao"  tabindex="9"  onchange="EditandoRegistroEsc();">
			
					<option value="" >selecione</option>
				<option value='N' >Não</option>
				<option value='S'>Sim</option>
			</select>
				
		</div>
	</div>
</div>
	
	
	
	<div class="form-row" style='padding-bottom:30px;'>
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			<input  type="button" class="sendBtn" onClick="maiscamposqualificacao('cidade3');" value="&#10010; Incluir Escolaridade "/>			
			</div>
	</div>

	
	
		<script type="text/javascript">

				carrega_escolaridade();
					function carrega_escolaridade(){
					
					var xmlHttp;
					try{    
					xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					catch (e){
					alert("No AJAX!?");
					return false;
					}
					}
					}

					xmlHttp.onreadystatechange=function(){
					if(xmlHttp.readyState==4){
					document.getElementById('escolaridadeajax').innerHTML=xmlHttp.responseText;
					setTimeout('carrega_escolaridade()',10000000);
					}
					}
					xmlHttp.open("GET","escolaridade_trabalhado.php?id=<?=$id;?>&nome=<?=$nome;?>&cpf=<?=$cpf;?>",true); // aqui configuramos o arquivo
					xmlHttp.send(null);
					}

				
					</script>

					
					
		<table >
			<tr>
				<td class='td1' width='205px'>Escolaridade </td>
				<td class='td1' width='221px'> Série </td>
				<td class='td1' width='83px'> Situação   </td>
				<td class='td1' width='83px'> Comprovação   </td>
						
			</tr>

		</table>
		
			<table id="escolaridadeajax" name='escolaridadeajax' >
			
			</table>

<!------------------softwere------------->
<div class="form-row">
																		<h2>INFORMÁTICA</h2>

																		<div class="label">1 - Programa</div>
																		<div class="input-container" style='width:546px;'>		
																						<select name="softwareid1" id="softwareid1" onchange="EditandoRegistro1()" tabindex="3" style="width:465px;">
																					
																					<?
																					$query_software1 = "SELECT * FROM `software`where id='$softwareid1'";
																					$rs_software1    = mysql_query($query_software1);
																					while($campo_software1 = mysql_fetch_array($rs_software1)){																						
																					$nome_soft1 	= $campo_software1['nome']; 	
																					}
																					?>																						
																					<option value="<?=$softwareid1;?>"  ><?=$nome_soft1;?></option>
																					
																					
																						<?
																					$query_noticias_hcs = "SELECT * FROM `software`ORDER BY `software`.`nome` ASC";
																					$rs_noticias_hcs    = mysql_query($query_noticias_hcs);
																					while($campo_noticias_hcs = mysql_fetch_array($rs_noticias_hcs)){
																					$id_soft 	= $campo_noticias_hcs['id']; 	
																					$soft 	= $campo_noticias_hcs['nome']; 	
																					?>
																						<option value="<?=$id_soft;?>"><?=$soft;?></option>
																					<?}?>

																						</select>
																				
																		</div>
																	</div>

																<div class="form-row">	
																		
																		<div class="label">2 - Programa</div>
																		<div class="input-container" style='width:546px;'>		
																						<select name="softwareid2" id="softwareid2" onchange="EditandoRegistro1()" tabindex="3" style="width:465px;">
																					
																					<?
																					$query_software2 = "SELECT * FROM `software`where id='$softwareid2'";
																					$rs_software2    = mysql_query($query_software2);
																					while($campo_software2 = mysql_fetch_array($rs_software2)){																						
																					$nome_soft2 	= $campo_software2['nome']; 	
																					}
																					?>	
																					
																					<option value="<?=$softwareid2;?>"  ><?=$nome_soft2;?></option>
																						<?
																					$query_noticias_hcs2 = "SELECT * FROM `software`ORDER BY `software`.`nome` ASC";
																					$rs_noticias_hcs2    = mysql_query($query_noticias_hcs2);
																					while($campo_noticias_hcs2 = mysql_fetch_array($rs_noticias_hcs2)){
																					$id_soft2 	= $campo_noticias_hcs2['id']; 	
																					$soft2 	= $campo_noticias_hcs2['nome']; 	
																					?>
																						<option value="<?=$id_soft2;?>"><?=$soft2;?></option>
																					<?}?>

																						</select>
																				
																		</div>
																		
																</div>	
																<div class="form-row">	
																		<div class="label">3 - Programa</div>
																		<div class="input-container" style='width:546px;'>		
																						<select name="softwareid3" id="softwareid3" onchange="EditandoRegistro1()" tabindex="3" style="width:465px;">
																					
																					<?
																					$query_software3 = "SELECT * FROM `software`where id='$softwareid3'";
																					$rs_software3    = mysql_query($query_software3);
																					while($campo_software3 = mysql_fetch_array($rs_software3)){																						
																					$nome_soft3 	= $campo_software3['nome']; 	
																					}
																					?>	
																					
																					
																					<option value="<?=$softwareid3;?>"  ><?=$nome_soft3;?></option>
																						<?
																					$query_noticias_hcs3 = "SELECT * FROM `software`ORDER BY `software`.`nome` ASC";
																					$rs_noticias_hcs3    = mysql_query($query_noticias_hcs3);
																					while($campo_noticias_hcs3 = mysql_fetch_array($rs_noticias_hcs3)){
																					$id_soft3 	= $campo_noticias_hcs3['id']; 	
																					$soft3 	= $campo_noticias_hcs3['nome']; 	
																					?>
																						<option value="<?=$id_soft3;?>"><?=$soft3;?></option>
																					<?}?>

																						</select>
																				
																		</div>
																</div>		
																		
																		
																		
	
<!------------------softwere------------->	
		
		<!------------------idiaoma------------->	
		
		
																		<div class="form-row">
																		<h2>IDIOMAS</h2>

																	   
																		<div class="input-container" style='width:546px;margin-left:79px;' >		
																			
																			<table align='left'>
																				
																				<tr>
																					<td align='left'>Idioma</td>
																					<td align='left'>Leitura</td>
																					<td align='left'>Escrita</td>
																					<td align='left'>Conversação</td>
																				</tr>
																				
																				<tr>
																					<td>
																						<select name='idiomaid1' style='width:150px;'>
																						
																						<?
																					$query_idiomaid1 = "SELECT * FROM `idioma` where id='$idiomaid1'";
																					$rs_idiomaid1    = mysql_query($query_idiomaid1);
																					while($campo_idiomaid1 = mysql_fetch_array($rs_idiomaid1)){																						
																					$nome_idiomaid1 	= $campo_idiomaid1['nome']; 	
																					}
																					?>	
																					
																						<option value="<?=$idiomaid1;?>"  ><?=$nome_idiomaid1;?></option>
																							<?
																						$query_noticias_hcs3i = "SELECT * FROM `idioma` ORDER BY `idioma`.`nome` ASC";
																						$rs_noticias_hcs3i    = mysql_query($query_noticias_hcs3i);
																						while($campo_noticias_hcs3i = mysql_fetch_array($rs_noticias_hcs3i)){
																						$idiomaid11 	= $campo_noticias_hcs3i['id']; 	
																						$nome_idioma1 	= $campo_noticias_hcs3i['nome']; 	
																						?>
																							<option value="<?=$idiomaid11;?>"><?=$nome_idioma1;?></option>
																						<?}?>
																					
																						</select>
																					</td>
																					
																					<?
																					switch ($leitura1){										
																					case "B":											
																					$leitura1_N = "Básica";
																					break;case "I":											
																					$leitura1_N = "Intermediária";
																					break;case "A":											
																					$leitura1_N = "Avançada";
																					break;case "F":											
																					$leitura1_N = "Fluente";
																					break;
																					}
																					
																					switch ($escrita1){										
																					case "B":											
																					$escrita1_N = "Básica";
																					break;case "I":											
																					$escrita1_N = "Intermediária";
																					break;case "A":											
																					$escrita1_N = "Avançada";
																					break;case "F":											
																					$escrita1_N = "Fluente";
																					break;
																					}
																					
																					switch ($conversacao1){										
																					case "B":											
																					$conversacao1_N = "Básica";
																					break;case "I":											
																					$conversacao1_N = "Intermediária";
																					break;case "A":											
																					$conversacao1_N = "Avançada";
																					break;case "F":											
																					$conversacao1_N = "Fluente";
																					break;
																					}
																					
																					
																					?>
																					<td><select style='width:150px;' name='leitura1'><?if($leitura1!="" ){?><option value='<?=$leitura1;?>'><?=$leitura1_N;?></option> <?}else{echo"<option value=''>--</option>";}?><option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
																					<td><select style='width:150px;' name='escrita1'><?if($escrita1!=""){?><option value='<?=$escrita1;?>'><?=$escrita1_N;?></option><?}else{echo"<option value=''>--</option>";}?> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
																					<td><select style='width:150px;' name='conversacao1'><?if($conversacao1!=""){?><option value='<?=$conversacao1;?>'><?=$conversacao1_N;?></option> <?}else{echo"<option value=''>--</option>";}?><option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
																				</tr>
																				
																				
																				<tr>
																					<td>
																						<select name='idiomaid2' style='width:150px;'>
																						<?
																					$query_idiomaid2 = "SELECT * FROM `idioma`where id='$idiomaid2'";
																					$rs_idiomaid2    = mysql_query($query_idiomaid2);
																					while($campo_idiomaid2d = mysql_fetch_array($rs_idiomaid2)){																						
																					$nome_idiomaid2 	= $campo_idiomaid2d['nome']; 	
																					}
																					?>	
																					
																						<option value="<?=$idiomaid2;?>"  ><?=$nome_idiomaid2;?></option>
																							<?
																						$query_noticias_hcs3i2 = "SELECT * FROM `idioma` ORDER BY `idioma`.`nome` ASC";
																						$rs_noticias_hcs3i2    = mysql_query($query_noticias_hcs3i2);
																						while($campo_idiomaid2 = mysql_fetch_array($rs_noticias_hcs3i2)){
																						$idiomaid22 	= $campo_idiomaid2['id']; 
																						$nome_idioma2 	= $campo_idiomaid2['nome']; 																						
																						?>
																							<option value="<?=$idiomaid22;?>"><?=$nome_idioma2;?></option>
																						<?}?>
																					
																						</select>
																					</td>
																					
																					<?
																					switch ($leitura2){										
																					case "B":											
																					$leitura2_N = "Básica";
																					break;case "I":											
																					$leitura2_N = "Intermediária";
																					break;case "A":											
																					$leitura2_N = "Avançada";
																					break;case "F":											
																					$leitura2_N = "Fluente";
																					break;
																					}
																					
																					switch ($escrita2){										
																					case "B":											
																					$escrita2_N = "Básica";
																					break;case "I":											
																					$escrita2_N = "Intermediária";
																					break;case "A":											
																					$escrita2_N = "Avançada";
																					break;case "F":											
																					$escrita2_N = "Fluente";
																					break;
																					}
																					
																					switch ($conversacao2){										
																					case "B":											
																					$conversacao2_N = "Básica";
																					break;case "I":											
																					$conversacao2_N = "Intermediária";
																					break;case "A":											
																					$conversacao2_N = "Avançada";
																					break;case "F":											
																					$conversacao2_N = "Fluente";
																					break;
																					}
																					
																					
																					?>
																					<td><select style='width:150px;' name='leitura2'><?if($leitura2!=""){?><option value='<?=$leitura2;?>'><?=$leitura2_N;?></option> <?}else{echo"<option value=''>--</option>";}?><option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
																					<td><select style='width:150px;' name='escrita2'><?if($escrita2!=""){?><option value='<?=$escrita2;?>'><?=$escrita2_N;?></option><?}else{echo"<option value=''>--</option>";}?> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
																					<td><select style='width:150px;' name='conversacao2'><?if($conversacao2!=""){?><option value='<?=$conversacao2;?>'><?=$conversacao2_N;?></option> <?}else{echo"<option value=''>--</option>";}?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
																				</tr>
																				
																				<tr>
																					<td>
																						<select name='idiomaid3' style='width:150px;'>
																						
																						<?
																					$query_idiomaid3 = "SELECT * FROM `idioma`where id='$idiomaid3'";
																					$rs_idiomaid3    = mysql_query($query_idiomaid3);
																					while($campo_idiomaid3 = mysql_fetch_array($rs_idiomaid3)){																						
																					$nome_idiomaid3 	= $campo_idiomaid3['nome']; 	
																					}
																					?>	
																					
																						<option value="<?=$idiomaid3;?>"  ><?=$nome_idiomaid3;?></option>
																							<?
																						$query_noticias_hcs3i23 = "SELECT * FROM `idioma` ORDER BY `idioma`.`nome` ASC";
																						$rs_noticias_hcs3i23    = mysql_query($query_noticias_hcs3i23);
																						while($campo_noticias_hcs3i2 = mysql_fetch_array($rs_noticias_hcs3i23)){
																						$idiomaid123 	= $campo_noticias_hcs3i2['id']; 
																						$nome_idioma3 	= $campo_noticias_hcs3i2['nome'];
																						
																						?>
																							<option value="<?=$idiomaid123;?>"><?=$nome_idioma3;?></option>
																						<?}?>
																					
																						</select>
																					</td>
																					
																					<?
																					switch ($leitura3){										
																					case "B":											
																					$leitura3_N = "Básica";
																					break;case "I":											
																					$leitura3_N = "Intermediária";
																					break;case "A":											
																					$leitura3_N = "Avançada";
																					break;case "F":											
																					$leitura3_N = "Fluente";
																					break;
																					}
																					
																					switch ($escrita3){										
																					case "B":											
																					$escrita3_N = "Básica";
																					break;case "I":											
																					$escrita3_N = "Intermediária";
																					break;case "A":											
																					$escrita3_N = "Avançada";
																					break;case "F":											
																					$escrita3_N = "Fluente";
																					break;
																					}
																					
																					switch ($conversacao3){										
																					case "B":											
																					$conversacao3_N = "Básica";
																					break;case "I":											
																					$conversacao3_N = "Intermediária";
																					break;case "A":											
																					$conversacao3_N = "Avançada";
																					break;case "F":											
																					$conversacao3_N = "Fluente";
																					break;
																					}
																					
																					
																					?>
																					<td><select style='width:150px;' name='leitura3'><?if($leitura3!=""){?><option value='<?=$leitura3;?>'><?=$leitura3_N;?></option> <?}else{echo"<option value=''>--</option>";}?></option> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
																					<td><select style='width:150px;' name='escrita3'><?if($escrita3!=""){?><option value='<?=$escrita3;?>'><?=$escrita3_N;?></option><?}else{echo"<option value=''>--</option>";}?> <option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
																					<td><select style='width:150px;' name='conversacao3'><?if($conversacao3!=""){?><option value='<?=$conversacao3;?>'><?=$conversacao3_N;?></option> <?}else{echo"<option value=''>--</option>";}?><option value='B'>Básica</option><option value='I'>Intermediária</option><option value='A'>Avançada</option><option value='F'>Fluente</option></select></td>
																				</tr>
																				
																				
																				
																				
																			</table>
																				
																		</div>
																	</div>

	

	
	<!------------------idiaoma------------->	
	



<!---------------------------------------------------------------------------------------------------------->


										
										
													<script type="text/javascript">
					var input2 = 2;
					function maiscampos(campo) {

					//var valor = "input "+input+" - "+campo+" <input type='text' name='"+campo+"' value=''><br>";
					var nova1 = document.getElementById("formcurso");
					var novadiv1 = document.createElement("div");
					var nomediv1 = "div";
					
					
		formcursos="<div name='formcurso1' id='formcurso1'>"+
		"<div class='form-row' style='border:1px solid #cdcdcd'></div>"+
		"<div class='form-row'>"+
	    "<div class='label'></div>"+
	    "<div class='input-container' style='width:546px;'>"+	
						"Situação"+
			"<select name='situacaocurso[]' id='situacaocurso' style='width:151px'>"+
				"<option value='<?=$situacaocurso;?>'  ><?=$situacaocurso;?></option>"+
				"<option value='C' >Completo</option>"+
				"<option value='U'>Cursando</option>"+
				"<option value'I'>Incompleto</option>"+
			"</select>"+			
			"Segmento de Atuação"+

			"<select name='segmentoatuacaoid[]' id='segmentoatuacaoid'  style='width:153px;'>"+
				"<option value='<?=$segmentoatuacaoid;?>'  ><?=$segmentoatuacaoid;?></option>"+
				<?
					$query_noticias_hcsa = 'SELECT * FROM `segmentoatuacao` ORDER BY `segmentoatuacao`.`nome` ASC';
					$rs_noticias_hcsa    = mysql_query($query_noticias_hcsa);
					while($campo_noticias_hcsa = mysql_fetch_array($rs_noticias_hcsa)){
					$nomeseguimento 	= $campo_noticias_hcsa['nome']; 	
					$idseguimento 	= $campo_noticias_hcsa['id']; 	
					?>
						"<option value='<?=$idseguimento;?>'><?=$nomeseguimento;?></option>"+
					<?}?>
			"</select>"+
				
		"</div>"+
		"</div>"+
	"</div>"+
	
	
	"<div class='form-row'>"+
	    "<div class='label'>Cursos</div>"+
	    "<div class='input-container' style='width:546px;'>	"+	
			"<input onChange='javascript:this.value=this.value.toUpperCase();' onChange='javascript:this.value=this.value.toUpperCase();' name='curso[]' id='curso' value='<?=$curso;?>' maxlength='100' class='input req-same' onchange='Maiuscula(this);EditandoRegistro();'  style='width:480' type='text'>"+
				
		"</div>"+
	"</div>"+
	
	"<div class='form-row'>"+
	   " <div class='label'>Tem Comprovação?</div>"+
	    "<div class='input-container' style='width:546px;'>	"+	
			"<select name='comprovacaocurso[]' id='comprovacaocurso' style='width:78' onchange='EditandoRegistro();'>"+
				"<option value='<?=$comprovacaocurso;?>' ><?=$comprovacaocurso;?></option>"+
				"<option value='N' >Não</option>"+
				"<option value='S'>Sim</option>"+
			"</select>	"+
		"</div>"+
	"</div>";
	
	
								
					novadiv1.innerHTML = formcursos;
					nova1.appendChild(novadiv1);

					input2++;
					}
					</script>
										
									

		<input type='hidden' name='situacaocurso[]' value='nao'/>
		<input type='hidden' name='segmentoatuacaoid[]' value='nao'/>
		<input type='hidden' name='curso[]' value='nao'/>
		<input type='hidden' name='comprovacaocurso[]' value='nao'/>
<div class="form-row">
		<h2>CURSOS / PALESTRAS</h2>
		
		
		<p style="font-size:14px;color:red;">
	<b>&#9755; ATENÇÃO:</B> Cursos / Palestras só sera visualizado após conclusão do cadastro!
	</p>
	
	</br></br>
		<div name='formcurso' id='formcurso'>
		<div class="form-row">
	    <div class="label"></div>
	    <div class="input-container" style='width:546px;'>		
						Situação
			<select name="situacaocurso[]" id="situacaocurso" onchange="EditandoRegistro()" tabindex="14" style="width:151px">
				<option value="<?=$situacaocurso;?>"  ><?=$situacaocurso;?></option>
				<option value="C" >Completo</option>
				<option value="U">Cursando</option>
				<option value="I">Incompleto</option>
			</select>			
			Segmento de Atuação
<!--
			<select name="segmentoatuacaoid" id="segmentoatuacaoid" onchange="EditandoRegistro(); CarregaCursos('1');" tabindex="15" style="width:283px;">
-->
			<select name="segmentoatuacaoid[]" id="segmentoatuacaoid" onchange="EditandoRegistro();" tabindex="16" style="width:153px;">
				<option value="<?=$segmentoatuacaoid;?>"  ><?=$segmentoatuacaoid;?></option>
				<?
					$query_noticias_hcsa = "SELECT * FROM `segmentoatuacao` ORDER BY `segmentoatuacao`.`nome` ASC";
					$rs_noticias_hcsa    = mysql_query($query_noticias_hcsa);
					while($campo_noticias_hcsa = mysql_fetch_array($rs_noticias_hcsa)){
					$nomeseguimento 	= $campo_noticias_hcsa['nome']; 	
					$idseguimento 	= $campo_noticias_hcsa['id']; 	
					?>
						<option value="<?=$idseguimento;?>"><?=$nomeseguimento;?></option>
					<?}?>
			</select>
				
		</div>
		</div>
	
	
	
	<div class="form-row">
	    <div class="label">Cursos</div>
	    <div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="curso[]" id="curso" value="<?=$curso;?>" maxlength="100" class="input req-same" onchange="Maiuscula(this);EditandoRegistro();" tabindex="17" style="width:480" type="text">
				
		</div>
	</div>
	
	<div class="form-row">
	    <div class="label">Tem Comprovação?</div>
	    <div class="input-container" style='width:546px;'>		
			<select name="comprovacaocurso[]" id="comprovacaocurso" tabindex="19" style="width:78" onchange="EditandoRegistro();">
				<option value="<?=$comprovacaocurso;?>" ><?=$comprovacaocurso;?></option>
				<option value='N' >Não</option>
				<option value='S'>Sim</option>
			</select>	
		</div>
	</div>
	
	
</div>
	
	<div class="form-row" style='padding-bottom:30px;'>
			<div class="label"></div>
			<div class="input-container" style='width:546px;'>		
			<input onChange="javascript:this.value=this.value.toUpperCase();" onChange="javascript:this.value=this.value.toUpperCase();" name="" type="button" class="sendBtn" onClick="maiscampos('cidade3');" value="&#10010; Incluir Cursos/Palestras "/>
			<div id="errorDiv2" class="error-div"></div>
			</div>
			</div>
			
				<div id='enviaform_cursos_palestras' name='enviaform_cursos_palestras'></div>
				
</div>				
			
			
			
			
			
			
			
			
			
			
			
			
			<div style='padding-bottom:80px;'>
			
					<h2> CURSOS / PALESTRAS CADASTRADOS</h2>

			<table >
			<tr>
				<td class='td1' width='205px'>Segmento de Atuação  </td>
				<td class='td1' width='221px'> Curso </td>
				<td class='td1' width='83px'> Situação   </td>
				<td class='td1' width='83px'> AP. Comp.   </td>
						
			</tr>

		</table>
		
		
							<script type="text/javascript">

					carrega_proficional();
					function carrega_proficional(){
					
					var xmlHttp;
					try{    
					xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
					}
					catch (e){
					try{
					xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					catch (e){
					alert("No AJAX!?");
					return false;
					}
					}
					}

					xmlHttp.onreadystatechange=function(){
					if(xmlHttp.readyState==4){
					document.getElementById('cursos_palestra_lista').innerHTML=xmlHttp.responseText;
					setTimeout('carrega_proficional()',10000000);
					}
					}
					xmlHttp.open("GET","curso_palestras.php?id=<?=$id;?>&nome=<?=$nome;?>&cpf=<?=$cpf;?>",true); // aqui configuramos o arquivo
					xmlHttp.send(null);
					}

					

					</script>

					
			<table id="cursos_palestra_lista" name='cursos_palestra_lista' >
			
			</table>
			</div>
			
			




		

