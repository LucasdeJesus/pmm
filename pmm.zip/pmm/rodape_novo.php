<div style='width:100%;border-top:1px solid #fff; border-bottom:2px solid #157FCC;background-color: #3892D3;;margin-top:0px;height:38px;' align='center' >
		
		<table width='960px'>
				<tr>
					<td>
						<font style='color:#fff;font-size:15px;line-height:36px;'>Agência de Trabalho, Emprego, Educação Profissional e Renda (AGETRAB)</font><br>
						
					</td>
					<td align='rigth'>
						<a href='interno'style='color:#fff;font-size:15px;line-height:36px;'>Administrativo </a>
						
					</td>
				</tr>
			</table>
			
		</div>
	