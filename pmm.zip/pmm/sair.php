<?
//session_start();
session_unset();
//session_destroy();
?>
<html>

</head><body >
Saindo...
<SCRIPT language="JavaScript">window.location.href="index.php";</SCRIPT>
</body></html>

