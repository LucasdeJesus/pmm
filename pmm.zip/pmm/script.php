<?
error_reporting(E_ALL ^ E_NOTICE);
include'conexao.php';



$dataget= $_GET['dia'];
$pieces = explode("-", $dataget);
$pieces[0]; // ano
$pieces[1]; // mes
$pieces[2]; // dia

$diasoma = $pieces[1] + 1;

$data = $pieces[0]."-".$diasoma."-".$pieces[2];

//echo $data;


$vaga= $_GET['quatidadedia'];
$acao= $_GET['acao'];

//echo"esse e $dia e $quatidadedia";

	switch ($acao) {
			case cadastro:
			
			$query_noticias_total_emca = "SELECT * FROM `diaagendamento` where status='A' and data='$data'";	
			$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
			$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
			
			if($total_total_emca > 0)			
			{
			echo"Data $data já está Ativa";
				
			}else{

					$query="insert INTO `diaagendamento` ( `data`, `vaga`,`status`,`tipo`) VALUES  ('$data','$vaga','A','$tipoatendimento')";
					$rs= mysql_query($query);
					
				

							if ($rs) {

								echo"Data $data Ativa";

							} else {
									
								echo"Não foi possível cadastrar, tente novamente.";
											
							}
			}
			break;
			

			case excluir:			
				$query_noticias_total_emca = "DELETE FROM  diaagendamento where data='$data'";	
				$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 	

				if ($rs_noticias_total_emca) {

					echo"Data $data Desativada";

				} else {
						
					echo"Não foi possível Desativada, tente novamente.";
								
				}
							
			break;
			
			
			
			case agendar:
			
			
						$cpf_busca =$_GET['cpf_busca'];
						$nome = $_GET['nome'];
						$datanascimento = $_GET['datanascimento'];
						$telcel = $_GET['telcel'];
						$telres = $_GET['telres'];
						$horario = $_GET['horario'];
			
			$query_noticias_total_emca = "SELECT * FROM `agendamentoctps` where status='A' and cpf='$cpf_busca'";	
			$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
			$total_total_emca = mysql_num_rows($rs_noticias_total_emca);
			
			if($total_total_emca > 0)			
			{
			echo"0";
				
			}else{

					$query="insert INTO `agendamentoctps` ( `data`, `cpf`,`status`,`nome`,`datanascimento`,`telefone`,`celular`,`horario`) VALUES  ('$data','$cpf_busca','A','$nome','$datanascimento','$telres','$telcel','$horario')";
					$rs= mysql_query($query);
					
				

							if ($rs) {

								echo"2";

							} else {
									
								echo"1";
											
							}
			}
			break;
			
			
			case cancelaagendamento:
			
			$id= $_GET['id'];
			$query="update  agendamentoctps set status='C' where id='$id' ";
			$rs= mysql_query($query);
			
				if ($rs) {

						echo"2";

					} else {
							
						echo"1";
									
					}
			break;
		}

?>