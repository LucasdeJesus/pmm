		<?include("interno/input_banco.php");
error_reporting(0);


 
		$id_vaga= $_POST['id_vaga_e']; 	 
		$status_e= $_POST['estatus']; 	 
		$id_trabalhadore= $_POST['id_trabalhadore_e']; 	 
		$obs = $_POST['obs']; 	 
		
		$id_emcaminhamento= $_POST['id_emcaminhamento_e'];
		$cpf= $_POST['cpf3'];
		
		$acao= $_GET['acao']; 	 		 			 	
				 			 	
		
		$dia= date("d");
		$mes= date("m");
		$ano= date("Y");
		
		switch ($acao) {
			case cadastro:
			
				if($id_emcaminhamento =="")
				{
				
				
						$query="INSERT INTO `encaminhamento` ( `trabalhadorid`, `vagaid`, `observacao`, `status`, `usuarioid` ) VALUES ('$id_trabalhadore', '$id_vaga', '$obs', '$status_e', '$usuarioID');";
						$rs= mysql_query($query);					
						
				}
				else
				{

				
					
					/*$query="UPDATE `emcaminhamento` SET id_trabalhandor='$id_trabalhandor ', id_vaga='$id_vaga ', obs='$obs ', selStatus='$selStatus ', data=CURRENT_TIMESTAMP, id_usuario='$usuarioID ', dia='$dia ', mes='$mes ', ano='$ano' where id_emcaminhamento='$id_emcaminhamento'";
					$rs= mysql_query($query);	*/
				
				
					//echo"Alteração  Feita!";
				}					
					
					
			
			
			break;
			
			case excluir:
			
			$id_vaga= $_GET['id_vaga'];
			$nome= $_GET['nome'];
			?>
			
			
				<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
				
				decisao = confirm("Deseja realmente excluir vaga do ID:\n <?=$nome;?>?");				
				if (decisao){
				
				<?
				$query="DELETE FROM  vagas where id_vaga='$id_vaga'";
				$rs= mysql_query($query);	
				?>
				alert ("Vaga excluida com sucesso!");
				setTimeout("self.close();",2);
				
				} 
				else 
				
				{				
				alert ("Opreação cancelada,\n"			
				);
				setTimeout("self.close();",2);
				
				}
				
				</SCRIPT>
			<?
		
			break;
			
			
		
		}
	
		
		?>		