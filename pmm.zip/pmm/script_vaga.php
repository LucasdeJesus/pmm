﻿<?include("conf.php");

error_reporting(0);

		if($usuario_id > 0){}else{			
			?>
			
			<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Sessão expirou !")</SCRIPT>
			<SCRIPT language="JavaScript">window.location.href="index.php";</SCRIPT>
			
			
			<?	
			};
		
		
		$id= $_GET['id']; 	 
		$empresaid=(string)addslashes($_POST['empresaid']);
		$idcbo=(string)addslashes($_POST['cboid']);
		$descricao=(string)addslashes($_POST['descricao']);
		$cargo=(string)addslashes($_POST['cargo']);
		$horariotrabalho=(string)addslashes($_POST['horariotrabalho']);
		$quantidadedisponivel=(string)addslashes($_POST['quantidadedisponivel']);
		$quantidadeencaminhar=(string)addslashes($_POST['quantidadeencaminhar']);
		$datalimiteencaminhar_1=(string)addslashes($_POST['datalimiteencaminhar']);
		$datalimiteencaminhar = implode("-",array_reverse(explode("/",$datalimiteencaminhar_1)));

		$vagadeficiente=(string)addslashes($_POST['vagadeficiente']);

		$necEspAuditiva=(string)addslashes($_POST['necEspAuditiva']); 
		if(empty($necEspAuditiva)){$necEspAuditiva='N';};

		$necEspAuditivaTipo=(string)addslashes($_POST['necEspAuditivaTipo']);
		$necEspAuditivaUniBi=(string)addslashes($_POST['necEspAuditivaUniBi']);
		$necEspFala=(string)addslashes($_POST['necEspFala']);
		if(empty($necEspFala)){$necEspFala='N';};

		$necEspFalaTipo=(string)addslashes($_POST['necEspFalaTipo']);
		$necEspFisica=(string)addslashes($_POST['necEspFisica']);
		if(empty($necEspFisica)){$necEspFisica='N';};

		$necEspFisicaTipo=(string)addslashes($_POST['necEspFisicaTipo']);
		$necEspFisicaInfSup=(string)addslashes($_POST['necEspFisicaInfSup']);
		$necEspMental=(string)addslashes($_POST['necEspMental']);
		if(empty($necEspMental)){$necEspMental='N';};

		$necEspRecursosCom=(string)addslashes($_POST['necEspRecursosCom']);
		if(empty($necEspRecursosCom)){$necEspRecursosCom='N';};
		$necEspCuidadoPess=(string)addslashes($_POST['necEspCuidadoPess']);
		if(empty($necEspCuidadoPess)){$necEspCuidadoPess='N';};
		$necEspLazer=(string)addslashes($_POST['necEspLazer']);
		if(empty($necEspLazer)){$necEspLazer='N';};
		$necEspSaudeSeg=(string)addslashes($_POST['necEspSaudeSeg']);
		if(empty($necEspSaudeSeg)){$necEspSaudeSeg='N';};
		$necEspHabSocial=(string)addslashes($_POST['necEspHabSocial']);
		if(empty($necEspHabSocial)){$necEspHabSocial='N';};
		$necEspHabAcad=(string)addslashes($_POST['necEspHabAcad']);
		if(empty($necEspHabAcad)){$necEspHabAcad='N';};
		$necEspComunic=(string)addslashes($_POST['necEspComunic']);
		if(empty($necEspComunic)){$necEspComunic='N';};
		$necEspTrabalho=(string)addslashes($_POST['necEspTrabalho']);
		if(empty($necEspTrabalho)){$necEspTrabalho='N';};
		$necEspVisual=(string)addslashes($_POST['necEspVisual']);
		if(empty($necEspVisual)){$necEspVisual='N';};
		$necEspVisualTipo=(string)addslashes($_POST['necEspVisualTipo']);
		$necEspVisualUniBi=(string)addslashes($_POST['necEspVisualUniBi']);


		$codigocid=(string)addslashes($_POST['codigocid']);
		$ceplocal=(string)addslashes($_POST['ceplocal']);
		$cidadelocalid=(string)addslashes($_POST['cidadelocalid']);
		$bairrolocal=(string)addslashes($_POST['bairrolocal']);
		$enderecolocal=(string)addslashes($_POST['enderecolocal']);
		$proximodelocal=(string)addslashes($_POST['proximodelocal']);
		$local=(string)addslashes($_POST['local']);
		$onoffshore=(string)addslashes($_POST['onoffshore']);
		$salario_1=(string)addslashes($_POST['salario']);
		$salario = str_replace(",",".","$salario_1");

		$comissao=(string)addslashes($_POST['comissao']);
		$prospeccao=(string)addslashes($_POST['prospeccao']);
		$cartaoalimentacao=(string)addslashes($_POST['cartaoalimentacao']);
		if(empty($cartaoalimentacao)){$cartaoalimentacao='N';};
		$alimentacaolocal=(string)addslashes($_POST['alimentacaolocal']);
		if(empty($alimentacaolocal)){$alimentacaolocal='N';};
		$lanche=(string)addslashes($_POST['lanche']);
		if(empty($lanche)){$lanche='N';};
		$cestabasica=(string)addslashes($_POST['cestabasica']);
		if(empty($cestabasica)){$cestabasica='N';};
		$planosaude=(string)addslashes($_POST['planosaude']);
		if(empty($planosaude)){$planosaude='N';};
		$planoodonto=(string)addslashes($_POST['planoodonto']);
		if(empty($planoodonto)){$planoodonto='N';};
		$segurovida=(string)addslashes($_POST['segurovida']);
		if(empty($segurovida)){$segurovida='N';};
		$carteiraassinada=(string)addslashes($_POST['carteiraassinada']);
		if(empty($carteiraassinada)){$carteiraassinada='N';};
		$valetransporte=(string)addslashes($_POST['valetransporte']);
		if(empty($valetransporte)){$valetransporte='N';};
		$premiacao=(string)addslashes($_POST['premiacao']);
		if(empty($premiacao)){$premiacao='N';};
		$outrosbeneficios=(string)addslashes($_POST['outrosbeneficios']);
		$tempoano=(string)addslashes($_POST['tempoano']);
		if($tempoano==""){$tempoano="0";}else{}
		$tempomes=(string)addslashes($_POST['tempomes']);
		if($tempomes==""){$tempomes="0";}else{}
		$comprovada=(string)addslashes($_POST['comprovada']);
		if(empty($comprovada)){$comprovada='N';};
		$importanciatempo=(string)addslashes($_POST['importanciatempo']);
		$idademinima=(string)addslashes($_POST['idademinima']);
		$idademaxima=(string)addslashes($_POST['idademaxima']);
		$importanciaidade=(string)addslashes($_POST['importanciaidade']);
		$escolaridade=(string)addslashes($_POST['escolaridade']);
		$escolaridadesituacao=(string)addslashes($_POST['escolaridadesituacao']);
		$importanciaescolaridade=(string)addslashes($_POST['importanciaescolaridade']);
		$cnh=(string)addslashes($_POST['cnh']);
		$importanciacnh=(string)addslashes($_POST['importanciacnh']);
		$sexo=(string)addslashes($_POST['sexo']);
		$importanciasexo=(string)addslashes($_POST['importanciasexo']);
		$estadocivil=(string)addslashes($_POST['estadocivil']);
		$importanciaestadocivil=(string)addslashes($_POST['importanciaestadocivil']);
		$aceitasemexperiencia=(string)addslashes($_POST['aceitasemexperiencia']);
		if(empty($aceitasemexperiencia)){$aceitasemexperiencia='N';};
		$softwareid1=(string)addslashes($_POST['softwareid1']);
		if(empty($softwareid1)){$softwareid1='18';};
		$softwareid2=(string)addslashes($_POST['softwareid2']);
		if(empty($softwareid2)){$softwareid2='18';};
		$softwareid3=(string)addslashes($_POST['softwareid3']);
		if(empty($softwareid3)){$softwareid3='18';};


		$idiomaid1=(string)addslashes($_POST['idiomaid1']);
		if(empty($idiomaid1)){$idiomaid1='21';};
		$idiomaid2=(string)addslashes($_POST['idiomaid2']);
		if(empty($idiomaid2)){$idiomaid2='21';};
		$idiomaid3=(string)addslashes($_POST['idiomaid3']);
		if(empty($idiomaid3)){$idiomaid3='21';};


		$leitura1=(string)addslashes($_POST['leitura1']);
		$leitura2=(string)addslashes($_POST['leitura2']);
		$leitura3=(string)addslashes($_POST['leitura3']);
		$escrita1=(string)addslashes($_POST['escrita1']);
		$escrita2=(string)addslashes($_POST['escrita2']);
		$escrita3=(string)addslashes($_POST['escrita3']);
		$conversacao1=(string)addslashes($_POST['conversacao1']);
		$conversacao2=(string)addslashes($_POST['conversacao2']);
		$conversacao3=(string)addslashes($_POST['conversacao3']);
		$horarioatendimento=(string)addslashes($_POST['horarioatendimento']);
		$viaencaminhamento=(string)addslashes($_POST['viaencaminhamento']);
		$observacao=(string)addslashes($_POST['observacao']);
		$status="I";
		$formacaptacaoid=(string)addslashes($_POST['formacaptacaoid']);
		$localcaptacaoid=(string)addslashes($_POST['localcaptacaoid']);


		$cepentrevista=(string)addslashes($_POST['cepentrevista']);
		$estadoentrevista=(string)addslashes($_POST['estadoentrevista']);
		$cidadeentrevistaid=(string)addslashes($_POST['cidadeentrevistaid']);
		$bairroentrevista=(string)addslashes($_POST['bairroentrevista']);
		$enderecoentrevista=(string)addslashes($_POST['enderecoentrevista']);
		$proximode=(string)addslashes($_POST['proximode']);
		$falarcom=(string)addslashes($_POST['falarcom']);
		$emailentrevista=(string)addslashes($_POST['emailentrevista']);
		 $numeroentrevista=(string)addslashes($_POST['numeroentrevista']);
		$numerolocal=(string)addslashes($_POST['numerolocal']);
		$sigilosa=(string)addslashes($_POST['sigilosa']);
		$codigocid =(string)addslashes($_POST['codigocid']); 
		$aceitadeficiente =(string)addslashes($_POST['aceitadeficiente']); 

		//$query_noticias2 = "SELECT * FROM  `cbo` WHERE  `cbo` LIKE  '%$idcbo%'";	
		//$rs_noticias2    = mysql_query($query_noticias2); 													
		//while($campo_noticias2 = mysql_fetch_array($rs_noticias2)){		 
		$cboid= "27752";

		//}	


		
		$acao= $_GET['acao']; 	 		 			 	
				 			 	
		
		$dia= date("d");
		$mes= date("m");
		$ano= date("Y");
		
		$usuarioID ="3";
		switch ($acao) {
			case cadastro:
			
			if($empresaid==""){}else{
			$query="insert INTO `vaga` ( `empresaid`, `cboid`, `descricao`, `cargo`, `horariotrabalho`, `quantidadedisponivel`, `quantidadeencaminhar`, `datalimiteencaminhar`, `vagadeficiente`, `necEspAuditiva`, `necEspAuditivaTipo`, `necEspAuditivaUniBi`, `necEspFala`, `necEspFalaTipo`, `necEspFisica`, `necEspFisicaTipo`, `necEspFisicaInfSup`, `necEspMental`, `necEspRecursosCom`, `necEspCuidadoPess`, `necEspLazer`, `necEspSaudeSeg`, `necEspHabSocial`, `necEspHabAcad`, `necEspComunic`, `necEspTrabalho`, `necEspVisual`, `necEspVisualTipo`, `necEspVisualUniBi`, `codigocid`, `ceplocal`, `cidadelocalid`, `bairrolocal`, `enderecolocal`,`numerolocal`, `proximodelocal`, `local`, `onoffshore`, `salario`, `comissao`, `prospeccao`, `cartaoalimentacao`, `alimentacaolocal`, `lanche`, `cestabasica`, `planosaude`, `planoodonto`, `segurovida`, `carteiraassinada`, `valetransporte`, `premiacao`, `outrosbeneficios`, `tempoano`, `tempomes`, `comprovada`, `importanciatempo`, `idademinima`, `idademaxima`, `importanciaidade`, `escolaridade`, `escolaridadesituacao`, `importanciaescolaridade`, `cnh`, `importanciacnh`, `sexo`, `importanciasexo`, `estadocivil`, `importanciaestadocivil`, `aceitasemexperiencia`, `softwareid1`, `softwareid2`, `softwareid3`, `idiomaid1`, `idiomaid2`, `idiomaid3`, `leitura1`, `leitura2`, `leitura3`, `escrita1`, `escrita2`, `escrita3`, `conversacao1`, `conversacao2`, `conversacao3`, `horarioatendimento`, `viaencaminhamento`, `observacao`, `status`,`sigilosa`, `formacaptacaoid`, `localcaptacaoid`, `usuarioid`,  `cepentrevista`,  `cidadeentrevistaid`, `bairroentrevista`, `enderecoentrevista`, `numeroentrevista`, `proximode`, `falarcom`, `emailentrevista`,`aceitadeficiente`) VALUES 
									   ('$empresaid','$cboid','$descricao','$cargo','$horariotrabalho','$quantidadedisponivel','$quantidadeencaminhar','$datalimiteencaminhar','$vagadeficiente','$necEspAuditiva','$necEspAuditivaTipo','$necEspAuditivaUniBi','$necEspFala','$necEspFalaTipo','$necEspFisica','$necEspFisicaTipo','$necEspFisicaInfSup','$necEspMental','$necEspRecursosCom','$necEspCuidadoPess','$necEspLazer','$necEspSaudeSeg','$necEspHabSocial','$necEspHabAcad','$necEspComunic','$necEspTrabalho','$necEspVisual','$necEspVisualTipo','$necEspVisualUniBi','$codigocid','$ceplocal','$cidadelocalid','$bairrolocal','$enderecolocal','$numerolocal','$proximodelocal','$local','$onoffshore','$salario','$comissao','$prospeccao','$cartaoalimentacao','$alimentacaolocal','$lanche','$cestabasica','$planosaude','$planoodonto','$segurovida','$carteiraassinada','$valetransporte','$premiacao','$outrosbeneficios','$tempoano','$tempomes','$comprovada','$importanciatempo','$idademinima','$idademaxima','$importanciaidade','$escolaridade','$escolaridadesituacao','$importanciaescolaridade','$cnh','$importanciacnh','$sexo','$importanciasexo','$estadocivil','$importanciaestadocivil','$aceitasemexperiencia','$softwareid1','$softwareid2','$softwareid3','$idiomaid1','$idiomaid2','$idiomaid3','$leitura1','$leitura2','$leitura3','$escrita1','$escrita2','$escrita3','$conversacao1','$conversacao2','$conversacao3','$horarioatendimento','$viaencaminhamento','$observacao','$status','$sigilosa','$formacaptacaoid','$localcaptacaoid','$usuarioID','$cepentrevista','$cidadeentrevistaid','$bairroentrevista','$enderecoentrevista','$numeroentrevista','$proximode','$falarcom','$emailentrevista','$aceitadeficiente')";
			$rs= mysql_query($query);
		
			}
			//ECHO"$query";
			if ($rs) {

					?>
					
					<SCRIPT language="JavaScript">window.location.href="lista_vaga_empresa.php?msg=Cadastro salvo !";</SCRIPT>
					<?

				} else {

					?>
					<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Não foi possível cadastrar, tente novamente.  ")</SCRIPT>
					<SCRIPT language="JavaScript">window.history.go(-1);</SCRIPT>
					<?
			
						//echo "<br />Dados sobre o erro:" . mysql_error();

				}
			break;
		
		case editar:
		
			$id = $_GET['id'];
			$query="UPDATE `vaga` SET   					
					empresaid= '$usuario_id',
					 cboid= '$cboid',
					 descricao= '$descricao',
					 cargo= '$cargo',
					 horariotrabalho= '$horariotrabalho',
					 quantidadedisponivel= '$quantidadedisponivel',
					 quantidadeencaminhar= '$quantidadeencaminhar',
					 datalimiteencaminhar= '$datalimiteencaminhar',
					 vagadeficiente= '$vagadeficiente',
					 necEspAuditiva= '$necEspAuditiva',
					 necEspAuditivaTipo= '$necEspAuditivaTipo',
					 necEspAuditivaUniBi= '$necEspAuditivaUniBi',
					 necEspFala= '$necEspFala',
					 necEspFalaTipo= '$necEspFalaTipo',
					 necEspFisica= '$necEspFisica',
					 necEspFisicaTipo= '$necEspFisicaTipo',
					 necEspFisicaInfSup= '$necEspFisicaInfSup',
					 necEspMental= '$necEspMental',
					 necEspRecursosCom= '$necEspRecursosCom',
					 necEspCuidadoPess= '$necEspCuidadoPess',
					 necEspLazer= '$necEspLazer',
					 necEspSaudeSeg= '$necEspSaudeSeg',
					 necEspHabSocial= '$necEspHabSocial',
					 necEspHabAcad= '$necEspHabAcad',
					 necEspComunic= '$necEspComunic',
					 necEspTrabalho= '$necEspTrabalho',
					 necEspVisual= '$necEspVisual',
					 necEspVisualTipo= '$necEspVisualTipo',
					 necEspVisualUniBi= '$necEspVisualUniBi',
					 codigocid= '$codigocid',
					 ceplocal= '$ceplocal',
					 cidadelocalid= '$cidadelocalid',
					 bairrolocal= '$bairrolocal',
					 enderecolocal= '$enderecolocal',
					 proximodelocal= '$proximodelocal',
					 local= '$local',
					 onoffshore= '$onoffshore',
					 salario= '$salario',
					 comissao= '$comissao',
					 prospeccao= '$prospeccao',
					 cartaoalimentacao= '$cartaoalimentacao',
					 alimentacaolocal= '$alimentacaolocal',
					 lanche= '$lanche',
					 cestabasica= '$cestabasica',
					 planosaude= '$planosaude',
					 planoodonto= '$planoodonto',
					 segurovida= '$segurovida',
					 carteiraassinada= '$carteiraassinada',
					 valetransporte= '$valetransporte',
					 premiacao= '$premiacao',
					 outrosbeneficios= '$outrosbeneficios',
					 tempoano= '$tempoano',
					 tempomes= '$tempomes',
					 comprovada= '$comprovada',
					 importanciatempo= '$importanciatempo',
					 idademinima= '$idademinima',
					 idademaxima= '$idademaxima',
					 importanciaidade= '$importanciaidade',
					 escolaridade= '$escolaridade',
					 escolaridadesituacao= '$escolaridadesituacao',
					 importanciaescolaridade= '$importanciaescolaridade',
					 cnh= '$cnh',
					 importanciacnh= '$importanciacnh',
					 sexo= '$sexo',
					 importanciasexo= '$importanciasexo',
					 estadocivil= '$estadocivil',
					 importanciaestadocivil= '$importanciaestadocivil',
					 aceitasemexperiencia= '$aceitasemexperiencia',
					 softwareid1= '$softwareid1',
					 softwareid2= '$softwareid2',
					 softwareid3= '$softwareid3',
					 idiomaid1= '$idiomaid1',
					 idiomaid2= '$idiomaid2',
					 idiomaid3= '$idiomaid3',
					 leitura1= '$leitura1',
					 leitura2= '$leitura2',
					 leitura3= '$leitura3',
					 escrita1= '$escrita1',
					 escrita2= '$escrita2',
					 escrita3= '$escrita3',
					 conversacao1= '$conversacao1',
					 conversacao2= '$conversacao2',
					 conversacao3= '$conversacao3',
					 horarioatendimento= '$horarioatendimento',
					 viaencaminhamento= '$viaencaminhamento',
					 observacao= '$observacao',
					 status= '$status',
					 formacaptacaoid= '$formacaptacaoid',
					 localcaptacaoid= '$localcaptacaoid',
					 usuarioid= '$usuarioID',					 
					 cepentrevista= '$cepentrevista',					 
					 cidadeentrevistaid= '$cidadeentrevistaid',
					 bairroentrevista= '$bairroentrevista',
					 enderecoentrevista= '$enderecoentrevista',
					 proximode= '$proximode',
					 falarcom= '$falarcom',
					 sigilosa= '$sigilosa',
					 aceitadeficiente= '$aceitadeficiente',
					 emailentrevista= '$emailentrevista',dataupdate= NOW()
					 
					WHERE id='$id'
			";
			$rs= mysql_query($query);
			

			
			if ($rs) {

					?>
					
					<SCRIPT language="JavaScript">window.location.href="lista_vaga_empresa.php?msg=Alteração Feita";</SCRIPT>
					<?

				} else {

					?>
					<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("Não foi possível Salvar, tente novamente.  ")</SCRIPT>
					<SCRIPT language="JavaScript">window.history.go(-1);</SCRIPT>
					<?
			
						//echo "<br />Dados sobre o erro:" . mysql_error();
						

				}
				
			break;
			case excluir:
			
			$id= $_GET['id'];
			$nome= $_GET['nome'];
			?>
			
			
				<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
				
				
				
						<?
						$query="DELETE FROM  vaga where id='$id'";
						$rs= mysql_query($query);	
						?>
				alert("Excluindo vaga ID:<?=$id;?> ")
				setTimeout("self.close();",2);
				
				
				</SCRIPT>
			<?
		
			break;
			
			
			
		
		}
	
		
		?>		