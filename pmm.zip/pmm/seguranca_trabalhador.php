<?php
include"interno/input_banco.php";

    $login_cookie = $_COOKIE['usuario'];
        if(isset($login_cookie)){
           // echo"Bem-Vindo, $login_cookie <br>";
            //echo"Essas informações <font color='red'>PODEM</font> ser acessadas por você";
			
			
			
			
        }else{
			
            ?>
			<script>
			parent.location="index.php";
			
			</script>
			<?
        }
		
		function protegepagina(){};
		
		
		if($login_cookie==""){ $login_cookie = $HTTP_COOKIE_VARS["usuario"];}
		
		if($login_cookie==""){
			
			?>
			<script>
				parent.location="index.php";			
			</script>
			<?
			
			
		}else{
		 
					$sql32u = "SELECT * FROM `usuario` WHERE `usuario` = '$login_cookie' limit 1";
					$rsd32u = mysql_query($sql32u);
					while($rs32u = mysql_fetch_array($rsd32u)) {
					//$perfil = $rs32u['perfil'];		
					$usuario_nomelogin  = $rs32u['nome'];
					//echo"$usuarioID";
					}
					
					$sql32u = "SELECT * FROM `trabalhador` WHERE `cpf` = '$login_cookie' limit 1";
					$rsd32u = mysql_query($sql32u);
					while($rs32u = mysql_fetch_array($rsd32u)) {
					//$perfil = $rs32u['perfil'];
					$usuario_id  = $rs32u['id'];
					$usuario_nome  = $rs32u['nome'];
					//echo"$usuarioID";
					}
		
		}
			

?>								
 
