<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página

error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?include'topo.php';?>

<body >


<div id="bg-container" class='contener'>

<form  class="form" method="post" action="" id="ajax_form">

  	<h2>Softwares</h2>

		<div class="form-row">
		<div class="label">Softwares</div>
		<div class="input-container"><input name="nome" value='<?=$txtcc;?>' type="n"  onkeyup="this.value = this.value.toUpperCase();" class="input req-same" maxlength="40" /></div>
		</div>
		
		

		<div class="form-row">
		<div class="label"></div>
		<div class="input-container" style='width:546px;'>		
		<input id="submitBtn2" value="Salvar" type="submit" class="sendBtn" />
		<div id="errorDiv2" class="error-div"></div>
		</div>
		</div>
		</form>	
</div>
</body>
</html>