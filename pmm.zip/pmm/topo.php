<?error_reporting(E_ALL ^ E_NOTICE);

?>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>SEMTRE</title>
    <link rel="stylesheet" type="text/css" href="assets/reset.css" />
    <link rel="stylesheet" type="text/css" href="assets/styles.css" />
		
		<link rel="stylesheet" href="reveal.css">				
		<link rel='stylesheet' type='text/css' href='styles.css' />	
		
		
		<link rel="stylesheet" href="http://code.jquery.com/ui/1.9.0/themes/base/jquery-ui.css" />
	<script src="http://code.jquery.com/jquery-1.8.2.js"></script>

	<script src="http://code.jquery.com/ui/1.9.0/jquery-ui.js"></script>

	<?php $anofinaldata= date("Y"); ?>
	<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-62329413-1', 'auto');
  ga('send', 'pageview');

</script>		
			<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>

		
<SCRIPT LANGUAGE="JavaScript">   
<!-- Disable   
function disableselect(e){   
return false   
}   

function reEnable(){   
return true   
}   

//if IE4+   
document.onselectstart=new Function ("return false")   
document.oncontextmenu=new Function ("return false")   
//if NS6   
if (window.sidebar){   
document.onmousedown=disableselect   
document.onclick=reEnable   
}   
//-->   
</script>  
		
<script language="JavaScript">
function validar_cpf(){
var cpf_busca = document.cadastro.cpf_busca.value;
var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
if(!filtro.test(cpf_busca)){
window.alert("CPF inválido. Tente novamente.");
return false;
}

cpf_busca = remove(cpf_busca, ".");
cpf_busca = remove(cpf_busca, "-");

if(cpf_busca.length != 11 || cpf_busca == "00000000000" || cpf_busca == "11111111111" ||
cpf_busca == "22222222222" || cpf_busca == "33333333333" || cpf_busca == "44444444444" ||
cpf_busca == "55555555555" || cpf_busca == "66666666666" || cpf_busca == "77777777777" ||
cpf_busca == "88888888888" || cpf_busca == "99999999999"){
window.alert("cpf inválido. Tente novamente.");
return false;
}

soma = 0;
for(i = 0; i < 9; i++)
soma += parseInt(cpf_busca.charAt(i)) * (10 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_busca.charAt(9))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
soma = 0;
for(i = 0; i < 10; i ++)
soma += parseInt(cpf_busca.charAt(i)) * (11 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_busca.charAt(10))){
window.alert("cpf inválido. Tente novamente.");
return false;
}
return true;
}

function remove(str, sub) {
i = str.indexOf(sub);
r = "";
if (i == -1) return str;
r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
return r;
}
</script>


	<script type='text/javascript' src="789/js/jquery.autocomplete.js"></script>
	<link rel="stylesheet" type="text/css" href="789/js/jquery.autocomplete.css" />
	<script type="text/javascript" src="jquery.maskedinput-1.1.4.pack.js"/></script>
	<script type="text/javascript" src="jquery.reveal.js"></script>
	<script type="text/javascript" src="jquery.validate.js" ></script>
	<script src="jquery.maskMoney.js" type="text/javascript"></script>
	<script src="js/jquery.validate.min.js" type="text/javascript"></script>
	

<?php $anofinaldata= date("Y"); ?>


	<script type="text/javascript">		
		$(function() {
		$("#datanascimento").datepicker({
		changeMonth: true,
		changeYear: true,
		yearRange: '1900:<?=$anofinaldata;?>',
		dateFormat: 'dd/mm/yy',
        dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
        dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
        dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
        monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
        monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
		});
		});

	  </script>
	  
		<script type="text/javascript">
			$(document).ready(function(){	$("#cpf_trabalhador").mask("999.999.999-99");});
			$(document).ready(function(){	$("#cpf_trabalhadorF").mask("999.999.999-99");});
			$(document).ready(function(){	$("#cpf_trabalhador_cadastro").mask("999.999.999-99");});
			$(document).ready(function(){	$("#cpfagendamento").mask("999.999.999-99");});
			$(document).ready(function(){	$("#cpf_login").mask("999.999.999-99");});
			$(document).ready(function(){	$("#cpf").mask("999.999.999-99");});
			$(document).ready(function(){	$("#tel1").mask("(99)9999.9999");});
			$(document).ready(function(){	$("#tel2").mask("(99)99999.9999");});
			$(document).ready(function(){	$("#tel3").mask("(99)9999.9999");});
			$(document).ready(function(){	$("#telres").mask("(99)9999.9999");});
			$(document).ready(function(){	$("#telrec").mask("(99)9999.9999");});			
			$(document).ready(function(){	$("#telcel").mask("(99)99999.9999");});			
			$(document).ready(function(){	$("#datainicio").mask("99/99/9999");});			
			$(document).ready(function(){	$("#datafinal").mask("99/99/9999");});			
			$(document).ready(function(){	$("#txvagadata").mask("99/99/9999");});			
			$(document).ready(function(){	$("#datalimiteencaminhar").mask("99/99/9999");});			
			$(document).ready(function(){	$("#datanascimento").mask("99/99/9999");});			
			$(document).ready(function(){	$("#datanascimento1").mask("99/99/9999");});			
			$(document).ready(function(){	$("#cpf_busca").mask("999.999.999-99");});			
			$(document).ready(function(){	$("#cep").mask("99999-999");});			
			$(document).ready(function(){	$("#cepentrevista").mask("99999-999");});			
			$(document).ready(function(){	$("#ceplocal").mask("99999-999");});	
			
			
			
				
			

			
		</script>
		
		<script type="text/javascript">
function mascaraMutuario(o,f){
    v_obj=o
    v_fun=f
    setTimeout('execmascara()',1)
}
 
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
 
function cpfCnpj(v){
 
    //Remove tudo o que não é dígito
    v=v.replace(/\D/g,"")
 
    if (v.length <= 13) { //CPF
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um ponto entre o terceiro e o quarto dígitos
        //de novo (para o segundo bloco de números)
        v=v.replace(/(\d{3})(\d)/,"$1.$2")
 
        //Coloca um hífen entre o terceiro e o quarto dígitos
        v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")	
		
		
 
    } else { //CNPJ
 
        //Coloca ponto entre o segundo e o terceiro dígitos
        v=v.replace(/^(\d{2})(\d)/,"$1.$2")
 
        //Coloca ponto entre o quinto e o sexto dígitos
        v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
 
        //Coloca uma barra entre o oitavo e o nono dígitos
        v=v.replace(/\.(\d{3})(\d)/,".$1/$2")
 
        //Coloca um hífen depois do bloco de quatro dígitos
        v=v.replace(/(\d{4})(\d)/,"$1-$2")
 
    }
	
	
	
    return v
 
}
			</script>
			
	
	<script language = "JavaScript">
	
	//valida o CNPJ digitado
function ValidarCNPJ(ObjCnpj){
	var cnpj = ObjCnpj.value;
	var valida = new Array(6,5,4,3,2,9,8,7,6,5,4,3,2);
	var dig1= new Number;
	var dig2= new Number;
	
	exp = /\.|\-|\//g
	cnpj = cnpj.toString().replace( exp, "" ); 
	var digito = new Number(eval(cnpj.charAt(12)+cnpj.charAt(13)));
		
	for(i = 0; i<valida.length; i++){
		dig1 += (i>0? (cnpj.charAt(i-1)*valida[i]):0);	
		dig2 += cnpj.charAt(i)*valida[i];	
	}
	dig1 = (((dig1%11)<2)? 0:(11-(dig1%11)));
	dig2 = (((dig2%11)<2)? 0:(11-(dig2%11)));
	
	if(((dig1*10)+dig2) != digito){	
		//alert('CNPJ Invalido!');
		document.getElementById("msg_cnpjsenha").innerHTML = "Favor Inserir CNPJ Válido!";
		document.getElementById("msg_cnpjcadastro").innerHTML = "Favor Inserir CNPJ Válido!";
		document.getElementById("msg_cnpjlogin").innerHTML = "Favor Inserir CNPJ Válido!";
		ObjCnpj.focus();
		return (false);
	}	
	
	
	document.getElementById("msg_cnpjsenha").innerHTML = "OK";
		document.getElementById("msg_cnpjcadastro").innerHTML = "OK";
		document.getElementById("msg_cnpjlogin").innerHTML = "OK";
	return (true);
}

</script>
				
<script language="JavaScript">
function cpf_loginfun(){
var cpf_login = document.cpf_loginF.cpf_login.value;
var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
if(!filtro.test(cpf_login)){
//window.alert("CPF inválido. Tente novamente.");
document.getElementById("msg_cpflogin").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}

cpf_login = remove(cpf_login, ".");
cpf_login = remove(cpf_login, "-");

if(cpf_login.length != 11 || cpf_login == "00000000000" || cpf_login == "11111111111" ||
cpf_login == "22222222222" || cpf_login == "33333333333" || cpf_login == "44444444444" ||
cpf_login == "55555555555" || cpf_login == "66666666666" || cpf_login == "77777777777" ||
cpf_login == "88888888888" || cpf_login == "99999999999"){
//window.alert("CPF inválido. Tente novamente.");
document.getElementById("msg_cpflogin").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}

soma = 0;
for(i = 0; i < 9; i++)
soma += parseInt(cpf_login.charAt(i)) * (10 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_login.charAt(9))){
//window.alert("CPF inválido. Tente novamente.");
document.getElementById("msg_cpflogin").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}
soma = 0;
for(i = 0; i < 10; i ++)
soma += parseInt(cpf_login.charAt(i)) * (11 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_login.charAt(10))){
//window.alert("CPF inválido. Tente novamente.");
document.getElementById("msg_cpflogin").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}
return true;
}

function remove(str, sub) {
i = str.indexOf(sub);
r = "";
if (i == -1) return str;
r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
return r;
}
</script>	

		
									
<script language="JavaScript">
function cpf_trabalhadorfun(){
var cpf_trabalhador = document.cpf_trabalhadorF.cpf_trabalhador.value;
var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
if(!filtro.test(cpf_trabalhador)){
//window.alert("CPF inválido. Tente novamente.");
document.getElementById("msg_cpfcadastro").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}

cpf_trabalhador = remove(cpf_trabalhador, ".");
cpf_trabalhador = remove(cpf_trabalhador, "-");

if(cpf_trabalhador.length != 11 || cpf_trabalhador == "00000000000" || cpf_trabalhador == "11111111111" ||
cpf_trabalhador == "22222222222" || cpf_trabalhador == "33333333333" || cpf_trabalhador == "44444444444" ||
cpf_trabalhador == "55555555555" || cpf_trabalhador == "66666666666" || cpf_trabalhador == "77777777777" ||
cpf_trabalhador == "88888888888" || cpf_trabalhador == "99999999999"){
//window.alert("CPF inválido. Tente novamente.");
document.getElementById("msg_cpfcadastro").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}

soma = 0;
for(i = 0; i < 9; i++)
soma += parseInt(cpf_trabalhador.charAt(i)) * (10 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_trabalhador.charAt(9))){
document.getElementById("msg_cpfcadastro").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}
soma = 0;
for(i = 0; i < 10; i ++)
soma += parseInt(cpf_trabalhador.charAt(i)) * (11 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_trabalhador.charAt(10))){
//window.alert("CPF inválido. Tente novamente.");
document.getElementById("msg_cpfcadastro").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}
return true;
}

function remove(str, sub) {
i = str.indexOf(sub);
r = "";
if (i == -1) return str;
r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
return r;
}



</script>	


<script language="JavaScript">
function cpf_trabalhadorfun_senha(){

var cpf_trabalhadorsenha = document.cpf_loginFemailF.cpf_trabalhador_cadastro.value;

var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
if(!filtro.test(cpf_trabalhadorsenha)){
//window.alert("CPF inválido. Tente novamente.");
document.getElementById("msg_cpfsenha").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}

cpf_trabalhadorsenha = remove(cpf_trabalhadorsenha, ".");
cpf_trabalhadorsenha = remove(cpf_trabalhadorsenha, "-");

if(cpf_trabalhadorsenha.length != 11 || cpf_trabalhadorsenha == "00000000000" || cpf_trabalhadorsenha == "11111111111" ||
cpf_trabalhadorsenha == "22222222222" || cpf_trabalhadorsenha == "33333333333" || cpf_trabalhadorsenha == "44444444444" ||
cpf_trabalhadorsenha == "55555555555" || cpf_trabalhadorsenha == "66666666666" || cpf_trabalhadorsenha == "77777777777" ||
cpf_trabalhadorsenha == "88888888888" || cpf_trabalhadorsenha == "99999999999"){
//window.alert("CPF inválido. Tente novamente.");
document.getElementById("msg_cpfsenha").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}

soma = 0;
for(i = 0; i < 9; i++)
soma += parseInt(cpf_trabalhadorsenha.charAt(i)) * (10 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_trabalhadorsenha.charAt(9))){
document.getElementById("msg_cpfsenha").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}
soma = 0;
for(i = 0; i < 10; i ++)
soma += parseInt(cpf_trabalhadorsenha.charAt(i)) * (11 - i);
resto = 11 - (soma % 11);
if(resto == 10 || resto == 11)
resto = 0;
if(resto != parseInt(cpf_trabalhadorsenha.charAt(10))){
//window.alert("CPF inválido. Tente novamente.");
document.getElementById("msg_cpfsenha").innerHTML = "CPF INVÁLIDO. TENTE NOVAMENTE.";
return false;
}
return true;
}

function remove(str, sub) {
i = str.indexOf(sub);
r = "";
if (i == -1) return str;
r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
return r;
}



</script>
</head>
