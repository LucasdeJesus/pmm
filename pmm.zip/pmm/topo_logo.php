<style>
#loading {
background:#000 url(img/carregamento-da-pagina-com-loading.gif) no-repeat center center;
height: 50px;
width: 250px;
position: fixed;
left: 50%;
top: 50%;
margin: -25px 0 0 -25px;
z-index: 1000;
}
</style>

<script>
	
	function Abrir_Pagina(URL) {
			  window.open(URL,'','width=1000,height=500');      
			} 
			
	</script>
<script type='text/javascript'>

$(document).ready(function(){
// Executa o evento CLICK em todos os links do menu

 $('#cssmenuee a').live('click',function(){
  // Faz o carregamento da página de acordo com o COD da página, que vai pegar os valores da página page.php.
  $('#paginatoda').load($(this).attr('href'));
  return false;

    

 });



});

</script>
<!--<div id="loading"></div>-->
<?include'enviaemail.php';?>
<div style='width:100%;border-top:3px solid #00B8AD; border-bottom:1px solid #D1D8DB;background-color:#FAFAFA;margin-top:20px;' align='center' >
		
			<table width='960px' >
				<tr>
					<td >
						<a href='index.php'><img src='img/logo.jpg'/></a>
					</td>
					
					<td>
						<div id='cssmenu'>
							<ul>								
								<li class='has-sub'><a ><span>Agendamento</span></a>
									<ul>
										
										<li class='has-sub'><a  title="Candidatar para Vagas de Emprego" data-reveal-id="cadastro_trabalhador"><span> Vagas de Emprego</span></a> </li>
										
										<li class='has-sub'><a href='agendamentoonline.php?urlifreme=agendamento/agendamento.php?tipo=D' title="Emissão de Carteira de Identidade" ><span>Emissão RG</span></a> </li>
										<li class='has-sub'><a href='agendamentoonline.php?urlifreme=agendamento/agendamento.php?tipo=C' title="Emissão de Carteira de Trabalho"><span>Emissão CTPS</span></a> </li>
										<li class='has-sub'><a href='#' title="Veificar meus agendamento" data-reveal-id='verificaragendamento'><span>Verificar meus agendamento</span></a> </li>
										
									</ul>
								</li>
								
								<li class='has-sub'><a ><span>Cadastro </span></a>
									<ul>
										
										<li class='has-sub'><a  title="Cadastro do Trabalhado" data-reveal-id="cadastro_trabalhador"><span>Cadastro do Trabalhador</span></a> </li>										
										<li class='has-sub'><a  title="Cadastro do Empregador" data-reveal-id="cadastro_empresa"><span>Cadastro do Empregador</span></a> </li>										
																				
									</ul>
								</li>
								
								<li class='has-sub'><a ><span>Login </span></a>
									<ul>
										
										<li class='has-sub'><a  title="Login do Trabalhado" data-reveal-id="myModal"><span>Login do Trabalhado</span></a> </li>										
										<li class='has-sub'><a  title="Login do Empregador" data-reveal-id="myModal2"><span>Login do Empregador</span></a> </li>										
																				
									</ul>
								</li>
								 <li ><a href='contato.php'><span>Contato</span></a></li>
								 <!--<li ><a href='ajuda.php' ><span>Ajuda</span></a></li>-->
								
							</ul>
						</div>
					</td>
					
				</tr>
			</table>
		</div>

		
		
		<div id="verificaragendamento" class="reveal-modal">
								
								
										<h2>Verificar agendamento</h2>
										<div style='font-size:16px; '>

										
										</div>
										
										<br><h2>Informe CPF para verificar seu Agendamento</h2>
										
										
										<script>
																	

									
								function cancelaagendamento(id) {
					
											$.ajax({
												url: 'agendamento/script.php?id='+id+'&acao=cancelaagendamento',
												success: function(data) {				
												
												
													if($.trim(data)  == 2){
														//$("#naoagendamentoexiste" ).show("slow");
													//$("#agendamentoexiste" ).hide("hide");
													//alert("Agendamento Cancelado!");
													//window.location.assign("listaagendamento.php?id=<?=$cpf_buscaagenda;?>&msg=Agendamento Cancelado!");
													buscaagendamento();
													}
												}
												
												});						
												
												
									}
					
					
					
				
								
				
				
															function buscaagendamento(){
																 
															var data = document.getElementById("cpfagendamento").value;
															
															
															document.getElementById("carregandoagendamento").style.display = 'block';
															
															
																		var xmlHttp;
																		try{    
																		xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
																		}
																		catch (e){
																		try{
																		xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
																		}
																		catch (e){
																		try{
																		xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
																		}
																		catch (e){
																		alert("No AJAX!?");
																		return false;
																		}
																		}
																		}
																		var url = "consultaagendamento.php?id="+data;
																		xmlHttp.onreadystatechange=function(){
																		if(xmlHttp.readyState==4){
																		document.getElementById('meusagendamentocadastrado').innerHTML=xmlHttp.responseText;
																		setTimeout('buscaagendamento()',100);
																		}
																		}
																		xmlHttp.open("GET",url,true); // aqui configuramos o arquivo
																		xmlHttp.send(null);
																		}

																		window.onload=function(){
																		setTimeout('buscaagendamento()',9000); // aqui o tempo entre uma atualização e outra
																		}
															
															

													</script>
													
										<form  class="form" method="POST" action="#"  id="formagendament" name='formagendament' >
												
												<div id='carregandoagendamento' style='display:none'> Carregando aguarde....</div>
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container"><input name="cpfagendamento" id='cpfagendamento' required   placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  /></div>
												
												</div>
												
												
												
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><a href="#" class="sendBtn"  onSubmit="buscaagendamento();" > Avançar</a></div>
												</div>
												
												<div  id='meusagendamentocadastrado'></div>
												
											
										
										</form>
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
		
		
		<div id="myModal" class="reveal-modal">
								
										<script type="text/javascript">
										function exibe(id) {
										if(document.getElementById(id).style.display=="none") {
										document.getElementById(id).style.display = "inline";
										}
										else {
										document.getElementById(id).style.display = "none";
										}
										}
										</script>
								
								
								
								
										
										
										<h2>Acesso área do Trabalhador</h2>
										<form  class="form" method="POST" action="valida_trabalhado.php"  id="cpf_loginF" name='cpf_loginF' onSubmit="return cpf_loginfun()">
												
												
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container">
													<input name="cpf_login" id='cpf_login' required    placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  />
													<div id="msg_cpflogin" name='msg_cpflogin' style="color:red;font-size:10px;"></div>
												</div>
												</div>
												
												
												<div class="form-row">
												<div class="label">Senha</div>
												<div class="input-container"><input name="senha" id='senha' required  placeholder="senha" type="password"  style='width:130px;'class="input req-same"   /></div>
												</div>

												
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn" value='acessar'  /></div>
												</div>
												
												<p> Se você esqueceu sua senha, <a href='#' onclick="javascript: exibe('conteudo');">clique aqui</a></p>			
												
												
										
										</form>
										
										<!-----envia senha email ---->
										<div id="conteudo" style="display: none;">
										
										<form  class="form" action='login.php' method='post' id="cpf_loginFemailF" name="cpf_loginFemailF" onSubmit="return cpf_trabalhadorfun_senha()">
										<h2>Informa seu CPF Cadastrado</h2>
										<p>Você recebara um email com a senha!</p>
												
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container"><input name="cpf_trabalhador_cadastro" id='cpf_trabalhador_cadastro'    required  placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  /></div>
												<div id="msg_cpfsenha" name='msg_cpfsenha' style="color:red;font-size:10px;"></div>
												</div>
												
												<div class="form-row">
												<div class="label">Data Nascimento</div>
												<div class="input-container"><input name="datanascimento" id='datanascimento'    required  placeholder="__/__/__" type="text"  class="input req-same" style='width:130px;'maxlength="14"  /></div>
												
												</div>
												
												
												<div class="form-row">
											<div class="label"></div>
											<div class="input-container" style='width:246px;'>		
												<input type='hidden' value ='2' name='pass'/>
											
												<input id="submitBtn2" value="Enviar" type="submit" class="sendBtn" />
													<div id="errorDiv2" class="error-div"></div>
											</div>
										</div>
										
													
										</form>
										
										
										</div>
										
										<!------------envia senha email -------------->
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
								
								<div id="cadastro_trabalhador" class="reveal-modal">
								
								
										<h2>Serviços ao  Trabalhador</h2>
										<div style='font-size:16px; '>

										&#9745; Acesso as Vagas</br>
										&#9745; Agendar atendimento</br>
										&#9745; Cadastra Currículo
										
										</div>
										
										<br><h2>Cadastre-se para Agendar</h2>
										<form  class="form" method="POST" action="cadatro_trabalhador_1.php"  id="cpf_trabalhadorF" name='cpf_trabalhadorF' onSubmit="return cpf_trabalhadorfun()">
												
												
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container"><input name="cpf_trabalhador" id='cpf_trabalhador' required   placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  /></div>
												<div id="msg_cpfcadastro" name='msg_cpfcadastro' style="color:red;font-size:10px;"></div>
												</div>
												
												
												
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn"  value='Avançar'  /></div>
												</div>
												
											
										
										</form>
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
								
								
								
								<div id="myModal2" class="reveal-modal">
								
								
								
								
										<h2>Acesso área do Empregador</h2>
										<form  class="form" method="post" action="valida_empresa.php"  id="cadastroem" name='cadastroem' onSubmit=" return ValidarCNPJ(cadastroem.txCNPJ);">
												
												
												<div class="form-row">
												<div class="label">CNPJ</div>
												<div class="input-container">
													<input name="txCNPJ" id="txCNPJ" required value=''maxlength="18" placeholder="Insira o CNPJ" tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)'  style="width:194px;" type="text" class="input req-same">
													<div id="msg_cnpjlogin" name='msg_cnpjlogin' style="color:red;font-size:10px;"></div>
												</div>
												</div>
												
												
												<div class="form-row">
												<div class="label">Senha</div>
												<div class="input-container"><input name="senha" required  id='senha' placeholder="senha" type="password"  style='width:130px;'class="input req-same"   /></div>
												</div>
												
												<input type='hidden' name="enviado" value="posted">
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn" onmouseover='return ValidarCNPJ(cadastroem.txCNPJ);' value='acessar'  /></div>
												</div>
						
													<p> Se você esqueceu sua senha, <a href='#' onclick="javascript: exibe('conteudo_empresa');">clique aqui</a></p>
													
													
													
													
										</form>
										
									
										
										<!-----envia senha email ---->
										<div id="conteudo_empresa" style="display: none;">
										
										<form  class="form"   action="login.php"id='lembrasenha' method="post"name='lembrasenha' onSubmit=" return  ValidarCNPJ(lembrasenha.txCNPJ);">
										<h2>Informa seu CPF/CNPJ Cadastrado</h2>
										<p>Você recebara um email com a senha!</p>
												
												<div class="form-row">
												<div class="label">CNPJ</div>
												<div class="input-container">
													<input name="txCNPJ" id="txCNPJ" required value=''maxlength="18" placeholder="Insira o CNPJ" tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)' onBlur="ValidarCNPJ(lembrasenha.txCNPJ);" style="width:194px;" type="text" class="input req-same">
												<div id="msg_cnpjsenha" name='msg_cnpjsenha' style="color:red;font-size:10px;"></div>
												</div>
												</div>
												
												<div class="form-row">
											<div class="label"></div>
											<div class="input-container" style='width:246px;'>		
												<input type='hidden' value ='1' name='pass'/>
											
												<input id="submitBtn2" value="Enviar" type="submit" class="sendBtn" />
													<div id="errorDiv2" class="error-div"></div>
											</div>
										</div>
										
													
										</form>
										
										
										</div>
										
										<!------------envia senha email -------------->
										
										
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
								
								
								
								<div id="cadastro_empresa" class="reveal-modal">
								
								
										<h2>Cadastro do Empregador</h2>
										<form  class="form" method="GET" onSubmit="return  ValidarCNPJ(cadastroem2.txCNPJ);" action="cadatro_empresa_1.php"  id="cadastroem2" name='cadastroem2' >
												
												
												<div class="form-row">
												<div class="label">CNPJ</div>
												<div class="input-container">
													<input name="txCNPJ" id="txCNPJ" required value=''maxlength="18" placeholder="Insira o CNPJ" tabindex="1" onkeypress='mascaraMutuario(this,cpfCnpj)' onkeypress='mascaraMutuario(this,cpfCnpj)'style="width:194px;" type="text" class="input req-same">
													<div id="msg_cnpjcadastro" name='msg_cnpjcadastro' style="color:red;font-size:10px;"></div>
												</div>
												</div>
												
																								
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn"  onmouseover="ValidarCNPJ(cadastroem2.txCNPJ);" value='próximo &#10132;'  /></div>
												</div>
						
													
										</form>
										
										
										
										
										
								
								<a class="close-reveal-modal">&#215;</a>
								</div>