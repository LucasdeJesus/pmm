<style>
#loading {
background:#000 url(img/carregamento-da-pagina-com-loading.gif) no-repeat center center;
height: 99%;
width: 100%;
position: fixed;

z-index: 1000;
}
</style>

	
<!--<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script><div id="loading"></div>-->

	
	
	
	<div style='width:100%;' align='center'>
	<table width='960px' >
	<tr>
	<td >
	Olá <?=$usuario_nome;?>, <a href='sair.php'  class="sendBtn ">sair</a>

	</td>

	</tr>
	</table>
	</div>
<div style='width:100%;border-top:3px solid #00B8AD; border-bottom:1px solid #D1D8DB;background-color:#FAFAFA;margin-top:20px;' align='center' >
		
			<table width='960px' >
				<tr>
					<td >
						<a href='#'><img src='img/logo.jpg'/></a>
					</td>
					
					<td>
						<div id='cssmenu'>
<ul>
   <li ><a href='area_empresa.php'><span>Home</span></a></li>
   <li class='has-sub'><a href='#'><span>Vagas</span></a>
      <ul>
         <li class='has-sub'><a href='cadatro_vaga_empresa.php'><span>Cadastrar Vaga</span></a> </li>
         <li class='has-sub'><a href='lista_vaga_empresa.php'><span>Listar Vagas</span></a> </li>
        
      </ul>
   </li>
   <li><a href='meus_dados_empresa.php'><span>Meus Dados</span></a></li>
 <li ><a href='contato.php'><span>Contato</span></a></li>
</ul>
</div>
					</td>
					
				</tr>
			</table>
		</div>
		