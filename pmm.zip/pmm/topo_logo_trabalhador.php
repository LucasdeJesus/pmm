<style>
#loading {
background:#000 url(img/carregamento-da-pagina-com-loading.gif) no-repeat center center;
height: 99%;
width: 100%;
position: fixed;

z-index: 1000;
}
</style>
	
<script language="JavaScript"> 
	function Abrir_Pagina(URL,Configuracao) {
	  window.open(URL,'',Configuracao);      
	} 
</script>	
<!--<div id="loading"></div>-->


	<?
	
	
	$senhanova 	=(string)addslashes($_POST['senhanova']); 
	if($senhanova ==""){}else{
	
	
			$query_noticias_dados = "SELECT cpf FROM `trabalhador` where id='$usuario_id'";	
			$rs_noticias_dados    = mysql_query($query_noticias_dados);
			while($campo_noticias_dados = mysql_fetch_array($rs_noticias_dados)){			
			$cpf  = $campo_noticias_dados['cpf'];
			}
													
		$querys="update  usuario set senha ='$senhanova' where usuario='$cpf' ";
		$rss= mysql_query($querys);
	
		if($rss){
			echo"<h3>Senha Alterada com sucesso</h3>";
		}else{
			echo"<h3>Erro tente novamente</h3>";
			//echo $querys;
		}
	}
	
	?>
	<div style='width:100%;' align='center'>
	<table width='960px' >
	<tr>
	<td >
	Olá <?=$usuario_nome;?> SEU ID <?=$usuario_id;?>, <a href='sair.php'  class="sendBtn ">sair</a>                  |   <a href='#'  data-reveal-id="myModal" class="sendBtn ">Alterar senha</a>

	</td>

	</tr>
	</table>
	</div>
	
	
	
	<div id="myModal" class="reveal-modal">
								
														
								
								
										
										
										<h2>ALTERAR SENHA</h2>
										<form  class="form" method="POST" action=""  id="cpf_loginF" >
												
												
												<div class="form-row">
												<div class="label">NOVA SENHA</div>
												<div class="input-container">
													<input name="senhanova" id='senhanova' required    placeholder="Nova senha " type="password"  class="input req-same" style='width:130px;'maxlength="14"  />													
													<div id="msg_cpflogin" name='msg_cpflogin' style="color:red;font-size:10px;"></div>
												</div>
												</div>
												
												<div class="form-row">
												<div class="label">CONFIRME SENHA</div>
												<div class="input-container">
													<input name="senha2" id='senha2' required    placeholder="Confirme Senha" type="password"  class="input req-same" style='width:130px;'maxlength="14"  />													
													<div id="msg_cpflogin" name='msg_cpflogin' style="color:red;font-size:10px;"></div>
												</div>
												</div>
												
												
												
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><input type='submit' class="sendBtn" value='Salvar'  /></div>
												</div>
												
										</form>
										
										
										
										<!------------envia senha email -------------->
								
								<a class="close-reveal-modal">&#215;</a>
								</div>
	
	
	
<div style='width:100%;border-top:3px solid #00B8AD; border-bottom:1px solid #D1D8DB;background-color:#FAFAFA;margin-top:20px;' align='center' >
		
			<table width='960px' >
				<tr>
					<td >
						<a href='#'><img src='img/logo.jpg'/></a>
					</td>
					
					<td>
						<div id='cssmenu'>
							<ul>
								
								<li class='has-sub'><a href='#'><span>Vagas</span></a>
									<ul>
										<!--<li class='has-sub'><a href='listar_vaga_disponivel_trabalhador.php'><span>Vagas Compatíveis Disponíveis</span></a> </li>-->
										<li class='has-sub'><a href='#' Onclick="Abrir_Pagina('http://sistemas.macae.rj.gov.br:84/catalogo/semtre/index/mural');"><span>Todas Vagas Disponíveis</span></a> </li>
										

									</ul>
								</li>
								<li><a href='' ><span>Meu Currículo</span></a>
									<ul>
										<li class='has-sub'><a href='area_trabalhador.php?semtre=ok'><span>Editar Currículo</span></a> </li>
										<!--<li class='has-sub'><a href='imprimi_curriculo_trabalhado.php?semtre=ok'><span>Imprimir Currículo</span></a> </li>-->
										

									</ul>
								</li>
								
								
								<li class='has-sub'><a href='#'><span>Agendamento</span></a>
									<ul>
										
									<li class='has-sub'><a  href="carregaagendamento.php?urlifreme=agendamento/agendamento.php?tipo=V" title="Candidatar para Vagas de Emprego" ><span> Vagas de Emprego</span></a> </li>										
										<li class='has-sub'><a href="carregaagendamento.php?urlifreme=agendamento/agendamento.php?tipo=D"  title="Emissão de Carteira de Identidade" ><span>Emissão RG</span></a> </li>
										<li class='has-sub'><a href="carregaagendamento.php?urlifreme=agendamento/agendamento.php?tipo=C"  title="Emissão de Carteira de Trabalho"><span>Emissão CTPS</span></a> </li>
										<li class='has-sub'><a href='#' title="Veificar meus agendamento" data-reveal-id='verificaragendamento'><span>Verificar meus agendamento</span></a> </li>
									</ul>
								</li>
								
								<li ><a href='contato.php'><span>Contato</span></a></li>
							</ul>
						</div>
					</td>
					
				</tr>
			</table>
		</div>
		
		
			
		<div id="verificaragendamento" class="reveal-modal">
								
								
										<h2>Verificar agendamento</h2>
										<div style='font-size:16px; '>

										
										</div>
										
										<br><h2>Informe CPF para verificar seu Agendamento</h2>
										
										
										<script>
																												
															function buscaagendamento(){
															var data = document.getElementById("cpfagendamento").value;
															var xmlHttp;
															try{    
															xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
															}
															catch (e){
															try{
															xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
															}
															catch (e){
															try{
															xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
															}
															catch (e){
															alert("No AJAX!?");
															return false;
															}
															}
															}
															var url = "consultaagendamento.php?id="+data;
															xmlHttp.onreadystatechange=function(){
															if(xmlHttp.readyState==4){
															document.getElementById('meusagendamentocadastrado').innerHTML=xmlHttp.responseText;
															setTimeout('buscaagendamento()',100);
															}
															}
															xmlHttp.open("GET",url,true); // aqui configuramos o arquivo
															xmlHttp.send(null);
															}

															window.onload=function(){
															setTimeout('buscaagendamento()',9000); // aqui o tempo entre uma atualização e outra
															}

													</script>
													
										<form  class="form" method="POST" action="#"  id="formagendament" name='formagendament' >
												
												
												<div class="form-row">
												<div class="label">CPF</div>
												<div class="input-container"><input name="cpfagendamento" id='cpfagendamento' required   placeholder="Insira o CPF" type="text"  class="input req-same" style='width:130px;'maxlength="14"  /></div>
												
												</div>
												
												
												
												<div class="form-row">
												<div class="label"></div>
												<div class="input-container"><a href="#" class="sendBtn"  onSubmit="buscaagendamento();" > Avançar</a></div>
												</div>
												
												<div  id='meusagendamentocadastrado'></div>
												
											
										
										</form>
								
								<a class="close-reveal-modal">&#215;</a>
								</div>