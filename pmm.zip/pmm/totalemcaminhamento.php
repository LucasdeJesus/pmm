	<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	
	
	
	
	?>
	
	
		
					<?
						
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			
			
						if($get_acao==""){$limit="limit 100";}else{$limit="";};
						
						if($post_status==""){$sqlostatus="`status` IN ('A','S','C','P','E','N','I','R','O')";}else{$sqlostatus=" status='$post_status'  ";}
						if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
						if($post_descricao==""){}else{$sqldescricao="and `descricao` LIKE '%$post_descricao%' ";}				
						if($post_escolaridade==""){}else{$sqloescolaridade="and escolaridade='$post_escolaridade' ";}
						if($post_sexo==""){}else{$sqlsexo="and sexo IN ('$post_sexo','A') ";}
						if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
						if($post_id==""){}else{$sqlid="and id='$post_id' ";}
						if($post_atendente==""){}else{$sqlatendente="and usuarioid='$post_atendente' ";}
						if($empresaid==""){}else{$sqlempresaid="and empresaid='$empresaid' ";}
						

						
						
						$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
						$post_datafinal1 = implode("-",array_reverse(explode("/",$post_datafinal)));
						
						
						if(($post_datainicio=="") || ($post_datafinal==""))
						{
							if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
							if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
							
						
						}
						else
						
						{
							$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1))); // 15/03/2006
								$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
						}
						
																		
													
						
										if($sql2data==""){
											$query_noticias = "SELECT *  FROM `vaga` where  
										".$sqlostatus."				
										".$sqlcargo."				
										".$sqldescricao."				
										".$sqloescolaridade."				
										".$sqlsexo."				
										".$sqlaceitasemexperiencia."				
										".$sqlid."				
										".$sqlempresaid."	
										".$sql2data."
										
										ORDER BY  `vaga`.`cargo` ASC ".$limit."";
										}else{
										
												$whileencamaninha ="";
												$query_noticiase1 = "SELECT * FROM `encaminhamento` WHERE ".$sqlostatus." ".$sql2data." ".$sqlatendente."";
												$rs_noticiase1    = mysql_query($query_noticiase1);									
												while($campo_noticiase1= mysql_fetch_array($rs_noticiase1)){
												
												$idvagaem	= $campo_noticiase1['vagaid'];
												$whileencamaninha.="'$idvagaem',"; 
												}
												
												$query_noticias = "SELECT *  FROM `vaga` where  
												".$sqlostatus."				
												".$sqlcargo."				
												".$sqldescricao."				
												".$sqloescolaridade."				
												".$sqlsexo."				
												".$sqlaceitasemexperiencia."				
												".$sqlid."				
												".$sqlempresaid."	
												and `id` IN ($whileencamaninha '0')
												ORDER BY  `vaga`.`cargo` ASC  ".$limit."";
												
												//echo $query_noticias;
											
										}
										
										
										

										$rs_noticias    = mysql_query($query_noticias);		
										
										
										//echo"$query_noticiase1";
										$iddasvagas ="";
										while($campo_noticias = mysql_fetch_array($rs_noticias)){	
										$id_vaga= $campo_noticias['id'];										
										$iddasvagas.="'$id_vaga',"; 									
										 }
										 $total=0;
										$query_noticiase1 = "SELECT * FROM `encaminhamento` WHERE ".$sqlostatus."  and `vagaid`IN ($iddasvagas '0') ".$sql2data." ".$sqlatendente." group by usuarioid ";
										$rs_noticiase1    = mysql_query($query_noticiase1);										
										
										$totalencaminhamento1 = mysql_num_rows($rs_noticiase1);
										while($campo_noticiase1= mysql_fetch_array($rs_noticiase1)){																			
										$usuarioid11	= $campo_noticiase1['usuarioid'];										
													
													$query_noticiasceu1 = "SELECT * FROM `usuario`  WHERE id='$usuarioid11' ";
													$rs_noticiasceu1    = mysql_query($query_noticiasceu1);
													while($campo_noticiasceu1 = mysql_fetch_array($rs_noticiasceu1)){	
													$usuarioa1	= $campo_noticiasceu1['usuario']; 												
													$nomeat	= $campo_noticiasceu1['nome']; 												

													}
													?>
													
													
												<div id="getexcel">	
													
													<table border="1" width="500px"  class="sortable">
													
														
														<tr width='50%'>
															<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
															<font color="#ffffff" face="Tahoma"><b>&nbsp;<?=$nomeat;?>&nbsp;</b></font>
														    </td>


												
												<?
												$numero=1;
													$query_noticiase = "SELECT * FROM `encaminhamento` WHERE  ".$sqlostatus."  and `vagaid`IN ($iddasvagas '0') ".$sql2data."  and usuarioid='$usuarioid11'";
													$rs_noticiase    = mysql_query($query_noticiase);										
													
													$totalencaminhamento = mysql_num_rows($rs_noticiase);
													
													$total +="$totalencaminhamento";	
													
													?>
													
				
														
														
														
																<td class='td2' width='50%'> <?=$totalencaminhamento;?> </td>	
																		
													
											
											</tr>
											</table>
	

							<? }?>
							
	

<table border="1" width="500px"  class="sortable">			
			<tr width='50%'>
				<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
				<font color="#ffffff" face="Tahoma"><b>&nbsp;Total&nbsp;</b></font>
				</td>

				<td class='td2' width='50%'> <?=$total;?> </td>
			</tr>
</table>	
							
																	
											
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
		  
		  <?
		  
		  
				$rs_noticias2    = mysql_query($query_noticias);					
				//echo"$query_noticiase1";
				$iddasvagas2 ="";
				while($campo_noticias2 = mysql_fetch_array($rs_noticias2)){	
				$id_vaga2= $campo_noticias2['id'];										
				$iddasvagas2.="'$id_vaga2',"; 									
				}
				$query_noticiase12 = "SELECT * FROM `encaminhamento` WHERE ".$sqlostatus."  and `vagaid`IN ($iddasvagas '0') ".$sql2data." ".$sqlatendente." group by usuarioid ";
				$rs_noticiase12    = mysql_query($query_noticiase12);										

				$totalencaminhamento12 = mysql_num_rows($rs_noticiase12);
				while($campo_noticiase12= mysql_fetch_array($rs_noticiase12)){																			
				$usuarioid112	= $campo_noticiase12['usuarioid'];										

				$query_noticiasceu12 = "SELECT * FROM `usuario`  WHERE id='$usuarioid112' ";
				$rs_noticiasceu12    = mysql_query($query_noticiasceu12);
				while($campo_noticiasceu12 = mysql_fetch_array($rs_noticiasceu12)){	
				$usuarioa12	= $campo_noticiasceu12['usuario']; 												
				$nomeat2	= $campo_noticiasceu12['nome']; 												

				}
				
				
				$query_noticiase2 = "SELECT * FROM `encaminhamento` WHERE  ".$sqlostatus."  and `vagaid`IN ($iddasvagas2 '0') ".$sql2data."  and usuarioid='$usuarioid112'";
				$rs_noticiase2    = mysql_query($query_noticiase2);										

				$totalencaminhamento2 = mysql_num_rows($rs_noticiase2);				
				
		 
		  ?>
          ['<?=$usuarioa12;?>', <?$pa= (($totalencaminhamento2 / $total) * 100);echo number_format($pa, 2); ?>],		
		<?}?>
        ]);

        var options = {
          title: 'Total de Encaminhamento',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>

    <div id="piechart_3d" style="width: 900px; height: 500px;"></div>
						
	</div>
