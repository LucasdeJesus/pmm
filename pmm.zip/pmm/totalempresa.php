	<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_GET ['exporta'];
	if($exporta=="excel")
	{
	$data= mktime();
    header("Content-type: application/vnd.ms-excel");
    header("Content-type: application/force-download");
    header("Content-Disposition: attachment; filename=lista_vaga".$data.".xls");
    header("Pragma: no-cache");
	}else{}
	

	
	
	?>

	
	<div id="getexcel">
	
	<table border="1" width="500px" class="sortable" align='left'>
	
	
		
					<?
						$busca_cnpj1 = $_GET['busca_cnpj1'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
			$numero=1;
			
						
				$query_totalempresa= "SELECT * FROM `empresa` ORDER BY `segmentoatuacaoid` ASC";	
				$rs_totalempresa     = mysql_query($query_totalempresa);
				$total = mysql_num_rows($rs_totalempresa);					
						
				$query_noticias_lista_vaga = "SELECT * FROM `segmentoatuacao` ORDER BY `segmentoatuacao`.`nome` ASC ";
				$rs_noticias_lista_vaga    = mysql_query($query_noticias_lista_vaga);							
				while($campo_noticias_lista_vaga = mysql_fetch_array($rs_noticias_lista_vaga)){
				$idseg  	= $campo_noticias_lista_vaga['id'];
				$nomeseg  	= $campo_noticias_lista_vaga['nome'];

				
		
				if($get_acao==""){
				$query_noticias = "SELECT *  FROM `empresa`  where segmentoatuacaoid='$idseg' ORDER BY `empresa`.`nome` DESC ";
				}
				else
				{
					//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
					if($post_status==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='$post_status'  ";}				
					if($post_segmentoatuacao==""){}else{$sqlsegmentoatuacao="and segmentoatuacaoid='$post_segmentoatuacao' ";}
					if($post_jovemaprendiz==""){}else{$sqljovemaprendiz="and jovemaprendiz='$post_jovemaprendiz'";}
					if($post_estagios==""){}else{$sqlestagios="and estagios='$post_estagios' ";}
					if($post_contapcd==""){}else{$sqlcontapcd="and contapcd='$post_contapcd' ";}
					
					
					$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
					$post_datafinal1 = implode("-",array_reverse(explode("/",$post_datafinal$post_datafinal1s = implode("-",array_reverse(explode("/",$post_datafinal)));
						$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1s))); // 15/03/2006
					
					if(($post_datainicio=="") || ($post_datafinal==""))
					{
						if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
						if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
						
					
					}
					else{
					$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
					}
					
					
					$query_noticias = "SELECT *  FROM `empresa` where
					".$sqlostatus."
					".$sql2data."
					".$sqlsegmentoatuacao."
					".$sqljovemaprendiz."
					".$sqlestagios."
					".$sqlcontapcd."
					 ORDER BY `empresa`.`nome` DESC ";
					
				}				
		
				$rs_noticias    = mysql_query($query_noticias); 
				$totalseg = mysql_num_rows($rs_noticias);			
		
		
			?>
	
				<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
				<td bgcolor="#000080" align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')" width='50%'>
				<font color="#ffffff" face="Tahoma"><b><?=$nomeseg;?></b></font>
				</td>

				<td  align="center" id="trCab8" class='td2'  width='50%'>
				<span color="#000" face="Tahoma"><b><?=$totalseg;?></b></span>
				</td>	

				<td  align="center" id="trCab8" class='td2'  width='50%'>
				<span color="#000" face="Tahoma"><b>
				<?
				$pa= (($totalseg / $total) * 100);
				echo number_format($pa, 2) ."%".""; 
				?>
				</b></span>
				</td>		

				</tr>			
				
	<?}?>
	
			<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
				<td bgcolor="#000080" align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')" width='50%'>
				<font color="#ffffff" face="Tahoma"><b>Total</b></font>
				</td>

				<td  align="center" id="trCab8" class='td2'  width='50%'>
				<span color="#000" face="Tahoma"><b><?=$total;?></b></span>
				</td>	

				<td  align="center" id="trCab8" class='td2'  width='50%'>
				<span color="#000" face="Tahoma"><b>
				
				</b></span>
				</td>		

				</tr>
	</table>
	
	
	
	
	 <table>
	 <tr>
	 <td>
	 
	 <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
		  
		  <?
		  $query_totalempresa= "SELECT * FROM `empresa` ORDER BY `segmentoatuacaoid` ASC";	
				$rs_totalempresa     = mysql_query($query_totalempresa);
				$total = mysql_num_rows($rs_totalempresa);					
						
				$query_noticias_lista_vaga = "SELECT * FROM `segmentoatuacao` ORDER BY `segmentoatuacao`.`nome` ASC ";
				$rs_noticias_lista_vaga    = mysql_query($query_noticias_lista_vaga);							
				while($campo_noticias_lista_vaga = mysql_fetch_array($rs_noticias_lista_vaga)){
				$idseg  	= $campo_noticias_lista_vaga['id'];
				$nomeseg  	= $campo_noticias_lista_vaga['nome'];

				
		
				if($get_acao==""){
				$query_noticias = "SELECT *  FROM `empresa`  where segmentoatuacaoid='$idseg' ORDER BY `empresa`.`nome` DESC ";
				}
				else
				{
					//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
					if($post_status==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='$post_status'  ";}				
					if($post_segmentoatuacao==""){}else{$sqlsegmentoatuacao="and segmentoatuacaoid='$post_segmentoatuacao' ";}
					if($post_jovemaprendiz==""){}else{$sqljovemaprendiz="and jovemaprendiz='$post_jovemaprendiz'";}
					if($post_estagios==""){}else{$sqlestagios="and estagios='$post_estagios' ";}
					if($post_contapcd==""){}else{$sqlcontapcd="and contapcd='$post_contapcd' ";}
					
					
					$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
					$post_datafinal1 = implode("-",array_reverse(explode("/",$post_datafinal)));
					
					if(($post_datainicio=="") || ($post_datafinal==""))
					{
						if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
						if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
						
					
					}
					else{
					$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
					}
					
					
					$query_noticias = "SELECT *  FROM `empresa` where
					".$sqlostatus."
					".$sql2data."
					".$sqlsegmentoatuacao."
					".$sqljovemaprendiz."
					".$sqlestagios."
					".$sqlcontapcd."
					 ORDER BY `empresa`.`nome` DESC ";
					
				}				
		
				$rs_noticias    = mysql_query($query_noticias); 
				$totalseg = mysql_num_rows($rs_noticias);			
		
		
		  ?>
          ['<?=$nomeseg;?>', <?$pa= (($totalseg / $total) * 100);echo number_format($pa, 2); ?>],		
		<?}?>
        ]);

        var options = {
          title: 'Total de Empresa',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>

    <div id="piechart_3d" style="width: 900px; height: 500px;"></div>
	</td>
	

	</tr>
		
	
	</table>
	</div>
	