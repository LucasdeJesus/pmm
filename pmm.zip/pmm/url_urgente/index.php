<?
$actual_link = $_SERVER['HTTP_REFERER'];
	if($actual_link=="http://sistemas.macae.rj.gov.br:84/catalogo/semtre/index/mural"){
	?>
	<SCRIPT language="JavaScript">
		//window.location='http://www.cetepmacae.rj.gov.br/semtre/interno/interno/muralexterno.php'
		window.location='http://institutocoimbra.com.br/semtre/interno/interno/muralexterno.php';
	</script><?
	}
	
?>


<iframe src="http://institutocoimbra.com.br/semtre/" style="position:fixed; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;">

