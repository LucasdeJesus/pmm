<script src="../js/sorttable.js"></script>
	<?
	$exporta= $_POST ['acao'];
	if($exporta=="post")
	{
	$arquivo = "relatorio.xls";
header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header ("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
header ("Cache-Control: no-cache, must-revalidate");
header ("Pragma: no-cache");
header ("Content-type: application/x-m---cel");
header ("Content-Disposition: attachment; filename=\"{$arquivo}\"" );
header ("Content-Description: PHP Generated Data" );
	?>
	
	<?
	}else{}
	

	
	?>
	
<script type="text/javascript"> 
	
	$(document).ready(function(){
	      $('#mostra').click(function(){
			//mostra div
		  	$('#divMostra').show();
		  		
	      });
	      $('#fecha').click(function(){
			//oculta div
		  	$('#divMostra').hide();
		  		
	      });
	 });
     
</script>
	

<style>

table.sortable thead {   
    font-weight: bold;
  cursor: pointer;
    cursor: hand;
}

#sorttable_sortrevind{
font-size:15px;
color:#fff;
}

#sorttable_sortfwdind{
font-size:15px;
color:#fff;
}
	


</style>
	<style>
	.text_azul{color:blue;}
	span{line-height:130%;}
	</style>
	
		<?
						
				
				//`datacadastro` BETWEEN '2014-09-30' AND '2014-10-01'
				if($post_status==""){$sqlostatus="status='A'";}else{$sqlostatus=" status='$post_status'  ";}
				if($post_ocupacao==""){}else{$sqlcargo="and `cargo` LIKE '%$post_ocupacao%' ";}
				if($post_descricao==""){}else{$sqldescricao="and `descricao` LIKE '%$post_descricao%' ";}				
				if($post_escolaridade==""){}else{$sqloescolaridade="and escolaridade='$post_escolaridade' ";}
				if($post_sexo==""){}else{$sqlsexo="and sexo IN ('$post_sexo','A') ";}
				if($post_semexperiencia==""){}else{$sqlaceitasemexperiencia="and aceitasemexperiencia='$post_semexperiencia'";}
				if($post_id==""){}else{$sqlid="and id='$post_id' ";}
				if($empresaid==""){}else{$sqlempresaid="and empresaid='$empresaid' ";}
				if($post_segmentoatuacao==""){}else{$sqlsegmentoatuacao="and segmentoatuacaoid='$post_segmentoatuacao' ";}
				
				if($_POST['acao']==""){$post_datainicio= date('d/m/Y');}else{};
				if($post_contapcd==""){}else{$sqlcontacpd="and `vagadeficiente` = '$post_contapcd' ";}	
				
				$post_datainicio1 = implode("-",array_reverse(explode("/",$post_datainicio)));
				$post_datafinal1 = implode("-",array_reverse(explode("/",$post_datafinal)));
						
				
				if(($post_datainicio=="") || ($post_datafinal==""))
				{
					if($post_datainicio==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datainicio1%' ";}
					if($post_datafinal1==""){}else{$sql2data="and `datacadastro` LIKE '%$post_datafinal1%' ";}
					
					if($post_datainicio==""){}else{$sql2datareabertas="and `dataupdate` LIKE '%$post_datainicio1%' ";}
					if($post_datafinal1==""){}else{$sql2datareabertas="and `dataupdate` LIKE '%$post_datafinal1%' ";}
					
				
				}
				else{
				$post_datafinal1 = date('Y-m-d', strtotime("+1 days",strtotime($post_datafinal1))); // 15/03/2006
				$sql2data= "and `datacadastro` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
				$sql2datareabertas= "and `dataupdate` BETWEEN '$post_datainicio1' AND '$post_datafinal1'";
				}
				
				if($post_status =="" ){$statusvaga="`status` IN ( 'A',  'S',  'C',  'P',  'E',  'R',  'N',  'O',  'I',  'T')";}else{$statusvaga="status='$post_status'";}
				
				
				
			$totalA = 0;
			$query_noticiasA = "SELECT *  FROM `vaga` where status='A' ".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."				
				".$sqlempresaid."
					".$sqlcontacpd."				
				".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_noticiasA    = mysql_query($query_noticiasA); 
			while($campo_ocupacaoA = mysql_fetch_array($rs_noticiasA)){
			$quantidadedisponivelA        = $campo_ocupacaoA ['quantidadedisponivel'];
			$totalA+="$quantidadedisponivelA";
			}
			
		
			$totalS =0;
			$query_noticiasS = "SELECT *  FROM `vaga` where status='S' ".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."				
				".$sqlempresaid."
				".$sqlcontacpd."
				".$sql2data." ORDER BY  `vaga`.`cargo` ASC ";
			$rs_noticiasS   = mysql_query($query_noticiasS); 
			while($campo_ocupacaoS = mysql_fetch_array($rs_noticiasS)){
			$quantidadedisponivelS        = $campo_ocupacaoS ['quantidadedisponivel'];
			$totalS+="$quantidadedisponivelS";
			}
			
			
			
			$totalP=0;
			$query_noticiasP = "SELECT *  FROM `vaga` where status='P'".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."				
				".$sqlempresaid."
				".$sqlcontacpd."
				".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_noticiasP   = mysql_query($query_noticiasP);
			while($campo_ocupacaoP = mysql_fetch_array($rs_noticiasP)){
			$quantidadedisponivelP        = $campo_ocupacaoP ['quantidadedisponivel'];
			$totalP+="$quantidadedisponivelP";
			}				
			 

			
			$totalO = 0;
			$query_noticiasO = "SELECT *  FROM `vaga` where status='O' ".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."				
				".$sqlempresaid."
				".$sqlcontacpd."				
				".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_noticiasO   = mysql_query($query_noticiasO);
			while($campo_ocupacaoO = mysql_fetch_array($rs_noticiasO)){
			$quantidadedisponivelO        = $campo_ocupacaoO ['quantidadedisponivel'];
			$totalO+="$quantidadedisponivelO";
			}				
			

			
			$totalC=0;
			$query_noticiasC = "SELECT *  FROM `vaga` where status='C' ".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."	
				".$sqlcontacpd."
				".$sqlempresaid."	
				".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_noticiasC   = mysql_query($query_noticiasC);			
			while($campo_ocupacaoC = mysql_fetch_array($rs_noticiasC)){
			$quantidadedisponivelC        = $campo_ocupacaoC ['quantidadedisponivel'];
			$totalC+="$quantidadedisponivelC";
			}	
			
	
			$totalE=0;
			$query_noticiasE = "SELECT *  FROM `vaga` where status='E' ".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."	
				".$sqlcontacpd."
				".$sqlempresaid."	
				".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_noticiasE  = mysql_query($query_noticiasE);
			while($campo_ocupacaoE = mysql_fetch_array($rs_noticiasE)){
			$quantidadedisponivelE        = $campo_ocupacaoE ['quantidadedisponivel'];
			$totalE+="$quantidadedisponivelE";
			}	
			

			$totalR=0;
			$query_noticiasR = "SELECT *  FROM `vaga` where status='R' ".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."
				".$sqlcontacpd."
				".$sqlempresaid."	
				".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_noticiasR  = mysql_query($query_noticiasR);
			while($campo_ocupacaoR = mysql_fetch_array($rs_noticiasR)){
			$quantidadedisponivelR        = $campo_ocupacaoR ['quantidadedisponivel'];
			$totalR+="$quantidadedisponivelR";
			}				
			

			
			$totalN=0;
			$query_noticiasN = "SELECT *  FROM `vaga` where status='N'".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."				
				".$sqlempresaid."	
				".$sqlcontacpd."
				".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_noticiasN  = mysql_query($query_noticiasN);
			while($campo_ocupacaoN  = mysql_fetch_array($rs_noticiasN)){
			$quantidadedisponivelN        = $campo_ocupacaoN ['quantidadedisponivel'];
			$totalN+="$quantidadedisponivelN";
			}			
			

			
			$totalG=0;
			$query_noticiasG = "SELECT *  FROM `vaga` where status='G' ".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."
				".$sqlcontacpd."				
				".$sqlempresaid."	
				".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_noticiasG  = mysql_query($query_noticiasG); 
			while($campo_ocupacaoG  = mysql_fetch_array($rs_noticiasG )){
			$quantidadedisponivelG        = $campo_ocupacaoG ['quantidadedisponivel'];
			$totalG+="$quantidadedisponivelG";
			}
			
			

			$totalI=0;
			$query_noticiasI = "SELECT *  FROM `vaga` where status='I' ".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."	
				".$sqlcontacpd."
				".$sqlempresaid."	
				".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_noticiasI  = mysql_query($query_noticiasI);
			while($campo_ocupacaoI  = mysql_fetch_array($rs_noticiasI )){
			$quantidadedisponivelI        = $campo_ocupacaoI ['quantidadedisponivel'];
			$totalI+="$quantidadedisponivelI";
			}
			
			
			
			
			
			$vagasdiponivel=0;
			$query_ocupacao = "SELECT *  FROM `vaga` where status='A' ".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."
				".$sqlcontacpd."				
				".$sqlempresaid."	
				".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_ocupacao     = mysql_query($query_ocupacao );
			while($campo_ocupacao  = mysql_fetch_array($rs_ocupacao )){
			$quantidadedisponivel        = $campo_ocupacao ['quantidadedisponivel'];
			$vagasdiponivel+="$quantidadedisponivel";
			}
		
		
		
			?>
		


<p style="margin:30px;"><a href="javascript: void(0);" id="mostra" class="myButton" >Exibir Detalhes</a>&nbsp;<a href="javascript: void(0);" id="fecha" class="myButton">Fechar</a> </p>
		
			
						<?
						$busca_cnpj1 = $_GET['busca'];
						$busca_nome = $_GET['busca_nome'];
						$campo= $_GET['campo'];
						$status_get= $_GET['status'];
						
						
			
			
					$query_noticiase = "SELECT *  FROM `vaga` where $statusvaga ".$sqlcargo."				
					".$sqldescricao."				
					".$sqloescolaridade."				
					".$sqlsexo."				
					".$sqlaceitasemexperiencia."				
					".$sqlid."				
					".$sqlempresaid."
					".$sqlcontacpd."
					".$sql2data."group by empresaid ORDER BY cargo ASC ";
					$rs_noticiase    = mysql_query($query_noticiase); 
					$totale = mysql_num_rows($rs_noticiase);	
						//echo $query_noticiase;
					while($campo_noticiase = mysql_fetch_array($rs_noticiase)){
					$empresaide= $campo_noticiase['empresaid']; 
								
					
						$sqle = "SELECT * FROM  `empresa` WHERE  `id` ='$empresaide'";
						$rsde = mysql_query($sqle);
						while($rse = mysql_fetch_array($rsde)) {
						$txnomede= $rse['nome'];
						$empresaidde = $rse['empresaid'];	
						$segmentoatuacaoid2 = $rse['segmentoatuacaoid'];	
						}						
						?>	
							
<div id="getexcel">
			<!--<div style="margin-top:20px;"><h2><?=$txnomede;?> - <?=$empresaide;?></h2></div>-->
					
					<div style="margin-top:20px;display: none;" id="divMostra">
					<table style='width:95%;' class="sortable">
						<tr <?if($post_segmentoatuacao > 0){if($segmentoatuacaoid2=="$post_segmentoatuacao"){}else{echo"style='display:none;'";}}?>>
							<td class='td1' >N°</td>
							<td class='td1' >ID</td>
							<td class='td1' >Empresa </td>
							<td class='td1' >Seg. Atuação </td>
							<td class='td1' >Ocupação </td>
							<td class='td1'>Qtd. </td>
							<td class='td1'>Encaminhados</td>
							<td class='td1'>Datas</td>
							<td class='td1'>Datas Aguar.</td>
							
							<td class='td1'>Status</td>
							
							
									
						</tr>
			
						<?		$numero=1;
								$total_quantidade=0;						
								$total_total_total_emca=0;						
								$total_quantidadedisponivel=0;						
								$query_noticias = "SELECT *  FROM `vaga` where $statusvaga and empresaid='$empresaide' ".$sqlcargo."				
								".$sqldescricao."				
								".$sqloescolaridade."				
								".$sqlsexo."				
								".$sqlaceitasemexperiencia."				
								".$sqlid."				
								".$sqlempresaid."
								".$sqlcontacpd."								
								".$sql2data."ORDER BY  `vaga`.`cargo` ASC ";
								$rs_noticias    = mysql_query($query_noticias); 
								$total = mysql_num_rows($rs_noticias);			
								while($campo_noticias = mysql_fetch_array($rs_noticias)){			
												$id= $campo_noticias['id']; 	 
												$empresaid= $campo_noticias['empresaid']; 	 
												$selvagasigilosa = $campo_noticias['selvagasigilosa'];								
												$cboid = $campo_noticias['cboid'];
												$descricao = $campo_noticias['descricao'];
												$cargo = $campo_noticias['cargo']; 
												$txvagadata = $campo_noticias['txvagadata'];
												$horariotrabalho = $campo_noticias['horariotrabalho'];
												$vagadeficiente = $campo_noticias['vagadeficiente'];
												$quantidadedisponivel = $campo_noticias['quantidadedisponivel'];
												$txvagapreenchidaCTM = $campo_noticias['txvagapreenchidaCTM']; 
												$txvagapreenchidaOutros = $campo_noticias['txvagapreenchidaOutros'];
												$txvagaCancelada = $campo_noticias['txvagaCancelada']; 
												$txvagasativas = $campo_noticias['txvagasativas']; 
												$quantidadeencaminhar = $campo_noticias['quantidadeencaminhar'];
												$datalimiteencaminhar = $campo_noticias['datalimiteencaminhar'];
												$chktemporaria = $campo_noticias['chktemporaria'];
												$ceplocal = $campo_noticias['ceplocal'];
												$txtestado_local = $campo_noticias['txtestado_local'];
												$cidadelocalid = $campo_noticias['cidadelocalid'];
												$bairrolocal = $campo_noticias['bairrolocal'];
												$enderecolocal = $campo_noticias['enderecolocal']; 
												$proximodelocal = $campo_noticias['proximodelocal']; 
												$onoffshore = $campo_noticias['onoffshore']; 
												$local = $campo_noticias['local'];
												$salario = $campo_noticias['salario'];
												$comissao = $campo_noticias['comissao'];
												$prospeccao = $campo_noticias['prospeccao'];
												$cartaoalimentacao = $campo_noticias['cartaoalimentacao']; 
												$alimentacaolocal = $campo_noticias['alimentacaolocal']; 
												$lanche = $campo_noticias['lanche'];
												$cestabasica = $campo_noticias['cestabasica']; 
												$planosaude = $campo_noticias['planosaude']; 
												$planoodonto = $campo_noticias['planoodonto'];
												$segurovida = $campo_noticias['segurovida'];
												$carteiraassinada = $campo_noticias['carteiraassinada']; 
												$valetransporte= $campo_noticias['valetransporte'];
												$premiacao = $campo_noticias['premiacao']; 
												$outrosbeneficios = $campo_noticias['outrosbeneficios'];
												$tempoano = $campo_noticias['tempoano']; 
												$tempomes = $campo_noticias['tempomes']; 
												$comprovada = $campo_noticias['comprovada'];
												$idademinima = $campo_noticias['idademinima']; 
												$idademaxima = $campo_noticias['idademaxima']; 
												$escolaridade = $campo_noticias['escolaridade'];
												$escolaridadesituacao = $campo_noticias['escolaridadesituacao'];
												$cnh= $campo_noticias['cnh']; 
												$sexo = $campo_noticias['sexo'];
												$estadocivil = $campo_noticias['estadocivil']; 
												$txvagafilhos = $campo_noticias['txvagafilhos'];
												$importanciatempo = $campo_noticias['importanciatempo']; 
												$importanciaidade = $campo_noticias['importanciaidade']; 
												$importanciaescolaridade = $campo_noticias['importanciaescolaridade']; 
												$importanciacnh = $campo_noticias['importanciacnh'];
												$importanciasexo = $campo_noticias['importanciasexo']; 
												$importanciaestadocivil = $campo_noticias['importanciaestadocivil'];
												$selvagafilhos_niv = $campo_noticias['selvagafilhos_niv'];
												$txvagaregiao = $campo_noticias['txvagaregiao'];
												$txvagahabilidades = $campo_noticias['txvagahabilidades']; 
												$txvagarestricoes = $campo_noticias['txvagarestricoes'];
												$importanciaestadocivil = $campo_noticias['importanciaestadocivil']; 
												$selvagaidiomas_niv = $campo_noticias['selvagaidiomas_niv'];
												$selvagainformatica_niv = $campo_noticias['selvagainformatica_niv'];
												$txtcep = $campo_noticias['txtcep'];
												$txtestado = $campo_noticias['txtestado'];
												$txtcidade = $campo_noticias['txtcidade'];
												$txtbairro = $campo_noticias['txtbairro'];
												$txtendereco = $campo_noticias['txtendereco']; 
												$txtproximode = $campo_noticias['txtproximode'];
												$txtfalarcom = $campo_noticias['txtfalarcom']; 
												$txtEmailEntrevista = $campo_noticias['txtEmailEntrevista']; 
												$horarioatendimento = $campo_noticias['horarioatendimento'];
												$viaencaminhamento = $campo_noticias['viaencaminhamento'];
												$observacao = $campo_noticias['observacao']; 
												$status = $campo_noticias['status']; 
												$formacaptacaoid = $campo_noticias['formacaptacaoid'];
												$localcaptacaoid = $campo_noticias['localcaptacaoid']; 
												$selpublicar = $campo_noticias['selpublicar']; 
												$dia = $campo_noticias['dia']; 
												$mes = $campo_noticias['mes']; 
												$ano = $campo_noticias['ano']; 
												
												 $softwareid1 = $campo_noticias['softwareid1']; 
												 $softwareid2 = $campo_noticias['softwareid2']; 
												 $softwareid3 = $campo_noticias['softwareid3'];
												 
												 $idiomaid1 = $campo_noticias['idiomaid1']; 
												 $leitura1 = $campo_noticias['leitura1']; 
												 $escrita1 = $campo_noticias['escrita1']; 
												 $conversacao1 = $campo_noticias['conversacao1']; 
												 
												  $idiomaid2 = $campo_noticias['idiomaid2']; 
												 $leitura2 = $campo_noticias['leitura2']; 
												 $escrita2 = $campo_noticias['escrita2']; 
												 $conversacao2 = $campo_noticias['conversacao2']; 
												 
												  $idiomaid3 = $campo_noticias['idiomaid3']; 
												 $leitura3 = $campo_noticias['leitura3']; 
												 $escrita3 = $campo_noticias['escrita3']; 
												 $conversacao3 = $campo_noticias['conversacao3']; 
												 $cadastrado_por = $campo_noticias['usuarioid']; 
												 $datacadastro = $campo_noticias['datacadastro']; 
												 $dataupdate = $campo_noticias['dataupdate']; 
												 $dataaguardamdo = $campo_noticias['dataaguardamdo']; 
												
					
			?>

			
			<?
					
					
												
												
						$sql = "SELECT * FROM `empresa` where id ='$empresaid'";
						$rsd = mysql_query($sql);
						while($rs = mysql_fetch_array($rsd)) {
						$txnomed = $rs['nome'];
						$empresaidd = $rs['empresaid'];	
						$segmentoatuacaoid = $rs['segmentoatuacaoid'];	
							}						
					?>
					
			<tr class='tr_tb' <?if($post_segmentoatuacao > 0){if($segmentoatuacaoid=="$post_segmentoatuacao"){}else{echo"style='display:none;'";}}?>>		
				<td class='td2' > <?=$numero++;?> </td>
				<td class='td2' > <?=$id ;?> </td>
					
					
							<?
							$query_seguimentoatuacao_db = "SELECT * FROM  `segmentoatuacao` where id='$segmentoatuacaoid' ";
							$rs_seguimentoatuacao_db    = mysql_query($query_seguimentoatuacao_db);
							while($campo_seguimentoatuacao_db = mysql_fetch_array($rs_seguimentoatuacao_db)){		
							$seguimento_id_db 	= $campo_seguimentoatuacao_db['id']; 
							$seguimento_nome_db 	= $campo_seguimentoatuacao_db['nome']; 
							}
							?>
													
				<td class='td2' >  <?=$txnomed;?></td>
				<td class='td2' >  <?=$seguimento_nome_db;?></td>
						<?
							
							
					$query_noticias_total_emca = "SELECT * FROM  encaminhamento  WHERE vagaid ='$id'";	
					$rs_noticias_total_emca    = mysql_query($query_noticias_total_emca); 
					$total_total_emca = mysql_num_rows($rs_noticias_total_emca);	
					
						?>
						
						
				<td class='td2' >  <?=$cargo;?></td>	

				<?$total_quantidade+=$quantidadeencaminhar?>
				<?$total_quantidadedisponivel+=$quantidadedisponivel?>
				<?$total_total_total_emca+=$total_total_emca?>
				<td class='td2' >  <?=$quantidadedisponivel;?></td>				
				<td class='td2' >  <?=$total_total_emca;?>/<?=$quantidadeencaminhar;?></td>				
				<td class='td2' >  <b>Cadastro:</b><? echo date("d-m-Y H:i:s", strtotime($datacadastro));?><?if($dataupdate=="0000-00-00 00:00:00"){}else{?><br><b>Atualizado:</b><?echo date("d-m-Y H:i:s", strtotime($dataupdate));}?></td>				
				<td class='td2' >  <?if($dataaguardamdo=="0000-00-00 00:00:00"){echo"- - ";}else{?><? if($dataaguardamdo==""){}else{echo date("d-m-Y H:i:s", strtotime($dataaguardamdo));}} ;?></td>				
							
				
						<?
						switch ($status){										
						case "A":											
						$status_N2 = "Ativa";
						break;case "S":											
						$status_N2 = "Suspensa";
						break;case "P":											
						$status_N2 = "Preenchida pelo CTM";
						break;case "O":											
						$status_N2 = "Preenchida pelo Solicitante";
						break;case "C":											
						$status_N2 = "Cancelada";
						break;case "E":											
						$status_N2 = "Encerrada";
						break;case "R":											
						$status_N2 = "Aguardando Resposta";
						break;case "N":											
						$status_N2 = "Sem retorno ";						
						break;case "G":											
						$status_N2 = "Sigilosa";
						break;
						;case "T":											
						$status_N2 = "Sem Retorno";
						break;
						}
					?>
					
				<td class='td2' >  <?=$status_N2;?></td>				
				
			</tr>
			<?}?>	
			<tr class='tr_tb' style="background-color:#ADFF2F;<?if($post_segmentoatuacao > 0){if($segmentoatuacaoid=="$post_segmentoatuacao"){}else{echo"display:none;";}}?>" >		
				<td class='td2' ></td>
				<td class='td2' ></td>
				<td class='td2' >TOTAL</td>
				<td class='td2' ></td>
				<td class='td2' ></td>
				<td class='td2' ><?=$total_quantidadedisponivel;?></td>
				<td class='td2' ><?=$total_total_total_emca;?>/<?=$total_quantidade;?></td>
				<td class='td2' ></td>
				<td class='td2' ></td>
				<td class='td2' ></td>
		</tr>		
		<?}?>	
		
	</table>
	</div>
	
	
		
		
		
		
		


		
<table border="1" width="500px" class="sortable" align='left'>
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		
		
<td bgcolor="#000080" align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')" width='50%'>
			<font color="#ffffff" face="Tahoma"><b>Disponivel Ativa</b></font>
		</td>
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b><?=$vagasdiponivel;?></b></span>
		</td>	
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
			100%
			</b></span>
		</td>		
		
	</tr>

	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		
		
<td bgcolor="#000080" align="center" id="trCab8" onMouseOver="MouseSobreCab('8')" onMouseOut="MouseSaiCab('8')" onClick="SelecionaCab('8')" width='50%'>
			<font color="#ffffff" face="Tahoma"><b>Ativa</b></font>
		</td>
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b><?=$totalA;?></b></span>
		</td>	
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
			<?
			$pa= (($totalA / $total) * 100);
			echo number_format($pa, 2) ."%".""; 
			?>
			</b></span>
		</td>		
		
	</tr>
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		<td bgcolor="#000080" align="center" id="trCab1" onMouseOver="MouseSobreCab('1')" onMouseOut="MouseSaiCab('1')" onClick="SelecionaCab('1')">
			<font color="#ffffff" face="Tahoma"><b>Suspensa</b></font>
		</td>
		
		<!--fim td descrição-->
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$totalS;?></b></span>
		</td>
		
			<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
						<?
			$pas= (($totalS / $total) * 100);
			echo number_format($pas, 2) ."%".""; 
			?>
			</b></span>
		</td>	
	</tr>	
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		<td bgcolor="#000080" align="center" id="trCab2" onMouseOver="MouseSobreCab('2')" onMouseOut="MouseSaiCab('2')" onClick="SelecionaCab('2')">
			<font color="#ffffff" face="Tahoma"><b>Preenchida pelo CTM</b></font>
		</td>
			<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$totalP;?></b></span>
		</td>
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
				<?
			$pp= (($totalP / $total) * 100);
			echo number_format($pp, 2) ."%".""; 
			?>
			</b></span>
		</td>	
	</tr>
	
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >		
		<td bgcolor="#000080" align="center" id="trCab3" onMouseOver="MouseSobreCab('3')" onMouseOut="MouseSaiCab('3')" onClick="SelecionaCab('3')">
			<font color="#ffffff" face="Tahoma"><b>Preenchida pelo Solicitante</b></font>
		</td>
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$totalO;?></b></span>
		</td>
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
<?
			$po= (($totalO / $total) * 100);
			echo number_format($po, 2) ."%".""; 
			?>
			</b></span>
		</td>	
		
	</tr>
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		
		<td bgcolor="#000080" align="center" id="trCab5" onMouseOver="MouseSobreCab('5')" onMouseOut="MouseSaiCab('5')" onClick="SelecionaCab('5')">
			<font color="#ffffff" face="Tahoma"><b>Cancelada</b></font>
		</td>
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$totalC;?></b></span>
		</td>
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
			<?
			$pc= (($totalC / $total) * 100);
			echo number_format($pc, 2) ."%".""; 
			?>
			</b></span>
		</td>	
		
		
	</tr>
	
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	

		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>Encerrada</b></font>
		</td>
		
		
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$totalE;?></b></span>
		</td>
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
			<?
			$pe= (($totalE / $total) * 100);
			echo number_format($pe, 2) ."%".""; 
			?>
			</b></span>
		</td>	
	</tr>
	
	
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>Aguardando Resposta</b></font>
		</td>
		
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$totalR;?></b></span>
		</td>
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
			<?
			$pr= (($totalR / $total) * 100);
			echo number_format($pr, 2) ."%".""; 
			?>
			</b></span>
		</td>
	
	</tr>
	
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>Sem retorno </b></font>
		</td>
		
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$totalN;?></b></span>
		</td>
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
			<?
			$pn= (($totalN / $total) * 100);
			echo number_format($pn, 2) ."%".""; 
			?>
			</b></span>
		</td>
	</tr>
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>Sigilosa</b></font>
		</td>
		
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$totalG;?></b></span>
		</td>
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
			<?
			$pg= (($totalG / $total) * 100);
			echo number_format($pg, 2) ."%".""; 
			?>
			</b></span>
		</td>
	</tr>
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>Em análise</b></font>
		</td>
		
		
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$totalI;?></b></span>
		</td>
		
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
			<?
			$pi= (($totalI / $total) * 100);
			echo number_format($pi, 2) ."%".""; 
			?>
			</b></span>
		</td>
	

	</tr>
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>Total</b></font>
		</td>
		
		<?$total = $totalI+$totalG+$totalN+$totalR+$totalE+$totalC+$totalO+$totalP+$totalS+$vagasdiponivel;?>
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$total;?></b></span>
		</td>
		
			
		<td  align="center" id="trCab8" class='td2'  width='50%'>
			<span color="#000" face="Tahoma"><b>
			<?echo(($total / $total) * 100) . "%" . "";?>
			</b></span>
		</td>
	

	</tr>
		
	
	</table>
	
	
	
	<!--
		
<table border="1" width="500px" class="sortable" align='left'>
	
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>Abertas</b></font>
		</td>
		
		
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$total;?></b></span>
		</td>
		
			
		

	</tr>
	
	<?
	
			/*$vagasreabertas=0;
			$query_ocupacao_reabertas = "SELECT *  FROM `vaga` where $statusvaga ".$sqlcargo."				
				".$sqldescricao."				
				".$sqloescolaridade."				
				".$sqlsexo."				
				".$sqlaceitasemexperiencia."				
				".$sqlid."
				".$sqlcontacpd."				
				".$sqlempresaid."	
				".$sql2datareabertas."ORDER BY  `vaga`.`cargo` ASC ";
			$rs_ocupacao_reabertas     = mysql_query($query_ocupacao_reabertas );
			while($campo_ocupacao_reabertas  = mysql_fetch_array($rs_ocupacao_reabertas )){
			$quantidadedisponivel_reabertas        = $campo_ocupacao_reabertas ['quantidadedisponivel'];
			$vagasreabertas+="$quantidadedisponivel_reabertas";
			}
		
			echo $query_ocupacao_reabertas;
			*/
	?>
	
	<tr   class='tr_tb'   onclick="javascript:atualizaForm('<?=$id;?>'); window.close();"  >	
		<td bgcolor="#000080" align="center" id="trCab6" onMouseOver="MouseSobreCab('6')" onMouseOut="MouseSaiCab('6')" onClick="SelecionaCab('6')">
			<font color="#ffffff" face="Tahoma"><b>Reabertas</b></font>
		</td>
		
		
		<td  align="center" class='td2' id="trCab3" >
			<span color="#000" face="Tahoma"><b><?=$vagasreabertas;?></b></span>
		</td>
		
	

	</tr>
		
	
</table>-->
	
	<!--
	 <div><img src="http://chart.apis.google.com/chart?cht=p&chd=t:
	 <?echo number_format($pa, 2);?>,
	 <?echo number_format($pas, 2);?>,
	 <?echo number_format($pp, 2);?>,
	 <?echo number_format($po, 2);?>,
	 <?echo number_format($pc, 2);?>,
	 <?echo number_format($pe, 2);?>,
	 <?echo number_format($pr, 2);?>,
	 <?echo number_format($pn, 2);?>,
	 <?echo number_format($pg, 2);?>,
	 <?echo number_format($pi, 2);?>	 
	 &chs=900x450&chl=
	 <?echo number_format($pa, 2) ."%";?>| 
	 <?echo number_format($pas, 2) ."%";?>| 
	 <?echo number_format($pp, 2) ."%";?>| 
	 <?echo number_format($po, 2) ."%";?>| 
	 <?echo number_format($pc, 2) ."%";?>| 
	 <?echo number_format($pe, 2) ."%";?>| 
	 <?echo number_format($pr, 2) ."%";?>| 
	 <?echo number_format($pn, 2) ."%";?>| 
	 <?echo number_format($pg, 2) ."%";?>| 
	 <?echo number_format($pi, 2) ."%";?>	 
	 &chdl=Ativa|Suspensa|Preenchida pelo CTM|Preenchida pelo Solicitante|Cancelada|Encerrada|Aguardando Resposta|Sem retorno |Sigilosa|Em analise" /></div>-->
	 
	 <table>
	 <tr>
	 <td>
	 
	 <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Ativa', <?echo number_format($pa, 2);?>],
		['Suspensa' ,<?echo number_format($pas, 2);?>],
		['Preenchida pelo CTM' ,<?echo number_format($pp, 2);?>],
		['Preenchida pelo Solicitante' ,<?echo number_format($po, 2);?>],
		['Cancelada' ,<?echo number_format($pc, 2);?>],
		['Encerrada' ,<?echo number_format($pe, 2);?>],
		['Aguardando Resposta' ,<?echo number_format($pr, 2);?>],
		['Sem retorno ' ,<?echo number_format($pn, 2);?>],
		['Sigilosa' ,<?echo number_format($pg, 2);?>],
		['Em analise',<?echo number_format($pi, 2);?>]
        ]);

        var options = {
          title: 'Total de Vagas',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>

    <div id="piechart_3d" style="width: 900px; height: 500px;"></div>
	</td>
	

	</tr>
		
	
	</table>
	
	</div>