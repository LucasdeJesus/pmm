<?php
include"interno/input_banco.php";
    $login = $_POST['txCNPJ'];   
    $senha = $_POST['senha'];
	
    
                     
            $verifica = mysql_query("SELECT * FROM usuario WHERE usuario = '$login' AND senha = '$senha'") or die("erro ao selecionar");
                if (mysql_num_rows($verifica)<=0){
                    echo"<script language='javascript' type='text/javascript'>window.location.href='login.php?msg=Login e/ou senha incorretos';</script>";
                    die();
                }else{
                    setcookie("usuario",$login);
                    header("Location:area_empresa.php");
                }
       
?>