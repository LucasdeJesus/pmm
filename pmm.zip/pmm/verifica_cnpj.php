<?include("seguranca.php"); // Inclui o arquivo com o sistema de segurança
protegePagina(); // Chama a função que protege a página
error_reporting(0);


	$cnpj = $_GET['cnpj'];
	
	if($cnpj==""){}else{

		$query_noticiasdcemede = "SELECT * FROM `empresa` WHERE `txCNPJ` LIKE '%$cnpj%' ";
		$rs_noticiasdcemede    = mysql_query($query_noticiasdcemede);
		$total_encontrado = mysql_num_rows($rs_noticiasdcemede);
		
		if($total_encontrado =="")
		{echo"";}
		else
		//{echo"<font style='color:red'><h4>CNPJ já cadastrado</h4></font> <script>window.alert('sometext');</script>";}
		{echo "$total_encontrado";}
		
	}
	
?>